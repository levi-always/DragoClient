# Drago Client v3.6 (Minecraft 1.21.11 Fabric — Vape V4 Pure Black Edition)

Complete pre-build Fabric Gradle source project and AI Studio source bundle for **Drago Client v3.6**.

## What's Fixed & Updated in Drago v3.6
- **Full Crash Fixes**: Resolved `NoSuchMethodError` in `ViperClient.onRenderFrame` (`MaceSwap.pollRenderFrame`) and descriptor mismatches (`class_746` -> `class_1657`) in `TriggerBot`, `SilentAura`, and `AutoHitCrystal`; verified all 129 classes and Mixins for MC 1.21.11 (including Pojav/Android ARM64 Mali-G57 + Sodium).
- **Drago Rebrand**: Updated Mod ID (`drago`), Mod Name (`Drago Client`), Watermark (`DRAGO v3.6`), ClickGUI & HUD Editor branding, `drago.mixins.json`, `assets/drago/*`, and `drago-config.properties`.
- **Vape V4 Pure Black ClickGUI**: Panels, sidebars, settings drawers, dropdowns, and tracks always stay pure black (`#0B0B0D`–`#16161C`).
- **5 Accent Themes Only**: `White` (Default), `Orange`, `Blue`, `Yellow`, and `Cyan` — changing themes only recolors active module buttons, toggle pills, and slider fills with automatic contrast text.
- **Zero-Miss TriggerBot**: Crosshair + hitbox raycast fallback with `120ms` edge grace window, zero random reaction jitter, and `Only Criticals` falling gate.
- **Very Smooth AimAssist + On Hit**: Sub-tick `renderTickDelta` entity/camera interpolation, zero random walk/velocity noise, and `On Hit` snap-on-attack option.
- **AutoHitCrystal Obsidian → Crystal → Break**: Triggers cleanly from End Crystal or Obsidian (`!onKey`) or keybind (`On Key`), boosted aim convergence, and `LivingEntity`-only blocking filter.
- **Removed D-Tap & Pearl Catch**: Completely stripped from modules, mixins, render hooks, and UI.
