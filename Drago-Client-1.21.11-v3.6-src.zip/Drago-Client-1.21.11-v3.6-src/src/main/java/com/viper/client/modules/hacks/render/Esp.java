package com.viper.client.modules.hacks.render;

public final class Esp extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.ModeSetting targetFilter;
    private final com.viper.client.modules.Setting.BooleanSetting boxElement;
    private final com.viper.client.modules.Setting.BooleanSetting nameElement;
    private final com.viper.client.modules.Setting.BooleanSetting healthElement;
    private final com.viper.client.modules.Setting.BooleanSetting distanceElement;
    private final com.viper.client.modules.Setting.BooleanSetting armorElement;
    private final com.viper.client.modules.Setting.BooleanSetting heldItemElement;
    private final com.viper.client.modules.Setting.BooleanSetting pingElement;
    private final com.viper.client.modules.Setting.BooleanSetting entityTypeElement;
    private final com.viper.client.modules.Setting.BooleanSetting skeletonElement;
    private final com.viper.client.modules.Setting.BooleanSetting facingDirElement;
    private final com.viper.client.modules.Setting.ColorSetting boxColor;
    private final com.viper.client.modules.Setting.NumberSetting thickness;
    private final com.viper.client.modules.Setting.NumberSetting opacity;

    public Esp() {
        super("esp", "ESP", "Ten-element 3D entity boxes, health, and skeleton.", com.viper.client.modules.Category.RENDER, "esp", -1);
        new java.lang.String[3][0] = "Players";
        new java.lang.String[3][1] = "Mobs";
        new java.lang.String[3][2] = "All";
        this.targetFilter = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("target", "Target", "Entities rendered by ESP", "Players", new java.lang.String[3])));
        this.boxElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("box", "Box", "Render 2D projected bounding box", 1)));
        this.nameElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("name", "Name", "Render entity name above bounding box", 1)));
        this.healthElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("health", "Health", "Render dynamic vertical health bar & HP", 1)));
        this.distanceElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("distance", "Distance", "Render distance in meters", 1)));
        this.armorElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("armor", "Armor", "Render armor bar on right side of box", 1)));
        this.heldItemElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("held_item", "Held Item", "Render main-hand item below box", 1)));
        this.pingElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("ping", "Ping", "Render player network latency in ms", 1)));
        this.entityTypeElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("entity_type", "Entity Type", "Render entity classification tag", 0)));
        this.skeletonElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("skeleton", "Skeleton", "Render 3D bone structure lines", 0)));
        this.facingDirElement = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("facing_direction", "Facing Direction", "Render 3D look-direction vector from eyes", 0)));
        this.boxColor = ((com.viper.client.modules.Setting.ColorSetting) this.registerSetting(new com.viper.client.modules.Setting.ColorSetting("color", "Color", "Primary ESP accent color", 15680580)));
        this.thickness = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("thickness", "Thickness", "ESP box & skeleton stroke width", 1.2, 0.5, 3.5, 0.1, "px")));
        this.opacity = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("opacity", "Opacity", "ESP overall opacity", 90.0, 15.0, 100.0, 5.0, "%")));
        return;
    }

    public void onRenderOverlay(net.minecraft.class_332 arg0, float arg1) {
        v3 = net.minecraft.class_310.method_1551();
        // if (v3 == null) -> offset 29
        // if (v3.field_1724 == null) -> offset 29
        // if (v3.field_1687 == null) -> offset 29
        // if (v3.field_1772 != null) -> offset 30
        return;
        v4 = com.viper.client.utils.WorldProjectionUtils.captureCameraFrame(arg0, com.viper.client.modules.hacks.render.Zoom.getActiveDivisorSnapshot());
        // if (v4 != null) -> offset 45
        return;
        v5 = v3.field_1772;
        v6 = (this.opacity.floatValue() / 100.0f);
        v7 = this.thickness.floatValue();
        v8 = this.boxColor.getArgb(v6);
        v9 = v3.field_1687.method_18112().iterator();
        // if (v9.hasNext() == 0) -> offset 1351
        v10 = ((net.minecraft.class_1297) v9.next());
        // if (com.viper.client.utils.TargetUtils.matchesTargetFilter(v10, v3.field_1724, ((java.lang.String) this.targetFilter.getValue())) != 0) -> offset 144
        // if ((v10 instanceof net.minecraft.class_1309) == 0) -> offset 97
        v11 = ((net.minecraft.class_1309) v10);
        v12 = (v10.field_6014 + ((v10.method_23317() - v10.field_6014) * (double)arg1));
        v14 = (v10.field_6036 + ((v10.method_23318() - v10.field_6036) * (double)arg1));
        v16 = (v10.field_5969 + ((v10.method_23321() - v10.field_5969) * (double)arg1));
        v18 = v10.method_5829();
        v19 = ((v18.field_1320 - v18.field_1323) * 0.5);
        v21 = (v18.field_1325 - v18.field_1322);
        v23 = new net.minecraft.class_238((v12 - v19), v14, (v16 - v19), (v12 + v19), (v14 + v21), (v16 + v19));
        // if (((java.lang.Boolean) this.skeletonElement.getValue()).booleanValue() == 0) -> offset 348
        this.renderSkeleton(arg0, v4, v12, v14, v16, v21, v11.field_6283, v7, com.viper.client.utils.AnimUtils.withAlpha(-723723, (v6 * 0.8799999952316284f)));
        // if (((java.lang.Boolean) this.facingDirElement.getValue()).booleanValue() == 0) -> offset 446
        v24 = v10.method_5828(arg1);
        v25 = (v14 + (double)v10.method_18381(v10.method_18376()));
        com.viper.client.utils.WorldProjectionUtils.drawWorldLine(arg0, v4, v12, v25, v16, (v12 + (v24.field_1352 * 1.65)), (v25 + (v24.field_1351 * 1.65)), (v16 + (v24.field_1350 * 1.65)), v7, com.viper.client.utils.AnimUtils.withAlpha(-340971, v6));
        v24 = com.viper.client.utils.WorldProjectionUtils.projectBox2DBounds(v4, v23);
        // if (v24.visible() != 0) -> offset 466
        v25 = Math.round(v24.minX());
        v26 = Math.round(v24.minY());
        v27 = Math.round(v24.maxX());
        v28 = Math.round(v24.maxY());
        v29 = Math.max(4, (v27 - v25));
        v30 = Math.max(6, (v28 - v26));
        // if (((java.lang.Boolean) this.boxElement.getValue()).booleanValue() == 0) -> offset 715
        v31 = com.viper.client.utils.AnimUtils.withAlpha(-1442840576, v6);
        arg0.method_25294((v25 - 1), (v26 - 1), (v27 + 1), (v26 + 1), v31);
        arg0.method_25294((v25 - 1), (v28 - 1), (v27 + 1), (v28 + 1), v31);
        arg0.method_25294((v25 - 1), v26, (v25 + 1), v28, v31);
        arg0.method_25294((v27 - 1), v26, (v27 + 1), v28, v31);
        com.viper.client.utils.AtlasRenderer.drawThinLine(arg0, (float)v25, (float)v26, (float)v27, (float)v26, v7, v8);
        com.viper.client.utils.AtlasRenderer.drawThinLine(arg0, (float)v27, (float)v26, (float)v27, (float)v28, v7, v8);
        com.viper.client.utils.AtlasRenderer.drawThinLine(arg0, (float)v27, (float)v28, (float)v25, (float)v28, v7, v8);
        com.viper.client.utils.AtlasRenderer.drawThinLine(arg0, (float)v25, (float)v28, (float)v25, (float)v26, v7, v8);
        // if (((java.lang.Boolean) this.healthElement.getValue()).booleanValue() == 0) -> offset 851
        v31 = Math.max(1.0f, v11.method_6063());
        v32 = Math.max(0.0f, (v11.method_6032() + v11.method_6067()));
        v33 = com.viper.client.utils.AnimUtils.clamp01((v32 / v31));
        v34 = com.viper.client.utils.AnimUtils.lerpColor(-1096636, -14498466, v33);
        v35 = (v25 - 4);
        arg0.method_25294((v35 - 1), v26, (v35 + 2), v28, com.viper.client.utils.AnimUtils.withAlpha(-1442248437, v6));
        v36 = Math.max(1, Math.round(((float)v30 * v33)));
        arg0.method_25294(v35, (v28 - v36), (v35 + 1), v28, com.viper.client.utils.AnimUtils.withAlpha(v34, v6));
        // if (((java.lang.Boolean) this.armorElement.getValue()).booleanValue() == 0) -> offset 961
        v31 = v11.method_6096();
        // if (v31 <= 0) -> offset 961
        v32 = com.viper.client.utils.AnimUtils.clamp01(((float)v31 / 20.0f));
        v33 = (v27 + 3);
        arg0.method_25294((v33 - 1), v26, (v33 + 2), v28, com.viper.client.utils.AnimUtils.withAlpha(-1442248437, v6));
        v34 = Math.max(1, Math.round(((float)v30 * v32)));
        arg0.method_25294(v33, (v28 - v34), (v33 + 1), v28, com.viper.client.utils.AnimUtils.withAlpha(-13058568, v6));
        v31 = new StringBuilder();
        // if (((java.lang.Boolean) this.entityTypeElement.getValue()).booleanValue() == 0) -> offset 1035
        // if ((v10 instanceof net.minecraft.class_1657) == 0) -> offset 1000
        v32 = v10.method_5864().method_5897().getString();
        v31.append("[").append(v32).append("] ");
        // if (((java.lang.Boolean) this.nameElement.getValue()).booleanValue() == 0) -> offset 1067
        v31.append(v10.method_5477().getString());
        // if (((java.lang.Boolean) this.pingElement.getValue()).booleanValue() == 0) -> offset 1166
        // if ((v10 instanceof net.minecraft.class_1657) == 0) -> offset 1166
        v32 = ((net.minecraft.class_1657) v10);
        // if (v3.method_1562() == null) -> offset 1166
        v33 = v3.method_1562().method_2871(v32.method_5667());
        // if (v33 == null) -> offset 1132
        v34 = 0;
        // if (v31.isEmpty() != 0) -> offset 1152
        v31.append(" ");
        v31.append(v34).append("ms");
        // if (((java.lang.Boolean) this.distanceElement.getValue()).booleanValue() == 0) -> offset 1238
        v32 = (double)v3.field_1724.method_5739(v10);
        // if (v31.isEmpty() != 0) -> offset 1211
        v31.append(" ");
        new java.lang.Object[1][0] = Double.valueOf(v32);
        v31.append(String.format(java.util.Locale.US, "%.1fm", new java.lang.Object[1]));
        // if (v31.isEmpty() != 0) -> offset 1273
        this.drawCompactTag(arg0, v5, v31.toString(), Math.round(v24.centerX()), (v26 - 11), v6);
        // if (((java.lang.Boolean) this.heldItemElement.getValue()).booleanValue() == 0) -> offset 1348
        v32 = v11.method_6047();
        // if (v32 == null) -> offset 1348
        // if (v32.method_7960() != 0) -> offset 1348
        v33 = v32.method_7964().getString();
        this.drawCompactTag(arg0, v5, v33, Math.round(v24.centerX()), (v28 + 3), (v6 * 0.9200000166893005f));
        return;
    }

    private void renderSkeleton(net.minecraft.class_332 arg0, com.viper.client.utils.WorldProjectionUtils.CameraFrame arg1, double arg2, double arg3, double arg4, double arg5, float arg6, float arg7, int arg8) {
        v14 = Math.toRadians((double)arg6);
        v16 = Math.cos(v14);
        v18 = Math.sin(v14);
        v20 = (arg3 + (arg5 * 0.42));
        v22 = (arg3 + (arg5 * 0.76));
        v24 = (arg3 + (arg5 * 0.93));
        com.viper.client.utils.WorldProjectionUtils.drawWorldLine(arg0, arg1, arg2, v20, arg4, arg2, v22, arg4, arg7, arg8);
        com.viper.client.utils.WorldProjectionUtils.drawWorldLine(arg0, arg1, arg2, v22, arg4, arg2, v24, arg4, arg7, arg8);
        v26 = 0.26;
        com.viper.client.utils.WorldProjectionUtils.drawWorldLine(arg0, arg1, (arg2 - (v16 * v26)), v22, (arg4 - (v18 * v26)), (arg2 + (v16 * v26)), v22, (arg4 + (v18 * v26)), arg7, arg8);
        com.viper.client.utils.WorldProjectionUtils.drawWorldLine(arg0, arg1, (arg2 - (v16 * v26)), v22, (arg4 - (v18 * v26)), (arg2 - (v16 * v26)), (arg3 + (arg5 * 0.38)), (arg4 - (v18 * v26)), arg7, arg8);
        com.viper.client.utils.WorldProjectionUtils.drawWorldLine(arg0, arg1, (arg2 + (v16 * v26)), v22, (arg4 + (v18 * v26)), (arg2 + (v16 * v26)), (arg3 + (arg5 * 0.38)), (arg4 + (v18 * v26)), arg7, arg8);
        v28 = 0.14;
        com.viper.client.utils.WorldProjectionUtils.drawWorldLine(arg0, arg1, (arg2 - (v16 * v28)), v20, (arg4 - (v18 * v28)), (arg2 + (v16 * v28)), v20, (arg4 + (v18 * v28)), arg7, arg8);
        com.viper.client.utils.WorldProjectionUtils.drawWorldLine(arg0, arg1, (arg2 - (v16 * v28)), v20, (arg4 - (v18 * v28)), (arg2 - (v16 * v28)), (arg3 + 0.04), (arg4 - (v18 * v28)), arg7, arg8);
        com.viper.client.utils.WorldProjectionUtils.drawWorldLine(arg0, arg1, (arg2 + (v16 * v28)), v20, (arg4 + (v18 * v28)), (arg2 + (v16 * v28)), (arg3 + 0.04), (arg4 + (v18 * v28)), arg7, arg8);
        return;
    }

    private void drawCompactTag(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, String arg2, int arg3, int arg4, float arg5) {
        arg0.method_51448().pushMatrix();
        arg0.method_51448().translate((float)arg3, (float)arg4);
        arg0.method_51448().scale(0.7799999713897705f, 0.7799999713897705f);
        v7 = arg1.method_1727(arg2);
        v8 = (((-v7) / 2) - 3);
        arg0.method_25294(v8, -2, ((v8 + v7) + 6), 10, com.viper.client.utils.AnimUtils.withAlpha(-1207367413, arg5));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, arg2, ((-v7) / 2), 0, com.viper.client.utils.AnimUtils.withAlpha(-723723, arg5), 0);
        arg0.method_51448().popMatrix();
        return;
    }

    public String getHudMetadata() {
        return ((java.lang.String) this.targetFilter.getValue());
    }

}
