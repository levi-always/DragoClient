package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_743.class})
public abstract class KeyboardInputMixin extends net.minecraft.class_744 {
    public KeyboardInputMixin() {
        super();
        return;
    }

    @Inject(method = {"method_3129"}, at = {@At("TAIL")})
    private void viper$processInput(org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg0) {
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 26
        // if (v2.field_1724 == null) -> offset 26
        // if (this == v2.field_1724.field_3913) -> offset 27
        return;
        v3 = com.viper.client.ViperClient.getInstance();
        // if (v3 == null) -> offset 342
        // if (v2.field_1690 == null) -> offset 342
        // if (v2.method_22683() == null) -> offset 342
        v4 = ((com.viper.client.modules.hacks.inventory.InvMove) v3.getModuleManager().getModule(com.viper.client.modules.hacks.inventory.InvMove.class));
        // if (v4 == null) -> offset 342
        // if (v4.shouldPollGuiMovement(v2) == 0) -> offset 342
        v5 = v2.method_22683().method_4490();
        v7 = com.viper.client.modules.hacks.inventory.InvMove.isPhysicalBindingDown(v5, v2.field_1690.field_1894);
        v8 = com.viper.client.modules.hacks.inventory.InvMove.isPhysicalBindingDown(v5, v2.field_1690.field_1881);
        v9 = com.viper.client.modules.hacks.inventory.InvMove.isPhysicalBindingDown(v5, v2.field_1690.field_1913);
        v10 = com.viper.client.modules.hacks.inventory.InvMove.isPhysicalBindingDown(v5, v2.field_1690.field_1849);
        // if (v4.isAllowJump() == 0) -> offset 169
        // if (com.viper.client.modules.hacks.inventory.InvMove.isPhysicalBindingDown(v5, v2.field_1690.field_1903) == 0) -> offset 169
        v11 = 0;
        // if (v4.isAllowSneak() == 0) -> offset 199
        // if (com.viper.client.modules.hacks.inventory.InvMove.isPhysicalBindingDown(v5, v2.field_1690.field_1832) == 0) -> offset 199
        v12 = 0;
        // if (v4.isAllowSprint() == 0) -> offset 229
        // if (com.viper.client.modules.hacks.inventory.InvMove.isPhysicalBindingDown(v5, v2.field_1690.field_1867) == 0) -> offset 229
        v13 = 0;
        // if (v7 != v8) -> offset 243
        // if (v7 == 0) -> offset 252
        v14 = -1.0f;
        // if (v9 != v10) -> offset 267
        // if (v9 == 0) -> offset 276
        v15 = -1.0f;
        // if (v12 == 0) -> offset 299
        v14 = (v14 * 0.30000001192092896f);
        v15 = (v15 * 0.30000001192092896f);
        this.field_54155 = new net.minecraft.class_10185(v7, v8, v9, v10, v11, v12, v13);
        this.field_55868 = new net.minecraft.class_241(v15, v14).method_35581();
        // if (v3 == null) -> offset 750
        // if (this.field_54155 == null) -> offset 750
        v4 = ((com.viper.client.modules.hacks.combat.WTap) v3.getModuleManager().getModule(com.viper.client.modules.hacks.combat.WTap.class));
        v5 = ((com.viper.client.modules.hacks.combat.SprintReset) v3.getModuleManager().getModule(com.viper.client.modules.hacks.combat.SprintReset.class));
        v6 = ((com.viper.client.modules.hacks.world.SafeWalk) v3.getModuleManager().getModule(com.viper.client.modules.hacks.world.SafeWalk.class));
        // if (v5 == null) -> offset 412
        // if (v5.isHoldingBackward() == 0) -> offset 412
        v7 = 0;
        // if (v4 == null) -> offset 428
        // if (v4.isReleasingForward() != 0) -> offset 446
        // if (v5 == null) -> offset 441
        // if (v5.isReleasingForward() != 0) -> offset 446
        // if (v7 == 0) -> offset 450
        v8 = 0;
        // if (v6 == null) -> offset 475
        // if (v6.shouldSneakAtEdge(v2, v2.field_1724) == 0) -> offset 475
        v9 = 0;
        // if (v8 != 0) -> offset 501
        // if (v9 != 0) -> offset 501
        // if (v5 == null) -> offset 505
        // if (v5.isSuppressingSprint() == 0) -> offset 505
        v10 = 0;
        // if (v8 != 0) -> offset 528
        // if (v7 != 0) -> offset 528
        // if (v10 != 0) -> offset 528
        // if (v9 == 0) -> offset 750
        v11 = this.field_54155;
        // if (v8 == 0) -> offset 543
        v12 = v11.comp_3159();
        // if (v7 != 0) -> offset 563
        // if (v11.comp_3160() == 0) -> offset 567
        v13 = 0;
        v14 = v11.comp_3161();
        v15 = v11.comp_3162();
        v16 = v11.comp_3163();
        // if (v9 != 0) -> offset 604
        // if (v11.comp_3164() == 0) -> offset 608
        v17 = 0;
        // if (v10 == 0) -> offset 620
        v18 = v11.comp_3165();
        // if (v12 != v13) -> offset 638
        // if (v12 == 0) -> offset 647
        v19 = -1.0f;
        // if (v14 != v15) -> offset 662
        // if (v14 == 0) -> offset 671
        v20 = -1.0f;
        // if (v17 == 0) -> offset 694
        v19 = (v19 * 0.30000001192092896f);
        v20 = (v20 * 0.30000001192092896f);
        this.field_54155 = new net.minecraft.class_10185(v12, v13, v14, v15, v16, v17, v18);
        this.field_55868 = new net.minecraft.class_241(v20, v19).method_35581();
        // if (v10 == 0) -> offset 750
        v2.field_1724.method_5728(0);
        // if (com.viper.client.utils.RotationUtils.isMoveFixActive() != 0) -> offset 757
        return;
        v4 = this.field_54155;
        // if (v4 != null) -> offset 769
        return;
        v5 = v4.comp_3159();
        v6 = v4.comp_3160();
        v7 = v4.comp_3161();
        v8 = v4.comp_3162();
        // if (v5 != v6) -> offset 808
        // if (v5 == 0) -> offset 817
        v9 = -1.0f;
        // if (v7 != v8) -> offset 832
        // if (v7 == 0) -> offset 841
        v10 = -1.0f;
        // if (Double.compare(v9, 0.0f) != 0) -> offset 860
        // if (Double.compare(v10, 0.0f) != 0) -> offset 860
        return;
        v11 = com.viper.client.utils.RotationUtils.computeRemappedWasd(v9, v10, com.viper.client.utils.RotationUtils.getCameraYaw(), com.viper.client.utils.RotationUtils.getServerYaw());
        v12 = v11[0];
        v13 = v11[1];
        // if (v12 <= 0) -> offset 896
        v14 = 0;
        // if (v12 >= 0) -> offset 908
        v15 = 0;
        // if (v13 <= 0) -> offset 920
        v16 = 0;
        // if (v13 >= 0) -> offset 932
        v17 = 0;
        // if (v4.comp_3165() == 0) -> offset 952
        // if (v14 == 0) -> offset 952
        v18 = 0;
        this.field_54155 = new net.minecraft.class_10185(v14, v15, v16, v17, v4.comp_3163(), v4.comp_3164(), v18);
        this.field_55868 = new net.minecraft.class_241((float)v13, (float)v12).method_35581();
        return;
    }

}
