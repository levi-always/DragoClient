package com.viper.client.utils;

public final class WorldProjectionUtils {
    private static final int[][] BOX_EDGES;

    private WorldProjectionUtils() {
        super();
        return;
    }

    public static com.viper.client.utils.WorldProjectionUtils.CameraFrame captureCameraFrame(net.minecraft.class_332 arg0, float arg1) {
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 19
        // if (v2.field_1773 == null) -> offset 19
        // if (arg0 != null) -> offset 21
        return null;
        v3 = v2.field_1773.method_19418();
        // if (v3 != null) -> offset 35
        return null;
        v4 = arg0.method_51421();
        v5 = arg0.method_51443();
        // if (v4 <= 0) -> offset 57
        // if (v5 > 0) -> offset 59
        return null;
        v6 = 70.0;
        // if (v2.field_1690 == null) -> offset 130
        // if (v2.field_1690.method_41808() == null) -> offset 130
        v8 = ((java.lang.Integer) v2.field_1690.method_41808().method_41753());
        // if (v8 == null) -> offset 130
        // if (v8.intValue() < 30) -> offset 130
        // if (v8.intValue() > 160) -> offset 130
        v6 = (double)v8.intValue();
        // if (Double.compare(arg1, 1.0099999904632568f) <= 0) -> offset 150
        v6 = Math.max(8.0, (v6 / (double)arg1));
        v8 = (((float)v5 * 0.5f) / (float)Math.tan((Math.toRadians(v6) * 0.5)));
        v9 = v3.method_23767().conjugate(new org.joml.Quaternionf());
        return new com.viper.client.utils.WorldProjectionUtils.CameraFrame(v3.method_71156(), v9, v4, v5, ((float)v4 * 0.5f), ((float)v5 * 0.5f), v8);
    }

    public static org.joml.Vector3f worldToView(com.viper.client.utils.WorldProjectionUtils.CameraFrame arg0, double arg1, double arg2, double arg3, org.joml.Vector3f arg4) {
        arg4.set((float)(arg1 - arg0.camPos().field_1352), (float)(arg2 - arg0.camPos().field_1351), (float)(arg3 - arg0.camPos().field_1350));
        arg0.invCamRot().transform(arg4);
        return arg4;
    }

    public static com.viper.client.utils.WorldProjectionUtils.ScreenPoint projectWorldPoint(com.viper.client.utils.WorldProjectionUtils.CameraFrame arg0, double arg1, double arg2, double arg3) {
        v7 = com.viper.client.utils.WorldProjectionUtils.worldToView(arg0, arg1, arg2, arg3, new org.joml.Vector3f());
        v8 = (-v7.z);
        // if (Double.compare(v8, 0.07999999821186066f) >= 0) -> offset 52
        return new com.viper.client.utils.WorldProjectionUtils.ScreenPoint(arg0.centerX(), arg0.centerY(), v8, 0);
        v9 = (arg0.centerX() + ((v7.x / v8) * arg0.focalY()));
        v10 = (arg0.centerY() - ((v7.y / v8) * arg0.focalY()));
        return new com.viper.client.utils.WorldProjectionUtils.ScreenPoint(v9, v10, v8, 1);
    }

    public static void drawClippedSegment(net.minecraft.class_332 arg0, com.viper.client.utils.WorldProjectionUtils.CameraFrame arg1, org.joml.Vector3f arg2, org.joml.Vector3f arg3, float arg4, int arg5) {
        v6 = (-arg2.z);
        v7 = (-arg3.z);
        // if (Double.compare(v6, 0.07999999821186066f) >= 0) -> offset 31
        // if (Double.compare(v7, 0.07999999821186066f) >= 0) -> offset 31
        return;
        v8 = arg2.x;
        v9 = arg2.y;
        v10 = arg3.x;
        v11 = arg3.y;
        // if (Double.compare(v6, 0.07999999821186066f) >= 0) -> offset 109
        v12 = ((0.07999999821186066f - v6) / (v7 - v6));
        v8 = (v8 + ((v10 - v8) * v12));
        v9 = (v9 + ((v11 - v9) * v12));
        v6 = 0.07999999821186066f;
        // if (Double.compare(v7, 0.07999999821186066f) >= 0) -> offset 160
        v12 = ((0.07999999821186066f - v7) / (v6 - v7));
        v10 = (v10 + ((v8 - v10) * v12));
        v11 = (v11 + ((v9 - v11) * v12));
        v7 = 0.07999999821186066f;
        v12 = (arg1.centerX() + ((v8 / v6) * arg1.focalY()));
        v13 = (arg1.centerY() - ((v9 / v6) * arg1.focalY()));
        v14 = (arg1.centerX() + ((v10 / v7) * arg1.focalY()));
        v15 = (arg1.centerY() - ((v11 / v7) * arg1.focalY()));
        com.viper.client.utils.AtlasRenderer.drawThinLine(arg0, v12, v13, v14, v15, arg4, arg5);
        return;
    }

    public static void drawWorldLine(net.minecraft.class_332 arg0, com.viper.client.utils.WorldProjectionUtils.CameraFrame arg1, double arg2, double arg3, double arg4, double arg5, double arg6, double arg7, float arg8, int arg9) {
        v16 = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg2, arg3, arg4, new org.joml.Vector3f());
        v17 = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg5, arg6, arg7, new org.joml.Vector3f());
        com.viper.client.utils.WorldProjectionUtils.drawClippedSegment(arg0, arg1, v16, v17, arg8, arg9);
        return;
    }

    public static void drawWorldBoxWireframe(net.minecraft.class_332 arg0, com.viper.client.utils.WorldProjectionUtils.CameraFrame arg1, net.minecraft.class_238 arg2, float arg3, int arg4) {
        v5 = new org.joml.Vector3f[8];
        v5[0] = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg2.field_1323, arg2.field_1322, arg2.field_1321, new org.joml.Vector3f());
        v5[1] = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg2.field_1320, arg2.field_1322, arg2.field_1321, new org.joml.Vector3f());
        v5[2] = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg2.field_1320, arg2.field_1322, arg2.field_1324, new org.joml.Vector3f());
        v5[3] = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg2.field_1323, arg2.field_1322, arg2.field_1324, new org.joml.Vector3f());
        v5[4] = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg2.field_1323, arg2.field_1325, arg2.field_1321, new org.joml.Vector3f());
        v5[5] = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg2.field_1320, arg2.field_1325, arg2.field_1321, new org.joml.Vector3f());
        v5[6] = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg2.field_1320, arg2.field_1325, arg2.field_1324, new org.joml.Vector3f());
        v5[7] = com.viper.client.utils.WorldProjectionUtils.worldToView(arg1, arg2.field_1323, arg2.field_1325, arg2.field_1324, new org.joml.Vector3f());
        v6 = com.viper.client.utils.WorldProjectionUtils.BOX_EDGES;
        v7 = v6.length;
        v8 = 0;
        // if (v8 >= v7) -> offset 280
        v9 = v6[v8];
        com.viper.client.utils.WorldProjectionUtils.drawClippedSegment(arg0, arg1, v5[v9[0]], v5[v9[1]], arg3, arg4);
        v8 += 1;
        return;
    }

    public static com.viper.client.utils.WorldProjectionUtils.ScreenBounds projectBox2DBounds(com.viper.client.utils.WorldProjectionUtils.CameraFrame arg0, net.minecraft.class_238 arg1) {
        new Object[2][0] = arg1.field_1323;
        new Object[2][1] = arg1.field_1320;
        v2 = new Object[2];
        new Object[2][0] = arg1.field_1322;
        new Object[2][1] = arg1.field_1325;
        v3 = new Object[2];
        new Object[2][0] = arg1.field_1321;
        new Object[2][1] = arg1.field_1324;
        v4 = new Object[2];
        v5 = 3.4028234663852886e+38f;
        v6 = 3.4028234663852886e+38f;
        v7 = -3.4028234663852886e+38f;
        v8 = -3.4028234663852886e+38f;
        v9 = 0;
        v10 = v2;
        v11 = v10.length;
        v12 = 0;
        // if (v12 >= v11) -> offset 239
        v13 = v10[v12];
        v15 = v3;
        v16 = v15.length;
        v17 = 0;
        // if (v17 >= v16) -> offset 233
        v18 = v15[v17];
        v20 = v4;
        v21 = v20.length;
        v22 = 0;
        // if (v22 >= v21) -> offset 227
        v23 = v20[v22];
        v25 = com.viper.client.utils.WorldProjectionUtils.projectWorldPoint(arg0, v13, v18, v23);
        // if (v25.visible() == 0) -> offset 221
        v9 += 1;
        v5 = Math.min(v5, v25.x());
        v6 = Math.min(v6, v25.y());
        v7 = Math.max(v7, v25.x());
        v8 = Math.max(v8, v25.y());
        v22 += 1;
        v17 += 1;
        v12 += 1;
        // if (v9 == 0) -> offset 264
        // if (Double.compare((v7 - v5), 1.0f) < 0) -> offset 264
        // if (Double.compare((v8 - v6), 1.0f) >= 0) -> offset 277
        return new com.viper.client.utils.WorldProjectionUtils.ScreenBounds(0.0f, 0.0f, 0.0f, 0.0f, 0);
        // if (Double.compare(v7, -40.0f) < 0) -> offset 321
        // if (Double.compare(v5, (float)(arg0.screenW() + 40)) > 0) -> offset 321
        // if (Double.compare(v8, -40.0f) < 0) -> offset 321
        // if (Double.compare(v6, (float)(arg0.screenH() + 40)) <= 0) -> offset 338
        return new com.viper.client.utils.WorldProjectionUtils.ScreenBounds(v5, v6, v7, v8, 0);
        return new com.viper.client.utils.WorldProjectionUtils.ScreenBounds(v5, v6, v7, v8, 1);
    }

    public final class CameraFrame extends java.lang.Record {
        private final net.minecraft.class_243 camPos;
        private final org.joml.Quaternionf invCamRot;
        private final int screenW;
        private final int screenH;
        private final float centerX;
        private final float centerY;
        private final float focalY;

        public CameraFrame(net.minecraft.class_243 arg0, org.joml.Quaternionf arg1, int arg2, int arg3, float arg4, float arg5, float arg6) {
            super();
            this.camPos = arg0;
            this.invCamRot = arg1;
            this.screenW = arg2;
            this.screenH = arg3;
            this.centerX = arg4;
            this.centerY = arg5;
            this.focalY = arg6;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public net.minecraft.class_243 camPos() {
            return this.camPos;
        }

        public org.joml.Quaternionf invCamRot() {
            return this.invCamRot;
        }

        public int screenW() {
            return this.screenW;
        }

        public int screenH() {
            return this.screenH;
        }

        public float centerX() {
            return this.centerX;
        }

        public float centerY() {
            return this.centerY;
        }

        public float focalY() {
            return this.focalY;
        }

    }

    public final class ScreenBounds extends java.lang.Record {
        private final float minX;
        private final float minY;
        private final float maxX;
        private final float maxY;
        private final boolean visible;

        public ScreenBounds(float arg0, float arg1, float arg2, float arg3, boolean arg4) {
            super();
            this.minX = arg0;
            this.minY = arg1;
            this.maxX = arg2;
            this.maxY = arg3;
            this.visible = arg4;
            return;
        }

        public float width() {
            return (this.maxX - this.minX);
        }

        public float height() {
            return (this.maxY - this.minY);
        }

        public float centerX() {
            return ((this.minX + this.maxX) * 0.5f);
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public float minX() {
            return this.minX;
        }

        public float minY() {
            return this.minY;
        }

        public float maxX() {
            return this.maxX;
        }

        public float maxY() {
            return this.maxY;
        }

        public boolean visible() {
            return this.visible;
        }

    }

    public final class ScreenPoint extends java.lang.Record {
        private final float x;
        private final float y;
        private final float depth;
        private final boolean visible;

        public ScreenPoint(float arg0, float arg1, float arg2, boolean arg3) {
            super();
            this.x = arg0;
            this.y = arg1;
            this.depth = arg2;
            this.visible = arg3;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public float x() {
            return this.x;
        }

        public float y() {
            return this.y;
        }

        public float depth() {
            return this.depth;
        }

        public boolean visible() {
            return this.visible;
        }

    }

}
