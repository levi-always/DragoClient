package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_4184.class})
public abstract class CameraMixin {
    @Unique
    private boolean viper$swappedAngles;
    @Unique
    private float viper$savedYaw;
    @Unique
    private float viper$savedLastYaw;
    @Unique
    private float viper$savedPitch;
    @Unique
    private float viper$savedLastPitch;

    public CameraMixin() {
        super();
        this.viper$swappedAngles = 0;
        return;
    }

    @Inject(method = {"method_19321"}, at = {@At("HEAD")})
    private void viper$beforeCameraUpdate(net.minecraft.class_1937 arg0, net.minecraft.class_1297 arg1, boolean arg2, boolean arg3, float arg4, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg5) {
        this.viper$swappedAngles = 0;
        // if (arg1 != null) -> offset 10
        return;
        v7 = net.minecraft.class_310.method_1551();
        // if (v7 == null) -> offset 29
        // if (arg1 == v7.field_1724) -> offset 30
        return;
        v8 = com.viper.client.ViperClient.getInstance();
        // if (v8 == null) -> offset 56
        v9 = null;
        // if (v9 == null) -> offset 76
        // if (v9.isEnabled() == 0) -> offset 76
        v10 = 0;
        v11 = com.viper.client.utils.RotationUtils.isSilentControlling();
        // if (v10 != 0) -> offset 95
        // if (v11 != 0) -> offset 95
        return;
        this.viper$savedYaw = arg1.method_36454();
        this.viper$savedLastYaw = arg1.field_5982;
        this.viper$savedPitch = arg1.method_36455();
        this.viper$savedLastPitch = arg1.field_6004;
        this.viper$swappedAngles = 1;
        // if (v10 == 0) -> offset 145
        v12 = com.viper.client.utils.RotationUtils.getCameraYaw();
        // if (v10 == 0) -> offset 163
        v13 = com.viper.client.utils.RotationUtils.getCameraPitch();
        arg1.method_36456(v12);
        arg1.field_5982 = v12;
        arg1.method_36457(v13);
        arg1.field_6004 = v13;
        return;
    }

    @Inject(method = {"method_19321"}, at = {@At("RETURN")})
    private void viper$afterCameraUpdate(net.minecraft.class_1937 arg0, net.minecraft.class_1297 arg1, boolean arg2, boolean arg3, float arg4, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg5) {
        // if (this.viper$swappedAngles == 0) -> offset 11
        // if (arg1 != null) -> offset 12
        return;
        arg1.method_36456(this.viper$savedYaw);
        arg1.field_5982 = this.viper$savedLastYaw;
        arg1.method_36457(this.viper$savedPitch);
        arg1.field_6004 = this.viper$savedLastPitch;
        this.viper$swappedAngles = 0;
        return;
    }

}
