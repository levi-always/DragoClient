package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_1657.class})
public abstract class PlayerEntityMixin {
    public PlayerEntityMixin() {
        super();
        return;
    }

    @Inject(method = {"method_21825"}, at = {@At("RETURN")}, cancellable = true)
    private void viper$clipAtLedge(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable arg0) {
        // if (arg0.getReturnValueZ() == 0) -> offset 8
        return;
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 24
        // if (this == v2.field_1724) -> offset 25
        return;
        v3 = com.viper.client.ViperClient.getInstance();
        // if (v3 != null) -> offset 34
        return;
        v4 = ((com.viper.client.modules.hacks.world.SafeWalk) v3.getModuleManager().getModule(com.viper.client.modules.hacks.world.SafeWalk.class));
        // if (v4 == null) -> offset 73
        // if (v4.shouldClipAtLedge(((net.minecraft.class_1657) this)) == 0) -> offset 73
        arg0.setReturnValue(Boolean.valueOf(1));
        return;
    }

}
