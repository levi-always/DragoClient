package com.viper.client.ui;

import com.viper.client.utils.AnimUtils;

public final class ThemeManager {
    public static final String[] THEME_GROUPS = new String[]{"All"};
    private boolean darkMode = true;
    private ThemePreset activeTheme = ThemePreset.WHITE;
    private boolean watermarkEnabled = true;
    private boolean arrayListEnabled = true;
    private boolean menuBlurEnabled = false;
    private boolean customFontEnabled = true;
    private int openGuiKeyCode = 344;
    private double uiScale = 4.0;
    private float darkBlend = 1.0f;
    private float gradPhase = 0.0f;
    private int animGradStart = ThemePreset.WHITE.getGradStart();
    private int animGradMid = ThemePreset.WHITE.getGradMid();
    private int animGradEnd = ThemePreset.WHITE.getGradEnd();
    private int animTextStart = ThemePreset.WHITE.getTextStart();
    private int animTextEnd = ThemePreset.WHITE.getTextEnd();
    private int animGlassTint = ThemePreset.WHITE.getGlassTint();
    private int watermarkX = 10;
    private int watermarkY = 10;
    private int arrayListX = -1;
    private int arrayListY = 10;

    public enum ThemePreset {
        ORANGE("orange", "Orange", "Black UI", 0xFFFB923C, 0xFFF97316, 0xFFEA580C, 0xFFFDBA74, 0xFFF97316, 0xFF0B0B0E),
        BLUE("blue", "Blue", "Black UI", 0xFF60A5FA, 0xFF3B82F6, 0xFF2563EB, 0xFF93C5FD, 0xFF3B82F6, 0xFF0B0B0E),
        YELLOW("yellow", "Yellow", "Black UI", 0xFFFDE047, 0xFFFACC15, 0xFFEAB308, 0xFFFEF08A, 0xFFFACC15, 0xFF0B0B0E),
        WHITE("white", "White", "Black UI", 0xFFFFFFFF, 0xFFF4F4F5, 0xFFD4D4D8, 0xFFFFFFFF, 0xFFE4E4E7, 0xFF0B0B0E),
        CYAN("cyan", "Cyan", "Black UI", 0xFF22D3EE, 0xFF06B6D4, 0xFF0891B2, 0xFF67E8F9, 0xFF06B6D4, 0xFF0B0B0E);

        private final String id;
        private final String displayName;
        private final String group;
        private final int gradStart;
        private final int gradMid;
        private final int gradEnd;
        private final int textStart;
        private final int textEnd;
        private final int glassTint;

        ThemePreset(String id, String displayName, String group, int gradStart, int gradMid, int gradEnd, int textStart, int textEnd, int glassTint) {
            this.id = id;
            this.displayName = displayName;
            this.group = group;
            this.gradStart = gradStart;
            this.gradMid = gradMid;
            this.gradEnd = gradEnd;
            this.textStart = textStart;
            this.textEnd = textEnd;
            this.glassTint = glassTint;
        }

        public String getId() { return id; }
        public String getDisplayName() { return displayName; }
        public String getGroup() { return group; }
        public int getGradStart() { return gradStart; }
        public int getGradMid() { return gradMid; }
        public int getGradEnd() { return gradEnd; }
        public int getTextStart() { return textStart; }
        public int getTextEnd() { return textEnd; }
        public int getGlassTint() { return glassTint; }

        public static ThemePreset byId(String id) {
            if (id == null || id.isBlank()) return WHITE;
            String t = id.trim();
            for (ThemePreset p : values()) {
                if (p.id.equalsIgnoreCase(t)) return p;
            }
            return WHITE;
        }
    }

    public void updateAnimations(float dt) {
        this.darkBlend = 1.0f;
        this.gradPhase = (this.gradPhase + dt * 0.45f) % 1.0f;
        this.animGradStart = AnimUtils.lerpColor(this.animGradStart, this.activeTheme.getGradStart(), Math.min(1.0f, dt * 10.0f));
        this.animGradMid = AnimUtils.lerpColor(this.animGradMid, this.activeTheme.getGradMid(), Math.min(1.0f, dt * 10.0f));
        this.animGradEnd = AnimUtils.lerpColor(this.animGradEnd, this.activeTheme.getGradEnd(), Math.min(1.0f, dt * 10.0f));
        this.animTextStart = AnimUtils.lerpColor(this.animTextStart, this.activeTheme.getTextStart(), Math.min(1.0f, dt * 10.0f));
        this.animTextEnd = AnimUtils.lerpColor(this.animTextEnd, this.activeTheme.getTextEnd(), Math.min(1.0f, dt * 10.0f));
        this.animGlassTint = 0xFF0B0B0D;
    }

    public int accentPrimary() { return animGradMid; }
    public int accentSecondary() { return animGradStart; }
    public int accentEnd() { return animGradEnd; }
    public int accentSoftBg() { return AnimUtils.withAlpha(accentPrimary(), 0.16f); }
    public int contrastTextOnAccent() {
        int c = accentPrimary();
        int r = (c >>> 16) & 0xFF, g = (c >>> 8) & 0xFF, b = c & 0xFF;
        return ((r * 299 + g * 587 + b * 114) / 1000) > 155 ? 0xFF0B0B0D : 0xFFFFFFFF;
    }
    public int backdropTint() { return 0x88000000; }
    public int windowBg() { return 0xF40B0B0D; }
    public int sidebarBg() { return 0xFA0E0E12; }
    public int headerBg() { return 0xFA0E0E12; }
    public int categoryBarBg() { return 0xFA121216; }
    public int cardBg() { return 0xFF121216; }
    public int cardHoverBg() { return 0xFF1A1A21; }
    public int settingsDrawerBg() { return 0xFF0D0D11; }
    public int dropdownBg() { return 0xFA121216; }
    public int controlTrackBg() { return 0xFF22222B; }
    public int borderSubtle() { return 0xFF22222A; }
    public int borderStrong() { return 0xFF2F2F3A; }
    public int textPrimary() { return 0xFFF4F4F5; }
    public int textSecondary() { return 0xFFA1A1AA; }
    public int textMuted() { return 0xFF71717A; }

    public ThemePreset getActiveTheme() { return activeTheme; }
    public void setActiveTheme(ThemePreset t) { if (t != null) this.activeTheme = t; }
    public boolean isDarkMode() { return true; }
    public void setDarkMode(boolean v) { this.darkMode = true; }
    public void toggleTheme() {}
    public boolean isWatermarkEnabled() { return watermarkEnabled; }
    public void setWatermarkEnabled(boolean v) { this.watermarkEnabled = v; }
    public boolean isArrayListEnabled() { return arrayListEnabled; }
    public void setArrayListEnabled(boolean v) { this.arrayListEnabled = v; }
    public boolean isMenuBlurEnabled() { return menuBlurEnabled; }
    public void setMenuBlurEnabled(boolean v) { this.menuBlurEnabled = v; }
    public boolean isCustomFontEnabled() { return customFontEnabled; }
    public void setCustomFontEnabled(boolean v) { this.customFontEnabled = v; }
    public int getOpenGuiKeyCode() { return openGuiKeyCode; }
    public void setOpenGuiKeyCode(int k) { this.openGuiKeyCode = k; }
    public double getUiScale() { return uiScale; }
    public void setUiScale(double s) { this.uiScale = Math.max(1.0, Math.min(8.0, s)); }
    public int getWatermarkX() { return watermarkX; }
    public int getWatermarkY() { return watermarkY; }
    public void setWatermarkPos(int x, int y) { this.watermarkX = x; this.watermarkY = y; }
    public int getArrayListX() { return arrayListX; }
    public int getArrayListY() { return arrayListY; }
    public void setArrayListPos(int x, int y) { this.arrayListX = x; this.arrayListY = y; }
    public int getAnimatedWaveColor(int idx) { return accentPrimary(); }
    public int getAnimatedAccentColor(float off) { return accentPrimary(); }
    public int getAnimatedTextColor(float off) { return animTextStart; }
}
