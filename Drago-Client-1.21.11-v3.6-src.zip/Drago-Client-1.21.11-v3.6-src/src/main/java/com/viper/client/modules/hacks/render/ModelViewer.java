package com.viper.client.modules.hacks.render;

public final class ModelViewer extends com.viper.client.modules.Module {
    public final com.viper.client.modules.Setting.NumberSetting scale;
    public final com.viper.client.modules.Setting.NumberSetting posX;
    public final com.viper.client.modules.Setting.NumberSetting posY;
    public final com.viper.client.modules.Setting.NumberSetting posZ;
    public final com.viper.client.modules.Setting.NumberSetting rotX;
    public final com.viper.client.modules.Setting.NumberSetting rotY;
    public final com.viper.client.modules.Setting.NumberSetting rotZ;
    public final com.viper.client.modules.Setting.BooleanSetting affectOffhand;

    public ModelViewer() {
        super("model_viewer", "ModelViewer", "Customize held item scale (0.1-2.5), X/Y/Z position, and rotation.", com.viper.client.modules.Category.RENDER, "model_viewer", -1);
        this.scale = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("scale", "Item Scale", "Scale multiplier for held items (0.1 to 2.5, default 1.0)", 1.0, 0.1, 2.5, 0.05, "x")));
        this.posX = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("pos_x", "Pos X", "Horizontal held item offset", 0.0, -1.5, 1.5, 0.05, "")));
        this.posY = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("pos_y", "Pos Y", "Vertical held item offset", 0.0, -1.5, 1.5, 0.05, "")));
        this.posZ = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("pos_z", "Pos Z", "Depth held item offset", 0.0, -1.5, 1.5, 0.05, "")));
        this.rotX = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("rot_x", "Rot X", "Pitch rotation in degrees", 0.0, -180.0, 180.0, 1.0, "°")));
        this.rotY = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("rot_y", "Rot Y", "Yaw rotation in degrees", 0.0, -180.0, 180.0, 1.0, "°")));
        this.rotZ = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("rot_z", "Rot Z", "Roll rotation in degrees", 0.0, -180.0, 180.0, 1.0, "°")));
        this.affectOffhand = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("affect_offhand", "Affect Offhand", "Apply custom position/scale/rotation to offhand items as well", 1)));
        return;
    }

    public String getHudMetadata() {
        return this.scale.formatDisplay();
    }

}
