package com.viper.client.modules.hacks.combat;

public final class SprintReset extends com.viper.client.modules.Module {
    public final com.viper.client.modules.Setting.ModeSetting tapMode;
    public final com.viper.client.modules.Setting.NumberSetting moveDuration;
    public final com.viper.client.modules.Setting.NumberSetting cooldown;
    public final com.viper.client.modules.Setting.BooleanSetting playersOnly;
    public final com.viper.client.modules.Setting.BooleanSetting weaponsOnly;
    private long activeUntilMs;
    private long lastTriggeredMs;

    public SprintReset() {
        super("sprint_reset", "SprintReset", "S Tap or W Tap sprint reset on hit for maximum knockback.", com.viper.client.modules.Category.COMBAT, "sprint_reset", -1);
        new java.lang.String[2][0] = "S Tap";
        new java.lang.String[2][1] = "W Tap";
        this.tapMode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("tap_mode", "Tap Mode", "Choose S Tap (default: briefly step back) or W Tap (briefly release forward)", "S Tap", new java.lang.String[2])));
        this.moveDuration = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("move_duration", "Move Duration", "How long (ms) to hold S or release W after landing a hit", 75.0, 20.0, 250.0, 5.0, "ms")));
        this.cooldown = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("cooldown", "Cooldown", "Minimum delay before triggering another reset", 100.0, 0.0, 500.0, 10.0, "ms")));
        this.playersOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("players_only", "Players Only", "Only reset sprint when attacking Players", 1)));
        this.weaponsOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("weapons_only", "Weapons Only", "Only reset sprint when holding a weapon", 0)));
        this.activeUntilMs = 0L;
        this.lastTriggeredMs = 0L;
        return;
    }

    protected void onDisable() {
        this.activeUntilMs = 0L;
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(((java.lang.String) this.tapMode.getValue()), this.moveDuration.intValue());
    }

    private boolean isPulseActive() {
        // if (this.isEnabled() == 0) -> offset 16
        // if (Double.compare(this.activeUntilMs, 0L) > 0) -> offset 18
        return false;
        // if (Double.compare(System.currentTimeMillis(), this.activeUntilMs) < 0) -> offset 36
        this.activeUntilMs = 0L;
        return false;
        return true;
    }

    public boolean isHoldingBackward() {
        // if (this.tapMode.is("S Tap") == 0) -> offset 23
        // if (this.isPulseActive() == 0) -> offset 23
        return false;
    }

    public boolean isReleasingForward() {
        // if (this.tapMode.is("W Tap") == 0) -> offset 23
        // if (this.isPulseActive() == 0) -> offset 23
        return false;
    }

    public boolean isSuppressingSprint() {
        return this.isPulseActive();
    }

    public void onAttackEntity(Object arg0) {
        // if (this.isEnabled() != 0) -> offset 8
        return;
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 23
        // if (v2.field_1724 != null) -> offset 24
        return;
        v3 = v2.field_1724;
        // if (com.viper.client.utils.TargetUtils.matchesPlayersOnly(arg0, v3, Boolean.TRUE.equals(this.playersOnly.getValue())) != 0) -> offset 51
        return;
        // if (Boolean.TRUE.equals(this.weaponsOnly.getValue()) == 0) -> offset 75
        // if (com.viper.client.utils.WeaponUtils.isHoldingWeapon(v3) != 0) -> offset 75
        return;
        v4 = System.currentTimeMillis();
        // if (Double.compare((v4 - this.lastTriggeredMs), this.cooldown.longValue()) >= 0) -> offset 99
        return;
        this.lastTriggeredMs = v4;
        this.activeUntilMs = (v4 + Math.max(20L, this.moveDuration.longValue()));
        v3.method_5728(0);
        return;
    }

    public void onTick() {
        // if (Double.compare(this.activeUntilMs, 0L) <= 0) -> offset 25
        // if (Double.compare(System.currentTimeMillis(), this.activeUntilMs) < 0) -> offset 25
        this.activeUntilMs = 0L;
        return;
    }

}
