package com.viper.client.modules.hacks.combat;

public final class KnockbackDelay extends com.viper.client.modules.Module {
    public final com.viper.client.modules.Setting.NumberSetting chance;
    public final com.viper.client.modules.Setting.NumberSetting groundDelay;
    public final com.viper.client.modules.Setting.NumberSetting airDelay;
    public final com.viper.client.modules.Setting.BooleanSetting waterCheck;
    private final java.util.Deque queue;
    private boolean releasing;

    public KnockbackDelay() {
        super("knockback_delay", "KnockbackDelay", "Holds incoming velocity packets in order and releases after configured delay.", com.viper.client.modules.Category.COMBAT, "knockback_delay", -1);
        this.chance = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("chance", "Chance", "Probability of delaying incoming velocity packets", 100.0, 0.0, 100.0, 1.0, "%")));
        this.groundDelay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("ground_delay", "Ground Delay", "Delay before releasing queued velocity packets on ground", 80.0, 0.0, 500.0, 5.0, "ms")));
        this.airDelay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("air_delay", "Air Delay", "Delay before releasing queued velocity packets in air", 120.0, 0.0, 500.0, 5.0, "ms")));
        this.waterCheck = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("water_check", "Water Check", "Immediately release and bypass velocity delay while in water", 1)));
        this.queue = new java.util.ArrayDeque();
        this.releasing = 0;
        return;
    }

    protected void onDisable() {
        this.flushAllQueued();
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.groundDelay.intValue(), this.airDelay.intValue());
    }

    public int getQueuedPacketCount() {
        return this.queue.size();
    }

    public static void onNetworkReset() {
        v0 = com.viper.client.ViperClient.getInstance();
        // if (v0 != null) -> offset 9
        return;
        v1 = ((com.viper.client.modules.hacks.combat.KnockbackDelay) v0.getModuleManager().getModule(com.viper.client.modules.hacks.combat.KnockbackDelay.class));
        // if (v1 == null) -> offset 30
        v1.clearQueueSafely();
        return;
    }

    public void clearQueueSafely() {
        this.queue.clear();
        this.releasing = 0;
        return;
    }

    public static boolean handleIncomingVelocity(net.minecraft.class_634 arg0, net.minecraft.class_2743 arg1) {
        // if (arg0 == null) -> offset 8
        // if (arg1 != null) -> offset 10
        return false;
        v2 = com.viper.client.ViperClient.getInstance();
        // if (v2 != null) -> offset 20
        return false;
        v3 = ((com.viper.client.modules.hacks.combat.KnockbackDelay) v2.getModuleManager().getModule(com.viper.client.modules.hacks.combat.KnockbackDelay.class));
        // if (v3 == null) -> offset 51
        // if (v3.isEnabled() == 0) -> offset 51
        // if (v3.releasing == 0) -> offset 53
        return false;
        v4 = net.minecraft.class_310.method_1551();
        // if (v4 == null) -> offset 87
        // if (v4.field_1724 == null) -> offset 87
        // if (v4.field_1687 == null) -> offset 87
        // if (v4.method_18854() != 0) -> offset 89
        return false;
        v5 = v4.field_1724;
        // if (arg1.method_11818() == v5.method_5628()) -> offset 110
        return false;
        // if (v5.method_5799() != 0) -> offset 134
        // if (v5.method_5869() != 0) -> offset 134
        // if (v5.method_52535() == 0) -> offset 138
        v6 = 0;
        // if (Boolean.TRUE.equals(v3.waterCheck.getValue()) == 0) -> offset 168
        // if (v6 == 0) -> offset 168
        v3.flushAllQueued();
        return false;
        v7 = System.currentTimeMillis();
        // if (v5.method_24828() == 0) -> offset 191
        v9 = v3.airDelay.longValue();
        v11 = v3.chance.doubleValue();
        // if (Double.compare(v11, 100.0) >= 0) -> offset 241
        // if (Double.compare(v11, 0.0) <= 0) -> offset 245
        // if (Double.compare((java.util.concurrent.ThreadLocalRandom.current().nextDouble() * 100.0), v11) >= 0) -> offset 245
        v13 = 0;
        return v3.enqueueOrPass(arg0, arg1, v7, v9, v13);
    }

    public boolean enqueueOrPass(net.minecraft.class_634 arg0, net.minecraft.class_2743 arg1, long arg2, long arg3, boolean arg4) {
        // if (arg1 == null) -> offset 11
        // if (this.releasing == 0) -> offset 13
        return false;
        // if (arg4 == 0) -> offset 25
        // if (Double.compare(arg3, 0L) > 0) -> offset 82
        // if (this.queue.isEmpty() == 0) -> offset 39
        return false;
        v8 = Math.max(arg2, ((com.viper.client.modules.hacks.combat.KnockbackDelay.QueuedVelocity) this.queue.peekLast()).releaseAtMs);
        this.queue.addLast(new com.viper.client.modules.hacks.combat.KnockbackDelay.QueuedVelocity(arg0, arg1, v8));
        return true;
        v8 = (arg2 + arg3);
        // if (this.queue.isEmpty() != 0) -> offset 122
        v8 = Math.max(v8, ((com.viper.client.modules.hacks.combat.KnockbackDelay.QueuedVelocity) this.queue.peekLast()).releaseAtMs);
        this.queue.addLast(new com.viper.client.modules.hacks.combat.KnockbackDelay.QueuedVelocity(arg0, arg1, v8));
        return true;
    }

    public int releaseDuePackets(long arg0, boolean arg1, java.util.function.Consumer arg2) {
        // if (this.releasing != 0) -> offset 19
        // if (this.queue.isEmpty() == 0) -> offset 21
        return 0;
        v5 = 0;
        this.releasing = 1;
        // if (this.queue.isEmpty() != 0) -> offset 108
        v6 = ((com.viper.client.modules.hacks.combat.KnockbackDelay.QueuedVelocity) this.queue.peekFirst());
        // if (arg1 != 0) -> offset 72
        // if (Double.compare(arg0, v6.releaseAtMs) >= 0) -> offset 72
        this.queue.pollFirst();
        // if (v6.packet == null) -> offset 105
        arg2.accept(v6.packet);
        v5 += 1;
        this.releasing = 0;
        v7 = /*?*/;
        this.releasing = 0;
        throw v7;
        return v5;
    }

    private void flushAllQueued() {
        // if (this.queue.isEmpty() == 0) -> offset 13
        return;
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 42
        // if (v1.field_1724 == null) -> offset 42
        // if (v1.field_1687 == null) -> offset 42
        // if (v1.method_18854() != 0) -> offset 52
        this.queue.clear();
        return;
        this.releaseDuePackets(System.currentTimeMillis(), 1, accept(v1));
        return;
    }

    private void stepRelease() {
        // if (this.queue.isEmpty() == 0) -> offset 13
        return;
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 35
        // if (v1.field_1724 == null) -> offset 35
        // if (v1.field_1687 != null) -> offset 45
        this.queue.clear();
        return;
        // if (v1.method_18854() != 0) -> offset 53
        return;
        v2 = v1.field_1724;
        // if (Boolean.TRUE.equals(this.waterCheck.getValue()) == 0) -> offset 99
        // if (v2.method_5799() != 0) -> offset 95
        // if (v2.method_5869() != 0) -> offset 95
        // if (v2.method_52535() == 0) -> offset 99
        v3 = 0;
        this.releaseDuePackets(System.currentTimeMillis(), v3, accept(v2));
        return;
    }

    public void onTick() {
        this.stepRelease();
        return;
    }

    public static void pollRenderFrame() {
        v0 = com.viper.client.ViperClient.getInstance();
        // if (v0 != null) -> offset 9
        return;
        v1 = ((com.viper.client.modules.hacks.combat.KnockbackDelay) v0.getModuleManager().getModule(com.viper.client.modules.hacks.combat.KnockbackDelay.class));
        // if (v1 == null) -> offset 37
        // if (v1.isEnabled() == 0) -> offset 37
        v1.stepRelease();
        v0 = /*?*/;
        return;
    }

    final class QueuedVelocity {
        final net.minecraft.class_634 handler;
        final net.minecraft.class_2743 packet;
        final long releaseAtMs;

        QueuedVelocity(net.minecraft.class_634 arg0, net.minecraft.class_2743 arg1, long arg2) {
            super();
            this.handler = arg0;
            this.packet = arg1;
            this.releaseAtMs = arg2;
            return;
        }

    }

}
