package com.viper.client.modules.hacks.render;

public final class BlockSearch extends com.viper.client.modules.Module {
    private static final int BLOCKS_PER_TICK_BUDGET = 4096;
    private static final int MAX_RESULTS = 96;
    private final com.viper.client.modules.Setting.ModeSetting targetBlocks;
    private final com.viper.client.modules.Setting.NumberSetting radius;
    private final com.viper.client.modules.Setting.BooleanSetting tracers;
    private final com.viper.client.modules.Setting.ColorSetting color;
    private final com.viper.client.modules.Setting.NumberSetting thickness;
    private final com.viper.client.modules.Setting.NumberSetting opacity;
    private final java.util.List matchedBlocks;
    private final java.util.List pendingMatches;
    private final java.util.Set cachedPresetBlocks;
    private String cachedPresetName;
    private int scanCursor;
    private int scanCooldownTicks;
    private int centerX;
    private int centerY;
    private int centerZ;
    private int scanR;
    private int scanY;

    public BlockSearch() {
        super("block_search", "Search", "Finds and highlights selected blocks across chunks.", com.viper.client.modules.Category.RENDER, "search", -1);
        new java.lang.String[5][0] = "Obsidian & Anchors";
        new java.lang.String[5][1] = "Diamonds & Debris";
        new java.lang.String[5][2] = "Spawners & Portals";
        new java.lang.String[5][3] = "Beds & Beacons";
        new java.lang.String[5][4] = "Redstone";
        this.targetBlocks = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("blocks", "Target Blocks", "Block group to search and highlight", "Obsidian & Anchors", new java.lang.String[5])));
        this.radius = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("radius", "Radius", "Block search radius in meters", 20.0, 8.0, 36.0, 2.0, "m")));
        this.tracers = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("tracers", "Tracers", "Draw tracer lines from screen center to found blocks", 0)));
        this.color = ((com.viper.client.modules.Setting.ColorSetting) this.registerSetting(new com.viper.client.modules.Setting.ColorSetting("color", "Color", "Found block highlight color", 14427686)));
        this.thickness = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("thickness", "Thickness", "Wireframe thickness", 1.2, 0.5, 3.0, 0.1, "px")));
        this.opacity = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("opacity", "Opacity", "Highlight opacity", 80.0, 15.0, 100.0, 5.0, "%")));
        this.matchedBlocks = new java.util.ArrayList();
        this.pendingMatches = new java.util.ArrayList();
        this.cachedPresetBlocks = new java.util.HashSet();
        this.cachedPresetName = "";
        this.scanCursor = 0;
        this.scanCooldownTicks = 0;
        return;
    }

    protected void onDisable() {
        this.matchedBlocks.clear();
        this.pendingMatches.clear();
        this.scanCursor = 0;
        this.scanCooldownTicks = 0;
        return;
    }

    private void refreshPresetCacheIfNeeded(String arg0) {
        // if (arg0.equals(this.cachedPresetName) == 0) -> offset 24
        // if (this.cachedPresetBlocks.isEmpty() != 0) -> offset 24
        return;
        this.cachedPresetName = arg0;
        this.cachedPresetBlocks.clear();
        v2 = net.minecraft.class_7923.field_41175.iterator();
        // if (v2.hasNext() == 0) -> offset 138
        v3 = v2.next();
        // if ((v3 instanceof net.minecraft.class_2248) != 0) -> offset 73
        v4 = ((net.minecraft.class_2248) v3);
        v5 = net.minecraft.class_7923.field_41175.method_10221(v4);
        // if (v5 == null) -> offset 110
        v6 = "";
        // if (com.viper.client.modules.hacks.render.BlockSearch.matchesPresetKey(v6, arg0) == 0) -> offset 135
        this.cachedPresetBlocks.add(v4);
        return;
    }

    private static boolean matchesPresetKey(String arg0, String arg1) {
        // if (arg0 == null) -> offset 11
        // if (arg0.isEmpty() == 0) -> offset 13
        return false;
        v2 = arg1;
        v3 = -1;
        // if (v2.equals("Diamonds & Debris") == 0) -> offset 117
        v3 = 0;
        // if (v2.equals("Spawners & Portals") == 0) -> offset 117
        v3 = 1;
        // if (v2.equals("Beds & Beacons") == 0) -> offset 117
        v3 = 2;
        // if (v2.equals("Redstone") == 0) -> offset 117
        v3 = 3;
        // if (arg0.contains("diamond_ore") != 0) -> offset 166
        // if (arg0.contains("ancient_debris") == 0) -> offset 170
        // if (arg0.contains("spawner") != 0) -> offset 213
        // if (arg0.contains("portal") != 0) -> offset 213
        // if (arg0.contains("trial_spawner") != 0) -> offset 213
        // if (arg0.contains("vault") == 0) -> offset 217
        // if (arg0.endsWith("_bed") != 0) -> offset 241
        // if (arg0.contains("beacon") == 0) -> offset 245
        // if (arg0.contains("piston") != 0) -> offset 289
        // if (arg0.contains("observer") != 0) -> offset 289
        // if (arg0.contains("redstone_block") != 0) -> offset 289
        // if (arg0.contains("hopper") == 0) -> offset 293
        // if (arg0.contains("obsidian") != 0) -> offset 317
        // if (arg0.contains("respawn_anchor") == 0) -> offset 321
        return false;
    }

    public void onTick() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 22
        // if (v1.field_1724 == null) -> offset 22
        // if (v1.field_1687 != null) -> offset 23
        return;
        v2 = ((java.lang.String) this.targetBlocks.getValue());
        this.refreshPresetCacheIfNeeded(v2);
        // if (this.scanCursor != 0) -> offset 139
        // if (this.scanCooldownTicks <= 0) -> offset 64
        this.scanCooldownTicks = (this.scanCooldownTicks - 1);
        return;
        this.scanR = this.radius.intValue();
        this.scanY = Math.min(this.scanR, 20);
        this.centerX = v1.field_1724.method_24515().method_10263();
        this.centerY = v1.field_1724.method_24515().method_10264();
        this.centerZ = v1.field_1724.method_24515().method_10260();
        this.pendingMatches.clear();
        v3 = ((this.scanR * 2) + 1);
        v4 = ((this.scanY * 2) + 1);
        v5 = ((v3 * v3) * v4);
        v6 = 0;
        v7 = new net.minecraft.class_2338.class_2339();
        // if (this.scanCursor >= v5) -> offset 353
        // if (v6 >= 4096) -> offset 353
        // if (this.pendingMatches.size() >= 96) -> offset 353
        this.scanCursor = (this.scanCursor + 1);
        v8 = /*?*/;
        v6 += 1;
        v9 = ((v8 % v3) - this.scanR);
        v10 = (v8 / v3);
        v11 = ((v10 % v3) - this.scanR);
        v12 = ((v10 / v3) - this.scanY);
        v7.method_10103((this.centerX + v11), (this.centerY + v12), (this.centerZ + v9));
        v13 = v1.field_1687.method_8320(v7);
        // if (v13 == null) -> offset 178
        // if (v13.method_26215() == 0) -> offset 318
        // if (this.cachedPresetBlocks.contains(v13.method_26204()) == 0) -> offset 350
        this.pendingMatches.add(v7.method_10062());
        // if (this.scanCursor >= v5) -> offset 376
        // if (this.pendingMatches.size() < 96) -> offset 419
        this.matchedBlocks.clear();
        this.matchedBlocks.addAll(this.pendingMatches);
        this.pendingMatches.clear();
        this.scanCursor = 0;
        this.scanCooldownTicks = 12;
        return;
    }

    public void onRenderOverlay(net.minecraft.class_332 arg0, float arg1) {
        // if (this.matchedBlocks.isEmpty() == 0) -> offset 13
        return;
        v3 = com.viper.client.utils.WorldProjectionUtils.captureCameraFrame(arg0, com.viper.client.modules.hacks.render.Zoom.getActiveDivisorSnapshot());
        // if (v3 != null) -> offset 26
        return;
        v4 = this.color.getArgb((this.opacity.floatValue() / 100.0f));
        v5 = this.thickness.floatValue();
        v6 = this.matchedBlocks.iterator();
        // if (v6.hasNext() == 0) -> offset 240
        v7 = ((net.minecraft.class_2338) v6.next());
        v8 = new net.minecraft.class_238((double)v7.method_10263(), (double)v7.method_10264(), (double)v7.method_10260(), ((double)v7.method_10263() + 1.0), ((double)v7.method_10264() + 1.0), ((double)v7.method_10260() + 1.0));
        com.viper.client.utils.WorldProjectionUtils.drawWorldBoxWireframe(arg0, v3, v8, v5, v4);
        // if (Boolean.TRUE.equals(this.tracers.getValue()) == 0) -> offset 237
        v9 = com.viper.client.utils.WorldProjectionUtils.projectWorldPoint(v3, ((double)v7.method_10263() + 0.5), ((double)v7.method_10264() + 0.5), ((double)v7.method_10260() + 0.5));
        // if (v9.visible() == 0) -> offset 237
        com.viper.client.utils.AtlasRenderer.drawThinLine(arg0, v3.centerX(), v3.centerY(), v9.x(), v9.y(), 0.8999999761581421f, v4);
        return;
    }

    public String getHudMetadata() {
        return String.valueOf(this.matchedBlocks.size());
    }

}
