package com.viper.client.modules.hacks.world;

public final class WorldCategoryInfo {
    public static final com.viper.client.modules.Category CATEGORY;

    private WorldCategoryInfo() {
        super();
        return;
    }

}
