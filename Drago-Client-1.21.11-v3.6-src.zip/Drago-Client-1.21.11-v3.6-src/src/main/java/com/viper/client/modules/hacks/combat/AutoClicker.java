package com.viper.client.modules.hacks.combat;

public final class AutoClicker extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.NumberSetting cps;
    private final com.viper.client.modules.Setting.ModeSetting clickMode;
    private final com.viper.client.modules.Setting.ModeSetting triggerMode;
    private final com.viper.client.modules.Setting.BooleanSetting weaponsOnly;
    private final com.viper.client.modules.Setting.BooleanSetting ignoreScreens;
    private final com.viper.client.modules.Setting.BooleanSetting simulateClick;
    private long lastNs;
    private double leftAcc;
    private double rightAcc;

    public AutoClicker() {
        super("auto_clicker", "AutoClicker", "High-precision Auto Clicker supporting 1 to 260 CPS with Simulate Click.", com.viper.client.modules.Category.COMBAT, "auto_clicker", -1);
        this.cps = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("cps", "CPS", "Target clicks per second (up to 260 CPS)", 14.0, 1.0, 260.0, 1.0, " CPS")));
        new java.lang.String[3][0] = "Left";
        new java.lang.String[3][1] = "Right";
        new java.lang.String[3][2] = "Both";
        this.clickMode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("click_mode", "Click Button", "Mouse button(s) to auto-click", "Left", new java.lang.String[3])));
        new java.lang.String[2][0] = "Hold";
        new java.lang.String[2][1] = "Always";
        this.triggerMode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("trigger_mode", "Trigger", "Hold mouse button or Always active", "Hold", new java.lang.String[2])));
        this.weaponsOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("weapons_only", "Weapons Only", "Only auto-click while holding a weapon", 0)));
        this.ignoreScreens = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("ignore_screens", "Ignore Screens", "Pause AutoClicker when inventory or menu is open", 1)));
        this.simulateClick = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate key press state during every click", 1)));
        this.lastNs = 0L;
        this.leftAcc = 0.0;
        this.rightAcc = 0.0;
        return;
    }

    public String getHudMetadata() {
        return this.cps.formatDisplay();
    }

    protected void onDisable() {
        this.lastNs = 0L;
        this.leftAcc = 0.0;
        this.rightAcc = 0.0;
        return;
    }

    private void step() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 378
        // if (v1.field_1724 == null) -> offset 378
        // if (v1.field_1687 == null) -> offset 378
        // if (v1.field_1761 == null) -> offset 378
        // if (((java.lang.Boolean) this.ignoreScreens.getValue()).booleanValue() == 0) -> offset 52
        // if (v1.field_1755 != null) -> offset 368
        v2 = v1.field_1724;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 80
        // if (com.viper.client.utils.WeaponUtils.isHoldingWeapon(v2) == 0) -> offset 368
        v3 = System.nanoTime();
        // if (Double.compare(this.lastNs, 0L) != 0) -> offset 99
        this.lastNs = v3;
        return;
        v5 = ((double)(v3 - this.lastNs) / 1000000000.0);
        this.lastNs = v3;
        // if (Double.compare(v5, 0.0) <= 0) -> offset 378
        // if (Double.compare(v5, 0.1) <= 0) -> offset 138
        v5 = 0.1;
        v7 = v1.method_22683().method_4490();
        v9 = this.triggerMode.is("Always");
        v10 = (this.cps.doubleValue() * v5);
        v12 = ((java.lang.Boolean) this.simulateClick.getValue()).booleanValue();
        // if (this.clickMode.is("Right") != 0) -> offset 278
        // if (v9 != 0) -> offset 222
        // if (org.lwjgl.glfw.GLFW.glfwGetMouseButton(v7, 0) == 1) -> offset 222
        this.leftAcc = 0.0;
        this.leftAcc = (this.leftAcc + v10);
        v13 = Math.min((int)this.leftAcc, 16);
        v14 = 0;
        // if (v14 >= v13) -> offset 278
        com.viper.client.utils.ClickSimulator.performRawClick(v1, 0, v12);
        this.leftAcc = (this.leftAcc - 1.0);
        v14 += 1;
        // if (this.clickMode.is("Left") != 0) -> offset 378
        // if (v9 != 0) -> offset 312
        // if (org.lwjgl.glfw.GLFW.glfwGetMouseButton(v7, 1) == 1) -> offset 312
        this.rightAcc = 0.0;
        return;
        this.rightAcc = (this.rightAcc + v10);
        v15 = Math.min((int)this.rightAcc, 16);
        v16 = 0;
        // if (v16 >= v15) -> offset 378
        com.viper.client.utils.ClickSimulator.performRawClick(v1, 1, v12);
        this.rightAcc = (this.rightAcc - 1.0);
        v16 += 1;
        this.leftAcc = 0.0;
        this.rightAcc = 0.0;
        return;
    }

    public void onTick() {
        this.step();
        return;
    }

    public static void pollRenderFrame() {
        v0 = com.viper.client.ViperClient.getInstance();
        // if (v0 == null) -> offset 37
        v1 = ((com.viper.client.modules.hacks.combat.AutoClicker) v0.getModuleManager().getModule(com.viper.client.modules.hacks.combat.AutoClicker.class));
        // if (v1 == null) -> offset 37
        // if (v1.isEnabled() == 0) -> offset 37
        v1.step();
        return;
    }

}
