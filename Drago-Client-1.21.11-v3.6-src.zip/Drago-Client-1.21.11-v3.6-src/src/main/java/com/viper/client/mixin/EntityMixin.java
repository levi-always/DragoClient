package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_1297.class})
public abstract class EntityMixin {
    public EntityMixin() {
        super();
        return;
    }

    @Inject(method = {"method_5871"}, at = {@At("RETURN")}, cancellable = true)
    private void viper$expandTargetingMargin(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable arg0) {
        v2 = com.viper.client.ViperClient.getInstance();
        // if (v2 != null) -> offset 9
        return;
        v3 = 0.0f;
        v4 = ((com.viper.client.modules.hacks.combat.Hitboxes) v2.getModuleManager().getModule(com.viper.client.modules.hacks.combat.Hitboxes.class));
        // if (v4 == null) -> offset 50
        // if (v4.isEnabled() == 0) -> offset 50
        v3 = (v3 + v4.getExtraMarginFor(((net.minecraft.class_1297) this)));
        v5 = ((com.viper.client.modules.hacks.combat.Reach) v2.getModuleManager().getModule(com.viper.client.modules.hacks.combat.Reach.class));
        // if (v5 == null) -> offset 89
        // if (v5.isEnabled() == 0) -> offset 89
        v3 = (v3 + v5.getExtraMarginFor(((net.minecraft.class_1297) this)));
        // if (Double.compare(v3, 0.0f) <= 0) -> offset 114
        arg0.setReturnValue(Float.valueOf((((java.lang.Float) arg0.getReturnValue()).floatValue() + v3)));
        v2 = /*?*/;
        return;
    }

    @Inject(method = {"method_5872"}, at = {@At("HEAD")}, cancellable = true)
    private void viper$onChangeLookDirection(double arg0, double arg1, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg2) {
        // if (com.viper.client.utils.RotationUtils.isSyntheticMouseDispatch() == 0) -> offset 7
        return;
        v6 = net.minecraft.class_310.method_1551();
        // if (v6 == null) -> offset 26
        // if (this == v6.field_1724) -> offset 27
        return;
        v7 = com.viper.client.ViperClient.getInstance();
        // if (v7 == null) -> offset 86
        // if (v6.field_1755 != null) -> offset 86
        v8 = ((com.viper.client.modules.hacks.world.Freelook) v7.getModuleManager().getModule(com.viper.client.modules.hacks.world.Freelook.class));
        // if (v8 == null) -> offset 86
        // if (v8.isEnabled() == 0) -> offset 86
        v8.applyMouseDelta(arg0, arg1);
        arg2.cancel();
        return;
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 103
        com.viper.client.utils.RotationUtils.applySilentMouseDelta(arg0, arg1);
        arg2.cancel();
        return;
        com.viper.client.utils.RotationUtils.onRawMouseInput(arg0, arg1);
        v6 = /*?*/;
        return;
    }

}
