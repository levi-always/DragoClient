package com.viper.client.modules.hacks.combat;

public final class Hitboxes extends com.viper.client.modules.Module {
    public final com.viper.client.modules.Setting.NumberSetting hitboxExpander;
    public final com.viper.client.modules.Setting.BooleanSetting playersOnly;
    public final com.viper.client.modules.Setting.BooleanSetting weaponsOnly;
    public final com.viper.client.modules.Setting.BooleanSetting showHitbox;
    public final com.viper.client.modules.Setting.ColorSetting hitboxColor;
    public final com.viper.client.modules.Setting.NumberSetting lineWidth;
    public final com.viper.client.modules.Setting.ModeSetting colorMode;

    public Hitboxes() {
        super("hitboxes", "Hitboxes", "Expands target hitboxes with crisp custom wireframe.", com.viper.client.modules.Category.COMBAT, "hitboxes", -1);
        this.hitboxExpander = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("hitbox_expander", "Hitbox Expander", "Expansion level from 0 to 30 (+0.10 block margin per unit)", 2.0, 0.0, 30.0, 0.5, "")));
        this.playersOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("players_only", "Players Only", "Expand hitboxes on Players only (turn OFF for Players & Animals/Mobs)", 1)));
        this.weaponsOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("weapons_only", "Weapons Only", "Only expand and render hitboxes while holding a weapon", 0)));
        this.showHitbox = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("show_hitbox", "Show Hitbox", "Render a crisp, thin wireframe around the expanded hitbox", 1)));
        java.util.Objects.requireNonNull(this.showHitbox);
        this.hitboxColor = ((com.viper.client.modules.Setting.ColorSetting) this.registerSetting(((com.viper.client.modules.Setting.ColorSetting) new com.viper.client.modules.Setting.ColorSetting("hitbox_color", "Hitbox Color", "Wireframe color of the rendered expanded hitbox", -770210).visibleWhen(getAsBoolean(this.showHitbox)))));
        java.util.Objects.requireNonNull(this.showHitbox);
        this.lineWidth = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(((com.viper.client.modules.Setting.NumberSetting) new com.viper.client.modules.Setting.NumberSetting("line_width", "Line Width", "Ultra-thin stroke width for the rendered hitbox outline", 1.0, 0.5, 2.5, 0.1, "px").visibleWhen(getAsBoolean(this.showHitbox)))));
        new java.lang.String[7][0] = "Custom";
        new java.lang.String[7][1] = "Rainbow";
        new java.lang.String[7][2] = "Red";
        new java.lang.String[7][3] = "Cyan";
        new java.lang.String[7][4] = "Emerald";
        new java.lang.String[7][5] = "Gold";
        new java.lang.String[7][6] = "Violet";
        this.colorMode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("color_mode", "Color Mode", "Hitbox outline color preset or Custom color", "Custom", new java.lang.String[7])));
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.hitboxExpander.formatDisplay());
    }

    public float getExtraMarginFor(net.minecraft.class_1297 arg0) {
        // if (this.isEnabled() == 0) -> offset 25
        // if (Double.compare(((java.lang.Double) this.hitboxExpander.getValue()).doubleValue(), 0.0) > 0) -> offset 27
        return 0.0f;
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 42
        // if (v2.field_1724 != null) -> offset 44
        return 0.0f;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 72
        // if (com.viper.client.utils.WeaponUtils.isHoldingWeapon(v2.field_1724) != 0) -> offset 72
        return 0.0f;
        // if (com.viper.client.utils.TargetUtils.matchesPlayersOnly(arg0, v2.field_1724, ((java.lang.Boolean) this.playersOnly.getValue()).booleanValue()) != 0) -> offset 98
        return 0.0f;
        return (float)(((java.lang.Double) this.hitboxExpander.getValue()).doubleValue() * 0.1);
    }

    public void onRenderOverlay(net.minecraft.class_332 arg0, float arg1) {
        this.renderWorldHitboxes(arg0, arg1);
        return;
    }

    public void renderWorldHitboxes(net.minecraft.class_332 arg0, float arg1) {
        // if (this.isEnabled() == 0) -> offset 23
        // if (((java.lang.Boolean) this.showHitbox.getValue()).booleanValue() != 0) -> offset 24
        return;
        v3 = net.minecraft.class_310.method_1551();
        // if (v3 == null) -> offset 46
        // if (v3.field_1724 == null) -> offset 46
        // if (v3.field_1687 != null) -> offset 47
        return;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 74
        // if (com.viper.client.utils.WeaponUtils.isHoldingWeapon(v3.field_1724) != 0) -> offset 74
        return;
        v4 = com.viper.client.utils.WorldProjectionUtils.captureCameraFrame(arg0, 1.0f);
        // if (v4 != null) -> offset 87
        return;
        v5 = Math.max(0.0, (((java.lang.Double) this.hitboxExpander.getValue()).doubleValue() * 0.1));
        v7 = this.lineWidth.floatValue();
        v8 = this.resolveHitboxArgb();
        v9 = v3.field_1687.method_18112().iterator();
        // if (v9.hasNext() == 0) -> offset 292
        v10 = ((net.minecraft.class_1297) v9.next());
        // if (com.viper.client.utils.TargetUtils.matchesPlayersOnly(v10, v3.field_1724, ((java.lang.Boolean) this.playersOnly.getValue()).booleanValue()) != 0) -> offset 194
        // if (Double.compare(v3.field_1724.method_5858(v10), 2304.0) <= 0) -> offset 213
        v11 = v10.method_30950(arg1);
        v12 = v10.method_30950(1.0f);
        v13 = v10.method_5829().method_989((v11.field_1352 - v12.field_1352), (v11.field_1351 - v12.field_1351), (v11.field_1350 - v12.field_1350)).method_1014(v5);
        com.viper.client.utils.WorldProjectionUtils.drawWorldBoxWireframe(arg0, v4, v13, v7, v8);
        return;
    }

    private int resolveHitboxArgb() {
        // if (this.colorMode.is("Rainbow") == 0) -> offset 41
        return -369098752;
        // if (this.colorMode.is("Red") == 0) -> offset 58
        return -352371876;
        // if (this.colorMode.is("Cyan") == 0) -> offset 75
        return -369039873;
        // if (this.colorMode.is("Emerald") == 0) -> offset 92
        return -366811766;
        // if (this.colorMode.is("Gold") == 0) -> offset 109
        return -352338386;
        // if (this.colorMode.is("Violet") == 0) -> offset 126
        return -358066697;
        return this.hitboxColor.getArgb(0.9200000166893005f);
    }

    private int resolveHitboxArgbForRender(com.viper.client.modules.Setting.ColorSetting arg0, float arg1) {
        return this.resolveHitboxArgb();
    }

}
