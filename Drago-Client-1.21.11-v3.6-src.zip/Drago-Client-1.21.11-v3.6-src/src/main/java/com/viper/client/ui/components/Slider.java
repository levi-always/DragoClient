package com.viper.client.ui.components;

public final class Slider extends com.viper.client.ui.components.UIComponent {
    private final com.viper.client.modules.Setting.NumberSetting setting;
    private boolean dragging;
    private float fillAnim;
    private float dragAnim;

    public Slider(com.viper.client.modules.Setting.NumberSetting arg0) {
        super();
        this.dragging = 0;
        this.dragAnim = 0.0f;
        this.setting = arg0;
        this.fillAnim = (float)arg0.getNormalizedProgress();
        this.setDescription(arg0.getDescription());
        this.setVisibleSupplier(arg0.getVisibleCondition());
        return;
    }

    protected void onHidden() {
        this.dragging = 0;
        return;
    }

    public com.viper.client.modules.Setting.NumberSetting getSetting() {
        return this.setting;
    }

    public boolean isDragging() {
        return this.dragging;
    }

    private void updateValueFromMouse(double arg0) {
        v3 = (this.x + 8);
        v4 = Math.max(12, (this.width - 16));
        v5 = Math.max(0.0, Math.min(1.0, ((arg0 - (double)v3) / (double)v4)));
        v7 = (this.setting.getMin() + (v5 * (this.setting.getMax() - this.setting.getMin())));
        this.setting.setValue(Double.valueOf(v7));
        return;
    }

    public void render(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, com.viper.client.ui.ThemeManager arg2, int arg3, int arg4, float arg5) {
        this.updateBaseAnimations((double)arg3, (double)arg4, arg5);
        // if (this.dragging == 0) -> offset 26
        this.updateValueFromMouse((double)arg3);
        v7 = (float)this.setting.getNormalizedProgress();
        this.fillAnim = com.viper.client.utils.AnimUtils.damp(this.fillAnim, v7, 22.0f, arg5);
        // if (this.dragging == 0) -> offset 69
        // if (this.hovered == 0) -> offset 81
        1.0f.dragAnim = com.viper.client.utils.AnimUtils.damp(0.44999998807907104f, 0.0f, 18.0f, arg5);
        this.pushInteractiveScale(arg0, 0.012000000104308128f);
        v8 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.settingsDrawerBg(), arg2.cardHoverBg(), (this.hoverAnim * 0.6499999761581421f)));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, this.x, this.y, this.width, this.height, v8);
        // if (this.dragging == 0) -> offset 177
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(this.x, this.y, this.width, this.height, this, arg2.accentSecondary().applyAlpha(arg2.borderSubtle()));
        v9 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.textSecondary(), arg2.textPrimary(), Math.max((this.hoverAnim * 0.5f), this.dragAnim)));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, this.setting.getName(), (this.x + 8), (this.y + 4), v9, 0);
        v10 = this.setting.formatDisplay();
        v11 = com.viper.client.utils.AtlasRenderer.getTextWidth(arg1, v10);
        v12 = (v11 + 10);
        v13 = (((this.x + this.width) - v12) - 6);
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v13, (this.y + 3), v12, 11, this.applyAlpha(arg2.accentSoftBg()));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, v10, (v13 + 5), (this.y + 4), this.applyAlpha(arg2.accentSecondary()), 0);
        v14 = (this.x + 8);
        v15 = ((this.y + this.height) - 8);
        v16 = Math.max(12, (this.width - 16));
        v17 = 4;
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v14, v15, v16, v17, this.applyAlpha(arg2.controlTrackBg()));
        v18 = Math.round(((float)v16 * com.viper.client.utils.AnimUtils.clamp01(this.fillAnim)));
        // if (v18 <= 1) -> offset 451
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, v14, v15, Math.max(4, v18), v17, this.applyAlpha(arg2.accentSecondary()), this.applyAlpha(arg2.accentPrimary()));
        // if (this.dragging == 0) -> offset 463
        v19 = 8;
        v20 = (v14 + v18);
        v21 = (v15 + (v17 / 2));
        // if (Double.compare(this.dragAnim, 0.03999999910593033f) <= 0) -> offset 525
        v22 = this.applyAlpha(com.viper.client.utils.AnimUtils.withAlpha(arg2.accentSecondary(), (0.4000000059604645f * this.dragAnim)));
        com.viper.client.utils.AtlasRenderer.drawRadialGlow(arg0, v20, v21, 10, v22);
        com.viper.client.utils.AtlasRenderer.drawCircle(arg0, (v20 - (v19 / 2)), (v21 - (v19 / 2)), v19, this.applyAlpha(-1));
        this.popInteractiveScale(arg0);
        return;
    }

    public boolean mouseClicked(double arg0, double arg1, int arg2) {
        // if (arg2 != 0) -> offset 30
        // if (this.isMouseOver(arg0, arg1) == 0) -> offset 30
        this.dragging = 1;
        this.updateValueFromMouse(arg0);
        this.triggerPress();
        return true;
        return false;
    }

    public boolean mouseDragged(double arg0, double arg1, int arg2, double arg3, double arg4) {
        // if (this.dragging == 0) -> offset 19
        // if (arg2 != 0) -> offset 19
        this.updateValueFromMouse(arg0);
        return true;
        return false;
    }

    public boolean mouseReleased(double arg0, double arg1, int arg2) {
        // if (this.dragging == 0) -> offset 19
        // if (arg2 != 0) -> offset 19
        this.dragging = 0;
        return true;
        return false;
    }

}
