package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_315.class})
public abstract class GameOptionsMixin {
    public GameOptionsMixin() {
        super();
        return;
    }

    @Inject(method = {"method_57703"}, at = {@At("HEAD")}, cancellable = true)
    private void viper$getMenuBlurRadius(org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable arg0) {
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 != null) -> offset 9
        return;
        v5 = v2.field_1755;
        // if ((v5 instanceof com.viper.client.ui.ViperClickGuiScreen) == 0) -> offset 53
        v3 = ((com.viper.client.ui.ViperClickGuiScreen) v5);
        v5 = Math.round((5.0f * v3.getOpenProgress()));
        arg0.setReturnValue(Integer.valueOf(v5));
        v5 = v2.field_1755;
        // if ((v5 instanceof com.viper.client.ui.HudEditorScreen) == 0) -> offset 96
        v4 = ((com.viper.client.ui.HudEditorScreen) v5);
        v5 = Math.round((4.0f * v4.getOpenProgress()));
        arg0.setReturnValue(Integer.valueOf(v5));
        return;
    }

}
