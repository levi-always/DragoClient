package com.viper.client.modules.hacks.render;

public final class Nametags extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.ModeSetting targetFilter;
    private final com.viper.client.modules.Setting.BooleanSetting showHealth;
    private final com.viper.client.modules.Setting.BooleanSetting showPing;
    private final com.viper.client.modules.Setting.BooleanSetting showDistance;
    private final com.viper.client.modules.Setting.BooleanSetting showHeld;
    private final com.viper.client.modules.Setting.ColorSetting accentColor;
    private final com.viper.client.modules.Setting.NumberSetting scale;
    private final com.viper.client.modules.Setting.NumberSetting opacity;

    public Nametags() {
        super("nametags", "Nametags", "Crisp distance-independent nameplates with HP and ping.", com.viper.client.modules.Category.RENDER, "nametags", -1);
        new java.lang.String[3][0] = "Players";
        new java.lang.String[3][1] = "Mobs";
        new java.lang.String[3][2] = "All";
        this.targetFilter = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("target", "Target", "Entities showing enhanced nametags", "Players", new java.lang.String[3])));
        this.showHealth = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("show_health", "Health", "Append numeric health + absorption", 1)));
        this.showPing = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("show_ping", "Ping", "Append player latency in ms", 1)));
        this.showDistance = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("show_distance", "Distance", "Append distance in meters", 1)));
        this.showHeld = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("show_held", "Held Item", "Display main-hand item above nameplate", 0)));
        this.accentColor = ((com.viper.client.modules.Setting.ColorSetting) this.registerSetting(new com.viper.client.modules.Setting.ColorSetting("color", "Color", "Border accent color", 14427686)));
        this.scale = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("scale", "Size", "Nametag plate scale", 1.0, 0.65, 1.8, 0.05, "x")));
        this.opacity = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("opacity", "Opacity", "Nametag background opacity", 88.0, 20.0, 100.0, 5.0, "%")));
        return;
    }

    public void onRenderOverlay(net.minecraft.class_332 arg0, float arg1) {
        v3 = net.minecraft.class_310.method_1551();
        // if (v3 == null) -> offset 29
        // if (v3.field_1724 == null) -> offset 29
        // if (v3.field_1687 == null) -> offset 29
        // if (v3.field_1772 != null) -> offset 30
        return;
        v4 = com.viper.client.utils.WorldProjectionUtils.captureCameraFrame(arg0, com.viper.client.modules.hacks.render.Zoom.getActiveDivisorSnapshot());
        // if (v4 != null) -> offset 45
        return;
        v5 = v3.field_1772;
        v6 = (this.scale.floatValue() * 0.8799999952316284f);
        v7 = (this.opacity.floatValue() / 100.0f);
        v8 = v3.field_1687.method_18112().iterator();
        // if (v8.hasNext() == 0) -> offset 852
        v9 = ((net.minecraft.class_1297) v8.next());
        // if (com.viper.client.utils.TargetUtils.matchesTargetFilter(v9, v3.field_1724, ((java.lang.String) this.targetFilter.getValue())) != 0) -> offset 136
        // if ((v9 instanceof net.minecraft.class_1309) == 0) -> offset 89
        v10 = ((net.minecraft.class_1309) v9);
        v11 = (v9.field_6014 + ((v9.method_23317() - v9.field_6014) * (double)arg1));
        v13 = (((v9.field_6036 + ((v9.method_23318() - v9.field_6036) * (double)arg1)) + (double)v9.method_17682()) + 0.36);
        v15 = (v9.field_5969 + ((v9.method_23321() - v9.field_5969) * (double)arg1));
        v17 = com.viper.client.utils.WorldProjectionUtils.projectWorldPoint(v4, v11, v13, v15);
        // if (v17.visible() != 0) -> offset 252
        v18 = v9.method_5477().getString();
        // if (((java.lang.Boolean) this.showHealth.getValue()).booleanValue() == 0) -> offset 313
        new java.lang.Object[1][0] = Float.valueOf((v10.method_6032() + v10.method_6067()));
        v19 = "";
        v20 = "";
        // if (((java.lang.Boolean) this.showPing.getValue()).booleanValue() == 0) -> offset 396
        // if ((v9 instanceof net.minecraft.class_1657) == 0) -> offset 396
        v21 = ((net.minecraft.class_1657) v9);
        // if (v3.method_1562() == null) -> offset 396
        v22 = v3.method_1562().method_2871(v21.method_5667());
        // if (v22 == null) -> offset 388
        v20 = makeConcatWithConstants(0);
        // if (((java.lang.Boolean) this.showDistance.getValue()).booleanValue() == 0) -> offset 443
        new java.lang.Object[1][0] = Float.valueOf(v3.field_1724.method_5739(v9));
        v21 = "";
        v22 = makeConcatWithConstants(v18, v20, v21, v19);
        v23 = (v5.method_1727(v22) + 10);
        arg0.method_51448().pushMatrix();
        arg0.method_51448().translate(v17.x(), v17.y());
        arg0.method_51448().scale(v6, v6);
        v24 = ((-v23) / 2);
        v25 = -12;
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v24, v25, v23, 14, com.viper.client.utils.AnimUtils.withAlpha(-536278773, v7));
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, v24, v25, v23, 14, this.accentColor.getArgb((v7 * 0.8500000238418579f)));
        v26 = (v24 + 5);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, v5, v18, v26, (v25 + 3), com.viper.client.utils.AnimUtils.withAlpha(-1, v7), 0);
        v26 = (v26 + v5.method_1727(v18));
        // if (v20.isEmpty() != 0) -> offset 651
        com.viper.client.utils.AtlasRenderer.drawText(arg0, v5, v20, v26, (v25 + 3), com.viper.client.utils.AnimUtils.withAlpha(-6184534, v7), 0);
        v26 = (v26 + v5.method_1727(v20));
        // if (v21.isEmpty() != 0) -> offset 694
        com.viper.client.utils.AtlasRenderer.drawText(arg0, v5, v21, v26, (v25 + 3), com.viper.client.utils.AnimUtils.withAlpha(-2829096, v7), 0);
        v26 = (v26 + v5.method_1727(v21));
        // if (v19.isEmpty() != 0) -> offset 757
        v27 = com.viper.client.utils.AnimUtils.clamp01((v10.method_6032() / Math.max(1.0f, v10.method_6063())));
        v28 = com.viper.client.utils.AnimUtils.lerpColor(-1096636, -14498466, v27);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, v5, v19, v26, (v25 + 3), com.viper.client.utils.AnimUtils.withAlpha(v28, v7), 0);
        // if (((java.lang.Boolean) this.showHeld.getValue()).booleanValue() == 0) -> offset 841
        v27 = v10.method_6047();
        // if (v27 == null) -> offset 841
        // if (v27.method_7960() != 0) -> offset 841
        v28 = v27.method_7964().getString();
        v29 = v5.method_1727(v28);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, v5, v28, ((-v29) / 2), (v25 - 10), com.viper.client.utils.AnimUtils.withAlpha(-1776409, v7), 1);
        arg0.method_51448().popMatrix();
        return;
    }

    public String getHudMetadata() {
        return this.scale.formatDisplay();
    }

}
