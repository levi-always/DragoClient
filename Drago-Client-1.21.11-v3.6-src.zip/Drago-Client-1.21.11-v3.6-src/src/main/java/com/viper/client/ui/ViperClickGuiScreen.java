package com.viper.client.ui;

public final class ViperClickGuiScreen extends net.minecraft.class_437 {
    private final com.viper.client.ViperClient viper;
    private com.viper.client.ui.ViperClickGuiScreen.PanelSection activeSection;
    private com.viper.client.modules.Category selectedCategory;
    private String searchQuery;
    private boolean searchFocused;
    private com.viper.client.modules.Module inlineListeningModule;
    private String themeGroupFilter;
    private float openAnim;
    private boolean closing;
    private float lastCenterX;
    private float lastCenterY;
    private float lastUiScale;
    private boolean sidePillInit;
    private float sidePillY;
    private float sidePillH;
    private float scrollOffset;
    private float targetScrollOffset;
    private int maxScroll;
    private long lastFrameNs;
    private final com.viper.client.modules.Setting.NumberSetting uiScaleSetting;
    private final com.viper.client.ui.components.Slider uiScaleSlider;
    private final com.viper.client.ui.components.Toggle customFontToggle;
    private final com.viper.client.ui.components.Toggle darkModeToggle;
    private final com.viper.client.ui.components.Toggle watermarkToggle;
    private final com.viper.client.ui.components.Toggle arrayListToggle;
    private final com.viper.client.ui.components.Toggle menuBlurToggle;
    private final com.viper.client.ui.components.Keybind guiOpenKeybind;
    private final com.viper.client.ui.components.Button openHudEditorButton;
    private final com.viper.client.ui.components.Button resetDefaultsButton;
    private final java.util.Map moduleControls;
    private com.viper.client.ui.ViperClickGuiScreen.HitBox searchBoxRect;
    private com.viper.client.ui.ViperClickGuiScreen.HitBox searchClearRect;
    private com.viper.client.ui.ViperClickGuiScreen.HitBox quickConfigRect;
    private com.viper.client.ui.ViperClickGuiScreen.HitBox closeBtnRect;
    private com.viper.client.ui.ViperClickGuiScreen.HitBox saveProfileBtnRect;
    private final java.util.List sidebarRects;
    private final java.util.List segmentRects;
    private final java.util.List visibleCardHeaders;
    private final java.util.List visibleConfigRects;
    private final java.util.List visibleThemeRects;
    private int viewportTop;
    private int viewportBottom;
    private int viewportLeft;
    private int viewportRight;

    public ViperClickGuiScreen(com.viper.client.ViperClient arg0) {
        super(net.minecraft.class_2561.method_43470("DRAGO Client"));
        this.activeSection = com.viper.client.ui.ViperClickGuiScreen.PanelSection.MODULES;
        this.selectedCategory = com.viper.client.modules.Category.COMBAT;
        this.searchQuery = "";
        this.searchFocused = 0;
        this.inlineListeningModule = null;
        this.themeGroupFilter = "All";
        this.openAnim = 0.0f;
        this.closing = 0;
        this.lastCenterX = 0.0f;
        this.lastCenterY = 0.0f;
        this.lastUiScale = 1.0f;
        this.sidePillInit = 0;
        this.sidePillY = 0.0f;
        this.sidePillH = 26.0f;
        this.scrollOffset = 0.0f;
        this.targetScrollOffset = 0.0f;
        this.maxScroll = 0;
        this.lastFrameNs = System.nanoTime();
        this.moduleControls = new java.util.LinkedHashMap();
        this.searchBoxRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(0, 0, 0, 0);
        this.searchClearRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(0, 0, 0, 0);
        this.quickConfigRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(0, 0, 0, 0);
        this.closeBtnRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(0, 0, 0, 0);
        this.saveProfileBtnRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(0, 0, 0, 0);
        this.sidebarRects = new java.util.ArrayList();
        this.segmentRects = new java.util.ArrayList();
        this.visibleCardHeaders = new java.util.ArrayList();
        this.visibleConfigRects = new java.util.ArrayList();
        this.visibleThemeRects = new java.util.ArrayList();
        this.viewportTop = 0;
        this.viewportBottom = 0;
        this.viewportLeft = 0;
        this.viewportRight = 0;
        this.viper = arg0;
        v2 = arg0.getThemeManager();
        v3 = arg0.getModuleManager();
        this.uiScaleSetting = new com.viper.client.modules.Setting.NumberSetting("ui_scale", "UI Scale", "Menu interface scale (1-6, 3 to 4 is natural default)", v2.getUiScale(), 1.0, 6.0, 0.25, "x");
        this.uiScaleSlider = new com.viper.client.ui.components.Slider(this.uiScaleSetting);
        java.util.Objects.requireNonNull(v2);
        this.customFontToggle = new com.viper.client.ui.components.Toggle("Smooth Custom Font (NotoSans)", "Anti-aliased proportional vector sans font across the ClickGUI", getAsBoolean(v2), accept(v2, arg0));
        java.util.Objects.requireNonNull(v2);
        this.darkModeToggle = new com.viper.client.ui.components.Toggle("Obsidian Glass Dark Surface", "Toggle between Dark Glass and Daylight Glass", getAsBoolean(v2), accept(v2, arg0));
        java.util.Objects.requireNonNull(v2);
        this.watermarkToggle = new com.viper.client.ui.components.Toggle("HUD Watermark (DRAGO)", "Display floating DRAGO watermark on screen", getAsBoolean(v2), accept(v2, arg0));
        java.util.Objects.requireNonNull(v2);
        this.arrayListToggle = new com.viper.client.ui.components.Toggle("HUD Active ArrayList", "Display active modules beneath HUD watermark", getAsBoolean(v2), accept(v2, arg0));
        java.util.Objects.requireNonNull(v2);
        this.menuBlurToggle = new com.viper.client.ui.components.Toggle("Minecraft Backdrop Blur", "Apply native blur behind panel (disable for max FPS)", getAsBoolean(v2), accept(v2, arg0));
        java.util.Objects.requireNonNull(v2);
        this.guiOpenKeybind = new com.viper.client.ui.components.Keybind("ClickGUI Open Key", "Shortcut key to open or close DRAGO", getAsInt(v2), accept(v2, arg0));
        this.openHudEditorButton = new com.viper.client.ui.components.Button("Open Drag & Drop HUD Editor", "Reposition Watermark and ArrayList anywhere on screen", com.viper.client.ui.Icons.HUD_EDITOR, 1, run(this, arg0), null);
        this.resetDefaultsButton = new com.viper.client.ui.components.Button("Reset All Factory Defaults", "Restore module sliders, dropdowns, and HUD positions", com.viper.client.ui.Icons.RESET, run(this, v2, v3, arg0));
        v4 = v3.getModules().iterator();
        // if (v4.hasNext() == 0) -> offset 1057
        v5 = ((com.viper.client.modules.Module) v4.next());
        v6 = new java.util.ArrayList();
        v7 = new java.util.ArrayList();
        v8 = new java.util.ArrayList();
        v9 = v5.getSettings().iterator();
        // if (v9.hasNext() == 0) -> offset 929
        v10 = ((com.viper.client.modules.Setting) v9.next());
        // if ((v10 instanceof com.viper.client.modules.Setting.BooleanSetting) == 0) -> offset 718
        v12 = ((com.viper.client.modules.Setting.BooleanSetting) v10);
        v6.add(new com.viper.client.ui.components.Toggle(v12));
        // if ((v10 instanceof com.viper.client.modules.Setting.ModeSetting) == 0) -> offset 766
        v12 = ((com.viper.client.modules.Setting.ModeSetting) v10);
        v11 = new com.viper.client.ui.components.Dropdown(v12);
        v7.add(((com.viper.client.ui.components.Dropdown) v11));
        v6.add(v11);
        // if ((v10 instanceof com.viper.client.modules.Setting.NumberSetting) == 0) -> offset 799
        v12 = ((com.viper.client.modules.Setting.NumberSetting) v10);
        v6.add(new com.viper.client.ui.components.Slider(v12));
        // if ((v10 instanceof com.viper.client.modules.Setting.KeybindSetting) == 0) -> offset 878
        v12 = ((com.viper.client.modules.Setting.KeybindSetting) v10);
        java.util.Objects.requireNonNull(v12);
        java.util.Objects.requireNonNull(v12);
        v13 = new com.viper.client.ui.components.Keybind(v12.getName(), v12.getDescription(), getAsInt(v12), accept(v12));
        v13.setVisibleSupplier(v12.getVisibleCondition());
        v6.add(v13);
        // if ((v10 instanceof com.viper.client.modules.Setting.ColorSetting) != 0) -> offset 889
        v12 = ((com.viper.client.modules.Setting.ColorSetting) v10);
        v11 = new com.viper.client.ui.components.ColorPicker(v12);
        v8.add(((com.viper.client.ui.components.ColorPicker) v11));
        v6.add(v11);
        v9 = v7.iterator();
        // if (v9.hasNext() == 0) -> offset 977
        v10 = ((com.viper.client.ui.components.Dropdown) v9.next());
        v10.setOnOpenCallback(run(v7, v10, v8));
        v9 = v8.iterator();
        // if (v9.hasNext() == 0) -> offset 1025
        v10 = ((com.viper.client.ui.components.ColorPicker) v9.next());
        v10.setOnOpenCallback(run(v8, v10, v7));
        v6.add(new com.viper.client.ui.components.Keybind(v5));
        this.moduleControls.put(v5, v6);
        return;
    }

    protected void method_25426() {
        this.openAnim = 0.0f;
        this.closing = 0;
        this.lastFrameNs = System.nanoTime();
        this.uiScaleSetting.setValue(Double.valueOf(this.viper.getThemeManager().getUiScale()));
        return;
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25419() {
        // if (this.closing != 0) -> offset 12
        this.closing = 1;
        return;
    }

    public float getOpenProgress() {
        return com.viper.client.utils.AnimUtils.easeOutCubic(com.viper.client.utils.AnimUtils.clamp01(this.openAnim));
    }

    private float toUiX(double arg0) {
        // if (Double.compare(this.lastUiScale, 0.9990000128746033f) >= 0) -> offset 22
        // if (Double.compare(this.lastUiScale, 0.10000000149011612f) > 0) -> offset 25
        return (float)arg0;
        return (this.lastCenterX + (((float)arg0 - this.lastCenterX) / this.lastUiScale));
    }

    private float toUiY(double arg0) {
        // if (Double.compare(this.lastUiScale, 0.9990000128746033f) >= 0) -> offset 22
        // if (Double.compare(this.lastUiScale, 0.10000000149011612f) > 0) -> offset 25
        return (float)arg0;
        return (this.lastCenterY + (((float)arg0 - this.lastCenterY) / this.lastUiScale));
    }

    private boolean isSearchActive() {
        // if (this.searchQuery.trim().isEmpty() != 0) -> offset 17
        return false;
    }

    private void collapseModulePopups(com.viper.client.modules.Module arg0) {
        v2 = ((java.util.List) this.moduleControls.getOrDefault(arg0, java.util.List.of())).iterator();
        // if (v2.hasNext() == 0) -> offset 110
        v3 = ((com.viper.client.ui.components.UIComponent) v2.next());
        // if ((v3 instanceof com.viper.client.ui.components.Dropdown) == 0) -> offset 63
        v4 = ((com.viper.client.ui.components.Dropdown) v3);
        v4.setExpanded(0);
        // if ((v3 instanceof com.viper.client.ui.components.ColorPicker) == 0) -> offset 85
        v4 = ((com.viper.client.ui.components.ColorPicker) v3);
        v4.setExpanded(0);
        // if ((v3 instanceof com.viper.client.ui.components.Keybind) != 0) -> offset 95
        v4 = ((com.viper.client.ui.components.Keybind) v3);
        v4.setListening(0);
        return;
    }

    public void method_25420(net.minecraft.class_332 arg0, int arg1, int arg2, float arg3) {
        v5 = this.getOpenProgress();
        // if (this.viper.getThemeManager().isMenuBlurEnabled() == 0) -> offset 32
        // if (Double.compare(v5, 0.05000000074505806f) <= 0) -> offset 32
        arg0.method_71278();
        arg0.method_25294(0, 0, this.field_22789, this.field_22790, com.viper.client.utils.AnimUtils.withAlpha(this.viper.getThemeManager().backdropTint(), Math.max(0.05000000074505806f, v5)));
        return;
    }

    public void method_25394(net.minecraft.class_332 arg0, int arg1, int arg2, float arg3) {
        v5 = System.nanoTime();
        v7 = Math.max(0.0010000000474974513f, Math.min(0.05999999865889549f, ((float)(v5 - this.lastFrameNs) / 1000000000.0f)));
        this.lastFrameNs = v5;
        v8 = this.viper.getThemeManager();
        v8.updateAnimation(v7);
        // if (this.closing == 0) -> offset 69
        this.openAnim.openAnim = com.viper.client.utils.AnimUtils.damp(0.0f, 1.0f, 28.0f, v7);
        // if (this.closing == 0) -> offset 115
        // if (Double.compare(this.openAnim, 0.029999999329447746f) > 0) -> offset 115
        // if (this.field_22787 == null) -> offset 114
        this.field_22787.method_1507(null);
        return;
        v9 = this.getOpenProgress();
        this.scrollOffset = com.viper.client.utils.AnimUtils.damp(this.scrollOffset, this.targetScrollOffset, 22.0f, v7);
        this.sidebarRects.clear();
        this.segmentRects.clear();
        this.visibleCardHeaders.clear();
        this.visibleConfigRects.clear();
        this.visibleThemeRects.clear();
        v10 = Math.min(620, Math.max(460, (this.field_22789 - 48)));
        v11 = Math.min(395, Math.max(290, (this.field_22790 - 44)));
        v12 = ((this.field_22789 - v10) / 2);
        v13 = ((this.field_22790 - v11) / 2);
        v14 = com.viper.client.utils.AnimUtils.clamp((float)(v8.getUiScale() / 4.0), 0.44999998807907104f, 1.4500000476837158f);
        v15 = Math.min(((float)Math.max(120, (this.field_22789 - 14)) / (float)v10), ((float)Math.max(120, (this.field_22790 - 14)) / (float)v11));
        v16 = ((0.8999999761581421f + (0.10000000149011612f * v9)) * Math.min(v14, Math.max(0.44999998807907104f, v15)));
        v17 = ((1.0f - v9) * 14.0f);
        this.lastCenterX = ((float)v12 + ((float)v10 * 0.5f));
        this.lastCenterY = ((float)v13 + ((float)v11 * 0.5f));
        this.lastUiScale = v16;
        v18 = Math.round(this.toUiX((double)arg1));
        v19 = Math.round(this.toUiY((double)arg2));
        arg0.method_51448().pushMatrix();
        arg0.method_51448().translate(this.lastCenterX, (this.lastCenterY + v17));
        arg0.method_51448().scale(v16, v16);
        arg0.method_51448().translate((-this.lastCenterX), (-this.lastCenterY));
        com.viper.client.ui.glass.GlassRenderer.drawGlassPanel(arg0, v12, v13, v10, v11, com.viper.client.utils.AnimUtils.withAlpha(v8.windowBg(), v9), com.viper.client.utils.AnimUtils.withAlpha(v8.borderStrong(), v9), (v9 * 0.699999988079071f));
        com.viper.client.ui.glass.GlassRenderer.drawCornerGlows(arg0, v12, v13, v10, v11, v8.accentSecondary(), v8.accentPrimary(), 36, (0.0f * v9));
        v20 = 148;
        com.viper.client.ui.glass.GlassRenderer.drawGlassPanel(arg0, (v12 + 6), (v13 + 6), (v20 - 8), (v11 - 12), com.viper.client.utils.AnimUtils.withAlpha(v8.sidebarBg(), v9), com.viper.client.utils.AnimUtils.withAlpha(v8.borderSubtle(), v9), (v9 * 0.6499999761581421f));
        this.renderSidebar(arg0, v8, (v12 + 6), (v13 + 6), (v20 - 8), (v11 - 12), v18, v19, v7, v9);
        v21 = ((v12 + v20) + 6);
        v22 = ((v10 - v20) - 14);
        v23 = (v13 + 10);
        v24 = 34;
        this.renderTopBar(arg0, v8, v21, v23, v22, v24, v18, v19, v9);
        this.viewportLeft = v21;
        this.viewportRight = (v21 + v22);
        this.viewportTop = ((v23 + v24) + 8);
        this.viewportBottom = ((v13 + v11) - 12);
        v25 = Math.max(80, (this.viewportBottom - this.viewportTop));
        arg0.method_44379((this.viewportLeft - 2), (this.viewportTop - 2), (this.viewportRight + 2), (this.viewportBottom + 2));
        // if (this.isSearchActive() == 0) -> offset 789
        this.renderModulesView(arg0, v8, v21, this.viewportTop, v22, v25, v18, v19, v7, v9);
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.THEMES) -> offset 827
        this.renderThemesView(arg0, v8, v21, this.viewportTop, v22, v25, v18, v19, v7, v9);
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS) -> offset 865
        this.renderSettingsView(arg0, v8, v21, this.viewportTop, v22, v25, v18, v19, v7, v9);
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.CONFIGS) -> offset 903
        this.renderConfigsView(arg0, v8, v21, this.viewportTop, v22, v25, v18, v19, v7, v9);
        this.renderModulesView(arg0, v8, v21, this.viewportTop, v22, v25, v18, v19, v7, v9);
        arg0.method_44380();
        v26 = this;
        arg0.method_44380();
        throw v26;
        arg0.method_51448().popMatrix();
        v27 = /*?*/;
        arg0.method_51448().popMatrix();
        throw v27;
        return;
    }

    private void renderSidebar(net.minecraft.class_332 arg0, com.viper.client.ui.ThemeManager arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, float arg8, float arg9) {
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, (arg2 + 10), (arg3 + 10), 24, 24, com.viper.client.utils.AnimUtils.withAlpha(arg1.accentSecondary(), arg9), com.viper.client.utils.AnimUtils.withAlpha(arg1.accentPrimary(), arg9));
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.VIPER_LOGO, (arg2 + 15), (arg3 + 15), 14, com.viper.client.utils.AnimUtils.withAlpha(-1, arg9));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "DRAGO", (arg2 + 40), (arg3 + 13), com.viper.client.utils.AnimUtils.withAlpha(arg1.textPrimary(), arg9), 0);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "v3.6", (arg2 + 40), (arg3 + 24), com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg9), 0);
        v14 = java.util.List.of(new com.viper.client.ui.ViperClickGuiScreen.1NavDef("Combat", com.viper.client.ui.Icons.COMBAT, com.viper.client.ui.ViperClickGuiScreen.PanelSection.MODULES, com.viper.client.modules.Category.COMBAT, 0), new com.viper.client.ui.ViperClickGuiScreen.1NavDef("World", com.viper.client.ui.Icons.WORLD, com.viper.client.ui.ViperClickGuiScreen.PanelSection.MODULES, com.viper.client.modules.Category.WORLD, 0), new com.viper.client.ui.ViperClickGuiScreen.1NavDef("Render", com.viper.client.ui.Icons.RENDER, com.viper.client.ui.ViperClickGuiScreen.PanelSection.MODULES, com.viper.client.modules.Category.RENDER, 0), new com.viper.client.ui.ViperClickGuiScreen.1NavDef("Inventory", com.viper.client.ui.Icons.INVENTORY, com.viper.client.ui.ViperClickGuiScreen.PanelSection.MODULES, com.viper.client.modules.Category.INVENTORY, 0), new com.viper.client.ui.ViperClickGuiScreen.1NavDef("Settings", com.viper.client.ui.Icons.SETTINGS, com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS, null, 0));
        v15 = java.util.List.of(new com.viper.client.ui.ViperClickGuiScreen.1NavDef("Themes", com.viper.client.ui.Icons.THEMES, com.viper.client.ui.ViperClickGuiScreen.PanelSection.THEMES, null, 0), new com.viper.client.ui.ViperClickGuiScreen.1NavDef("Configs", com.viper.client.ui.Icons.CONFIGS, com.viper.client.ui.ViperClickGuiScreen.PanelSection.CONFIGS, null, 0), new com.viper.client.ui.ViperClickGuiScreen.1NavDef("HUD Editor", com.viper.client.ui.Icons.HUD_EDITOR, null, null, 1));
        v16 = (arg3 + 46);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "CATEGORIES", (arg2 + 12), v16, com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg9), 0);
        v16 += 13;
        v17 = null;
        v18 = new java.util.ArrayList();
        v19 = new java.util.ArrayList();
        v20 = v14.iterator();
        // if (v20.hasNext() == 0) -> offset 519
        v21 = ((com.viper.client.ui.ViperClickGuiScreen.1NavDef) v20.next());
        v22 = new com.viper.client.ui.ViperClickGuiScreen.HitBox((arg2 + 8), v16, (arg4 - 16), 23);
        this.sidebarRects.add(new com.viper.client.ui.ViperClickGuiScreen.SidebarItemRect(v21.sec(), v21.cat(), 0, v22));
        v18.add(v22);
        v19.add(v21);
        // if (this.isSearchActive() != 0) -> offset 498
        // if (v21.sec() != com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS) -> offset 464
        // if (this.activeSection == com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS) -> offset 494
        // if (v21.cat() == null) -> offset 498
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.MODULES) -> offset 498
        // if (this.selectedCategory != v21.cat()) -> offset 498
        v12 = 0;
        v23 = 0;
        // if (v12 == 0) -> offset 513
        v17 = v22;
        v16 += 25;
        v16 += 6;
        arg0.method_25294((arg2 + 12), v16, ((arg2 + arg4) - 12), (v16 + 1), com.viper.client.utils.AnimUtils.withAlpha(arg1.borderSubtle(), arg9));
        v16 += 8;
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "MISC", (arg2 + 12), v16, com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg9), 0);
        v16 += 13;
        v20 = v15.iterator();
        // if (v20.hasNext() == 0) -> offset 770
        v21 = ((com.viper.client.ui.ViperClickGuiScreen.1NavDef) v20.next());
        v22 = new com.viper.client.ui.ViperClickGuiScreen.HitBox((arg2 + 8), v16, (arg4 - 16), 23);
        this.sidebarRects.add(new com.viper.client.ui.ViperClickGuiScreen.SidebarItemRect(v21.sec(), v21.cat(), v21.hud(), v22));
        v18.add(v22);
        v19.add(v21);
        // if (this.isSearchActive() != 0) -> offset 749
        // if (v21.hud() != 0) -> offset 749
        // if (v21.sec() != com.viper.client.ui.ViperClickGuiScreen.PanelSection.THEMES) -> offset 724
        // if (this.activeSection == com.viper.client.ui.ViperClickGuiScreen.PanelSection.THEMES) -> offset 745
        // if (v21.sec() != com.viper.client.ui.ViperClickGuiScreen.PanelSection.CONFIGS) -> offset 749
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.CONFIGS) -> offset 749
        v12 = 0;
        v23 = 0;
        // if (v12 == 0) -> offset 764
        v17 = v22;
        v16 += 25;
        // if (v17 == null) -> offset 912
        // if (this.sidePillInit != 0) -> offset 810
        this.sidePillY = (float)v17.y();
        this.sidePillH = (float)v17.h();
        this.sidePillInit = 1;
        this.sidePillY = com.viper.client.utils.AnimUtils.damp(this.sidePillY, (float)v17.y(), 24.0f, arg8);
        this.sidePillH = com.viper.client.utils.AnimUtils.damp(this.sidePillH, (float)v17.h(), 24.0f, arg8);
        v20 = Math.round(this.sidePillY);
        v21 = Math.round(this.sidePillH);
        com.viper.client.ui.glass.GlassRenderer.drawGlassPill(arg0, v17.x(), v20, v17.w(), v21, com.viper.client.utils.AnimUtils.withAlpha(arg1.accentSoftBg(), arg9), com.viper.client.utils.AnimUtils.withAlpha(arg1.accentSecondary(), (0.550000011920929f * arg9)));
        v11 = 0;
        // if (v11 >= v18.size()) -> offset 1153
        v20 = ((com.viper.client.ui.ViperClickGuiScreen.HitBox) v18.get(v11));
        v21 = ((com.viper.client.ui.ViperClickGuiScreen.1NavDef) v19.get(v11));
        // if (v20 != v17) -> offset 960
        v12 = 0;
        v22 = v20.contains((double)arg6, (double)arg7);
        // if (v12 != 0) -> offset 1023
        // if (v22 == 0) -> offset 1023
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v20.x(), v20.y(), v20.w(), v20.h(), com.viper.client.utils.AnimUtils.withAlpha(arg1.cardHoverBg(), (0.5f * arg9)));
        // if (v12 == 0) -> offset 1035
        // if (v22 == 0) -> offset 1047
        v23 = com.viper.client.utils.AnimUtils.withAlpha(arg1.textSecondary(), arg9);
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, v21.icon(), (v20.x() + 8), (v20.y() + 6), 11, v23);
        // if (v12 != 0) -> offset 1097
        // if (v22 == 0) -> offset 1104
        v24 = com.viper.client.utils.AnimUtils.withAlpha(arg1.textSecondary(), arg9);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, v21.label(), (v20.x() + 25), (v20.y() + 7), v24, 0);
        v11 += 1;
        v11 = ((arg3 + arg5) - 32);
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, (arg2 + 8), v11, (arg4 - 16), 24, com.viper.client.utils.AnimUtils.withAlpha(arg1.cardBg(), arg9));
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, (arg2 + 8), v11, (arg4 - 16), 24, com.viper.client.utils.AnimUtils.withAlpha(arg1.borderSubtle(), arg9));
        com.viper.client.utils.AtlasRenderer.drawCircle(arg0, (arg2 + 15), (v11 + 7), 10, com.viper.client.utils.AnimUtils.withAlpha(arg1.accentSecondary(), arg9));
        com.viper.client.utils.AtlasRenderer.drawAutoFitText(arg0, this.field_22793, arg1.getActiveTheme().getDisplayName(), (arg2 + 30), (v11 + 8), (arg4 - 42), 0.8999999761581421f, com.viper.client.utils.AnimUtils.withAlpha(arg1.textPrimary(), arg9));
        return;
    }

    private void renderTopBar(net.minecraft.class_332 arg0, com.viper.client.ui.ThemeManager arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, float arg8) {
        com.viper.client.ui.glass.GlassRenderer.drawGlassPanel(arg0, arg2, arg3, arg4, arg5, com.viper.client.utils.AnimUtils.withAlpha(arg1.headerBg(), arg8), com.viper.client.utils.AnimUtils.withAlpha(arg1.borderSubtle(), arg8), (arg8 * 0.6000000238418579f));
        // if (this.isSearchActive() == 0) -> offset 57
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.THEMES) -> offset 73
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS) -> offset 89
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.CONFIGS) -> offset 105
        v10 = makeConcatWithConstants(this.selectedCategory.getDisplayName());
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, ((java.lang.String) v10), (arg2 + 12), (arg3 + 13), com.viper.client.utils.AnimUtils.withAlpha(arg1.textPrimary(), arg8), 0);
        this.closeBtnRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(((arg2 + arg4) - 28), (arg3 + 7), 20, 20);
        v11 = this.closeBtnRect.contains((double)arg6, (double)arg7);
        // if (v11 == 0) -> offset 223
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(this.closeBtnRect.x(), this.closeBtnRect.y(), 20, 20, 1726956612, com.viper.client.utils.AnimUtils.withAlpha(arg1.cardBg(), arg8));
        // if (v11 == 0) -> offset 268
        com.viper.client.utils.AtlasRenderer.drawIcon(com.viper.client.ui.Icons.CLOSE, (this.closeBtnRect.x() + 5), (this.closeBtnRect.y() + 5), 10, -1, com.viper.client.utils.AnimUtils.withAlpha(arg1.textSecondary(), arg8));
        v12 = 82;
        this.quickConfigRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(((this.closeBtnRect.x() - v12) - 6), (arg3 + 7), v12, 20);
        v13 = this.quickConfigRect.contains((double)arg6, (double)arg7);
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS) -> offset 368
        // if (v13 == 0) -> offset 380
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(this.quickConfigRect.y(), v12, 20, arg1.accentSoftBg(), arg1.cardHoverBg(), com.viper.client.utils.AnimUtils.withAlpha(arg1.cardBg(), arg8));
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS) -> offset 428
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(this.quickConfigRect.x(), this.quickConfigRect.y(), v12, 20, arg1.accentSecondary(), com.viper.client.utils.AnimUtils.withAlpha(arg1.borderSubtle(), arg8));
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.SETTINGS, (this.quickConfigRect.x() + 6), (this.quickConfigRect.y() + 5), 10, com.viper.client.utils.AnimUtils.withAlpha(arg1.accentSecondary(), arg8));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "Quick config", (this.quickConfigRect.x() + 19), (this.quickConfigRect.y() + 6), com.viper.client.utils.AnimUtils.withAlpha(arg1.textPrimary(), arg8), 0);
        v14 = Math.max(124, Math.min(188, (this.quickConfigRect.x() - (arg2 + 150))));
        this.searchBoxRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(((this.quickConfigRect.x() - v14) - 8), (arg3 + 7), v14, 20);
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, this.searchBoxRect.x(), this.searchBoxRect.y(), v14, 20, com.viper.client.utils.AnimUtils.withAlpha(arg1.dropdownBg(), arg8));
        // if (this.searchFocused == 0) -> offset 641
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(this.searchBoxRect.x(), this.searchBoxRect.y(), v14, 20, arg1.accentSecondary(), com.viper.client.utils.AnimUtils.withAlpha(arg1.borderSubtle(), arg8));
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.SEARCH, (this.searchBoxRect.x() + 6), (this.searchBoxRect.y() + 5), 10, com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg8));
        // if (this.searchQuery.isEmpty() != 0) -> offset 800
        this.searchClearRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(((this.searchBoxRect.x() + v14) - 18), (this.searchBoxRect.y() + 2), 16, 16);
        v15 = this.searchClearRect.contains((double)arg6, (double)arg7);
        // if (v15 == 0) -> offset 785
        com.viper.client.utils.AtlasRenderer.drawIcon(com.viper.client.ui.Icons.CLOSE, (this.searchClearRect.x() + 4), (this.searchClearRect.y() + 4), 8, -1, com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg8));
        this.searchClearRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(0, 0, 0, 0);
        // if (this.searchQuery.isEmpty() == 0) -> offset 844
        // if (this.searchFocused == 0) -> offset 838
        // if (this.searchFocused == 0) -> offset 861
        v15 = makeConcatWithConstants("|", "");
        // if (this.searchQuery.isEmpty() == 0) -> offset 894
        // if (this.searchFocused != 0) -> offset 894
        v16 = arg1.textPrimary();
        // if (this.searchQuery.isEmpty() == 0) -> offset 918
        v17 = (v14 - 38);
        com.viper.client.utils.AtlasRenderer.drawAutoFitText(arg0, this.field_22793, v15, (this.searchBoxRect.x() + 19), (this.searchBoxRect.y() + 6), v17, 0.9200000166893005f, com.viper.client.utils.AnimUtils.withAlpha(v16, arg8));
        return;
    }

    private void renderModulesView(net.minecraft.class_332 arg0, com.viper.client.ui.ThemeManager arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, float arg8, float arg9) {
        v13 = this.searchQuery.trim().toLowerCase(java.util.Locale.ROOT);
        v14 = new java.util.ArrayList();
        // if (v13.isEmpty() == 0) -> offset 49
        v15 = this.viper.getModuleManager().getVisibleModules();
        v16 = v15.iterator();
        // if (v16.hasNext() == 0) -> offset 275
        v17 = ((com.viper.client.modules.Module) v16.next());
        // if (v13.isEmpty() != 0) -> offset 264
        // if (v17.getName().toLowerCase(java.util.Locale.ROOT).contains(v13) != 0) -> offset 179
        // if (v17.getId().toLowerCase(java.util.Locale.ROOT).contains(v13) != 0) -> offset 179
        // if (v17.getDescription().toLowerCase(java.util.Locale.ROOT).contains(v13) != 0) -> offset 179
        // if (v17.getCategory().getDisplayName().toLowerCase(java.util.Locale.ROOT).contains(v13) == 0) -> offset 183
        v12 = 0;
        v18 = 0;
        // if (v12 != 0) -> offset 256
        v19 = v17.getSettings().iterator();
        // if (v19.hasNext() == 0) -> offset 256
        v20 = ((com.viper.client.modules.Setting) v19.next());
        // if (v20.getName().toLowerCase(java.util.Locale.ROOT).contains(v13) != 0) -> offset 250
        v12 = 1;
        // if (v12 != 0) -> offset 264
        v14.add(v17);
        // if (v14.isEmpty() == 0) -> offset 319
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "No matching modules found.", (arg2 + 12), (arg3 + 16), com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg9), 0);
        this.maxScroll = 0;
        return;
        v16 = 2;
        v17 = 8;
        v12 = ((arg4 - v17) / v16);
        new Object[2][0] = (arg3 - Math.round(this.scrollOffset));
        new Object[2][1] = (arg3 - Math.round(this.scrollOffset));
        v18 = new Object[2];
        v11 = 0;
        // if (v11 >= v14.size()) -> offset 1821
        v20 = ((com.viper.client.modules.Module) v14.get(v11));
        // if (v18[0] > v18[1]) -> offset 407
        v21 = 1;
        v22 = (arg2 + (v21 * (v12 + v17)));
        v23 = v18[v21];
        // if (v20.isEnabled() == 0) -> offset 448
        v20.getEnableAnim().setEnableAnim(com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 18.0f, arg8));
        // if (v20.isSettingsOpen() == 0) -> offset 479
        v20.getSettingsAnim().setSettingsAnim(com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 18.0f, arg8));
        v20.setPressAnim(com.viper.client.utils.AnimUtils.damp(v20.getPressAnim(), 0.0f, 20.0f, arg8));
        v24 = 44;
        // if (arg6 < v22) -> offset 552
        // if (arg6 > (v22 + v12)) -> offset 552
        // if (arg7 < v23) -> offset 552
        // if (arg7 > (v23 + v24)) -> offset 552
        v25 = 0;
        // if (v25 == 0) -> offset 571
        v20.getHoverAnim().setHoverAnim(com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 16.0f, arg8));
        v26 = ((java.util.List) this.moduleControls.getOrDefault(v20, java.util.List.of()));
        v27 = 8;
        v28 = v26.iterator();
        // if (v28.hasNext() == 0) -> offset 723
        v29 = ((com.viper.client.ui.components.UIComponent) v28.next());
        v29.updateVisibilityAnimation(arg8);
        v30 = com.viper.client.utils.AnimUtils.easeOutCubic(v29.getVisibilityAnim());
        // if (Double.compare(v30, 0.019999999552965164f) >= 0) -> offset 666
        // if ((v29 instanceof com.viper.client.ui.components.Slider) == 0) -> offset 679
        v19 = 22;
        v29.setBounds((v22 + 7), 0, (v12 - 14), v19);
        v27 = (v27 + Math.round(((float)(v29.getRenderedHeight() + 4) * v30)));
        v28 = com.viper.client.utils.AnimUtils.easeOutCubic(v20.getSettingsAnim());
        v29 = Math.round(((float)v27 * v28));
        v30 = (v24 + v29);
        v19 = com.viper.client.utils.AnimUtils.lerpColor(arg1.cardBg(), arg1.cardHoverBg(), Math.max((v20.getHoverAnim() * 0.47999998927116394f), (v20.getEnableAnim() * 0.2800000011920929f)));
        v31 = com.viper.client.utils.AnimUtils.lerpColor(arg1.borderSubtle(), arg1.accentSecondary(), Math.max((v20.getEnableAnim() * 0.7200000286102295f), (v20.getHoverAnim() * 0.3499999940395355f)));
        com.viper.client.ui.glass.GlassRenderer.drawGlassCard(arg0, v22, v23, v12, v30, com.viper.client.utils.AnimUtils.withAlpha(v19, arg9), com.viper.client.utils.AnimUtils.withAlpha(v31, arg9), arg1.accentPrimary(), ((v20.getEnableAnim() * 0.14000000059604645f) * arg9));
        // if (v20.isEnabled() == 0) -> offset 876
        v32 = arg1.settingsDrawerBg();
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, (v22 + 8), (v23 + 10), 24, 24, com.viper.client.utils.AnimUtils.withAlpha(v32, arg9));
        // if (v20.isEnabled() == 0) -> offset 943
        com.viper.client.utils.AtlasRenderer.drawIcon(com.viper.client.ui.Icons.of(v20.getIconName()), (v22 + 13), (v23 + 15), 14, arg1.accentSecondary(), com.viper.client.utils.AnimUtils.withAlpha(arg1.textSecondary(), arg9));
        // if (v20.isEnabled() == 0) -> offset 987
        com.viper.client.utils.AtlasRenderer.drawText(this.field_22793, v20.getName(), (v22 + 38), (v23 + 11), -1, com.viper.client.utils.AnimUtils.withAlpha(arg1.textPrimary(), arg9), 0);
        com.viper.client.utils.AtlasRenderer.drawAutoFitText(arg0, this.field_22793, v20.getDescription(), (v22 + 38), (v23 + 23), (v12 - 114), 0.8199999928474426f, com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg9));
        v33 = new com.viper.client.ui.ViperClickGuiScreen.HitBox(((v22 + v12) - 22), (v23 + 13), 16, 18);
        // if (v20.isSettingsOpen() == 0) -> offset 1096
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(v33.x(), v33.y(), 16, 18, arg1.accentSoftBg(), com.viper.client.utils.AnimUtils.withAlpha(arg1.settingsDrawerBg(), arg9));
        // if (v20.isSettingsOpen() == 0) -> offset 1123
        // if (v20.isSettingsOpen() == 0) -> offset 1157
        com.viper.client.utils.AtlasRenderer.drawIcon(com.viper.client.ui.Icons.CHEVRON_RIGHT, (v33.x() + 3), (v33.y() + 4), 10, arg1.accentSecondary(), com.viper.client.utils.AnimUtils.withAlpha(arg1.textSecondary(), arg9));
        v34 = 24;
        v35 = 12;
        v36 = ((v33.x() - v34) - 6);
        v37 = (v23 + 16);
        // if (Double.compare(v20.getEnableAnim(), 0.05000000074505806f) <= 0) -> offset 1266
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, v36, v37, v34, v35, com.viper.client.utils.AnimUtils.withAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg1.controlTrackBg(), arg1.accentSecondary(), v20.getEnableAnim()), arg9), com.viper.client.utils.AnimUtils.withAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg1.controlTrackBg(), arg1.accentPrimary(), v20.getEnableAnim()), arg9));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v36, v37, v34, v35, com.viper.client.utils.AnimUtils.withAlpha(arg1.controlTrackBg(), arg9));
        v38 = ((v36 + 2) + Math.round(((float)(v34 - 10) * v20.getEnableAnim())));
        com.viper.client.utils.AtlasRenderer.drawCircle(arg0, v38, (v37 + 2), 8, com.viper.client.utils.AnimUtils.withAlpha(-1, arg9));
        // if (this.inlineListeningModule != v20) -> offset 1342
        v39 = com.viper.client.utils.KeyUtils.getKeyName(v20.getKeyCode());
        v40 = Math.max(18, (com.viper.client.utils.AtlasRenderer.getTextWidth(this.field_22793, v39) + 8));
        v41 = new com.viper.client.ui.ViperClickGuiScreen.HitBox(((v36 - v40) - 5), (v23 + 15), v40, 14);
        // if (this.inlineListeningModule != v20) -> offset 1427
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(v41.x(), v41.y(), v40, 14, arg1.accentSoftBg(), com.viper.client.utils.AnimUtils.withAlpha(arg1.settingsDrawerBg(), arg9));
        // if (this.inlineListeningModule != v20) -> offset 1476
        com.viper.client.utils.AtlasRenderer.drawText(this.field_22793, v39, (v41.x() + 4), (v41.y() + 3), arg1.accentSecondary(), com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg9), 0);
        this.visibleCardHeaders.add(new com.viper.client.ui.ViperClickGuiScreen.CardHeaderRect(v20, new com.viper.client.ui.ViperClickGuiScreen.HitBox(v22, v23, v12, v24), v41, v33));
        // if (v29 <= 4) -> offset 1791
        v42 = (v23 + v24);
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, (v22 + 4), v42, (v12 - 8), (v29 - 4), com.viper.client.utils.AnimUtils.withAlpha(arg1.settingsDrawerBg(), (0.75f * arg9)));
        arg0.method_25294((v22 + 10), v42, ((v22 + v12) - 10), (v42 + 1), com.viper.client.utils.AnimUtils.withAlpha(arg1.borderSubtle(), arg9));
        arg0.method_44379((v22 + 2), v42, ((v22 + v12) - 2), ((v42 + v29) - 2));
        v43 = (v42 + 5);
        v44 = v26.iterator();
        // if (v44.hasNext() == 0) -> offset 1775
        v45 = ((com.viper.client.ui.components.UIComponent) v44.next());
        v46 = com.viper.client.utils.AnimUtils.easeOutCubic(v45.getVisibilityAnim());
        // if (Double.compare(v46, 0.03999999910593033f) >= 0) -> offset 1687
        // if ((v45 instanceof com.viper.client.ui.components.Slider) == 0) -> offset 1700
        v47 = 22;
        v45.setBounds((v22 + 7), v43, (v12 - 14), v47);
        v45.setAlphaFactor(((arg9 * v28) * v46));
        v45.render(arg0, this.field_22793, arg1, arg6, arg7, arg8);
        v43 = (v43 + Math.round(((float)(v45.getRenderedHeight() + 4) * v46)));
        arg0.method_44380();
        v48 = 28;
        arg0.method_44380();
        throw v48;
        v42 = v18;
        v43 = v21;
        v42[v43] = (v42[v43] + (v30 + 8));
        v11 += 1;
        v11 = (Math.max(v18[0], v18[1]) + Math.round(this.scrollOffset));
        this.maxScroll = Math.max(0, ((v11 - (arg3 + arg5)) + 8));
        this.targetScrollOffset = com.viper.client.utils.AnimUtils.clamp(this.targetScrollOffset, 0.0f, (float)this.maxScroll);
        return;
    }

    private void renderThemesView(net.minecraft.class_332 arg0, com.viper.client.ui.ThemeManager arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, float arg8, float arg9) {
        v13 = 54;
        v14 = arg1.getActiveTheme();
        com.viper.client.ui.glass.GlassRenderer.drawGlassCard(arg0, arg2, arg3, arg4, v13, com.viper.client.utils.AnimUtils.withAlpha(arg1.cardBg(), arg9), com.viper.client.utils.AnimUtils.withAlpha(arg1.accentSecondary(), arg9), arg1.accentPrimary(), (0.14000000059604645f * arg9));
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, (arg2 + 10), (arg3 + 10), 34, 34, com.viper.client.utils.AnimUtils.withAlpha(arg1.accentSecondary(), arg9), com.viper.client.utils.AnimUtils.withAlpha(arg1.accentPrimary(), arg9));
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.PALETTE, (arg2 + 19), (arg3 + 19), 16, com.viper.client.utils.AnimUtils.withAlpha(-1, arg9));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, makeConcatWithConstants(v14.getDisplayName()), (arg2 + 54), (arg3 + 13), com.viper.client.utils.AnimUtils.withAlpha(arg1.textPrimary(), arg9), 0);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, makeConcatWithConstants(v14.getGroup()), (arg2 + 54), (arg3 + 27), com.viper.client.utils.AnimUtils.withAlpha(arg1.textSecondary(), arg9), 0);
        v15 = ((arg3 + v13) + 8);
        new java.lang.String[3][0] = "All";
        new java.lang.String[3][1] = "Glass";
        new java.lang.String[3][2] = "Classic";
        v16 = new java.lang.String[3];
        v17 = arg2;
        v18 = v16;
        v19 = v18.length;
        v20 = 0;
        // if (v20 >= v19) -> offset 449
        v21 = v18[v20];
        v12 = (com.viper.client.utils.AtlasRenderer.getTextWidth(this.field_22793, v21) + 18);
        v22 = new com.viper.client.ui.ViperClickGuiScreen.HitBox(v17, v15, v12, 20);
        this.segmentRects.add(new com.viper.client.ui.ViperClickGuiScreen.SegmentRect(v21, v22));
        v23 = this.themeGroupFilter.equalsIgnoreCase(v21);
        // if (v23 == 0) -> offset 334
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(v22.x(), v22.y(), v12, 20, arg1.accentSoftBg(), com.viper.client.utils.AnimUtils.withAlpha(arg1.cardBg(), arg9));
        // if (v23 == 0) -> offset 373
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(v22.x(), v22.y(), v12, 20, arg1.accentSecondary(), com.viper.client.utils.AnimUtils.withAlpha(arg1.borderSubtle(), arg9));
        // if (v23 == 0) -> offset 420
        com.viper.client.utils.AtlasRenderer.drawText(this.field_22793, v21, (v22.x() + 9), (v22.y() + 6), arg1.accentSecondary(), com.viper.client.utils.AnimUtils.withAlpha(arg1.textSecondary(), arg9), 0);
        v17 = (v17 + (v12 + 6));
        v20 += 1;
        v18 = ((v15 + 28) - Math.round(this.scrollOffset));
        v19 = new java.util.ArrayList();
        v20 = com.viper.client.ui.ThemeManager.ThemePreset.values();
        v21 = v20.length;
        v22 = 0;
        // if (v22 >= v21) -> offset 544
        v23 = v20[v22];
        // if ("All".equalsIgnoreCase(this.themeGroupFilter) != 0) -> offset 530
        // if (v23.getGroup().equalsIgnoreCase(this.themeGroupFilter) != 0) -> offset 530
        v19.add(v23);
        v22 += 1;
        v20 = 2;
        v21 = 8;
        v12 = ((arg4 - v21) / v20);
        v22 = 48;
        v11 = 0;
        // if (v11 >= v19.size()) -> offset 884
        v23 = ((com.viper.client.ui.ThemeManager.ThemePreset) v19.get(v11));
        v24 = (v11 % v20);
        v25 = (v11 / v20);
        v26 = (arg2 + (v24 * (v12 + v21)));
        v27 = (v18 + (v25 * (v22 + v21)));
        v28 = new com.viper.client.ui.ViperClickGuiScreen.HitBox(v26, v27, v12, v22);
        this.visibleThemeRects.add(new com.viper.client.ui.ViperClickGuiScreen.ThemeCardRect(v23, v28));
        // if (v23 != v14) -> offset 678
        v29 = 0;
        v30 = v28.contains((double)arg6, (double)arg7);
        // if (v30 == 0) -> offset 715
        // if (v29 == 0) -> offset 737
        // if (v29 == 0) -> offset 765
        com.viper.client.ui.glass.GlassRenderer.drawGlassCard(v12, v22, arg1.cardHoverBg(), com.viper.client.utils.AnimUtils.withAlpha(arg1.cardBg(), arg9), v23.getGradStart(), com.viper.client.utils.AnimUtils.withAlpha(arg1.borderSubtle(), arg9), v23.getGradMid(), (0.1599999964237213f * arg9), 0.0f);
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, (v26 + 10), (v27 + 11), 26, 26, com.viper.client.utils.AnimUtils.withAlpha(v23.getGradStart(), arg9), com.viper.client.utils.AnimUtils.withAlpha(v23.getGradEnd(), arg9));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, v23.getDisplayName(), (v26 + 44), (v27 + 13), com.viper.client.utils.AnimUtils.withAlpha(arg1.textPrimary(), arg9), 0);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, makeConcatWithConstants(v23.getGroup()), (v26 + 44), (v27 + 26), com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg9), 0);
        v11 += 1;
        v11 = ((v19.size() + 1) / 2);
        this.maxScroll = Math.max(0, (((v15 + 28) + (v11 * (v22 + v21))) - (arg3 + arg5)));
        this.targetScrollOffset = com.viper.client.utils.AnimUtils.clamp(this.targetScrollOffset, 0.0f, (float)this.maxScroll);
        return;
    }

    private void renderSettingsView(net.minecraft.class_332 arg0, com.viper.client.ui.ThemeManager arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, float arg8, float arg9) {
        v11 = (arg3 - Math.round(this.scrollOffset));
        v12 = java.util.List.of(this.uiScaleSlider, this.customFontToggle, this.darkModeToggle, this.menuBlurToggle, this.watermarkToggle, this.arrayListToggle, this.guiOpenKeybind, this.openHudEditorButton, this.resetDefaultsButton);
        v13 = v12.iterator();
        // if (v13.hasNext() == 0) -> offset 150
        v14 = ((com.viper.client.ui.components.UIComponent) v13.next());
        // if ((v14 instanceof com.viper.client.ui.components.Slider) == 0) -> offset 97
        v15 = 26;
        v14.setBounds(arg2, v11, arg4, v15);
        v14.setAlphaFactor(arg9);
        v14.render(arg0, this.field_22793, arg1, arg6, arg7, arg8);
        v11 = (v11 + (v15 + 6));
        v13 = (v11 - (arg3 - Math.round(this.scrollOffset)));
        this.maxScroll = Math.max(0, (v13 - arg5));
        this.targetScrollOffset = com.viper.client.utils.AnimUtils.clamp(this.targetScrollOffset, 0.0f, (float)this.maxScroll);
        return;
    }

    private void renderConfigsView(net.minecraft.class_332 arg0, com.viper.client.ui.ThemeManager arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, float arg8, float arg9) {
        v11 = "+ Save Profile";
        v12 = (com.viper.client.utils.AtlasRenderer.getTextWidth(this.field_22793, v11) + 18);
        this.saveProfileBtnRect = new com.viper.client.ui.ViperClickGuiScreen.HitBox(((arg2 + arg4) - v12), arg3, v12, 22);
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, this.saveProfileBtnRect.x(), this.saveProfileBtnRect.y(), v12, 22, com.viper.client.utils.AnimUtils.withAlpha(arg1.accentSecondary(), arg9), com.viper.client.utils.AnimUtils.withAlpha(arg1.accentPrimary(), arg9));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, v11, (this.saveProfileBtnRect.x() + 9), (this.saveProfileBtnRect.y() + 7), com.viper.client.utils.AnimUtils.withAlpha(-1, arg9), 0);
        v13 = this.viper.getConfigManager().listUserProfiles();
        v14 = ((arg3 + 30) - Math.round(this.scrollOffset));
        // if (v13.isEmpty() == 0) -> offset 192
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "No saved profiles yet. Click '+ Save Profile' to store current settings.", (arg2 + 4), (v14 + 10), com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg9), 0);
        this.maxScroll = 0;
        return;
        v15 = v13.iterator();
        // if (v15.hasNext() == 0) -> offset 564
        v16 = ((com.viper.client.utils.ConfigManager.PresetProfile) v15.next());
        com.viper.client.ui.glass.GlassRenderer.drawGlassCard(arg0, arg2, v14, arg4, 42, com.viper.client.utils.AnimUtils.withAlpha(arg1.cardBg(), arg9), com.viper.client.utils.AnimUtils.withAlpha(arg1.borderSubtle(), arg9), arg1.accentPrimary(), 0.0f);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, v16.name(), (arg2 + 12), (v14 + 9), com.viper.client.utils.AnimUtils.withAlpha(arg1.textPrimary(), arg9), 0);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, v16.description(), (arg2 + 12), (v14 + 23), com.viper.client.utils.AnimUtils.withAlpha(arg1.textMuted(), arg9), 0);
        v17 = new com.viper.client.ui.ViperClickGuiScreen.HitBox(((arg2 + arg4) - 108), (v14 + 10), 48, 22);
        v18 = new com.viper.client.ui.ViperClickGuiScreen.HitBox(((arg2 + arg4) - 54), (v14 + 10), 46, 22);
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, v17.x(), v17.y(), v17.w(), v17.h(), com.viper.client.utils.AnimUtils.withAlpha(arg1.accentSecondary(), arg9), com.viper.client.utils.AnimUtils.withAlpha(arg1.accentPrimary(), arg9));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "Load", (v17.x() + 12), (v17.y() + 7), com.viper.client.utils.AnimUtils.withAlpha(-1, arg9), 0);
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v18.x(), v18.y(), v18.w(), v18.h(), com.viper.client.utils.AnimUtils.withAlpha(1156531268, arg9));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "Del", (v18.x() + 14), (v18.y() + 7), com.viper.client.utils.AnimUtils.withAlpha(-1, arg9), 0);
        this.visibleConfigRects.add(new com.viper.client.ui.ViperClickGuiScreen.ConfigActionRect(v16, v17, new com.viper.client.ui.ViperClickGuiScreen.HitBox(0, 0, 0, 0), new com.viper.client.ui.ViperClickGuiScreen.HitBox(0, 0, 0, 0), v18));
        v14 += 48;
        this.maxScroll = Math.max(0, ((v13.size() * 48) - (arg5 - 30)));
        return;
    }

    public boolean method_25402(net.minecraft.class_11909 arg0, boolean arg1) {
        // if (this.closing == 0) -> offset 9
        return true;
        v3 = (double)this.toUiX(arg0.comp_4798());
        v5 = (double)this.toUiY(arg0.comp_4799());
        v7 = arg0.method_74245();
        // if (this.closeBtnRect.contains(v3, v5) == 0) -> offset 55
        this.method_25419();
        return true;
        // if (this.quickConfigRect.contains(v3, v5) == 0) -> offset 98
        this.searchQuery = "";
        this.searchFocused = 0;
        this.activeSection = com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS;
        this.targetScrollOffset = 0.0f;
        this.scrollOffset = 0.0f;
        return true;
        // if (this.searchClearRect.contains(v3, v5) == 0) -> offset 134
        this.searchQuery = "";
        this.searchFocused = 1;
        this.targetScrollOffset = 0.0f;
        this.scrollOffset = 0.0f;
        return true;
        // if (this.searchBoxRect.contains(v3, v5) == 0) -> offset 154
        this.searchFocused = 1;
        return true;
        this.searchFocused = 0;
        v8 = this.sidebarRects.iterator();
        // if (v8.hasNext() == 0) -> offset 289
        v9 = ((com.viper.client.ui.ViperClickGuiScreen.SidebarItemRect) v8.next());
        // if (v9.rect().contains(v3, v5) != 0) -> offset 209
        // if (v9.hudEditor() == 0) -> offset 245
        // if (this.field_22787 == null) -> offset 243
        this.field_22787.method_1507(new com.viper.client.ui.HudEditorScreen(this.viper, this));
        return true;
        this.searchQuery = "";
        this.activeSection = v9.section();
        // if (v9.category() == null) -> offset 277
        this.selectedCategory = v9.category();
        this.targetScrollOffset = 0.0f;
        this.scrollOffset = 0.0f;
        return true;
        // if (this.isSearchActive() != 0) -> offset 792
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS) -> offset 454
        v8 = java.util.List.of(this.uiScaleSlider, this.customFontToggle, this.darkModeToggle, this.menuBlurToggle, this.watermarkToggle, this.arrayListToggle, this.guiOpenKeybind, this.openHudEditorButton, this.resetDefaultsButton).iterator();
        // if (v8.hasNext() == 0) -> offset 447
        v9 = ((com.viper.client.ui.components.UIComponent) v8.next());
        // if (v9 != this.uiScaleSlider) -> offset 422
        // if (v9.mouseClicked(v3, v5, v7) == 0) -> offset 422
        this.viper.getThemeManager().setUiScale(this.uiScaleSetting.doubleValue());
        this.viper.saveConfig();
        return true;
        // if (v9.mouseClicked(v3, v5, v7) != 0) -> offset 438
        this.viper.saveConfig();
        return true;
        return this.method_25402(arg0, arg1);
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.THEMES) -> offset 606
        v8 = this.segmentRects.iterator();
        // if (v8.hasNext() == 0) -> offset 525
        v9 = ((com.viper.client.ui.ViperClickGuiScreen.SegmentRect) v8.next());
        // if (v9.rect().contains(v3, v5) != 0) -> offset 514
        this.themeGroupFilter = v9.option();
        return true;
        v8 = this.visibleThemeRects.iterator();
        // if (v8.hasNext() == 0) -> offset 599
        v9 = ((com.viper.client.ui.ViperClickGuiScreen.ThemeCardRect) v8.next());
        // if (v9.rect().contains(v3, v5) != 0) -> offset 575
        this.viper.getThemeManager().setActiveTheme(v9.preset());
        this.viper.saveConfig();
        return true;
        return this.method_25402(arg0, arg1);
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.CONFIGS) -> offset 792
        // if (this.saveProfileBtnRect.contains(v3, v5) == 0) -> offset 670
        this.viper.getConfigManager().saveUserProfile(makeConcatWithConstants((System.currentTimeMillis() % 1000L)), "Combat", this.viper.getModuleManager(), this.viper.getThemeManager());
        return true;
        v8 = this.visibleConfigRects.iterator();
        // if (v8.hasNext() == 0) -> offset 785
        v9 = ((com.viper.client.ui.ViperClickGuiScreen.ConfigActionRect) v8.next());
        // if (v9.installRect().contains(v3, v5) == 0) -> offset 748
        this.viper.getConfigManager().installPreset(v9.preset(), this.viper.getModuleManager(), this.viper.getThemeManager());
        return true;
        // if (v9.deleteRect().contains(v3, v5) != 0) -> offset 765
        this.viper.getConfigManager().deleteUserProfile(v9.preset().id());
        return true;
        return this.method_25402(arg0, arg1);
        // if (Double.compare(v5, (double)this.viewportTop) < 0) -> offset 1166
        // if (Double.compare(v5, (double)this.viewportBottom) > 0) -> offset 1166
        v8 = this.viper.getModuleManager().getVisibleModules().iterator();
        // if (v8.hasNext() == 0) -> offset 970
        v9 = ((com.viper.client.modules.Module) v8.next());
        // if (v9.isSettingsOpen() == 0) -> offset 831
        // if (Double.compare(v9.getSettingsAnim(), 0.4000000059604645f) > 0) -> offset 876
        v10 = ((java.util.List) this.moduleControls.getOrDefault(v9, java.util.List.of())).iterator();
        // if (v10.hasNext() == 0) -> offset 967
        v11 = ((com.viper.client.ui.components.UIComponent) v10.next());
        // if (v11.isTargetVisible() == 0) -> offset 900
        // if (Double.compare(v11.getVisibilityAnim(), 0.5f) < 0) -> offset 900
        // if (v11.mouseClicked(v3, v5, v7) != 0) -> offset 958
        this.viper.saveConfig();
        return true;
        v8 = this.visibleCardHeaders.iterator();
        // if (v8.hasNext() == 0) -> offset 1166
        v9 = ((com.viper.client.ui.ViperClickGuiScreen.CardHeaderRect) v8.next());
        // if (v9.bindRect().contains(v3, v5) == 0) -> offset 1074
        // if (v7 != 1) -> offset 1047
        v9.module().setKeyCode(-1);
        this.inlineListeningModule = null;
        this.viper.saveConfig();
        // if (this.inlineListeningModule != v9.module()) -> offset 1064
        null.inlineListeningModule = v9.module();
        return true;
        // if (v9.fullRect().contains(v3, v5) != 0) -> offset 1091
        v10 = v9.module();
        // if (v7 == 1) -> offset 1123
        // if (v7 != 0) -> offset 1144
        // if (v9.chevronRect().contains(v3, v5) == 0) -> offset 1144
        v10.toggleSettingsOpen();
        // if (v10.isSettingsOpen() != 0) -> offset 1142
        this.collapseModulePopups(v10);
        return true;
        // if (v7 == 0) -> offset 1152
        v10.toggle();
        this.viper.saveConfig();
        return true;
        return this.method_25402(arg0, arg1);
    }

    public boolean method_25406(net.minecraft.class_11909 arg0) {
        v5 = (double)this.toUiX(arg0.comp_4798());
        v3 = (double)this.toUiY(arg0.comp_4799());
        v2 = arg0.method_74245();
        // if (/*?*/.mouseReleased(this.uiScaleSlider, v5, arg0.method_74245()) == 0) -> offset 66
        this.viper.getThemeManager().setUiScale(this.uiScaleSetting.doubleValue());
        this.viper.saveConfig();
        return true;
        v7 = this.moduleControls.values().iterator();
        // if (v7.hasNext() == 0) -> offset 162
        v8 = ((java.util.List) v7.next());
        v9 = v8.iterator();
        // if (v9.hasNext() == 0) -> offset 159
        v10 = ((com.viper.client.ui.components.UIComponent) v9.next());
        // if (v10.mouseReleased(v5, v3, v2) != 0) -> offset 150
        this.viper.saveConfig();
        return true;
        return this.method_25406(arg0);
    }

    public boolean method_25403(net.minecraft.class_11909 arg0, double arg1, double arg2) {
        // if (this.closing == 0) -> offset 9
        return true;
        v6 = (double)this.toUiX(arg0.comp_4798());
        v8 = (double)this.toUiY(arg0.comp_4799());
        v10 = arg0.method_74245();
        // if (this.isSearchActive() != 0) -> offset 92
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS) -> offset 92
        // if (this.uiScaleSlider.mouseDragged(v6, v8, v10, arg1, arg2) == 0) -> offset 92
        this.viper.getThemeManager().setUiScale(this.uiScaleSetting.doubleValue());
        return true;
        v11 = this.moduleControls.values().iterator();
        // if (v11.hasNext() == 0) -> offset 186
        v12 = ((java.util.List) v11.next());
        v13 = v12.iterator();
        // if (v13.hasNext() == 0) -> offset 183
        v14 = ((com.viper.client.ui.components.UIComponent) v13.next());
        // if (v14.mouseDragged(v6, v8, v10, arg1, arg2) != 0) -> offset 181
        return true;
        return this.method_25403(arg0, arg1, arg2);
    }

    public boolean method_25401(double arg0, double arg1, double arg2, double arg3) {
        // if (this.closing != 0) -> offset 41
        // if (this.maxScroll <= 0) -> offset 41
        this.targetScrollOffset = com.viper.client.utils.AnimUtils.clamp((this.targetScrollOffset - ((float)arg3 * 24.0f)), 0.0f, (float)this.maxScroll);
        return true;
        return this.method_25401(arg0, arg1, arg2, arg3);
    }

    public boolean method_25400(net.minecraft.class_11905 arg0) {
        // if (this.searchFocused != 0) -> offset 13
        return this.method_25400(arg0);
        v2 = arg0.comp_4793();
        // if (v2 < 32) -> offset 71
        // if (v2 == 127) -> offset 71
        // if (this.searchQuery.length() >= 28) -> offset 71
        this.searchQuery = makeConcatWithConstants(this.searchQuery, Character.toString(v2));
        this.targetScrollOffset = 0.0f;
        this.scrollOffset = 0.0f;
        return true;
        return true;
    }

    public boolean method_25404(net.minecraft.class_11908 arg0) {
        v2 = arg0.comp_4795();
        // if (this.inlineListeningModule == null) -> offset 70
        // if (v2 == 256) -> offset 33
        // if (v2 == 259) -> offset 33
        // if (v2 != 261) -> offset 44
        this.inlineListeningModule.setKeyCode(-1);
        // if (v2 <= 0) -> offset 56
        this.inlineListeningModule.setKeyCode(v2);
        this.inlineListeningModule = null;
        this.viper.saveConfig();
        return true;
        // if (this.activeSection != com.viper.client.ui.ViperClickGuiScreen.PanelSection.SETTINGS) -> offset 107
        // if (this.isSearchActive() != 0) -> offset 107
        // if (this.guiOpenKeybind.keyPressed(v2) == 0) -> offset 107
        this.viper.saveConfig();
        return true;
        v3 = this.moduleControls.values().iterator();
        // if (v3.hasNext() == 0) -> offset 197
        v4 = ((java.util.List) v3.next());
        v5 = v4.iterator();
        // if (v5.hasNext() == 0) -> offset 194
        v6 = ((com.viper.client.ui.components.UIComponent) v5.next());
        // if (v6.keyPressed(v2) != 0) -> offset 185
        this.viper.saveConfig();
        return true;
        // if (this.searchFocused == 0) -> offset 327
        // if (v2 != 256) -> offset 247
        // if (this.searchQuery.isEmpty() != 0) -> offset 240
        this.searchQuery = "";
        this.targetScrollOffset = 0.0f;
        this.scrollOffset = 0.0f;
        this.searchFocused = 0;
        return true;
        // if (v2 == 257) -> offset 261
        // if (v2 != 335) -> offset 268
        this.searchFocused = 0;
        return true;
        // if (v2 == 259) -> offset 282
        // if (v2 != 261) -> offset 325
        // if (this.searchQuery.isEmpty() != 0) -> offset 323
        this.searchQuery = this.searchQuery.substring(0, (this.searchQuery.length() - 1));
        this.targetScrollOffset = 0.0f;
        this.scrollOffset = 0.0f;
        return true;
        return true;
        // if (v2 == 256) -> offset 348
        // if (v2 != this.viper.getThemeManager().getOpenGuiKeyCode()) -> offset 354
        this.method_25419();
        return true;
        return this.method_25404(arg0);
    }

    final class 1NavDef extends java.lang.Record {
        private final String label;
        private final net.minecraft.class_2960 icon;
        private final com.viper.client.ui.ViperClickGuiScreen.PanelSection sec;
        private final com.viper.client.modules.Category cat;
        private final boolean hud;

        1NavDef(String arg0, net.minecraft.class_2960 arg1, com.viper.client.ui.ViperClickGuiScreen.PanelSection arg2, com.viper.client.modules.Category arg3, boolean arg4) {
            super();
            this.label = arg0;
            this.icon = arg1;
            this.sec = arg2;
            this.cat = arg3;
            this.hud = arg4;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public String label() {
            return this.label;
        }

        public net.minecraft.class_2960 icon() {
            return this.icon;
        }

        public com.viper.client.ui.ViperClickGuiScreen.PanelSection sec() {
            return this.sec;
        }

        public com.viper.client.modules.Category cat() {
            return this.cat;
        }

        public boolean hud() {
            return this.hud;
        }

    }

    final class CardHeaderRect extends java.lang.Record {
        private final com.viper.client.modules.Module module;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox fullRect;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox bindRect;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox chevronRect;

        private CardHeaderRect(com.viper.client.modules.Module arg0, com.viper.client.ui.ViperClickGuiScreen.HitBox arg1, com.viper.client.ui.ViperClickGuiScreen.HitBox arg2, com.viper.client.ui.ViperClickGuiScreen.HitBox arg3) {
            super();
            this.module = arg0;
            this.fullRect = arg1;
            this.bindRect = arg2;
            this.chevronRect = arg3;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public com.viper.client.modules.Module module() {
            return this.module;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox fullRect() {
            return this.fullRect;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox bindRect() {
            return this.bindRect;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox chevronRect() {
            return this.chevronRect;
        }

    }

    final class ConfigActionRect extends java.lang.Record {
        private final com.viper.client.utils.ConfigManager.PresetProfile preset;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox installRect;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox upRect;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox downRect;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox deleteRect;

        private ConfigActionRect(com.viper.client.utils.ConfigManager.PresetProfile arg0, com.viper.client.ui.ViperClickGuiScreen.HitBox arg1, com.viper.client.ui.ViperClickGuiScreen.HitBox arg2, com.viper.client.ui.ViperClickGuiScreen.HitBox arg3, com.viper.client.ui.ViperClickGuiScreen.HitBox arg4) {
            super();
            this.preset = arg0;
            this.installRect = arg1;
            this.upRect = arg2;
            this.downRect = arg3;
            this.deleteRect = arg4;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public com.viper.client.utils.ConfigManager.PresetProfile preset() {
            return this.preset;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox installRect() {
            return this.installRect;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox upRect() {
            return this.upRect;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox downRect() {
            return this.downRect;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox deleteRect() {
            return this.deleteRect;
        }

    }

    final class HitBox extends java.lang.Record {
        private final int x;
        private final int y;
        private final int w;
        private final int h;

        private HitBox(int arg0, int arg1, int arg2, int arg3) {
            super();
            this.x = arg0;
            this.y = arg1;
            this.w = arg2;
            this.h = arg3;
            return;
        }

        boolean contains(double arg0, double arg1) {
            // if (Double.compare(arg0, (double)this.x) < 0) -> offset 54
            // if (Double.compare(arg0, (double)(this.x + this.w)) > 0) -> offset 54
            // if (Double.compare(arg1, (double)this.y) < 0) -> offset 54
            // if (Double.compare(arg1, (double)(this.y + this.h)) > 0) -> offset 54
            return false;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public int x() {
            return this.x;
        }

        public int y() {
            return this.y;
        }

        public int w() {
            return this.w;
        }

        public int h() {
            return this.h;
        }

    }

     enum PanelSection {
        MODULES, THEMES, CONFIGS, SETTINGS;


    }

    final class SegmentRect extends java.lang.Record {
        private final String option;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox rect;

        private SegmentRect(String arg0, com.viper.client.ui.ViperClickGuiScreen.HitBox arg1) {
            super();
            this.option = arg0;
            this.rect = arg1;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public String option() {
            return this.option;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox rect() {
            return this.rect;
        }

    }

    final class SidebarItemRect extends java.lang.Record {
        private final com.viper.client.ui.ViperClickGuiScreen.PanelSection section;
        private final com.viper.client.modules.Category category;
        private final boolean hudEditor;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox rect;

        private SidebarItemRect(com.viper.client.ui.ViperClickGuiScreen.PanelSection arg0, com.viper.client.modules.Category arg1, boolean arg2, com.viper.client.ui.ViperClickGuiScreen.HitBox arg3) {
            super();
            this.section = arg0;
            this.category = arg1;
            this.hudEditor = arg2;
            this.rect = arg3;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public com.viper.client.ui.ViperClickGuiScreen.PanelSection section() {
            return this.section;
        }

        public com.viper.client.modules.Category category() {
            return this.category;
        }

        public boolean hudEditor() {
            return this.hudEditor;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox rect() {
            return this.rect;
        }

    }

    final class ThemeCardRect extends java.lang.Record {
        private final com.viper.client.ui.ThemeManager.ThemePreset preset;
        private final com.viper.client.ui.ViperClickGuiScreen.HitBox rect;

        private ThemeCardRect(com.viper.client.ui.ThemeManager.ThemePreset arg0, com.viper.client.ui.ViperClickGuiScreen.HitBox arg1) {
            super();
            this.preset = arg0;
            this.rect = arg1;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public com.viper.client.ui.ThemeManager.ThemePreset preset() {
            return this.preset;
        }

        public com.viper.client.ui.ViperClickGuiScreen.HitBox rect() {
            return this.rect;
        }

    }

}
