package com.viper.client.ui.components;

public abstract class UIComponent {
    protected int x;
    protected int y;
    protected int width;
    protected int height;
    protected boolean hovered;
    protected float hoverAnim;
    protected float pressAnim;
    protected float alphaFactor;
    private String description;
    private java.util.function.BooleanSupplier visibleSupplier;
    private float visibilityAnim;

    public UIComponent() {
        super();
        this.hoverAnim = 0.0f;
        this.pressAnim = 0.0f;
        this.alphaFactor = 1.0f;
        this.description = "";
        this.visibleSupplier = getAsBoolean();
        this.visibilityAnim = 1.0f;
        return;
    }

    public void setBounds(int arg0, int arg1, int arg2, int arg3) {
        this.x = arg0;
        this.y = arg1;
        this.width = arg2;
        this.height = arg3;
        return;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String arg0) {
        // if (arg0 != null) -> offset 10
        "".description = arg0;
        return;
    }

    public boolean isHovered() {
        return this.hovered;
    }

    public void setAlphaFactor(float arg0) {
        this.alphaFactor = com.viper.client.utils.AnimUtils.clamp01(arg0);
        return;
    }

    public void setVisibleSupplier(java.util.function.BooleanSupplier arg0) {
        // if (arg0 == null) -> offset 27
        this.visibleSupplier = arg0;
        // if (arg0.getAsBoolean() == 0) -> offset 23
        1.0f.visibilityAnim = 0.0f;
        return;
    }

    public boolean isTargetVisible() {
        return this.visibleSupplier.getAsBoolean();
    }

    public void updateVisibilityAnimation(float arg0) {
        v2 = this.visibleSupplier.getAsBoolean();
        // if (v2 == 0) -> offset 23
        this.visibilityAnim.visibilityAnim = com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 15.0f, arg0);
        // if (v2 != 0) -> offset 51
        // if (Double.compare(this.visibilityAnim, 0.05000000074505806f) >= 0) -> offset 51
        this.onHidden();
        return;
    }

    public float getVisibilityAnim() {
        return this.visibilityAnim;
    }

    protected void onHidden() {
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public int getRenderedHeight() {
        return this.height;
    }

    public boolean isMouseOver(double arg0, double arg1) {
        // if (Double.compare(arg0, (double)this.x) < 0) -> offset 54
        // if (Double.compare(arg0, (double)(this.x + this.width)) > 0) -> offset 54
        // if (Double.compare(arg1, (double)this.y) < 0) -> offset 54
        // if (Double.compare(arg1, (double)(this.y + this.height)) > 0) -> offset 54
        return false;
    }

    protected void updateBaseAnimations(double arg0, double arg1, float arg2) {
        this.hovered = this.isMouseOver(arg0, arg1);
        // if (this.hovered == 0) -> offset 26
        this.hoverAnim.hoverAnim = com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 16.0f, arg2);
        this.pressAnim = com.viper.client.utils.AnimUtils.damp(this.pressAnim, 0.0f, 18.0f, arg2);
        return;
    }

    protected void pushInteractiveScale(net.minecraft.class_332 arg0, float arg1) {
        v3 = ((1.0f + (arg1 * com.viper.client.utils.AnimUtils.easeOutCubic(this.hoverAnim))) - (0.017999999225139618f * this.pressAnim));
        v4 = ((float)this.x + ((float)this.width * 0.5f));
        v5 = ((float)this.y + ((float)this.height * 0.5f));
        arg0.method_51448().pushMatrix();
        arg0.method_51448().translate(v4, v5);
        arg0.method_51448().scale(v3, v3);
        arg0.method_51448().translate((-v4), (-v5));
        return;
    }

    protected void popInteractiveScale(net.minecraft.class_332 arg0) {
        arg0.method_51448().popMatrix();
        return;
    }

    protected int applyAlpha(int arg0) {
        // if (Double.compare(this.alphaFactor, 0.9990000128746033f) < 0) -> offset 14
        return com.viper.client.utils.AnimUtils.withAlpha(arg0, this.alphaFactor);
    }

    protected void triggerPress() {
        this.pressAnim = 1.0f;
        return;
    }

    public abstract void render(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, com.viper.client.ui.ThemeManager arg2, int arg3, int arg4, float arg5);

    public boolean mouseClicked(double arg0, double arg1, int arg2) {
        return false;
    }

    public boolean mouseReleased(double arg0, double arg1, int arg2) {
        return false;
    }

    public boolean mouseDragged(double arg0, double arg1, int arg2, double arg3, double arg4) {
        return false;
    }

    public boolean keyPressed(int arg0) {
        return false;
    }

}
