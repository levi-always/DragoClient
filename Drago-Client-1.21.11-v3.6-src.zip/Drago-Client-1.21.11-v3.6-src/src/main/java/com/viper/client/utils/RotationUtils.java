package com.viper.client.utils;

public final class RotationUtils {
    public static final String[] AIM_POINT_MODES;
    private static final double VANILLA_SENS_MULT = 0.6000000238418579;
    private static final double VANILLA_SENS_OFFSET = 0.20000000298023224;
    private static volatile boolean hasConfirmedAngles;
    private static volatile float confirmedServerYaw;
    private static volatile float confirmedServerPitch;
    private static volatile boolean syntheticMouseDispatch;
    private static volatile boolean silentControlling;
    private static volatile boolean silentReturning;
    private static volatile boolean moveFixActive;
    private static volatile int silentOwnerPriority;
    private static volatile boolean silentFedThisTick;
    private static volatile float cameraYaw;
    private static volatile float cameraPitch;
    private static volatile float serverYaw;
    private static volatile float serverPitch;
    private static volatile float prevServerYaw;
    private static volatile float prevServerPitch;
    private static float lastSilentYawVel;
    private static float lastSilentPitchVel;
    private static float silentAcquireProgress;
    private static float silentSmoothness;
    private static Object lastPlayerRef;
    private static volatile boolean cameraControlling;
    private static volatile boolean cameraReturning;
    private static volatile int cameraOwnerPriority;
    private static volatile net.minecraft.class_1297 cameraTargetEntity;
    private static volatile boolean cameraHasWorldPoint;
    private static volatile double cameraPointX;
    private static volatile double cameraPointY;
    private static volatile double cameraPointZ;
    private static volatile String cameraAimPointMode;
    private static volatile float cameraSmoothness;
    private static volatile boolean cameraReturnOnFinish;
    private static volatile float cameraDeadzoneDeg;
    private static float cameraAcquireProgress;
    private static float cameraAnchorYaw;
    private static float cameraAnchorPitch;
    private static double pixelAccumX;
    private static double pixelAccumY;
    private static long lastRenderNs;
    private static int autoTrackedEntityId;
    private static double autoLocalX;
    private static double autoLocalY;
    private static double autoLocalZ;
    private static double walkOffsetX;
    private static double walkOffsetY;
    private static double walkOffsetZ;
    private static long nextWalkRefreshMs;

    private RotationUtils() {
        super();
        return;
    }

    public static float wrapDegrees(float arg0) {
        v1 = (arg0 % 360.0f);
        // if (Double.compare(v1, 180.0f) < 0) -> offset 17
        v1 = (v1 - 360.0f);
        // if (Double.compare(v1, -180.0f) >= 0) -> offset 29
        v1 = (v1 + 360.0f);
        return v1;
    }

    public static float clampPitch(float arg0) {
        return Math.max(-89.9000015258789f, Math.min(89.9000015258789f, arg0));
    }

    public static boolean isSyntheticMouseDispatch() {
        return com.viper.client.utils.RotationUtils.syntheticMouseDispatch;
    }

    public static void recordPacketConfirmedAngles(float arg0, float arg1) {
        com.viper.client.utils.RotationUtils.confirmedServerYaw = arg0;
        com.viper.client.utils.RotationUtils.confirmedServerPitch = com.viper.client.utils.RotationUtils.clampPitch(arg1);
        com.viper.client.utils.RotationUtils.hasConfirmedAngles = 1;
        return;
    }

    public static float getConfirmedServerYaw(net.minecraft.class_746 arg0) {
        // if (com.viper.client.utils.RotationUtils.hasConfirmedAngles == 0) -> offset 10
        return com.viper.client.utils.RotationUtils.confirmedServerYaw;
        // if (arg0 == null) -> offset 21
        return com.viper.client.utils.RotationUtils.serverYaw;
    }

    public static float getConfirmedServerPitch(net.minecraft.class_746 arg0) {
        // if (com.viper.client.utils.RotationUtils.hasConfirmedAngles == 0) -> offset 10
        return com.viper.client.utils.RotationUtils.confirmedServerPitch;
        // if (arg0 == null) -> offset 21
        return com.viper.client.utils.RotationUtils.serverPitch;
    }

    public static float getRealViewYaw(net.minecraft.class_746 arg0) {
        // if (com.viper.client.utils.RotationUtils.silentControlling == 0) -> offset 12
        return arg0.method_36454();
    }

    public static float getRealViewPitch(net.minecraft.class_746 arg0) {
        // if (com.viper.client.utils.RotationUtils.silentControlling == 0) -> offset 12
        return arg0.method_36455();
    }

    public static double computeMouseMultiplierG() {
        v0 = net.minecraft.class_310.method_1551();
        // if (v0 == null) -> offset 84
        // if (v0.field_1690 == null) -> offset 84
        // if (v0.field_1690.method_42495() == null) -> offset 84
        v1 = ((java.lang.Double) v0.field_1690.method_42495().method_41753()).doubleValue();
        v3 = ((v1 * 0.6000000238418579) + 0.20000000298023224);
        v5 = (((v3 * v3) * v3) * 8.0);
        // if (Double.compare(v5, 1e-05) <= 0) -> offset 84
        // if (Double.compare(v5, 16.0) >= 0) -> offset 84
        return v5;
        v0 = /*?*/;
        return 1.0;
    }

    public static float computeMouseGcdStep() {
        return (float)(com.viper.client.utils.RotationUtils.computeMouseMultiplierG() * 0.15);
    }

    public static float quantizeToMouseGcd(float arg0) {
        v1 = com.viper.client.utils.RotationUtils.computeMouseMultiplierG();
        v3 = (v1 * 0.15);
        // if (Double.compare(v3, 1e-06) > 0) -> offset 20
        return arg0;
        v5 = Math.round(((double)arg0 / v3));
        return (float)(((double)v5 * v1) * 0.15);
    }

    public static void applySyntheticMousePixels(net.minecraft.class_746 arg0, long arg1, long arg2) {
        // if (arg0 == null) -> offset 16
        // if (Double.compare(arg1, 0L) != 0) -> offset 17
        // if (Double.compare(arg2, 0L) != 0) -> offset 17
        return;
        v5 = com.viper.client.utils.RotationUtils.computeMouseMultiplierG();
        com.viper.client.utils.RotationUtils.syntheticMouseDispatch = 1;
        arg0.method_5872(((double)arg1 * v5), ((double)arg2 * v5));
        com.viper.client.utils.RotationUtils.syntheticMouseDispatch = 0;
        v7 = /*?*/;
        com.viper.client.utils.RotationUtils.syntheticMouseDispatch = 0;
        throw v7;
        return;
    }

    public static float[] computeRotations(double arg0, double arg1, double arg2, double arg3, double arg4, double arg5) {
        v12 = (arg3 - arg0);
        v14 = (arg4 - arg1);
        v16 = (arg5 - arg2);
        v18 = Math.hypot(v12, v16);
        v20 = ((float)Math.toDegrees(Math.atan2(v16, v12)) - 90.0f);
        v21 = (float)(-Math.toDegrees(Math.atan2(v14, v18)));
        new Object[2][0] = com.viper.client.utils.RotationUtils.wrapDegrees(v20);
        new Object[2][1] = com.viper.client.utils.RotationUtils.clampPitch(v21);
        return new Object[2];
    }

    public static net.minecraft.class_243 directionFromAngles(float arg0, float arg1) {
        v2 = (Math.toRadians((double)(-arg0)) - 3.141592653589793);
        v4 = Math.toRadians((double)(-arg1));
        v6 = (-Math.cos(v4));
        v8 = Math.sin(v4);
        return new net.minecraft.class_243((Math.sin(v2) * v6), v8, (Math.cos(v2) * v6));
    }

    public static float[] getRotationsToEntity(net.minecraft.class_746 arg0, net.minecraft.class_1297 arg1) {
        v2 = arg0.method_33571();
        v3 = arg1.method_5829();
        v4 = Math.min(0.08, ((v3.field_1320 - v3.field_1323) * 0.2));
        v6 = Math.min(0.08, ((v3.field_1324 - v3.field_1321) * 0.2));
        v8 = Math.max((v3.field_1323 + v4), Math.min(v2.field_1352, (v3.field_1320 - v4)));
        v10 = Math.max((v3.field_1322 + 0.15), Math.min(v2.field_1351, (v3.field_1325 - 0.12)));
        v12 = Math.max((v3.field_1321 + v6), Math.min(v2.field_1350, (v3.field_1324 - v6)));
        return com.viper.client.utils.RotationUtils.computeRotations(v2.field_1352, v2.field_1351, v2.field_1350, v8, v10, v12);
    }

    private static void updateBoundedRandomWalk(boolean arg0, double arg1, double arg2, double arg3) {
        v7 = System.currentTimeMillis();
        // if (Double.compare(v7, com.viper.client.utils.RotationUtils.nextWalkRefreshMs) >= 0) -> offset 15
        return;
        com.viper.client.utils.RotationUtils.nextWalkRefreshMs = (v7 + (long)java.util.concurrent.ThreadLocalRandom.current().nextInt(85, 195));
        // if (arg0 != 0) -> offset 68
        com.viper.client.utils.RotationUtils.walkOffsetX = (com.viper.client.utils.RotationUtils.walkOffsetX * 0.65);
        com.viper.client.utils.RotationUtils.walkOffsetY = (com.viper.client.utils.RotationUtils.walkOffsetY * 0.65);
        com.viper.client.utils.RotationUtils.walkOffsetZ = (com.viper.client.utils.RotationUtils.walkOffsetZ * 0.65);
        return;
        v9 = java.util.concurrent.ThreadLocalRandom.current();
        v10 = Math.min(0.036, (arg1 * 0.075));
        v12 = Math.min(0.048, (arg2 * 0.04));
        v14 = Math.min(0.036, (arg3 * 0.075));
        com.viper.client.utils.RotationUtils.walkOffsetX = Math.max((-v10), Math.min(v10, ((com.viper.client.utils.RotationUtils.walkOffsetX * 0.55) + (v9.nextGaussian() * (v10 * 0.42)))));
        com.viper.client.utils.RotationUtils.walkOffsetY = Math.max((-v12), Math.min(v12, ((com.viper.client.utils.RotationUtils.walkOffsetY * 0.55) + (v9.nextGaussian() * (v12 * 0.42)))));
        com.viper.client.utils.RotationUtils.walkOffsetZ = Math.max((-v14), Math.min(v14, ((com.viper.client.utils.RotationUtils.walkOffsetZ * 0.55) + (v9.nextGaussian() * (v14 * 0.42)))));
        return;
    }

    public static float[] getAimPointRotations(net.minecraft.class_746 arg0, net.minecraft.class_1297 arg1, String arg2) {
        // if (com.viper.client.utils.RotationUtils.silentControlling == 0) -> offset 15
        // if (com.viper.client.utils.RotationUtils.silentControlling == 0) -> offset 31
        return com.viper.client.utils.RotationUtils.getAimPointRotationsForCurrent(arg2, com.viper.client.utils.RotationUtils.serverYaw, arg0.method_36454(), com.viper.client.utils.RotationUtils.serverPitch, arg0.method_36455());
    }

    public static float[] getAimPointRotationsForCurrent(net.minecraft.class_746 arg0, net.minecraft.class_1297 arg1, String arg2, float arg3, float arg4) {
        v5 = arg0.method_33571();
        v6 = arg1.method_5829();
        v7 = ((v6.field_1323 + v6.field_1320) * 0.5);
        v9 = ((v6.field_1321 + v6.field_1324) * 0.5);
        v11 = v6.field_1322;
        v13 = v6.field_1325;
        v15 = Math.max(0.12, (v6.field_1320 - v6.field_1323));
        v17 = Math.max(0.12, (v6.field_1324 - v6.field_1321));
        v19 = Math.max(0.25, (v13 - v11));
        v21 = (Math.min(v15, v17) * 0.5);
        v23 = (arg0.method_18798().method_1027() + arg1.method_18798().method_1027());
        // if (Double.compare(v23, 0.00015) <= 0) -> offset 154
        com.viper.client.utils.RotationUtils.updateBoundedRandomWalk(0, v15, v19, v17);
        // if ((arg1 instanceof net.minecraft.class_1309) == 0) -> offset 185
        v26 = ((net.minecraft.class_1309) arg1);
        v25 = arg1.method_36454();
        v26 = Math.toRadians((double)v25);
        v28 = (-Math.cos(v26));
        v30 = (-Math.sin(v26));
        v32 = Math.cos(v26);
        v34 = Math.sin(v26);
        // if (arg2 != null) -> offset 239
        v36 = arg2;
        // if ("Auto".equalsIgnoreCase(v36) == 0) -> offset 997
        v43 = com.viper.client.utils.RotationUtils.getRealViewYaw(arg0);
        v44 = com.viper.client.utils.RotationUtils.getRealViewPitch(arg0);
        v45 = com.viper.client.utils.RotationUtils.directionFromAngles(v43, v44);
        v46 = Math.hypot((v7 - v5.field_1352), Math.hypot(((v11 + (v19 * 0.55)) - v5.field_1351), (v9 - v5.field_1350)));
        v48 = v5.method_1019(v45.method_1021(v46));
        v49 = Math.min(0.08, (v15 * 0.18));
        v51 = Math.min(0.08, (v17 * 0.18));
        v53 = Math.max((v6.field_1323 + v49), Math.min((v6.field_1320 - v49), v48.field_1352));
        v55 = Math.max((v11 + (v19 * 0.16)), Math.min((v13 - (v19 * 0.1)), v48.field_1351));
        v57 = Math.max((v6.field_1321 + v51), Math.min((v6.field_1324 - v51), v48.field_1350));
        new Object[3][0] = 0.0;
        new Object[3][1] = (v19 * 0.84);
        new Object[3][2] = 0.0;
        new [D[7][0] = new Object[3];
        new Object[3][0] = 0.0;
        new Object[3][1] = (v19 * 0.66);
        new Object[3][2] = 0.0;
        new [D[7][1] = new Object[3];
        new Object[3][0] = 0.0;
        new Object[3][1] = (v19 * 0.5);
        new Object[3][2] = 0.0;
        new [D[7][2] = new Object[3];
        new Object[3][0] = ((v28 * v21) * 0.68);
        new Object[3][1] = (v19 * 0.63);
        new Object[3][2] = ((v30 * v21) * 0.68);
        new [D[7][3] = new Object[3];
        new Object[3][0] = ((v32 * v21) * 0.68);
        new Object[3][1] = (v19 * 0.63);
        new Object[3][2] = ((v34 * v21) * 0.68);
        new [D[7][4] = new Object[3];
        new Object[3][0] = ((v28 * v21) * 0.4);
        new Object[3][1] = (v19 * 0.26);
        new Object[3][2] = ((v30 * v21) * 0.4);
        new [D[7][5] = new Object[3];
        new Object[3][0] = ((v32 * v21) * 0.4);
        new Object[3][1] = (v19 * 0.26);
        new Object[3][2] = ((v34 * v21) * 0.4);
        new [D[7][6] = new Object[3];
        v59 = new [D[7];
        v60 = 0.0;
        v62 = (v19 * 0.66);
        v64 = 0.0;
        v66 = 3.4028234663852886e+38f;
        v67 = v59;
        v68 = v67.length;
        v69 = 0;
        // if (v69 >= v68) -> offset 816
        v70 = v67[v69];
        v71 = com.viper.client.utils.RotationUtils.computeRotations(v5.field_1352, v5.field_1351, v5.field_1350, (v7 + v70[0]), (v11 + v70[1]), (v9 + v70[2]));
        v72 = com.viper.client.utils.RotationUtils.getAngleDifference(v43, v44, v71[0], v71[1]);
        // if (Double.compare(v72, v66) >= 0) -> offset 810
        v66 = v72;
        v60 = v70[0];
        v62 = v70[1];
        v64 = v70[2];
        v69 += 1;
        v67 = ((((v53 - v7) * 0.6) + (v60 * 0.4)) + com.viper.client.utils.RotationUtils.walkOffsetX);
        v69 = ((((v55 - v11) * 0.6) + (v62 * 0.4)) + com.viper.client.utils.RotationUtils.walkOffsetY);
        v71 = ((((v57 - v9) * 0.6) + (v64 * 0.4)) + com.viper.client.utils.RotationUtils.walkOffsetZ);
        v73 = arg1.method_5628();
        // if (v73 == com.viper.client.utils.RotationUtils.autoTrackedEntityId) -> offset 919
        com.viper.client.utils.RotationUtils.autoTrackedEntityId = v73;
        com.viper.client.utils.RotationUtils.autoLocalX = v67;
        com.viper.client.utils.RotationUtils.autoLocalY = v69;
        com.viper.client.utils.RotationUtils.autoLocalZ = v71;
        com.viper.client.utils.RotationUtils.autoLocalX = (com.viper.client.utils.RotationUtils.autoLocalX + ((v67 - com.viper.client.utils.RotationUtils.autoLocalX) * 0.25));
        com.viper.client.utils.RotationUtils.autoLocalY = (com.viper.client.utils.RotationUtils.autoLocalY + ((v69 - com.viper.client.utils.RotationUtils.autoLocalY) * 0.25));
        com.viper.client.utils.RotationUtils.autoLocalZ = (com.viper.client.utils.RotationUtils.autoLocalZ + ((v71 - com.viper.client.utils.RotationUtils.autoLocalZ) * 0.25));
        v37 = (v7 + com.viper.client.utils.RotationUtils.autoLocalX);
        v39 = (v11 + com.viper.client.utils.RotationUtils.autoLocalY);
        v41 = (v9 + com.viper.client.utils.RotationUtils.autoLocalZ);
        v43 = v36;
        v44 = -1;
        // if (v43.equals("Head") == 0) -> offset 1193
        v44 = 0;
        // if (v43.equals("Center") == 0) -> offset 1193
        v44 = 1;
        // if (v43.equals("Torso") == 0) -> offset 1193
        v44 = 2;
        // if (v43.equals("Right Arm") == 0) -> offset 1193
        v44 = 3;
        // if (v43.equals("Left Arm") == 0) -> offset 1193
        v44 = 4;
        // if (v43.equals("Right Leg") == 0) -> offset 1193
        v44 = 5;
        // if (v43.equals("Left Leg") == 0) -> offset 1193
        v44 = 6;
        v37 = (v7 + (com.viper.client.utils.RotationUtils.walkOffsetX * 0.8));
        v39 = ((v11 + (v19 * 0.84)) + (com.viper.client.utils.RotationUtils.walkOffsetY * 0.65));
        v41 = (v9 + (com.viper.client.utils.RotationUtils.walkOffsetZ * 0.8));
        v37 = (v7 + com.viper.client.utils.RotationUtils.walkOffsetX);
        v39 = ((v11 + (v19 * 0.5)) + com.viper.client.utils.RotationUtils.walkOffsetY);
        v41 = (v9 + com.viper.client.utils.RotationUtils.walkOffsetZ);
        v37 = (v7 + com.viper.client.utils.RotationUtils.walkOffsetX);
        v39 = ((v11 + (v19 * 0.66)) + (com.viper.client.utils.RotationUtils.walkOffsetY * 0.85));
        v41 = (v9 + com.viper.client.utils.RotationUtils.walkOffsetZ);
        v37 = ((v7 + (v28 * (v21 * 0.68))) + (com.viper.client.utils.RotationUtils.walkOffsetX * 0.6));
        v39 = ((v11 + (v19 * 0.64)) + (com.viper.client.utils.RotationUtils.walkOffsetY * 0.8));
        v41 = ((v9 + (v30 * (v21 * 0.68))) + (com.viper.client.utils.RotationUtils.walkOffsetZ * 0.6));
        v37 = ((v7 + (v32 * (v21 * 0.68))) + (com.viper.client.utils.RotationUtils.walkOffsetX * 0.6));
        v39 = ((v11 + (v19 * 0.64)) + (com.viper.client.utils.RotationUtils.walkOffsetY * 0.8));
        v41 = ((v9 + (v34 * (v21 * 0.68))) + (com.viper.client.utils.RotationUtils.walkOffsetZ * 0.6));
        v37 = ((v7 + (v28 * (v21 * 0.4))) + (com.viper.client.utils.RotationUtils.walkOffsetX * 0.6));
        v39 = ((v11 + (v19 * 0.26)) + (com.viper.client.utils.RotationUtils.walkOffsetY * 0.75));
        v41 = ((v9 + (v30 * (v21 * 0.4))) + (com.viper.client.utils.RotationUtils.walkOffsetZ * 0.6));
        v37 = ((v7 + (v32 * (v21 * 0.4))) + (com.viper.client.utils.RotationUtils.walkOffsetX * 0.6));
        v39 = ((v11 + (v19 * 0.26)) + (com.viper.client.utils.RotationUtils.walkOffsetY * 0.75));
        v41 = ((v9 + (v34 * (v21 * 0.4))) + (com.viper.client.utils.RotationUtils.walkOffsetZ * 0.6));
        v37 = (v7 + com.viper.client.utils.RotationUtils.walkOffsetX);
        v39 = ((v11 + (v19 * 0.66)) + com.viper.client.utils.RotationUtils.walkOffsetY);
        v41 = (v9 + com.viper.client.utils.RotationUtils.walkOffsetZ);
        v43 = Math.min(0.085, (v15 * 0.18));
        v45 = Math.min(0.085, (v17 * 0.18));
        v47 = Math.min(0.1, (v19 * 0.1));
        v49 = Math.max((v6.field_1323 + v43), Math.min((v6.field_1320 - v43), v37));
        v51 = Math.max((v11 + v47), Math.min((v13 - v47), v39));
        v53 = Math.max((v6.field_1321 + v45), Math.min((v6.field_1324 - v45), v41));
        v55 = com.viper.client.utils.RotationUtils.computeRotations(v5.field_1352, v5.field_1351, v5.field_1350, v49, v51, v53);
        v56 = v6.method_1014((-Math.min(0.09, (v21 * 0.3))));
        // if (Double.compare(v23, 0.0004) >= 0) -> offset 1890
        // if (Double.compare(com.viper.client.utils.RotationUtils.getAngleDifference(arg3, arg4, v55[0], v55[1]), 1.850000023841858f) > 0) -> offset 1890
        v57 = com.viper.client.utils.RotationUtils.directionFromAngles(arg3, arg4);
        v58 = v56.method_992(v5, v5.method_1019(v57.method_1021(6.5)));
        // if (v58.isPresent() == 0) -> offset 1890
        new Object[2][0] = arg3;
        new Object[2][1] = arg4;
        return new Object[2];
        return v55;
    }

    public static float[] getOrganicRotationsToEntity(net.minecraft.class_746 arg0, net.minecraft.class_1297 arg1, boolean arg2) {
        // if (arg2 == 0) -> offset 12
        return com.viper.client.utils.RotationUtils.getAimPointRotations(arg1, "Torso", "Auto");
    }

    public static boolean raycastStrictServerHitbox(net.minecraft.class_746 arg0, net.minecraft.class_1297 arg1, float arg2, float arg3, double arg4) {
        v6 = arg0.method_33571();
        v7 = arg1.method_5829();
        // if (v7.method_1006(v6) == 0) -> offset 24
        return true;
        v8 = com.viper.client.utils.RotationUtils.directionFromAngles(arg2, arg3);
        v9 = v6.method_1019(v8.method_1021((arg4 + 0.05)));
        v10 = v7.method_992(v6, v9);
        // if (v10.isEmpty() == 0) -> offset 70
        return false;
        v11 = ((net.minecraft.class_243) v10.get());
        v12 = v6.method_1022(v11);
        // if (Double.compare(v12, (arg4 - 0.001)) <= 0) -> offset 103
        return false;
        return com.viper.client.utils.RotationUtils.hasUnobstructedLineOfSight(arg0, v6, v11);
    }

    public static boolean hasUnobstructedLineOfSight(net.minecraft.class_746 arg0, net.minecraft.class_243 arg1, net.minecraft.class_243 arg2) {
        v3 = net.minecraft.class_310.method_1551();
        // if (v3 == null) -> offset 19
        // if (v3.field_1687 == null) -> offset 19
        // if (arg0 != null) -> offset 21
        return true;
        v4 = v3.field_1687.method_17742(new net.minecraft.class_3959(arg1, arg2, net.minecraft.class_3959.class_3960.field_17558, net.minecraft.class_3959.class_242.field_1348, arg0));
        // if (v4 == null) -> offset 62
        // if (v4.method_17783() != net.minecraft.class_239.class_240.field_1333) -> offset 66
        return false;
    }

    public static boolean raycastEntityHitbox(net.minecraft.class_746 arg0, net.minecraft.class_1297 arg1, float arg2, float arg3, double arg4) {
        v6 = arg0.method_33571();
        v7 = arg1.method_5829().method_1014((double)arg1.method_5871());
        // if (v7.method_1006(v6) == 0) -> offset 32
        return true;
        v8 = com.viper.client.utils.RotationUtils.directionFromAngles(arg2, arg3);
        v9 = v6.method_1019(v8.method_1021((arg4 + 0.05)));
        v10 = v7.method_992(v6, v9);
        // if (v10.isPresent() == 0) -> offset 103
        // if (Double.compare(v6.method_1022(((net.minecraft.class_243) v10.get())), (arg4 + 0.001)) > 0) -> offset 103
        return false;
    }

    public static float getAngleDifference(float arg0, float arg1, float arg2, float arg3) {
        v4 = com.viper.client.utils.RotationUtils.wrapDegrees((arg2 - arg0));
        v5 = (arg3 - arg1);
        return (float)Math.hypot((double)v4, (double)v5);
    }

    public static float getAngleToEntity(net.minecraft.class_746 arg0, net.minecraft.class_1297 arg1) {
        v2 = com.viper.client.utils.RotationUtils.getRotationsToEntity(arg0, arg1);
        return com.viper.client.utils.RotationUtils.getAngleDifference(com.viper.client.utils.RotationUtils.getRealViewYaw(arg0), com.viper.client.utils.RotationUtils.getRealViewPitch(arg0), v2[0], v2[1]);
    }

    public static float[] smoothStep(float arg0, float arg1, float arg2, float arg3, float arg4) {
        return com.viper.client.utils.RotationUtils.smoothStepCapped(arg0, arg1, arg2, arg3, arg4, 40.0f, 1.0f);
    }

    public static float[] smoothStepCapped(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5) {
        return com.viper.client.utils.RotationUtils.smoothStepCapped(arg0, arg1, arg2, arg3, arg4, arg5, 1.0f);
    }

    public static float[] smoothStepCapped(float arg0, float arg1, float arg2, float arg3, float arg4, float arg5, float arg6) {
        v7 = com.viper.client.utils.AnimUtils.clamp(arg4, 1.0f, 100.0f);
        v8 = ((v7 - 1.0f) / 99.0f);
        v9 = (float)Math.pow((1.0 - ((double)v8 * 0.88)), 1.42);
        v9 = com.viper.client.utils.AnimUtils.clamp(v9, 0.05999999865889549f, 0.8799999952316284f);
        v10 = com.viper.client.utils.RotationUtils.wrapDegrees((arg2 - arg0));
        v11 = (arg3 - arg1);
        v12 = (float)Math.hypot((double)v10, (double)v11);
        // if (Double.compare(v12, 0.07999999821186066f) >= 0) -> offset 101
        new Object[2][0] = arg0;
        new Object[2][1] = com.viper.client.utils.RotationUtils.clampPitch(arg1);
        return new Object[2];
        v13 = com.viper.client.utils.AnimUtils.clamp(arg6, 0.2199999988079071f, 1.0f);
        v14 = com.viper.client.utils.AnimUtils.clamp((v12 / 26.0f), 0.41999998688697815f, 1.059999942779541f);
        v15 = (0.9399999976158142f + (java.util.concurrent.ThreadLocalRandom.current().nextFloat() * 0.11999999731779099f));
        v16 = com.viper.client.utils.AnimUtils.clamp((((v9 * v14) * v13) * v15), 0.05000000074505806f, 0.8600000143051147f);
        v17 = (arg5 * v13);
        v18 = com.viper.client.utils.AnimUtils.clamp((v10 * v16), (-v17), v17);
        v19 = com.viper.client.utils.AnimUtils.clamp(((v11 * v16) * 0.8600000143051147f), ((-v17) * 0.7599999904632568f), (v17 * 0.7599999904632568f));
        v20 = com.viper.client.utils.RotationUtils.quantizeToMouseGcd(v18);
        v21 = com.viper.client.utils.RotationUtils.quantizeToMouseGcd(v19);
        v22 = com.viper.client.utils.RotationUtils.computeMouseGcdStep();
        // if (Double.compare(v20, 0.0f) != 0) -> offset 269
        // if (Double.compare(Math.abs(v10), (v22 * 1.4500000476837158f)) <= 0) -> offset 269
        v20 = com.viper.client.utils.RotationUtils.quantizeToMouseGcd(Math.copySign(v22, v10));
        // if (Double.compare(v21, 0.0f) != 0) -> offset 303
        // if (Double.compare(Math.abs(v11), (v22 * 1.4500000476837158f)) <= 0) -> offset 303
        v21 = com.viper.client.utils.RotationUtils.quantizeToMouseGcd(Math.copySign(v22, v11));
        new Object[2][0] = (arg0 + v20);
        new Object[2][1] = com.viper.client.utils.RotationUtils.clampPitch((arg1 + v21));
        return new Object[2];
    }

    public static int[] computeRemappedWasd(float arg0, float arg1, float arg2, float arg3) {
        // if (Double.compare(Math.abs(arg0), 9.999999747378752e-05f) >= 0) -> offset 34
        // if (Double.compare(Math.abs(arg1), 9.999999747378752e-05f) >= 0) -> offset 34
        new Object[2][0] = 0;
        new Object[2][1] = 0;
        return new Object[2];
        v4 = Math.toRadians((double)arg2);
        v6 = Math.sin(v4);
        v8 = Math.cos(v4);
        v10 = (((double)arg1 * v8) - ((double)arg0 * v6));
        v12 = (((double)arg0 * v8) + ((double)arg1 * v6));
        v14 = Math.hypot(v10, v12);
        // if (Double.compare(v14, 1e-06) >= 0) -> offset 111
        new Object[2][0] = 0;
        new Object[2][1] = 0;
        return new Object[2];
        v10 = (v10 / v14);
        v12 = (v12 / v14);
        v16 = Math.toRadians((double)arg3);
        v18 = Math.sin(v16);
        v20 = Math.cos(v16);
        v22 = 0;
        v23 = 0;
        v24 = -2.0;
        v26 = -1;
        // if (v26 > 1) -> offset 294
        v27 = -1;
        // if (v27 > 1) -> offset 288
        // if (v26 != 0) -> offset 188
        // if (v27 != 0) -> offset 188
        // if (v26 == 0) -> offset 204
        // if (v27 == 0) -> offset 204
        v28 = 1.0;
        v30 = ((double)v26 * v28);
        v32 = ((double)v27 * v28);
        v34 = ((v32 * v20) - (v30 * v18));
        v36 = ((v30 * v20) + (v32 * v18));
        v38 = ((v10 * v34) + (v12 * v36));
        // if (Double.compare(v38, v24) <= 0) -> offset 282
        v24 = v38;
        v22 = v26;
        v23 = v27;
        v27 += 1;
        v26 += 1;
        new Object[2][0] = v22;
        new Object[2][1] = v23;
        return new Object[2];
    }

    public static void driveSilentRotation(net.minecraft.class_746 arg0, float arg1, float arg2, float arg3, boolean arg4, int arg5) {
        com.viper.client.utils.RotationUtils.driveSilentRotationCapped(arg0, arg1, arg2, arg3, 38.0f, arg4, arg5);
        return;
    }

    public static void driveSilentRotationCapped(net.minecraft.class_746 arg0, float arg1, float arg2, float arg3, float arg4, boolean arg5, int arg6) {
        // if (com.viper.client.utils.RotationUtils.silentControlling == 0) -> offset 21
        // if (com.viper.client.utils.RotationUtils.silentReturning != 0) -> offset 21
        // if (arg6 >= com.viper.client.utils.RotationUtils.silentOwnerPriority) -> offset 21
        return;
        // if (com.viper.client.utils.RotationUtils.silentControlling != 0) -> offset 89
        v7 = arg0.method_36454();
        v8 = arg0.method_36455();
        com.viper.client.utils.RotationUtils.cameraYaw = v7;
        com.viper.client.utils.RotationUtils.cameraPitch = v8;
        com.viper.client.utils.RotationUtils.serverYaw = v7;
        com.viper.client.utils.RotationUtils.serverPitch = v8;
        com.viper.client.utils.RotationUtils.prevServerYaw = v7;
        com.viper.client.utils.RotationUtils.prevServerPitch = v8;
        com.viper.client.utils.RotationUtils.lastSilentYawVel = 0.0f;
        com.viper.client.utils.RotationUtils.lastSilentPitchVel = 0.0f;
        com.viper.client.utils.RotationUtils.silentAcquireProgress = 0.0f;
        com.viper.client.utils.RotationUtils.silentControlling = 1;
        com.viper.client.utils.RotationUtils.lastPlayerRef = arg0;
        com.viper.client.utils.RotationUtils.silentReturning = 0;
        com.viper.client.utils.RotationUtils.silentOwnerPriority = arg6;
        com.viper.client.utils.RotationUtils.silentSmoothness = com.viper.client.utils.AnimUtils.clamp(arg3, 1.0f, 100.0f);
        com.viper.client.utils.RotationUtils.moveFixActive = arg5;
        com.viper.client.utils.RotationUtils.silentFedThisTick = 1;
        com.viper.client.utils.RotationUtils.silentAcquireProgress = Math.min(1.0f, (com.viper.client.utils.RotationUtils.silentAcquireProgress + 0.2199999988079071f));
        v7 = com.viper.client.utils.AnimUtils.easeOutCubic(com.viper.client.utils.RotationUtils.silentAcquireProgress);
        v8 = com.viper.client.utils.RotationUtils.smoothStepCapped(com.viper.client.utils.RotationUtils.serverYaw, com.viper.client.utils.RotationUtils.serverPitch, arg1, arg2, com.viper.client.utils.RotationUtils.silentSmoothness, arg4, v7);
        v9 = com.viper.client.utils.RotationUtils.wrapDegrees((v8[0] - com.viper.client.utils.RotationUtils.serverYaw));
        v10 = (v8[1] - com.viper.client.utils.RotationUtils.serverPitch);
        v11 = Math.max(20.0f, (arg4 * 0.6499999761581421f));
        v12 = com.viper.client.utils.RotationUtils.quantizeToMouseGcd((com.viper.client.utils.RotationUtils.lastSilentYawVel + com.viper.client.utils.AnimUtils.clamp((v9 - com.viper.client.utils.RotationUtils.lastSilentYawVel), (-v11), v11)));
        v13 = com.viper.client.utils.RotationUtils.quantizeToMouseGcd((com.viper.client.utils.RotationUtils.lastSilentPitchVel + com.viper.client.utils.AnimUtils.clamp((v10 - com.viper.client.utils.RotationUtils.lastSilentPitchVel), ((-v11) * 0.800000011920929f), (v11 * 0.800000011920929f))));
        com.viper.client.utils.RotationUtils.lastSilentYawVel = v12;
        com.viper.client.utils.RotationUtils.lastSilentPitchVel = v13;
        com.viper.client.utils.RotationUtils.serverYaw = (com.viper.client.utils.RotationUtils.serverYaw + v12);
        com.viper.client.utils.RotationUtils.serverPitch = com.viper.client.utils.RotationUtils.clampPitch((com.viper.client.utils.RotationUtils.serverPitch + v13));
        com.viper.client.utils.RotationUtils.applyServerAnglesToEntity(arg0);
        return;
    }

    public static void releaseSilentRotation(int arg0) {
        // if (com.viper.client.utils.RotationUtils.silentControlling == 0) -> offset 13
        // if (arg0 >= com.viper.client.utils.RotationUtils.silentOwnerPriority) -> offset 14
        return;
        com.viper.client.utils.RotationUtils.silentReturning = 1;
        com.viper.client.utils.RotationUtils.silentOwnerPriority = 0;
        return;
    }

    public static void clearSilentRotation() {
        // if (com.viper.client.utils.RotationUtils.silentControlling == 0) -> offset 14
        com.viper.client.utils.RotationUtils.silentReturning = 1;
        com.viper.client.utils.RotationUtils.silentOwnerPriority = 0;
        return;
    }

    public static void setSilentRotation(float arg0, float arg1, int arg2, boolean arg3) {
        v4 = net.minecraft.class_310.method_1551();
        // if (v4 == null) -> offset 36
        // if (v4.field_1724 == null) -> offset 36
        com.viper.client.utils.RotationUtils.driveSilentRotation(v4.field_1724, arg0, arg1, 55.0f, arg3, 1);
        com.viper.client.utils.RotationUtils.serverYaw = arg0;
        com.viper.client.utils.RotationUtils.serverPitch = com.viper.client.utils.RotationUtils.clampPitch(arg1);
        com.viper.client.utils.RotationUtils.silentControlling = 1;
        com.viper.client.utils.RotationUtils.moveFixActive = arg3;
        com.viper.client.utils.RotationUtils.silentFedThisTick = 1;
        return;
    }

    public static void beginClientTick() {
        v0 = net.minecraft.class_310.method_1551();
        // if (v0 == null) -> offset 32
        // if (v0.field_1724 == null) -> offset 32
        // if (v0.field_1687 == null) -> offset 32
        // if (v0.field_1724.method_5805() != 0) -> offset 36
        com.viper.client.utils.RotationUtils.forceResetAll();
        return;
        // if (com.viper.client.utils.RotationUtils.lastPlayerRef == null) -> offset 55
        // if (com.viper.client.utils.RotationUtils.lastPlayerRef == v0.field_1724) -> offset 55
        com.viper.client.utils.RotationUtils.forceResetAll();
        com.viper.client.utils.RotationUtils.lastPlayerRef = v0.field_1724;
        // if (com.viper.client.utils.RotationUtils.silentControlling == 0) -> offset 80
        com.viper.client.utils.RotationUtils.prevServerYaw = com.viper.client.utils.RotationUtils.serverYaw;
        com.viper.client.utils.RotationUtils.prevServerPitch = com.viper.client.utils.RotationUtils.serverPitch;
        com.viper.client.utils.RotationUtils.silentFedThisTick = 0;
        return;
    }

    public static void finishClientTick() {
        // if (com.viper.client.utils.RotationUtils.silentControlling != 0) -> offset 7
        return;
        v0 = net.minecraft.class_310.method_1551();
        // if (v0 == null) -> offset 22
        // if (v0.field_1724 != null) -> offset 26
        com.viper.client.utils.RotationUtils.forceResetAll();
        return;
        v1 = v0.field_1724;
        // if (com.viper.client.utils.RotationUtils.silentFedThisTick != 0) -> offset 45
        com.viper.client.utils.RotationUtils.silentReturning = 1;
        com.viper.client.utils.RotationUtils.silentOwnerPriority = 0;
        // if (com.viper.client.utils.RotationUtils.silentReturning == 0) -> offset 288
        com.viper.client.utils.RotationUtils.silentAcquireProgress = Math.max(0.0f, (com.viper.client.utils.RotationUtils.silentAcquireProgress - 0.1599999964237213f));
        v2 = com.viper.client.utils.AnimUtils.clamp((com.viper.client.utils.RotationUtils.silentSmoothness * 0.7799999713897705f), 28.0f, 82.0f);
        v3 = com.viper.client.utils.RotationUtils.smoothStepCapped(com.viper.client.utils.RotationUtils.serverYaw, com.viper.client.utils.RotationUtils.serverPitch, com.viper.client.utils.RotationUtils.cameraYaw, com.viper.client.utils.RotationUtils.cameraPitch, v2, 36.0f, 0.9200000166893005f);
        com.viper.client.utils.RotationUtils.lastSilentYawVel = com.viper.client.utils.RotationUtils.wrapDegrees((v3[0] - com.viper.client.utils.RotationUtils.serverYaw));
        com.viper.client.utils.RotationUtils.lastSilentPitchVel = (v3[1] - com.viper.client.utils.RotationUtils.serverPitch);
        com.viper.client.utils.RotationUtils.serverYaw = v3[0];
        com.viper.client.utils.RotationUtils.serverPitch = v3[1];
        v4 = com.viper.client.utils.RotationUtils.getAngleDifference(com.viper.client.utils.RotationUtils.serverYaw, com.viper.client.utils.RotationUtils.serverPitch, com.viper.client.utils.RotationUtils.cameraYaw, com.viper.client.utils.RotationUtils.cameraPitch);
        // if (Double.compare(v4, Math.max(0.3499999940395355f, (com.viper.client.utils.RotationUtils.computeMouseGcdStep() * 2.0999999046325684f))) > 0) -> offset 288
        v5 = (com.viper.client.utils.RotationUtils.serverYaw + com.viper.client.utils.RotationUtils.quantizeToMouseGcd(com.viper.client.utils.RotationUtils.wrapDegrees((com.viper.client.utils.RotationUtils.cameraYaw - com.viper.client.utils.RotationUtils.serverYaw))));
        v6 = com.viper.client.utils.RotationUtils.clampPitch((com.viper.client.utils.RotationUtils.serverPitch + com.viper.client.utils.RotationUtils.quantizeToMouseGcd((com.viper.client.utils.RotationUtils.cameraPitch - com.viper.client.utils.RotationUtils.serverPitch))));
        com.viper.client.utils.RotationUtils.cameraYaw = v5;
        com.viper.client.utils.RotationUtils.cameraPitch = v6;
        v1.method_36456(v5);
        v1.method_36457(v6);
        v1.field_5982 = com.viper.client.utils.RotationUtils.prevServerYaw;
        v1.field_6004 = com.viper.client.utils.RotationUtils.prevServerPitch;
        v1.field_6241 = v5;
        v1.field_6259 = com.viper.client.utils.RotationUtils.prevServerYaw;
        com.viper.client.utils.RotationUtils.silentControlling = 0;
        com.viper.client.utils.RotationUtils.silentReturning = 0;
        com.viper.client.utils.RotationUtils.moveFixActive = 0;
        com.viper.client.utils.RotationUtils.silentOwnerPriority = 0;
        com.viper.client.utils.RotationUtils.lastSilentYawVel = 0.0f;
        com.viper.client.utils.RotationUtils.lastSilentPitchVel = 0.0f;
        return;
        com.viper.client.utils.RotationUtils.applyServerAnglesToEntity(v1);
        return;
    }

    public static void tickSilentRotation() {
        com.viper.client.utils.RotationUtils.beginClientTick();
        return;
    }

    private static void applyServerAnglesToEntity(net.minecraft.class_746 arg0) {
        v1 = (com.viper.client.utils.RotationUtils.prevServerYaw + com.viper.client.utils.RotationUtils.wrapDegrees((com.viper.client.utils.RotationUtils.serverYaw - com.viper.client.utils.RotationUtils.prevServerYaw)));
        com.viper.client.utils.RotationUtils.serverYaw = v1;
        arg0.field_5982 = com.viper.client.utils.RotationUtils.prevServerYaw;
        arg0.field_6004 = com.viper.client.utils.RotationUtils.prevServerPitch;
        arg0.method_36456(com.viper.client.utils.RotationUtils.serverYaw);
        arg0.method_36457(com.viper.client.utils.RotationUtils.serverPitch);
        arg0.field_6259 = com.viper.client.utils.RotationUtils.prevServerYaw;
        arg0.field_6241 = com.viper.client.utils.RotationUtils.serverYaw;
        return;
    }

    public static void applySilentMouseDelta(double arg0, double arg1) {
        v4 = (float)(arg0 * 0.15);
        v5 = (float)(arg1 * 0.15);
        com.viper.client.utils.RotationUtils.cameraYaw = (com.viper.client.utils.RotationUtils.cameraYaw + v4);
        com.viper.client.utils.RotationUtils.cameraPitch = com.viper.client.utils.AnimUtils.clamp((com.viper.client.utils.RotationUtils.cameraPitch + v5), -90.0f, 90.0f);
        return;
    }

    public static void onRawMouseInput(double arg0, double arg1) {
        // if (com.viper.client.utils.RotationUtils.cameraControlling == 0) -> offset 12
        // if (com.viper.client.utils.RotationUtils.syntheticMouseDispatch == 0) -> offset 13
        return;
        v4 = (float)(arg0 * 0.15);
        v5 = (float)(arg1 * 0.15);
        com.viper.client.utils.RotationUtils.cameraAnchorYaw = (com.viper.client.utils.RotationUtils.cameraAnchorYaw + v4);
        com.viper.client.utils.RotationUtils.cameraAnchorPitch = com.viper.client.utils.RotationUtils.clampPitch((com.viper.client.utils.RotationUtils.cameraAnchorPitch + v5));
        // if (com.viper.client.utils.RotationUtils.cameraReturning == 0) -> offset 124
        // if (Double.compare(Math.hypot((double)v4, (double)v5), 0.6499999761581421) <= 0) -> offset 124
        v6 = net.minecraft.class_310.method_1551();
        // if (v6 == null) -> offset 124
        // if (v6.field_1724 == null) -> offset 124
        com.viper.client.utils.RotationUtils.cameraAnchorYaw = v6.field_1724.method_36454();
        com.viper.client.utils.RotationUtils.cameraAnchorPitch = v6.field_1724.method_36455();
        com.viper.client.utils.RotationUtils.cameraControlling = 0;
        com.viper.client.utils.RotationUtils.cameraReturning = 0;
        com.viper.client.utils.RotationUtils.cameraOwnerPriority = 0;
        return;
    }

    public static void driveCameraTarget(net.minecraft.class_746 arg0, net.minecraft.class_1297 arg1, String arg2, float arg3, boolean arg4, float arg5, int arg6) {
        // if (com.viper.client.utils.RotationUtils.cameraControlling == 0) -> offset 21
        // if (com.viper.client.utils.RotationUtils.cameraReturning != 0) -> offset 21
        // if (arg6 >= com.viper.client.utils.RotationUtils.cameraOwnerPriority) -> offset 21
        return;
        // if (com.viper.client.utils.RotationUtils.cameraControlling != 0) -> offset 57
        com.viper.client.utils.RotationUtils.cameraAnchorYaw = arg0.method_36454();
        com.viper.client.utils.RotationUtils.cameraAnchorPitch = arg0.method_36455();
        com.viper.client.utils.RotationUtils.cameraAcquireProgress = 0.0f;
        com.viper.client.utils.RotationUtils.pixelAccumX = 0.0;
        com.viper.client.utils.RotationUtils.pixelAccumY = 0.0;
        com.viper.client.utils.RotationUtils.cameraControlling = 1;
        com.viper.client.utils.RotationUtils.cameraReturning = 0;
        com.viper.client.utils.RotationUtils.cameraOwnerPriority = arg6;
        com.viper.client.utils.RotationUtils.cameraTargetEntity = arg1;
        com.viper.client.utils.RotationUtils.cameraHasWorldPoint = 0;
        // if (arg2 != null) -> offset 84
        com.viper.client.utils.RotationUtils.cameraAimPointMode = arg2;
        com.viper.client.utils.RotationUtils.cameraSmoothness = com.viper.client.utils.AnimUtils.clamp(arg3, 1.0f, 100.0f);
        com.viper.client.utils.RotationUtils.cameraReturnOnFinish = arg4;
        com.viper.client.utils.RotationUtils.cameraDeadzoneDeg = Math.max(0.0f, arg5);
        return;
    }

    public static void driveCameraPoint(net.minecraft.class_746 arg0, double arg1, double arg2, double arg3, float arg4, boolean arg5, int arg6) {
        // if (com.viper.client.utils.RotationUtils.cameraControlling == 0) -> offset 21
        // if (com.viper.client.utils.RotationUtils.cameraReturning != 0) -> offset 21
        // if (arg6 >= com.viper.client.utils.RotationUtils.cameraOwnerPriority) -> offset 21
        return;
        // if (com.viper.client.utils.RotationUtils.cameraControlling != 0) -> offset 57
        com.viper.client.utils.RotationUtils.cameraAnchorYaw = arg0.method_36454();
        com.viper.client.utils.RotationUtils.cameraAnchorPitch = arg0.method_36455();
        com.viper.client.utils.RotationUtils.cameraAcquireProgress = 0.0f;
        com.viper.client.utils.RotationUtils.pixelAccumX = 0.0;
        com.viper.client.utils.RotationUtils.pixelAccumY = 0.0;
        com.viper.client.utils.RotationUtils.cameraControlling = 1;
        com.viper.client.utils.RotationUtils.cameraReturning = 0;
        com.viper.client.utils.RotationUtils.cameraOwnerPriority = arg6;
        com.viper.client.utils.RotationUtils.cameraTargetEntity = null;
        com.viper.client.utils.RotationUtils.cameraHasWorldPoint = 1;
        com.viper.client.utils.RotationUtils.cameraPointX = arg1;
        com.viper.client.utils.RotationUtils.cameraPointY = arg2;
        com.viper.client.utils.RotationUtils.cameraPointZ = arg3;
        com.viper.client.utils.RotationUtils.cameraSmoothness = com.viper.client.utils.AnimUtils.clamp(arg4, 1.0f, 100.0f);
        com.viper.client.utils.RotationUtils.cameraReturnOnFinish = arg5;
        com.viper.client.utils.RotationUtils.cameraDeadzoneDeg = 0.15000000596046448f;
        return;
    }

    public static void releaseCameraTarget(int arg0) {
        // if (com.viper.client.utils.RotationUtils.cameraControlling == 0) -> offset 13
        // if (arg0 >= com.viper.client.utils.RotationUtils.cameraOwnerPriority) -> offset 14
        return;
        com.viper.client.utils.RotationUtils.cameraTargetEntity = null;
        com.viper.client.utils.RotationUtils.cameraHasWorldPoint = 0;
        com.viper.client.utils.RotationUtils.cameraOwnerPriority = 0;
        // if (com.viper.client.utils.RotationUtils.cameraReturnOnFinish == 0) -> offset 39
        com.viper.client.utils.RotationUtils.cameraReturning = 1;
        com.viper.client.utils.RotationUtils.cameraControlling = 0;
        com.viper.client.utils.RotationUtils.cameraReturning = 0;
        com.viper.client.utils.RotationUtils.cameraAcquireProgress = 0.0f;
        return;
    }

    public static void onRenderFrame(float arg0) {
        v1 = System.nanoTime();
        v3 = com.viper.client.utils.AnimUtils.clamp(((float)(v1 - com.viper.client.utils.RotationUtils.lastRenderNs) / 1000000000.0f), 0.0005000000237487257f, 0.07999999821186066f);
        com.viper.client.utils.RotationUtils.lastRenderNs = v1;
        // if (com.viper.client.utils.RotationUtils.cameraControlling != 0) -> offset 35
        return;
        v4 = net.minecraft.class_310.method_1551();
        // if (v4 == null) -> offset 69
        // if (v4.field_1724 == null) -> offset 69
        // if (v4.field_1687 == null) -> offset 69
        // if (v4.field_1755 == null) -> offset 90
        com.viper.client.utils.RotationUtils.cameraControlling = 0;
        com.viper.client.utils.RotationUtils.cameraReturning = 0;
        com.viper.client.utils.RotationUtils.cameraTargetEntity = null;
        com.viper.client.utils.RotationUtils.cameraHasWorldPoint = 0;
        com.viper.client.utils.RotationUtils.cameraOwnerPriority = 0;
        return;
        v5 = v4.field_1724;
        v6 = v5.method_36454();
        v7 = v5.method_36455();
        // if (com.viper.client.utils.RotationUtils.cameraReturning != 0) -> offset 220
        // if (com.viper.client.utils.RotationUtils.cameraTargetEntity == null) -> offset 220
        // if (com.viper.client.utils.RotationUtils.cameraTargetEntity.method_5805() == 0) -> offset 220
        com.viper.client.utils.RotationUtils.cameraAcquireProgress = Math.min(1.0f, (com.viper.client.utils.RotationUtils.cameraAcquireProgress + (v3 * 4.5f)));
        v11 = com.viper.client.utils.RotationUtils.getAimPointRotationsForCurrent(v5, com.viper.client.utils.RotationUtils.cameraTargetEntity, com.viper.client.utils.RotationUtils.cameraAimPointMode, v6, v7);
        v12 = com.viper.client.utils.RotationUtils.getAngleDifference(v6, v7, v11[0], v11[1]);
        // if (Double.compare(com.viper.client.utils.RotationUtils.cameraDeadzoneDeg, 0.0f) <= 0) -> offset 200
        // if (Double.compare(v12, com.viper.client.utils.RotationUtils.cameraDeadzoneDeg) >= 0) -> offset 200
        return;
        v8 = v11[0];
        v9 = v11[1];
        v10 = com.viper.client.utils.RotationUtils.cameraSmoothness;
        // if (com.viper.client.utils.RotationUtils.cameraReturning != 0) -> offset 339
        // if (com.viper.client.utils.RotationUtils.cameraHasWorldPoint == 0) -> offset 339
        com.viper.client.utils.RotationUtils.cameraAcquireProgress = Math.min(1.0f, (com.viper.client.utils.RotationUtils.cameraAcquireProgress + (v3 * 5.5f)));
        v11 = v5.method_33571();
        v12 = com.viper.client.utils.RotationUtils.computeRotations(v11.field_1352, v11.field_1351, v11.field_1350, com.viper.client.utils.RotationUtils.cameraPointX, com.viper.client.utils.RotationUtils.cameraPointY, com.viper.client.utils.RotationUtils.cameraPointZ);
        v13 = com.viper.client.utils.RotationUtils.getAngleDifference(v6, v7, v12[0], v12[1]);
        // if (Double.compare(com.viper.client.utils.RotationUtils.cameraDeadzoneDeg, 0.0f) <= 0) -> offset 319
        // if (Double.compare(v13, com.viper.client.utils.RotationUtils.cameraDeadzoneDeg) >= 0) -> offset 319
        return;
        v8 = v12[0];
        v9 = v12[1];
        v10 = com.viper.client.utils.RotationUtils.cameraSmoothness;
        // if (com.viper.client.utils.RotationUtils.cameraReturning == 0) -> offset 450
        com.viper.client.utils.RotationUtils.cameraAcquireProgress = Math.max(0.0f, (com.viper.client.utils.RotationUtils.cameraAcquireProgress - (v3 * 3.5f)));
        v8 = com.viper.client.utils.RotationUtils.cameraAnchorYaw;
        v9 = com.viper.client.utils.RotationUtils.cameraAnchorPitch;
        v10 = com.viper.client.utils.AnimUtils.clamp((com.viper.client.utils.RotationUtils.cameraSmoothness * 0.8500000238418579f), 45.0f, 90.0f);
        v11 = com.viper.client.utils.RotationUtils.getAngleDifference(v6, v7, v8, v9);
        // if (Double.compare(v11, Math.max(0.3499999940395355f, (com.viper.client.utils.RotationUtils.computeMouseGcdStep() * 2.0f))) > 0) -> offset 447
        com.viper.client.utils.RotationUtils.cameraControlling = 0;
        com.viper.client.utils.RotationUtils.cameraReturning = 0;
        com.viper.client.utils.RotationUtils.cameraTargetEntity = null;
        com.viper.client.utils.RotationUtils.cameraHasWorldPoint = 0;
        com.viper.client.utils.RotationUtils.cameraOwnerPriority = 0;
        com.viper.client.utils.RotationUtils.pixelAccumX = 0.0;
        com.viper.client.utils.RotationUtils.pixelAccumY = 0.0;
        return;
        com.viper.client.utils.RotationUtils.cameraControlling = 0;
        com.viper.client.utils.RotationUtils.cameraReturning = 0;
        com.viper.client.utils.RotationUtils.cameraTargetEntity = null;
        com.viper.client.utils.RotationUtils.cameraHasWorldPoint = 0;
        com.viper.client.utils.RotationUtils.cameraOwnerPriority = 0;
        return;
        v11 = com.viper.client.utils.RotationUtils.wrapDegrees((v8 - v6));
        v12 = (v9 - v7);
        v13 = (float)Math.hypot((double)v11, (double)v12);
        // if (Double.compare(v13, 0.05999999865889549f) >= 0) -> offset 510
        return;
        v14 = ((v10 - 1.0f) / 99.0f);
        v15 = (2.5999999046325684f + ((float)Math.pow((double)(1.0f - v14), 1.7200000286102295) * 26.0f));
        // if (com.viper.client.utils.RotationUtils.cameraReturning == 0) -> offset 554
        v16 = (0.25f + (0.75f * com.viper.client.utils.AnimUtils.easeOutCubic(com.viper.client.utils.RotationUtils.cameraAcquireProgress)));
        v17 = com.viper.client.utils.AnimUtils.clamp((v13 / 22.0f), 0.44999998807907104f, 1.0800000429153442f);
        v18 = (0.9599999785423279f + (java.util.concurrent.ThreadLocalRandom.current().nextFloat() * 0.07999999821186066f));
        v19 = (1.0f - (float)Math.exp((double)(((((-v15) * v16) * v17) * v18) * v3)));
        v20 = (((175.0f - (v14 * 110.0f)) * v3) * 4.199999809265137f);
        v21 = (double)com.viper.client.utils.AnimUtils.clamp((v11 * v19), (-v20), v20);
        v23 = (double)com.viper.client.utils.AnimUtils.clamp(((v12 * v19) * 0.8799999952316284f), ((-v20) * 0.7799999713897705f), (v20 * 0.7799999713897705f));
        v25 = Math.max(1e-05, (com.viper.client.utils.RotationUtils.computeMouseMultiplierG() * 0.15));
        com.viper.client.utils.RotationUtils.pixelAccumX = (com.viper.client.utils.RotationUtils.pixelAccumX + (v21 / v25));
        com.viper.client.utils.RotationUtils.pixelAccumY = (com.viper.client.utils.RotationUtils.pixelAccumY + (v23 / v25));
        v27 = Math.round(com.viper.client.utils.RotationUtils.pixelAccumX);
        v29 = Math.round(com.viper.client.utils.RotationUtils.pixelAccumY);
        // if (Double.compare(v27, 0L) != 0) -> offset 758
        // if (Double.compare(v29, 0L) != 0) -> offset 758
        return;
        com.viper.client.utils.RotationUtils.pixelAccumX = (com.viper.client.utils.RotationUtils.pixelAccumX - (double)v27);
        com.viper.client.utils.RotationUtils.pixelAccumY = (com.viper.client.utils.RotationUtils.pixelAccumY - (double)v29);
        com.viper.client.utils.RotationUtils.applySyntheticMousePixels(v5, v27, v29);
        return;
    }

    public static void forceResetAll() {
        com.viper.client.utils.RotationUtils.hasConfirmedAngles = 0;
        com.viper.client.utils.RotationUtils.silentControlling = 0;
        com.viper.client.utils.RotationUtils.silentReturning = 0;
        com.viper.client.utils.RotationUtils.moveFixActive = 0;
        com.viper.client.utils.RotationUtils.silentOwnerPriority = 0;
        com.viper.client.utils.RotationUtils.silentFedThisTick = 0;
        com.viper.client.utils.RotationUtils.silentAcquireProgress = 0.0f;
        com.viper.client.utils.RotationUtils.lastSilentYawVel = 0.0f;
        com.viper.client.utils.RotationUtils.lastSilentPitchVel = 0.0f;
        com.viper.client.utils.RotationUtils.cameraControlling = 0;
        com.viper.client.utils.RotationUtils.cameraReturning = 0;
        com.viper.client.utils.RotationUtils.cameraTargetEntity = null;
        com.viper.client.utils.RotationUtils.cameraHasWorldPoint = 0;
        com.viper.client.utils.RotationUtils.cameraOwnerPriority = 0;
        com.viper.client.utils.RotationUtils.cameraAcquireProgress = 0.0f;
        com.viper.client.utils.RotationUtils.pixelAccumX = 0.0;
        com.viper.client.utils.RotationUtils.pixelAccumY = 0.0;
        return;
    }

    public static boolean isSilentControlling() {
        return com.viper.client.utils.RotationUtils.silentControlling;
    }

    public static boolean hasSilentRotation() {
        return com.viper.client.utils.RotationUtils.silentControlling;
    }

    public static boolean isMoveFixActive() {
        // if (com.viper.client.utils.RotationUtils.silentControlling == 0) -> offset 16
        // if (com.viper.client.utils.RotationUtils.moveFixActive == 0) -> offset 16
        return false;
    }

    public static float getCameraYaw() {
        return com.viper.client.utils.RotationUtils.cameraYaw;
    }

    public static float getCameraPitch() {
        return com.viper.client.utils.RotationUtils.cameraPitch;
    }

    public static float getServerYaw() {
        return com.viper.client.utils.RotationUtils.serverYaw;
    }

    public static float getServerPitch() {
        return com.viper.client.utils.RotationUtils.serverPitch;
    }

    public static float getPrevServerYaw() {
        return com.viper.client.utils.RotationUtils.prevServerYaw;
    }

    public static float getPrevServerPitch() {
        return com.viper.client.utils.RotationUtils.prevServerPitch;
    }

    public static float getSilentYaw() {
        return com.viper.client.utils.RotationUtils.serverYaw;
    }

    public static float getSilentPitch() {
        return com.viper.client.utils.RotationUtils.serverPitch;
    }

}
