package com.viper.client.ui.components;

public final class Dropdown extends com.viper.client.ui.components.UIComponent {
    private static final int OPTION_HEIGHT = 18;
    private final String label;
    private final java.util.function.Supplier getter;
    private final java.util.function.Consumer setter;
    private final java.util.List options;
    private Runnable onOpenCallback;
    private boolean expanded;
    private float expandAnim;

    public Dropdown(String arg0, String arg1, java.util.function.Supplier arg2, java.util.function.Consumer arg3, java.util.List arg4) {
        super();
        this.expanded = 0;
        this.expandAnim = 0.0f;
        this.label = arg0;
        this.getter = arg2;
        this.setter = arg3;
        this.options = java.util.List.copyOf(arg4);
        this.setDescription(arg1);
        return;
    }

    public Dropdown(String arg0, java.util.function.Supplier arg1, java.util.function.Consumer arg2, java.util.List arg3) {
        this(arg0, "", arg1, arg2, arg3);
        return;
    }

    public Dropdown(com.viper.client.modules.Setting.ModeSetting arg0) {
        java.util.Objects.requireNonNull(arg0);
        java.util.Objects.requireNonNull(arg0);
        this(arg0.getName(), arg0.getDescription(), get(arg0), accept(arg0), arg0.getModes());
        this.setVisibleSupplier(arg0.getVisibleCondition());
        return;
    }

    public String getLabel() {
        return this.label;
    }

    public void setOnOpenCallback(Runnable arg0) {
        this.onOpenCallback = arg0;
        return;
    }

    public boolean isExpanded() {
        return this.expanded;
    }

    public void setExpanded(boolean arg0) {
        this.expanded = arg0;
        return;
    }

    protected void onHidden() {
        this.expanded = 0;
        return;
    }

    public String getSelected() {
        return ((java.lang.String) this.getter.get());
    }

    public int getRenderedHeight() {
        v1 = Math.round(((float)((this.options.size() * 18) + 4) * com.viper.client.utils.AnimUtils.easeOutCubic(this.expandAnim)));
        return (this.height + v1);
    }

    public void render(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, com.viper.client.ui.ThemeManager arg2, int arg3, int arg4, float arg5) {
        this.updateBaseAnimations((double)arg3, (double)arg4, arg5);
        // if (this.expanded == 0) -> offset 28
        this.expandAnim.expandAnim = com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 18.0f, arg5);
        this.pushInteractiveScale(arg0, 0.012000000104308128f);
        v7 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.dropdownBg(), arg2.cardHoverBg(), (this.hoverAnim * 0.75f)));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, this.x, this.y, this.width, this.height, v7);
        // if (this.expanded == 0) -> offset 124
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(this.x, this.y, this.width, this.height, this, arg2.accentSecondary().applyAlpha(arg2.borderSubtle()));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, this.label, (this.x + 8), (this.y + ((this.height - 8) / 2)), this.applyAlpha(arg2.textSecondary()), 0);
        v8 = ((java.lang.String) this.getter.get());
        v9 = com.viper.client.utils.AtlasRenderer.getTextWidth(arg1, v8);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, v8, (((this.x + this.width) - v9) - 20), (this.y + ((this.height - 8) / 2)), this.applyAlpha(arg2.textPrimary()), 0);
        // if (this.expanded == 0) -> offset 254
        com.viper.client.utils.AtlasRenderer.drawIcon(com.viper.client.ui.Icons.CHEVRON_DOWN, com.viper.client.ui.Icons.CHEVRON_RIGHT, ((this.x + this.width) - 16), (this.y + ((this.height - 10) / 2)), 10, this.applyAlpha(arg2.accentSecondary()));
        this.popInteractiveScale(arg0);
        v10 = Math.round(((float)((this.options.size() * 18) + 2) * com.viper.client.utils.AnimUtils.easeOutCubic(this.expandAnim)));
        // if (v10 <= 3) -> offset 701
        v11 = ((this.y + this.height) + 2);
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, (this.x + 1), v11, (this.width - 2), v10, this.applyAlpha(arg2.dropdownBg()));
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, (this.x + 1), v11, (this.width - 2), v10, this.applyAlpha(arg2.borderStrong()));
        v12 = 0;
        // if (v12 >= this.options.size()) -> offset 701
        v13 = ((v11 + 1) + (v12 * 18));
        // if ((v13 + 18) <= ((v11 + v10) + 2)) -> offset 451
        v14 = ((java.lang.String) this.options.get(v12));
        // if (arg3 < (this.x + 2)) -> offset 515
        // if (arg3 > ((this.x + this.width) - 2)) -> offset 515
        // if (arg4 < v13) -> offset 515
        // if (arg4 >= (v13 + 18)) -> offset 515
        v15 = 0;
        v16 = v14.equalsIgnoreCase(v8);
        // if (v16 == 0) -> offset 566
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, (this.x + 3), (v13 + 1), (this.width - 6), 16, this.applyAlpha(arg2.accentSoftBg()));
        // if (v15 == 0) -> offset 602
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, (this.x + 3), (v13 + 1), (this.width - 6), 16, this.applyAlpha(arg2.cardHoverBg()));
        // if (v16 == 0) -> offset 615
        // if (v15 == 0) -> offset 627
        v17 = arg2.textPrimary().applyAlpha(arg2.textSecondary());
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, v14, (this.x + 9), (v13 + 5), v17, 0);
        // if (v16 == 0) -> offset 695
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.CHECK, ((this.x + this.width) - 17), (v13 + 4), 10, this.applyAlpha(arg2.accentSecondary()));
        v12 += 1;
        return;
    }

    public boolean mouseClicked(double arg0, double arg1, int arg2) {
        // if (this.isMouseOver(arg0, arg1) == 0) -> offset 128
        // if (arg2 != 0) -> offset 61
        // if (this.expanded != 0) -> offset 25
        v6 = 0;
        // if (v6 == 0) -> offset 49
        // if (this.onOpenCallback == null) -> offset 49
        this.onOpenCallback.run();
        this.expanded = v6;
        this.triggerPress();
        return true;
        // if (arg2 != 1) -> offset 128
        v6 = this.options.indexOf(this.getter.get());
        this.setter.accept(((java.lang.String) this.options.get(((v6 + 1) % this.options.size()))));
        this.triggerPress();
        return true;
        // if (this.expanded == 0) -> offset 294
        // if (Double.compare(this.expandAnim, 0.44999998807907104f) <= 0) -> offset 294
        // if (arg2 != 0) -> offset 294
        v6 = ((this.y + this.height) + 2);
        v7 = ((this.options.size() * 18) + 2);
        // if (Double.compare(arg0, (double)(this.x + 1)) < 0) -> offset 294
        // if (Double.compare(arg0, (double)((this.x + this.width) - 1)) > 0) -> offset 294
        // if (Double.compare(arg1, (double)v6) < 0) -> offset 294
        // if (Double.compare(arg1, (double)(v6 + v7)) > 0) -> offset 294
        v8 = (int)((arg1 - (double)(v6 + 1)) / 18.0);
        // if (v8 < 0) -> offset 294
        // if (v8 >= this.options.size()) -> offset 294
        this.setter.accept(((java.lang.String) this.options.get(v8)));
        this.expanded = 0;
        this.triggerPress();
        return true;
        return false;
    }

}
