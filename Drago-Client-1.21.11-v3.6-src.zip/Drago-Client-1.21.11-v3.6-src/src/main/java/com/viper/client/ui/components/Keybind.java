package com.viper.client.ui.components;

import com.viper.client.modules.Setting;
import com.viper.client.ui.Icons;
import com.viper.client.ui.ThemeManager;
import com.viper.client.utils.AnimUtils;
import com.viper.client.utils.AtlasRenderer;
import com.viper.client.utils.KeyUtils;
import net.minecraft.class_327;
import net.minecraft.class_332;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

public final class Keybind extends UIComponent {
    private final String label;
    private final IntSupplier getter;
    private final IntConsumer setter;
    private boolean listening;
    private float listenAnim;

    public Keybind(String label, String description, IntSupplier getter, IntConsumer setter) {
        this.label = label;
        this.getter = getter;
        this.setter = setter;
        this.setDescription(description);
    }

    public Keybind(Setting.KeybindSetting setting) {
        this(setting.getName(), "Bind a keyboard or mouse shortcut for " + setting.getName() + " (Right-Click to clear)", setting::getKeyCode, setting::setKeyCode);
    }

    public boolean isListening() { return listening; }
    public void setListening(boolean listening) { this.listening = listening; }

    @Override
    public void render(class_332 ctx, class_327 tr, ThemeManager theme, int mouseX, int mouseY, float dt) {
        updateBaseAnimations(mouseX, mouseY, dt);
        listenAnim = AnimUtils.damp(listenAnim, listening ? 1.0f : 0.0f, 16.0f, dt);
        pushInteractiveScale(ctx, 0.012f);
        int bg = applyAlpha(AnimUtils.lerpColor(theme.settingsDrawerBg(), theme.cardHoverBg(), hoverAnim * 0.65f));
        AtlasRenderer.drawRoundedRect(ctx, x, y, width, height, bg);
        if (listening) {
            AtlasRenderer.drawRoundedBorder(ctx, x, y, width, height, applyAlpha(theme.accentSecondary()));
        } else {
            AtlasRenderer.drawRoundedBorder(ctx, x, y, width, height, applyAlpha(theme.borderSubtle()));
        }
        AtlasRenderer.drawIcon(ctx, Icons.KEYBIND, x + 7, y + (height - 11) / 2, 11, applyAlpha(listening ? theme.accentSecondary() : theme.textSecondary()));
        AtlasRenderer.drawText(ctx, tr, label, x + 22, y + (height - 8) / 2, applyAlpha(theme.textSecondary()), false);
        String keyLabel = listening ? "Press Key..." : KeyUtils.getKeyName(getter.getAsInt());
        int pillW = AtlasRenderer.getTextWidth(tr, keyLabel) + 12;
        int pillX = x + width - pillW - 5;
        int pillY = y + 3;
        int pillH = height - 6;
        AtlasRenderer.drawRoundedRect(ctx, pillX, pillY, pillW, pillH, applyAlpha(AnimUtils.lerpColor(theme.controlTrackBg(), theme.accentSoftBg(), listenAnim)));
        if (listening) AtlasRenderer.drawRoundedBorder(ctx, pillX, pillY, pillW, pillH, applyAlpha(theme.accentSecondary()));
        AtlasRenderer.drawText(ctx, tr, keyLabel, pillX + 6, y + (height - 8) / 2, applyAlpha(listening ? theme.accentSecondary() : theme.textPrimary()), false);
        popInteractiveScale(ctx);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (listening && button >= 2 && button <= 7) {
            setter.accept(1000 + button);
            listening = false;
            triggerPress();
            return true;
        }
        if (!isMouseOver(mouseX, mouseY)) {
            listening = false;
            return false;
        }
        if (button == 0) {
            listening = !listening;
            triggerPress();
            return true;
        }
        if (button == 1) {
            setter.accept(-1);
            listening = false;
            triggerPress();
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode) {
        if (!listening) return false;
        if (keyCode == KeyUtils.KEY_ESCAPE || keyCode == KeyUtils.KEY_BACKSPACE || keyCode == KeyUtils.KEY_DELETE) {
            setter.accept(-1);
        } else {
            setter.accept(keyCode);
        }
        listening = false;
        return true;
    }
}
