package com.viper.client.modules.hacks.combat;

import com.viper.client.ViperClient;
import com.viper.client.modules.Category;
import com.viper.client.modules.Module;
import com.viper.client.modules.Setting;
import com.viper.client.utils.ClickSimulator;
import com.viper.client.utils.HotbarCoordinator;
import com.viper.client.utils.KeyUtils;
import com.viper.client.utils.RotationUtils;
import com.viper.client.utils.WeaponUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_746;

public final class AutoHitCrystal extends Module {
    private static final String OWNER_ID = "auto_hit_crystal";
    private static final int HOTBAR_PRIORITY = 42;
    private static final int ROTATION_PRIORITY = 7;
    private static boolean bypassingUse;

    public final Setting.ModeSetting mode;
    public final Setting.BooleanSetting onKey;
    public final Setting.KeybindSetting triggerKey;
    public final Setting.BooleanSetting explodeIt;
    public final Setting.NumberSetting placeObsidianDelay;
    public final Setting.NumberSetting placeCrystalDelay;
    public final Setting.NumberSetting explodeDelay;
    public final Setting.BooleanSetting switchBack;
    public final Setting.BooleanSetting simulateClick;

    private Phase phase = Phase.IDLE;
    private int obsidianSlot = -1;
    private int crystalSlot = -1;
    private class_1268 crystalHand = class_1268.field_5808;
    private class_2338 clickPos;
    private class_2350 clickSide = class_2350.field_11036;
    private class_243 clickHitVec;
    private class_2338 obsidianPos;
    private long nextStepAtMs;
    private long phaseTimeoutMs;
    private long waitCrystalTimeoutMs;
    private boolean wasKeyDown;

    public AutoHitCrystal() {
        super("auto_hit_crystal", "AutoHitCrystal", "Auto places Obsidian + End Crystal + Explodes (via right-click or On Key from any item).", Category.COMBAT, "auto_hit_crystal", -1);
        this.mode = registerSetting(new Setting.ModeSetting("mode", "Mode", "Aim controller mode: Silent server aim or Legit aim", "Silent", new String[]{"Silent", "Legit"}));
        this.onKey = registerSetting(new Setting.BooleanSetting("on_key", "On Key", "Press bound key to swap Obsidian -> Crystal -> Explode from any held item", false));
        this.triggerKey = (Setting.KeybindSetting) registerSetting(new Setting.KeybindSetting("trigger_key", "Key", "Key to grab Obsidian & Crystal then explode", -1)).visibleWhen(() -> Boolean.TRUE.equals(onKey.getValue()));
        this.explodeIt = registerSetting(new Setting.BooleanSetting("explode_it", "Explode It", "Automatically punch placed End Crystal to detonate", true));
        this.placeObsidianDelay = registerSetting(new Setting.NumberSetting("place_obsidian_delay", "Place Obsidian Delay", "Delay before placing Obsidian (0-100ms)", 15.0, 0.0, 100.0, 5.0, "ms"));
        this.placeCrystalDelay = registerSetting(new Setting.NumberSetting("place_crystal_delay", "Place Crystal Delay", "Delay before placing End Crystal (0-100ms)", 20.0, 0.0, 100.0, 5.0, "ms"));
        this.explodeDelay = registerSetting(new Setting.NumberSetting("explode_delay", "Explode Delay", "Delay before hitting End Crystal to explode (0-100ms)", 25.0, 0.0, 100.0, 5.0, "ms"));
        this.switchBack = registerSetting(new Setting.BooleanSetting("switch_back", "Switch Back", "Restore previous hotbar slot after combo", true));
        this.simulateClick = registerSetting(new Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left/Right click presses", true));
    }

    public static boolean isBypassingUse() { return bypassingUse; }

    @Override
    protected void onDisable() {
        abortSequence();
        wasKeyDown = false;
    }

    private void abortSequence() {
        phase = Phase.IDLE;
        obsidianPos = null;
        clickPos = null;
        RotationUtils.releaseSilentRotation(ROTATION_PRIORITY);
        RotationUtils.releaseCameraTarget(ROTATION_PRIORITY);
        HotbarCoordinator.releaseOwner(OWNER_ID, Boolean.TRUE.equals(switchBack.getValue()));
    }

    private static int findHotbarSlot(class_746 player, boolean findCrystal) {
        String id = findCrystal ? "minecraft:end_crystal" : "minecraft:obsidian";
        for (int i = 0; i < 9; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (!stack.method_7960() && id.equals(WeaponUtils.getItemId(stack))) return i;
        }
        return -1;
    }

    private void pollTriggerKey(class_310 mc) {
        if (!Boolean.TRUE.equals(onKey.getValue()) || mc.field_1755 != null) {
            wasKeyDown = false;
            return;
        }
        int code = triggerKey.getKeyCode();
        if (code < 0) {
            wasKeyDown = false;
            return;
        }
        boolean down = KeyUtils.isBindDown(mc.method_22683().method_4490(), code);
        boolean pressed = down && !wasKeyDown;
        wasKeyDown = down;
        if (pressed && phase == Phase.IDLE) tryStart(mc);
    }

    public boolean interceptDoItemUse(class_310 mc) {
        if (Boolean.TRUE.equals(onKey.getValue())) return false;
        return tryStart(mc);
    }

    private boolean tryStart$viperImpl(class_310 mc) {
        if (bypassingUse || mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return false;
        if (mc.field_1755 != null || phase != Phase.IDLE) return false;
        class_746 player = mc.field_1724;
        boolean manualKey = Boolean.TRUE.equals(onKey.getValue());
        int obsSlot = findHotbarSlot(player, false);
        int crySlot = findHotbarSlot(player, true);
        boolean offCrystal = "minecraft:end_crystal".equals(WeaponUtils.getItemId(player.method_6079()));
        class_1268 cHand = offCrystal ? class_1268.field_5810 : class_1268.field_5808;
        if (cHand == class_1268.field_5808 && crySlot < 0) return false;

        class_2338 targetBlock = null;
        class_2350 side = class_2350.field_11036;
        class_243 hitVec = null;
        if (mc.field_1765 instanceof class_3965 bhr) {
            targetBlock = bhr.method_17777();
            side = bhr.method_17780();
            hitVec = bhr.method_17784();
        } else if (mc.field_1765 instanceof class_3966 ehr) {
            class_1297 ent = ehr.method_17782();
            if (ent != null) {
                targetBlock = ent.method_24515().method_10074();
                hitVec = targetBlock.method_46558().method_1031(0.0, 0.5, 0.0);
            }
        }
        if (targetBlock == null) return false;

        class_2680 state = mc.field_1687.method_8320(targetBlock);
        boolean alreadyObs = state != null && state.method_27852(class_2246.field_10540);
        if (alreadyObs) {
            int initSlot = cHand == class_1268.field_5808 ? crySlot : player.method_31548().method_67532();
            if (!HotbarCoordinator.beginSequence(OWNER_ID, HOTBAR_PRIORITY, initSlot, Boolean.TRUE.equals(switchBack.getValue()))) return false;
            obsidianSlot = obsSlot;
            crystalSlot = crySlot;
            crystalHand = cHand;
            obsidianPos = targetBlock;
            clickPos = targetBlock;
            clickSide = class_2350.field_11036;
            clickHitVec = targetBlock.method_46558().method_1031(0.0, 0.5, 0.0);
            phase = Phase.WAIT_PLACE_CRYSTAL;
            nextStepAtMs = System.currentTimeMillis() + Math.max(0L, placeCrystalDelay.longValue());
            phaseTimeoutMs = System.currentTimeMillis() + Math.max(450L, placeCrystalDelay.longValue() + 300L);
            advanceSequence();
            return true;
        }
        if (obsSlot < 0) return false;
        if (!manualKey && !"minecraft:obsidian".equals(WeaponUtils.getItemId(player.method_6047())) && !WeaponUtils.isHoldingWeapon(player)) return false;
        if (!HotbarCoordinator.beginSequence(OWNER_ID, HOTBAR_PRIORITY, obsSlot, Boolean.TRUE.equals(switchBack.getValue()))) return false;
        obsidianSlot = obsSlot;
        crystalSlot = crySlot;
        crystalHand = cHand;
        clickPos = targetBlock;
        clickSide = side;
        clickHitVec = hitVec != null ? hitVec : targetBlock.method_46558();
        obsidianPos = state != null && state.method_45474() ? targetBlock : targetBlock.method_10093(side);
        phase = Phase.WAIT_PLACE_OBSIDIAN;
        nextStepAtMs = System.currentTimeMillis() + Math.max(0L, placeObsidianDelay.longValue());
        phaseTimeoutMs = System.currentTimeMillis() + Math.max(450L, placeObsidianDelay.longValue() + 300L);
        advanceSequence();
        return true;
    }

    private float[] aimAtPoint(class_746 player, class_243 point) {
        class_243 eye = player.method_33571();
        float[] rot = RotationUtils.computeRotations(eye.field_1352, eye.field_1351, eye.field_1350, point.field_1352, point.field_1351, point.field_1350);
        if (mode.is("Silent")) {
            RotationUtils.releaseCameraTarget(ROTATION_PRIORITY);
            RotationUtils.driveSilentRotationCapped(player, rot[0], rot[1], 18.0f, 120.0f, false, ROTATION_PRIORITY);
            return new float[]{RotationUtils.getServerYaw(), RotationUtils.getServerPitch()};
        }
        RotationUtils.releaseSilentRotation(ROTATION_PRIORITY);
        RotationUtils.driveCameraPoint(player, point.field_1352, point.field_1351, point.field_1350, 46.0f, true, ROTATION_PRIORITY);
        return new float[]{player.method_36454(), player.method_36455()};
    }

    private class_1511 findSpawnedCrystal(class_310 mc, class_2338 obsPos) {
        class_243 top = obsPos.method_10093(class_2350.field_11036).method_46558();
        class_1511 best = null;
        double bestDist = 9.0;
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e instanceof class_1511 crystal && crystal.method_5805()) {
                double dx = crystal.method_23317() - top.field_1352;
                double dy = crystal.method_23318() - (top.field_1351 - 0.5);
                double dz = crystal.method_23321() - top.field_1350;
                double d2 = dx * dx + dy * dy + dz * dz;
                if (d2 < bestDist) { bestDist = d2; best = crystal; }
            }
        }
        return best;
    }

    private void advanceSequence$viperImpl() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        pollTriggerKey(mc);
        if (phase == Phase.IDLE) return;
        if (mc.field_1755 != null) { abortSequence(); return; }
        long now = System.currentTimeMillis();
        class_746 player = mc.field_1724;

        if (phase == Phase.WAIT_PLACE_OBSIDIAN) {
            if (now >= phaseTimeoutMs) { abortSequence(); return; }
            aimAtPoint(player, clickHitVec);
            if (now < nextStepAtMs) return;
            if (!HotbarCoordinator.selectSlotInSequence(OWNER_ID, HOTBAR_PRIORITY, obsidianSlot, Boolean.TRUE.equals(switchBack.getValue()))) {
                if (HotbarCoordinator.canSwitchSlotThisTick()) abortSequence();
                return;
            }
            bypassingUse = true;
            try {
                class_1269 res = ClickSimulator.interactBlock(mc.field_1761, player, class_1268.field_5808, new class_3965(clickHitVec, clickSide, clickPos, false));
                if (res != null && res.method_23665()) player.method_6104(class_1268.field_5808);
            } finally {
                bypassingUse = false;
            }
            phase = Phase.WAIT_PLACE_CRYSTAL;
            nextStepAtMs = now + Math.max(0L, placeCrystalDelay.longValue());
            phaseTimeoutMs = now + Math.max(450L, placeCrystalDelay.longValue() + 300L);
            if (placeCrystalDelay.longValue() > 0L) return;
        }

        if (phase == Phase.WAIT_PLACE_CRYSTAL) {
            if (obsidianPos == null || now >= phaseTimeoutMs) { abortSequence(); return; }
            class_243 topVec = obsidianPos.method_46558().method_1031(0.0, 0.5, 0.0);
            aimAtPoint(player, topVec);
            if (now < nextStepAtMs) return;
            if (crystalHand == class_1268.field_5808) {
                int cSlot = findHotbarSlot(player, true);
                if (cSlot < 0 || !HotbarCoordinator.selectSlotInSequence(OWNER_ID, HOTBAR_PRIORITY, cSlot, Boolean.TRUE.equals(switchBack.getValue()))) {
                    if (cSlot < 0 || HotbarCoordinator.canSwitchSlotThisTick()) abortSequence();
                    return;
                }
            }
            bypassingUse = true;
            try {
                class_1269 res = ClickSimulator.interactBlock(mc.field_1761, player, crystalHand, new class_3965(topVec, class_2350.field_11036, obsidianPos, false));
                if (res != null && res.method_23665()) player.method_6104(crystalHand);
            } finally {
                bypassingUse = false;
            }
            if (!Boolean.TRUE.equals(explodeIt.getValue())) { abortSequence(); return; }
            phase = Phase.WAIT_EXPLODE;
            nextStepAtMs = now + Math.max(0L, explodeDelay.longValue());
            waitCrystalTimeoutMs = now + Math.max(350L, explodeDelay.longValue() + 280L);
            if (explodeDelay.longValue() > 0L) return;
        }

        if (phase == Phase.WAIT_EXPLODE) {
            if (obsidianPos == null || now >= waitCrystalTimeoutMs) { abortSequence(); return; }
            class_1511 crystal = findSpawnedCrystal(mc, obsidianPos);
            if (crystal == null) return;
            aimAtPoint(player, obsidianPos.method_10093(class_2350.field_11036).method_46558());
            if (now < nextStepAtMs) return;
            ClickSimulator.attackEntity(mc.field_1761, player, crystal);
            player.method_6104(class_1268.field_5808);
            abortSequence();
        }
    }

    public boolean isSimulateClick() { return Boolean.TRUE.equals(simulateClick.getValue()); }
    public boolean tryStart(class_310 mc) { ClickSimulator.pushSimulate(isSimulateClick()); try { return tryStart$viperImpl(mc); } finally { ClickSimulator.popSimulate(); } }
    public void advanceSequence() { ClickSimulator.pushSimulate(isSimulateClick()); try { advanceSequence$viperImpl(); } finally { ClickSimulator.popSimulate(); } }
    @Override public void onTick() { advanceSequence(); }
    public enum Phase { IDLE, WAIT_PLACE_OBSIDIAN, WAIT_PLACE_CRYSTAL, WAIT_EXPLODE }
}
