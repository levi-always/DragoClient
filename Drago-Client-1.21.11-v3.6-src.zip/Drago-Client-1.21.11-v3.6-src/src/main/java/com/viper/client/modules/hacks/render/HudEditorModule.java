package com.viper.client.modules.hacks.render;

public final class HudEditorModule extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.BooleanSetting snapGrid;

    public HudEditorModule() {
        super("hud_editor", "HUD Editor", "Drag and snap HUD Watermark and ArrayList.", com.viper.client.modules.Category.RENDER, "hud_editor", -1);
        this.snapGrid = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("snap_grid", "Snap to Grid", "Snap dragged HUD elements to a 4px alignment grid", 1)));
        return;
    }

    public boolean isSnapGrid() {
        return ((java.lang.Boolean) this.snapGrid.getValue()).booleanValue();
    }

    protected void onEnable() {
        v1 = net.minecraft.class_310.method_1551();
        v2 = com.viper.client.ViperClient.getInstance();
        // if (v1 == null) -> offset 49
        // if (v2 == null) -> offset 49
        // if (v1.field_1724 != null) -> offset 33
        // if ((v1.field_1755 instanceof com.viper.client.ui.ViperClickGuiScreen) == 0) -> offset 49
        v1.method_1507(new com.viper.client.ui.HudEditorScreen(v2, v1.field_1755));
        this.setEnabled(0);
        return;
    }

}
