package com.viper.client.modules.hacks.world;

public final class Freelook extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.NumberSetting sensitivity;
    private final com.viper.client.modules.Setting.BooleanSetting autoThirdPerson;
    private float cameraYaw;
    private float cameraPitch;
    private net.minecraft.class_5498 savedPerspective;

    public Freelook() {
        super("freelook", "Freelook", "Orbits camera 360° without changing movement direction.", com.viper.client.modules.Category.WORLD, "freelook", -1);
        this.sensitivity = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("sensitivity", "Sensitivity", "Freelook orbit mouse sensitivity", 100.0, 25.0, 200.0, 5.0, "%")));
        this.autoThirdPerson = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("auto_third_person", "Auto Third Person", "Switch to third-person perspective while Freelook is active", 1)));
        this.cameraYaw = 0.0f;
        this.cameraPitch = 0.0f;
        this.savedPerspective = null;
        return;
    }

    protected void onEnable() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 91
        // if (v1.field_1724 == null) -> offset 91
        this.cameraYaw = v1.field_1724.method_36454();
        this.cameraPitch = v1.field_1724.method_36455();
        // if (((java.lang.Boolean) this.autoThirdPerson.getValue()).booleanValue() == 0) -> offset 91
        // if (v1.field_1690 == null) -> offset 91
        this.savedPerspective = v1.field_1690.method_31044();
        // if (this.savedPerspective != net.minecraft.class_5498.field_26664) -> offset 91
        v1.field_1690.method_31043(net.minecraft.class_5498.field_26665);
        v1 = /*?*/;
        return;
    }

    protected void onDisable() {
        v1 = net.minecraft.class_310.method_1551();
        // if (this.savedPerspective == null) -> offset 33
        // if (v1 == null) -> offset 33
        // if (v1.field_1690 == null) -> offset 33
        v1.field_1690.method_31043(this.savedPerspective);
        v1 = /*?*/;
        this.savedPerspective = null;
        return;
    }

    public void applyMouseDelta(double arg0, double arg1) {
        v5 = (0.15000000596046448f * (this.sensitivity.floatValue() / 100.0f));
        this.cameraYaw = (this.cameraYaw + ((float)arg0 * v5));
        this.cameraPitch = com.viper.client.utils.AnimUtils.clamp((this.cameraPitch + ((float)arg1 * v5)), -90.0f, 90.0f);
        return;
    }

    public float getCameraYaw() {
        return this.cameraYaw;
    }

    public float getCameraPitch() {
        return this.cameraPitch;
    }

    public String getHudMetadata() {
        return "360°";
    }

}
