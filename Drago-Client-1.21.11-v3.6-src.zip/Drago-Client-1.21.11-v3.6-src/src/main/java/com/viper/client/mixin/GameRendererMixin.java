package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_757.class})
public abstract class GameRendererMixin {
    public GameRendererMixin() {
        super();
        return;
    }

    @Inject(method = {"method_3192"}, at = {@At("HEAD")})
    private void viper$onRenderFrame(net.minecraft.class_9779 arg0, boolean arg1, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg2) {
        v4 = com.viper.client.ViperClient.getInstance();
        // if (v4 == null) -> offset 34
        // if (arg0 == null) -> offset 24
        v5 = 1.0f;
        v4.onRenderFrame(v5);
        return;
    }

    @Inject(method = {"method_3196"}, at = {@At("RETURN")}, cancellable = true)
    private void viper$modifyZoomFov(net.minecraft.class_4184 arg0, float arg1, boolean arg2, org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable arg3) {
        v5 = com.viper.client.ViperClient.getInstance();
        // if (v5 != null) -> offset 11
        return;
        v6 = ((com.viper.client.modules.hacks.render.Zoom) v5.getModuleManager().getModule(com.viper.client.modules.hacks.render.Zoom.class));
        // if (v6 == null) -> offset 73
        v7 = v6.updateAndGetDivisor();
        // if (Double.compare(v7, 1.0049999952316284f) <= 0) -> offset 73
        arg3.setReturnValue(Float.valueOf(Math.max(5.0f, (((java.lang.Float) arg3.getReturnValue()).floatValue() / v7))));
        return;
    }

}
