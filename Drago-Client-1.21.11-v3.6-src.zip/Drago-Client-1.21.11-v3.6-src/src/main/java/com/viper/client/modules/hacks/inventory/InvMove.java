package com.viper.client.modules.hacks.inventory;

public final class InvMove extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.BooleanSetting allowJump;
    private final com.viper.client.modules.Setting.BooleanSetting allowSprint;
    private final com.viper.client.modules.Setting.BooleanSetting allowSneak;

    public InvMove() {
        super("inv_move", "InvMove", "Move, jump, and sprint inside open menus.", com.viper.client.modules.Category.INVENTORY, "inv_move", -1);
        this.allowJump = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("jump", "Allow Jump", "Permit Spacebar jumping while a GUI is open", 1)));
        this.allowSprint = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("sprint", "Allow Sprint", "Maintain sprint key state while moving in GUIs", 1)));
        this.allowSneak = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("sneak", "Allow Sneak", "Permit sneaking while a GUI is open", 0)));
        return;
    }

    public boolean shouldPollGuiMovement(net.minecraft.class_310 arg0) {
        // if (this.isEnabled() == 0) -> offset 18
        // if (arg0 == null) -> offset 18
        // if (arg0.field_1724 != null) -> offset 20
        return false;
        v2 = arg0.field_1755;
        // if (v2 != null) -> offset 31
        return false;
        // if ((v2 instanceof net.minecraft.class_408) == 0) -> offset 40
        return false;
        v3 = v2.getClass().getSimpleName();
        // if (v3.contains("SignEdit") != 0) -> offset 79
        // if (v3.contains("BookEdit") != 0) -> offset 79
        // if (v3.contains("Anvil") != 0) -> offset 79
        return false;
    }

    public boolean isAllowJump() {
        return ((java.lang.Boolean) this.allowJump.getValue()).booleanValue();
    }

    public boolean isAllowSprint() {
        return ((java.lang.Boolean) this.allowSprint.getValue()).booleanValue();
    }

    public boolean isAllowSneak() {
        return ((java.lang.Boolean) this.allowSneak.getValue()).booleanValue();
    }

    public static boolean isPhysicalBindingDown(long arg0, net.minecraft.class_304 arg1) {
        // if (Double.compare(arg0, 0L) == 0) -> offset 10
        // if (arg1 != null) -> offset 12
        return false;
        v3 = arg1.method_1429();
        // if (v3 == null) -> offset 28
        // if (v3.method_1444() > 0) -> offset 30
        return false;
        // if (v3.method_1442() != net.minecraft.class_3675.class_307.field_1672) -> offset 58
        // if (org.lwjgl.glfw.GLFW.glfwGetMouseButton(arg0, v3.method_1444()) != 1) -> offset 56
        return false;
        // if (v3.method_1442() != net.minecraft.class_3675.class_307.field_1668) -> offset 86
        // if (org.lwjgl.glfw.GLFW.glfwGetKey(arg0, v3.method_1444()) != 1) -> offset 84
        return false;
        return false;
    }

    public String getHudMetadata() {
        // if (((java.lang.Boolean) this.allowSprint.getValue()).booleanValue() == 0) -> offset 21
        return "Walk";
    }

}
