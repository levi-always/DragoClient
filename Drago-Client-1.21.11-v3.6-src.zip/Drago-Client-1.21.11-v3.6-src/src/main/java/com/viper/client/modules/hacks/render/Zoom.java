package com.viper.client.modules.hacks.render;

public final class Zoom extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.NumberSetting zoomFactor;
    private final com.viper.client.modules.Setting.BooleanSetting smoothZoom;
    private final com.viper.client.modules.Setting.NumberSetting smoothSpeed;
    private float currentDivisor;
    private long lastUpdateNs;

    public Zoom() {
        super("zoom", "Zoom", "Magnifies camera FOV smoothly without distortion.", com.viper.client.modules.Category.RENDER, "zoom", -1);
        this.zoomFactor = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("zoom_factor", "Zoom Factor", "Optical FOV magnification divisor", 4.0, 1.5, 10.0, 0.5, "x")));
        this.smoothZoom = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("smooth", "Smooth Zoom", "Interpolate FOV smoothly on zoom in/out", 1)));
        java.util.Objects.requireNonNull(this.smoothZoom);
        this.smoothSpeed = ((com.viper.client.modules.Setting.NumberSetting) ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("smooth_speed", "Smooth Speed", "Zoom transition damping speed", 14.0, 4.0, 24.0, 1.0, ""))).visibleWhen(getAsBoolean(this.smoothZoom)));
        this.currentDivisor = 1.0f;
        this.lastUpdateNs = System.nanoTime();
        return;
    }

    public float updateAndGetDivisor() {
        v1 = System.nanoTime();
        v3 = Math.max(0.0010000000474974513f, Math.min(0.07999999821186066f, ((float)(v1 - this.lastUpdateNs) / 1000000000.0f)));
        this.lastUpdateNs = v1;
        // if (this.isEnabled() == 0) -> offset 47
        v4 = 1.0f;
        // if (((java.lang.Boolean) this.smoothZoom.getValue()).booleanValue() != 0) -> offset 75
        this.currentDivisor = v4;
        this.currentDivisor = com.viper.client.utils.AnimUtils.damp(this.currentDivisor, v4, this.smoothSpeed.floatValue(), v3);
        return Math.max(1.0f, this.currentDivisor);
    }

    public static float getActiveDivisorSnapshot() {
        v0 = com.viper.client.ViperClient.getInstance();
        // if (v0 != null) -> offset 10
        return 1.0f;
        v1 = ((com.viper.client.modules.hacks.render.Zoom) v0.getModuleManager().getModule(com.viper.client.modules.hacks.render.Zoom.class));
        // if (v1 != null) -> offset 29
        return 1.0f;
        return Math.max(1.0f, v1.currentDivisor);
    }

    public String getHudMetadata() {
        return this.zoomFactor.formatDisplay();
    }

}
