package com.viper.client.modules.hacks.combat;

public final class WindChargeClutch extends com.viper.client.modules.Module {
    private static final String OWNER_ID = "wind_charge_clutch";
    private static final int HOTBAR_PRIORITY = 47;
    private static final int ROTATION_PRIORITY = 5;
    public final com.viper.client.modules.Setting.NumberSetting prediction;
    public final com.viper.client.modules.Setting.NumberSetting timing;
    public final com.viper.client.modules.Setting.ModeSetting mode;
    public final com.viper.client.modules.Setting.BooleanSetting onKey;
    public final com.viper.client.modules.Setting.KeybindSetting triggerKey;
    public final com.viper.client.modules.Setting.NumberSetting minFall;
    public final com.viper.client.modules.Setting.BooleanSetting switchBack;
    public final com.viper.client.modules.Setting.BooleanSetting simulateClick;
    private boolean clutchedThisFall;
    private boolean preparingAim;
    private boolean restoring;
    private float returnYaw;
    private float returnPitch;
    private long cooldownUntilMs;
    private long restoreAtMs;

    public WindChargeClutch() {
        super("wind_charge_clutch", "WindChargeClutch", "Predicts landing and automatically uses Wind Charge downward to recover falls or knockback.", com.viper.client.modules.Category.COMBAT, "wind_charge_clutch", -1);
        this.prediction = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("prediction", "Prediction", "Trajectory lookahead window in ticks for landing prediction", 12.0, 4.0, 24.0, 1.0, "t")));
        this.timing = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("timing", "Timing", "Ticks before predicted impact to fire Wind Charge downward", 3.0, 1.0, 8.0, 0.5, "t")));
        new java.lang.String[2][0] = "Silent";
        new java.lang.String[2][1] = "Legit";
        this.mode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("mode", "Mode", "Silent server rotation or visible Legit downward aim", "Silent", new java.lang.String[2])));
        this.onKey = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("on_key", "On Key", "Only auto-clutch while holding the configured Key", 0)));
        java.util.Objects.requireNonNull(this.onKey);
        this.triggerKey = ((com.viper.client.modules.Setting.KeybindSetting) this.registerSetting(((com.viper.client.modules.Setting.KeybindSetting) new com.viper.client.modules.Setting.KeybindSetting("trigger_key", "Key", "Hold key to arm WindChargeClutch recovery", -1).visibleWhen(getAsBoolean(this.onKey)))));
        this.minFall = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("min_fall", "Min Fall", "Minimum current + predicted fall distance before clutching", 4.0, 2.0, 16.0, 0.5, "m")));
        this.switchBack = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("switch_back", "Switch Back", "Restore previous hotbar slot after firing Wind Charge", 1)));
        this.simulateClick = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Right click press during clutch", 1)));
        this.clutchedThisFall = 0;
        this.preparingAim = 0;
        this.restoring = 0;
        this.returnYaw = 0.0f;
        this.returnPitch = 0.0f;
        this.cooldownUntilMs = 0L;
        this.restoreAtMs = 0L;
        return;
    }

    protected void onDisable() {
        this.resetState(Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.timing.formatDisplay(), ((java.lang.String) this.mode.getValue()));
    }

    private void resetState(boolean arg0) {
        this.clutchedThisFall = 0;
        this.preparingAim = 0;
        this.restoring = 0;
        com.viper.client.utils.RotationUtils.releaseSilentRotation(5);
        com.viper.client.utils.RotationUtils.releaseCameraTarget(5);
        com.viper.client.utils.HotbarCoordinator.releaseOwner("wind_charge_clutch", arg0);
        return;
    }

    private static int findWindChargeSlot(net.minecraft.class_746 arg0) {
        v1 = 0;
        // if (v1 >= 9) -> offset 30
        // if (com.viper.client.modules.hacks.combat.WindCharge.isWindCharge(arg0.method_31548().method_5438(v1)) == 0) -> offset 24
        return v1;
        v1 += 1;
        return -1;
    }

    private static boolean isCoolingDown(net.minecraft.class_746 arg0, net.minecraft.class_1799 arg1) {
        // if (arg0 == null) -> offset 15
        // if (arg1 == null) -> offset 15
        // if (arg1.method_7960() == 0) -> offset 17
        return true;
        // if (arg0.method_7357() == null) -> offset 39
        // if (arg0.method_7357().method_7904(arg1) == 0) -> offset 39
        return false;
        v2 = 1;
        return false;
    }

    public static com.viper.client.modules.hacks.combat.WindChargeClutch.LandingPrediction simulateTrajectory(double arg0, double arg1, double arg2, double arg3, double arg4, double arg5, int arg6, com.viper.client.modules.hacks.combat.WindChargeClutch.SurfaceProbe arg7) {
        v14 = arg0;
        v16 = arg1;
        v18 = arg2;
        v20 = 1;
        // if (v20 > arg6) -> offset 294
        v21 = (v14 + arg3);
        v23 = (v16 + arg4);
        v25 = (v18 + arg5);
        v27 = (int)Math.floor(v21);
        v28 = (int)Math.floor(v25);
        v29 = (int)Math.floor((v16 - 0.02));
        v30 = (int)Math.floor((v23 - 0.02));
        v31 = v29;
        // if (v31 < v30) -> offset 248
        v32 = arg7.probe(v27, v31, v28);
        // if (v32 != com.viper.client.modules.hacks.combat.WindChargeClutch.SurfaceHit.WATER) -> offset 148
        return new com.viper.client.modules.hacks.combat.WindChargeClutch.LandingPrediction(1, 1, (double)v20, ((double)v31 + 1.0), Math.max(0.0, (arg1 - ((double)v31 + 1.0))), v21, v25);
        // if (v32 != com.viper.client.modules.hacks.combat.WindChargeClutch.SurfaceHit.SOLID) -> offset 242
        // if (Double.compare(Math.abs(arg4), 1e-05) <= 0) -> offset 191
        v33 = 0.5;
        v35 = ((double)(v20 - 1) + v33);
        v37 = Math.max(0.0, (arg1 - ((double)v31 + 1.0)));
        return new com.viper.client.modules.hacks.combat.WindChargeClutch.LandingPrediction(1, 0, v35, ((double)v31 + 1.0), v37, v21, v25);
        v31 += -1;
        v14 = v21;
        v16 = v23;
        v18 = v25;
        arg4 = ((arg4 - 0.08) * 0.98);
        arg3 = (arg3 * 0.91);
        arg5 = (arg5 * 0.91);
        v20 += 1;
        return new com.viper.client.modules.hacks.combat.WindChargeClutch.LandingPrediction(0, 0, inf, v16, Math.max(0.0, (arg1 - v16)), v14, v18);
    }

    private static com.viper.client.modules.hacks.combat.WindChargeClutch.SurfaceHit probeWorldBlock(net.minecraft.class_638 arg0, int arg1, int arg2, int arg3) {
        v4 = new net.minecraft.class_2338(arg1, arg2, arg3);
        v5 = arg0.method_8320(v4);
        // if (v5 == null) -> offset 33
        // if (v5.method_26215() == 0) -> offset 37
        return com.viper.client.modules.hacks.combat.WindChargeClutch.SurfaceHit.AIR;
        // if (v5.method_26227() == null) -> offset 60
        // if (v5.method_26227().method_15769() != 0) -> offset 60
        return com.viper.client.modules.hacks.combat.WindChargeClutch.SurfaceHit.WATER;
        // if (v5.method_26220(arg0, v4).method_1110() != 0) -> offset 78
        return com.viper.client.modules.hacks.combat.WindChargeClutch.SurfaceHit.SOLID;
        return com.viper.client.modules.hacks.combat.WindChargeClutch.SurfaceHit.AIR;
    }

    private boolean isKeyArmed(net.minecraft.class_310 arg0) {
        // if (Boolean.TRUE.equals(this.onKey.getValue()) != 0) -> offset 18
        return true;
        v2 = this.triggerKey.getKeyCode();
        // if (v2 <= 0) -> offset 37
        // if (arg0.field_1755 == null) -> offset 39
        return false;
        // if (arg0.method_22683() == null) -> offset 56
        v3 = org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        // if (Double.compare(v3, 0L) == 0) -> offset 79
        // if (org.lwjgl.glfw.GLFW.glfwGetKey(v3, v2) != 1) -> offset 79
        return false;
    }

    private void aimDownward(net.minecraft.class_746 arg0, double arg1, double arg2, double arg3) {
        v8 = arg0.method_33571();
        v9 = com.viper.client.utils.RotationUtils.computeRotations(v8.field_1352, v8.field_1351, v8.field_1350, arg1, arg2, arg3);
        v10 = Math.max(78.0f, v9[1]);
        // if (this.mode.is("Silent") == 0) -> offset 80
        com.viper.client.utils.RotationUtils.releaseCameraTarget(5);
        com.viper.client.utils.RotationUtils.driveSilentRotationCapped(arg0, v9[0], v10, 22.0f, 88.0f, 0, 5);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(5);
        v11 = arg0.method_36454();
        v12 = arg0.method_36455();
        v13 = com.viper.client.utils.RotationUtils.smoothStepCapped(v11, v12, v9[0], v10, 22.0f, 88.0f, 1.0f);
        arg0.method_36456(v13[0]);
        arg0.method_36457(v13[1]);
        return;
    }

    private void stepLogic$impl() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 29
        // if (v1.field_1724 == null) -> offset 29
        // if (v1.field_1687 == null) -> offset 29
        // if (v1.field_1761 != null) -> offset 30
        return;
        // if (v1.field_1755 == null) -> offset 69
        // if (this.preparingAim != 0) -> offset 51
        // if (this.restoring == 0) -> offset 68
        this.resetState(Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        v2 = v1.field_1724;
        v3 = System.currentTimeMillis();
        // if (this.restoring == 0) -> offset 182
        // if (this.mode.is("Silent") != 0) -> offset 141
        v5 = com.viper.client.utils.RotationUtils.smoothStepCapped(v2.method_36454(), v2.method_36455(), this.returnYaw, this.returnPitch, 28.0f, 64.0f, 1.0f);
        v2.method_36456(v5[0]);
        v2.method_36457(v5[1]);
        // if (Double.compare(v3, this.restoreAtMs) < 0) -> offset 181
        this.restoring = 0;
        com.viper.client.utils.RotationUtils.releaseSilentRotation(5);
        com.viper.client.utils.RotationUtils.releaseCameraTarget(5);
        com.viper.client.utils.HotbarCoordinator.releaseOwner("wind_charge_clutch", Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        // if (v2.method_24828() != 0) -> offset 210
        // if (v2.method_5799() != 0) -> offset 210
        // if (v2.method_5771() != 0) -> offset 210
        // if (v2.method_6128() == 0) -> offset 240
        this.clutchedThisFall = 0;
        // if (this.preparingAim == 0) -> offset 239
        this.resetState(Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        // if (this.isKeyArmed(v1) != 0) -> offset 273
        // if (this.preparingAim == 0) -> offset 272
        this.resetState(Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        // if (this.clutchedThisFall != 0) -> offset 289
        // if (Double.compare(v3, this.cooldownUntilMs) >= 0) -> offset 290
        return;
        v5 = v2.method_18798();
        // if (Double.compare(v5.field_1351, -0.08) < 0) -> offset 309
        return;
        v6 = Math.max(4, this.prediction.intValue());
        v7 = com.viper.client.modules.hacks.combat.WindChargeClutch.simulateTrajectory(v2.method_23317(), v2.method_23318(), v2.method_23321(), v5.field_1352, v5.field_1351, v5.field_1350, v6, probe(v1));
        // if (v7.landed == 0) -> offset 378
        // if (v7.waterSafe == 0) -> offset 379
        return;
        v8 = (Math.max(v2.field_6017, 0.0) + v7.predictedExtraDrop);
        // if (Double.compare(v8, this.minFall.doubleValue()) >= 0) -> offset 409
        return;
        v10 = com.viper.client.modules.hacks.combat.WindChargeClutch.findWindChargeSlot(v2);
        v11 = net.minecraft.class_1268.field_5808;
        v12 = null;
        // if (v10 < 0) -> offset 442
        v12 = v2.method_31548().method_5438(v10);
        // if (com.viper.client.modules.hacks.combat.WindCharge.isWindCharge(v2.method_6079()) == 0) -> offset 463
        v11 = net.minecraft.class_1268.field_5810;
        v12 = v2.method_6079();
        // if (v12 == null) -> offset 477
        // if (com.viper.client.modules.hacks.combat.WindChargeClutch.isCoolingDown(v2, v12) == 0) -> offset 478
        return;
        v13 = this.timing.doubleValue();
        // if (Double.compare(v7.ticksToImpact, (v13 + 4.5)) <= 0) -> offset 503
        return;
        // if (this.preparingAim != 0) -> offset 531
        this.returnYaw = com.viper.client.utils.RotationUtils.getRealViewYaw(v2);
        this.returnPitch = com.viper.client.utils.RotationUtils.getRealViewPitch(v2);
        this.preparingAim = 1;
        // if (v11 != net.minecraft.class_1268.field_5808) -> offset 572
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("wind_charge_clutch", 47, v10, Boolean.TRUE.equals(this.switchBack.getValue())) != 0) -> offset 565
        return;
        v1.field_1761.method_2911();
        this.aimDownward(v2, v7.landingX, v7.impactY, v7.landingZ);
        // if (Double.compare(v7.ticksToImpact, v13) > 0) -> offset 881
        // if (this.mode.is("Silent") == 0) -> offset 627
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 627
        v15 = v2.method_36455();
        // if (Double.compare(v15, 62.0f) >= 0) -> offset 655
        // if (Double.compare(v7.ticksToImpact, 1.5) <= 0) -> offset 655
        return;
        // if (this.mode.is("Silent") == 0) -> offset 679
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 679
        v16 = v2.method_36454();
        v17 = Math.max(78.0f, v15);
        v18 = v2.method_36454();
        v19 = v2.method_36455();
        // if (v2.field_3944 == null) -> offset 747
        v2.field_3944.method_52787(new net.minecraft.class_2828.class_2831(v16, v17, v2.method_24828(), v2.field_5976));
        com.viper.client.utils.RotationUtils.recordPacketConfirmedAngles(v16, v17);
        v2.method_36456(v16);
        v2.method_36457(v17);
        v20 = com.viper.client.utils.ClickSimulator.interactItem(v1.field_1761, v2, v11);
        // if (v20 == null) -> offset 792
        // if (v20.method_23665() == 0) -> offset 792
        v2.method_6104(v11);
        // if (this.mode.is("Silent") == 0) -> offset 848
        v2.method_36456(v18);
        v2.method_36457(v19);
        v21 = com.viper.client.utils.RotationUtils.getServerYaw();
        // if (this.mode.is("Silent") == 0) -> offset 845
        v2.method_36456(v18);
        v2.method_36457(v19);
        throw v21;
        this.clutchedThisFall = 1;
        this.preparingAim = 0;
        this.cooldownUntilMs = (v3 + 450L);
        this.restoring = 1;
        this.restoreAtMs = (v3 + 90L);
        return;
    }

    private void stepLogic() {
        com.viper.client.utils.ClickSimulator.pushSimulate(Boolean.TRUE.equals(this.simulateClick.getValue()));
        this.stepLogic$impl();
        com.viper.client.utils.ClickSimulator.popSimulate();
        v1 = /*?*/;
        com.viper.client.utils.ClickSimulator.popSimulate();
        throw v1;
        return;
    }

    public void onTick() {
        this.stepLogic();
        return;
    }

    public static void pollRenderFrame() {
        v0 = com.viper.client.ViperClient.getInstance();
        // if (v0 != null) -> offset 9
        return;
        v1 = ((com.viper.client.modules.hacks.combat.WindChargeClutch) v0.getModuleManager().getModule(com.viper.client.modules.hacks.combat.WindChargeClutch.class));
        // if (v1 == null) -> offset 37
        // if (v1.isEnabled() == 0) -> offset 37
        v1.stepLogic();
        v0 = /*?*/;
        return;
    }

    public final class LandingPrediction {
        public final boolean landed;
        public final boolean waterSafe;
        public final double ticksToImpact;
        public final double impactY;
        public final double predictedExtraDrop;
        public final double landingX;
        public final double landingZ;

        public LandingPrediction(boolean arg0, boolean arg1, double arg2, double arg3, double arg4, double arg5, double arg6) {
            super();
            this.landed = arg0;
            this.waterSafe = arg1;
            this.ticksToImpact = arg2;
            this.impactY = arg3;
            this.predictedExtraDrop = arg4;
            this.landingX = arg5;
            this.landingZ = arg6;
            return;
        }

    }

    public enum SurfaceHit {
        AIR, WATER, SOLID;


    }

    @FunctionalInterface
    public interface SurfaceProbe {
        public com.viper.client.modules.hacks.combat.WindChargeClutch.SurfaceHit probe(int arg0, int arg1, int arg2);

    }

}
