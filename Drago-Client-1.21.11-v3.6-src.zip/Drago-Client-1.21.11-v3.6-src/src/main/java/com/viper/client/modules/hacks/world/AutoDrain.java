package com.viper.client.modules.hacks.world;

public final class AutoDrain extends com.viper.client.modules.Module {
    private static final String OWNER_ID = "auto_drain";
    private static final int ROTATION_PRIORITY = 4;
    public final com.viper.client.modules.Setting.ModeSetting mode;
    public final com.viper.client.modules.Setting.ModeSetting method;
    public final com.viper.client.modules.Setting.NumberSetting swapDelay;
    public final com.viper.client.modules.Setting.NumberSetting drainDelay;
    public final com.viper.client.modules.Setting.NumberSetting range;
    public final com.viper.client.modules.Setting.BooleanSetting switchBack;
    private com.viper.client.modules.hacks.world.AutoDrain.Stage stage;
    private int ticksRemaining;
    private int syncWaitRetries;
    private net.minecraft.class_2338 activeWaterPos;
    private net.minecraft.class_3965 activeBlockPlacement;
    private boolean activeUsingBucket;
    private long cooldownUntilMs;

    private static net.minecraft.class_2350[] horizontalDirs() {
        new net.minecraft.class_2350[4][0] = net.minecraft.class_2350.field_11043;
        new net.minecraft.class_2350[4][1] = net.minecraft.class_2350.field_11035;
        new net.minecraft.class_2350[4][2] = net.minecraft.class_2350.field_11039;
        new net.minecraft.class_2350[4][3] = net.minecraft.class_2350.field_11034;
        return new net.minecraft.class_2350[4];
    }

    private static net.minecraft.class_2350[] supportDirs() {
        new net.minecraft.class_2350[6][0] = net.minecraft.class_2350.field_11033;
        new net.minecraft.class_2350[6][1] = net.minecraft.class_2350.field_11043;
        new net.minecraft.class_2350[6][2] = net.minecraft.class_2350.field_11035;
        new net.minecraft.class_2350[6][3] = net.minecraft.class_2350.field_11039;
        new net.minecraft.class_2350[6][4] = net.minecraft.class_2350.field_11034;
        new net.minecraft.class_2350[6][5] = net.minecraft.class_2350.field_11036;
        return new net.minecraft.class_2350[6];
    }

    public AutoDrain() {
        super("auto_drain", "Auto Drain", "Scoops or plugs nearby water sources automatically.", com.viper.client.modules.Category.WORLD, "auto_drain", -1);
        new java.lang.String[2][0] = "Silent";
        new java.lang.String[2][1] = "Legit";
        this.mode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("mode", "Mode", "Rotation mode for draining water sources (Silent or Legit)", "Silent", new java.lang.String[2])));
        new java.lang.String[2][0] = "Bucket";
        new java.lang.String[2][1] = "Block";
        this.method = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("method", "Method", "Drain water by scooping with an Empty Bucket or plugging with a Solid Block", "Bucket", new java.lang.String[2])));
        this.swapDelay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("swap_delay", "Swap Delay", "Delay in ticks before swapping to Empty Bucket or Block (1-20)", 2.0, 1.0, 20.0, 1.0, "t")));
        this.drainDelay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("drain_delay", "Drain Delay", "Delay in ticks after equipping item before scooping or placing (1-20)", 2.0, 1.0, 20.0, 1.0, "t")));
        this.range = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("range", "Range", "Maximum scan and interaction reach for placed water sources", 4.5, 2.5, 5.5, 0.1, "m")));
        this.switchBack = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("switch_back", "Switch Back", "Restore your original hotbar slot after draining water", 1)));
        this.stage = com.viper.client.modules.hacks.world.AutoDrain.Stage.IDLE;
        this.ticksRemaining = 0;
        this.syncWaitRetries = 0;
        this.activeWaterPos = null;
        this.activeBlockPlacement = null;
        this.activeUsingBucket = 1;
        this.cooldownUntilMs = 0L;
        return;
    }

    protected void onEnable() {
        this.resetSequence(0);
        return;
    }

    protected void onDisable() {
        this.resetSequence(1);
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(((java.lang.String) this.mode.getValue()), ((java.lang.String) this.method.getValue()));
    }

    private void resetSequence(boolean arg0) {
        this.stage = com.viper.client.modules.hacks.world.AutoDrain.Stage.IDLE;
        this.ticksRemaining = 0;
        this.syncWaitRetries = 0;
        this.activeWaterPos = null;
        this.activeBlockPlacement = null;
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        // if (arg0 == 0) -> offset 61
        // if (((java.lang.Boolean) this.switchBack.getValue()).booleanValue() == 0) -> offset 61
        com.viper.client.utils.HotbarCoordinator.releaseOwner(1, 0);
        return;
    }

    private static boolean isPureWaterSourceBlock(net.minecraft.class_638 arg0, net.minecraft.class_2338 arg1) {
        v2 = arg0.method_8320(arg1);
        // if (v2 == null) -> offset 17
        // if (v2.method_26215() == 0) -> offset 19
        return false;
        v3 = v2.method_26227();
        // if (v3 == null) -> offset 42
        // if (v3.method_15769() != 0) -> offset 42
        // if (v3.method_15771() != 0) -> offset 44
        return false;
        v4 = v2.method_26204();
        v5 = net.minecraft.class_7923.field_41175.method_10221(v4);
        // if (v5 == null) -> offset 81
        v6 = "";
        // if (v6.equals("minecraft:water") != 0) -> offset 108
        // if (v6.equals("water") == 0) -> offset 112
        return false;
    }

    private static boolean isIsolatedPlacedWaterSource(net.minecraft.class_638 arg0, net.minecraft.class_2338 arg1) {
        // if (com.viper.client.modules.hacks.world.AutoDrain.isPureWaterSourceBlock(arg0, arg1) != 0) -> offset 10
        return false;
        v2 = 0;
        v3 = com.viper.client.modules.hacks.world.AutoDrain.horizontalDirs();
        v4 = v3.length;
        v5 = 0;
        // if (v5 >= v4) -> offset 97
        v6 = v3[v5];
        v7 = new net.minecraft.class_2338((arg1.method_10263() + v6.method_10148()), arg1.method_10264(), (arg1.method_10260() + v6.method_10165()));
        // if (com.viper.client.modules.hacks.world.AutoDrain.isPureWaterSourceBlock(arg0, v7) == 0) -> offset 91
        v2 += 1;
        // if (v2 > 1) -> offset 89
        return false;
        v5 += 1;
        return true;
    }

    private static boolean canBucketRaycastHitWater(net.minecraft.class_638 arg0, net.minecraft.class_746 arg1, net.minecraft.class_243 arg2, net.minecraft.class_243 arg3, net.minecraft.class_2338 arg4) {
        v5 = arg0.method_17742(new net.minecraft.class_3959(arg2, arg3, net.minecraft.class_3959.class_3960.field_17559, net.minecraft.class_3959.class_242.field_1345, arg1));
        // if (v5 == null) -> offset 55
        // if (v5.method_17783() != net.minecraft.class_239.class_240.field_1332) -> offset 55
        // if (arg4.equals(v5.method_17777()) == 0) -> offset 55
        return false;
    }

    private static boolean doesAngleRaycastHitWater(net.minecraft.class_638 arg0, net.minecraft.class_746 arg1, float arg2, float arg3, double arg4, net.minecraft.class_2338 arg5) {
        v9 = arg1.method_33571();
        v7 = com.viper.client.utils.RotationUtils.directionFromAngles(arg2, arg3);
        v8 = v9.method_1019(com.viper.client.utils.RotationUtils.directionFromAngles(arg2, arg3).method_1021(arg4));
        v10 = arg0.method_17742(new net.minecraft.class_3959(v9, v9.method_1019(com.viper.client.utils.RotationUtils.directionFromAngles(arg2, arg3).method_1021(arg4)), net.minecraft.class_3959.class_3960.field_17559, net.minecraft.class_3959.class_242.field_1345, arg1));
        // if (v10 == null) -> offset 82
        // if (v10.method_17783() != net.minecraft.class_239.class_240.field_1332) -> offset 82
        // if (arg5.equals(v10.method_17777()) == 0) -> offset 82
        return false;
    }

    private static net.minecraft.class_3965 findBlockPlugPlacement(net.minecraft.class_638 arg0, net.minecraft.class_243 arg1, net.minecraft.class_2338 arg2, double arg3) {
        v5 = new net.minecraft.class_238((double)arg2.method_10263(), (double)arg2.method_10264(), (double)arg2.method_10260(), ((double)arg2.method_10263() + 1.0), ((double)arg2.method_10264() + 1.0), ((double)arg2.method_10260() + 1.0));
        // if (arg0.method_8335(null, v5).isEmpty() != 0) -> offset 62
        return null;
        v6 = java.util.concurrent.ThreadLocalRandom.current();
        v7 = com.viper.client.modules.hacks.world.AutoDrain.supportDirs();
        v8 = v7.length;
        v9 = 0;
        // if (v9 >= v8) -> offset 378
        v10 = v7[v9];
        v15 = new net.minecraft.class_2338((arg2.method_10263() + v10.method_10148()), (arg2.method_10264() + v10.method_10164()), (arg2.method_10260() + v10.method_10165()));
        v16 = arg0.method_8320(v15);
        // if (v16 == null) -> offset 372
        // if (v16.method_26215() != 0) -> offset 372
        // if (v16.method_45474() != 0) -> offset 372
        // if (v16.method_26220(arg0, v15).method_1110() == 0) -> offset 179
        v17 = v10.method_10153();
        v18 = ((v6.nextDouble() - 0.5) * 0.05);
        v20 = ((v6.nextDouble() - 0.5) * 0.05);
        // if (v17.method_10148() != 0) -> offset 250
        v22 = (v18 + 0.0);
        // if (v17.method_10164() != 0) -> offset 294
        v13 = (v20 + 0.0);
        // if (v17.method_10165() != 0) -> offset 333
        v11 = (v18 + 0.0);
        v24 = new net.minecraft.class_243(v22, (((double)v15.method_10264() + 0.5) + ((double)v17.method_10164() * 0.5)), (((double)v15.method_10260() + 0.5) + ((double)v17.method_10165() * 0.5)));
        // if (Double.compare(arg1.method_1022(v24), arg3) <= 0) -> offset 357
        return new net.minecraft.class_3965(v24, v17, v15, 0);
        v9 += 1;
        return null;
    }

    private void driveDrainAim(net.minecraft.class_746 arg0, net.minecraft.class_243 arg1) {
        // if (this.mode.is("Silent") == 0) -> offset 70
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        v3 = arg0.method_33571();
        v4 = com.viper.client.utils.RotationUtils.computeRotations(v3.field_1352, v3.field_1351, v3.field_1350, arg1.field_1352, arg1.field_1351, arg1.field_1350);
        com.viper.client.utils.RotationUtils.driveSilentRotation(arg0, v4[0], v4[1], 66.0f, 1, 4);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        com.viper.client.utils.RotationUtils.driveCameraPoint(arg0, arg1.field_1352, arg1.field_1351, arg1.field_1350, 70.0f, 1, 4);
        return;
    }

    private int resolveRequiredHotbarSlot(net.minecraft.class_746 arg0, boolean arg1) {
        // if (arg1 == 0) -> offset 11
        return com.viper.client.utils.WeaponUtils.findPlaceableSolidBlockHotbarSlot(arg0);
    }

    public void onTick() {
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 29
        // if (v2.field_1724 == null) -> offset 29
        // if (v2.field_1687 == null) -> offset 29
        // if (v2.field_1761 != null) -> offset 30
        return;
        // if (v2.field_1755 == null) -> offset 53
        // if (this.stage == com.viper.client.modules.hacks.world.AutoDrain.Stage.IDLE) -> offset 52
        this.resetSequence(1);
        return;
        v3 = v2.field_1724;
        v4 = v2.field_1687;
        v5 = Math.min(4.5, ((java.lang.Double) this.range.getValue()).doubleValue());
        // if (this.stage != com.viper.client.modules.hacks.world.AutoDrain.Stage.IDLE) -> offset 592
        v7 = System.currentTimeMillis();
        // if (Double.compare(v7, this.cooldownUntilMs) >= 0) -> offset 111
        return;
        // if (com.viper.client.utils.HotbarCoordinator.canAcquire("auto_drain", 32) != 0) -> offset 122
        return;
        v9 = this.method.is("Bucket");
        v10 = this.resolveRequiredHotbarSlot(v3, v9);
        // if (v10 >= 0) -> offset 148
        return;
        v11 = v3.method_33571();
        v12 = (int)Math.ceil(((java.lang.Double) this.range.getValue()).doubleValue());
        v13 = (int)Math.floor(v11.field_1352);
        v14 = (int)Math.floor(v11.field_1351);
        v15 = (int)Math.floor(v11.field_1350);
        v16 = null;
        v17 = null;
        v18 = 1.7976931348623157e+308;
        v20 = new net.minecraft.class_2338.class_2339();
        v21 = (v14 - v12);
        // if (v21 > (v14 + v12)) -> offset 485
        v22 = (v13 - v12);
        // if (v22 > (v13 + v12)) -> offset 479
        v23 = (v15 - v12);
        // if (v23 > (v15 + v12)) -> offset 473
        v20.method_10103(v22, v21, v23);
        v24 = new net.minecraft.class_243(((double)v22 + 0.5), ((double)v21 + 0.5), ((double)v23 + 0.5));
        v25 = v11.method_1025(v24);
        // if (Double.compare(v25, (((java.lang.Double) this.range.getValue()).doubleValue() * ((java.lang.Double) this.range.getValue()).doubleValue())) > 0) -> offset 467
        // if (Double.compare(v25, v18) >= 0) -> offset 467
        // if (com.viper.client.modules.hacks.world.AutoDrain.isIsolatedPlacedWaterSource(v4, v20) != 0) -> offset 382
        v27 = v20.method_10062();
        // if (v9 == 0) -> offset 434
        // if (Double.compare(v25, (v5 * v5)) > 0) -> offset 467
        // if (com.viper.client.modules.hacks.world.AutoDrain.canBucketRaycastHitWater(v4, v3, v11, v24, v27) != 0) -> offset 423
        v18 = v25;
        v16 = v27;
        v28 = com.viper.client.modules.hacks.world.AutoDrain.findBlockPlugPlacement(v4, v11, v27, v5);
        // if (v28 != null) -> offset 455
        v18 = v25;
        v16 = v27;
        v17 = v28;
        v23 += 1;
        v22 += 1;
        v21 += 1;
        // if (v16 != null) -> offset 491
        return;
        this.activeWaterPos = v16;
        this.activeBlockPlacement = v17;
        this.activeUsingBucket = v9;
        this.stage = com.viper.client.modules.hacks.world.AutoDrain.Stage.WAIT_SWAP;
        this.ticksRemaining = Math.max(1, this.swapDelay.intValue());
        this.syncWaitRetries = 3;
        // if (v9 == 0) -> offset 583
        v3.driveDrainAim(new net.minecraft.class_243(((double)v16.method_10263() + 0.5), ((double)v16.method_10264() + 0.5), ((double)v16.method_10260() + 0.5)), v17.method_17784());
        return;
        // if (this.activeWaterPos == null) -> offset 611
        // if (com.viper.client.modules.hacks.world.AutoDrain.isPureWaterSourceBlock(v4, this.activeWaterPos) != 0) -> offset 617
        this.resetSequence(1);
        return;
        v7 = this.resolveRequiredHotbarSlot(v3, this.activeUsingBucket);
        // if (v7 >= 0) -> offset 639
        this.resetSequence(1);
        return;
        v8 = v3.method_33571();
        // if (this.activeUsingBucket == 0) -> offset 734
        v1 = new net.minecraft.class_243(((double)this.activeWaterPos.method_10263() + 0.5), ((double)this.activeWaterPos.method_10264() + 0.5), ((double)this.activeWaterPos.method_10260() + 0.5));
        // if (Double.compare(v8.method_1022(v1), (v5 + 0.1)) > 0) -> offset 728
        // if (com.viper.client.modules.hacks.world.AutoDrain.canBucketRaycastHitWater(v4, v3, v8, v1, this.activeWaterPos) != 0) -> offset 801
        this.resetSequence(1);
        return;
        // if (this.activeBlockPlacement != null) -> offset 758
        this.activeBlockPlacement = com.viper.client.modules.hacks.world.AutoDrain.findBlockPlugPlacement(v4, v8, this.activeWaterPos, v5);
        // if (this.activeBlockPlacement == null) -> offset 787
        // if (Double.compare(v8.method_1022(this.activeBlockPlacement.method_17784()), (v5 + 0.1)) <= 0) -> offset 793
        this.resetSequence(1);
        return;
        v1 = this.activeBlockPlacement.method_17784();
        this.driveDrainAim(v3, v1);
        // if (this.stage != com.viper.client.modules.hacks.world.AutoDrain.Stage.WAIT_SWAP) -> offset 894
        this.ticksRemaining = (this.ticksRemaining - 1);
        // if (this.ticksRemaining <= 0) -> offset 835
        return;
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("auto_drain", 32, v7, ((java.lang.Boolean) this.switchBack.getValue()).booleanValue()) != 0) -> offset 866
        this.resetSequence(0);
        return;
        this.stage = com.viper.client.modules.hacks.world.AutoDrain.Stage.WAIT_DRAIN;
        this.ticksRemaining = Math.max(1, this.drainDelay.intValue());
        this.syncWaitRetries = 3;
        return;
        // if (this.stage != com.viper.client.modules.hacks.world.AutoDrain.Stage.WAIT_DRAIN) -> offset 1224
        // if ("auto_drain".equals(com.viper.client.utils.HotbarCoordinator.getActiveOwner()) != 0) -> offset 921
        this.resetSequence(0);
        return;
        // if (v3.method_31548().method_67532() == v7) -> offset 956
        com.viper.client.utils.HotbarCoordinator.beginSequence("auto_drain", 32, v7, ((java.lang.Boolean) this.switchBack.getValue()).booleanValue());
        this.ticksRemaining = (this.ticksRemaining - 1);
        // if (this.ticksRemaining <= 0) -> offset 974
        return;
        v9 = com.viper.client.utils.RotationUtils.getConfirmedServerYaw(v3);
        v10 = com.viper.client.utils.RotationUtils.getConfirmedServerPitch(v3);
        // if (this.activeUsingBucket == 0) -> offset 1088
        // if (com.viper.client.modules.hacks.world.AutoDrain.doesAngleRaycastHitWater(v4, v3, v9, v10, v5, this.activeWaterPos) != 0) -> offset 1030
        // if (this.syncWaitRetries <= 0) -> offset 1030
        this.syncWaitRetries = (this.syncWaitRetries - 1);
        return;
        // if (com.viper.client.utils.WeaponUtils.isEmptyBucket(v3.method_6047()) == 0) -> offset 1085
        v11 = v2.field_1761.method_2919(v3, net.minecraft.class_1268.field_5808);
        // if (v2.field_1761.method_2919(v3, net.minecraft.class_1268.field_5808) == null) -> offset 1085
        // if (v11.method_23665() == 0) -> offset 1085
        v3.method_6104(net.minecraft.class_1268.field_5808);
        this.cooldownUntilMs = (System.currentTimeMillis() + 180L);
        v12 = com.viper.client.utils.RotationUtils.computeRotations(v8.field_1352, v8.field_1351, v8.field_1350, v1.field_1352, v1.field_1351, v1.field_1350);
        // if (Double.compare(com.viper.client.utils.RotationUtils.getAngleDifference(v9, v10, v12[0], v12[1]), 18.0f) <= 0) -> offset 1160
        // if (this.syncWaitRetries <= 0) -> offset 1160
        this.syncWaitRetries = (this.syncWaitRetries - 1);
        return;
        // if (com.viper.client.utils.WeaponUtils.isBlockItem(v3.method_6047()) == 0) -> offset 1219
        v11 = v2.field_1761.method_2896(v3, net.minecraft.class_1268.field_5808, this.activeBlockPlacement);
        // if (v2.field_1761.method_2896(v3, net.minecraft.class_1268.field_5808, this.activeBlockPlacement) == null) -> offset 1219
        // if (v11.method_23665() == 0) -> offset 1219
        v3.method_6104(net.minecraft.class_1268.field_5808);
        this.cooldownUntilMs = (System.currentTimeMillis() + 180L);
        this.resetSequence(1);
        return;
    }

     enum Stage {
        IDLE, WAIT_SWAP, WAIT_DRAIN;


    }

}
