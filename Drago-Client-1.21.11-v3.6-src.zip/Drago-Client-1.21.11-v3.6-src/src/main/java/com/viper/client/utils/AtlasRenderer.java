package com.viper.client.utils;

public final class AtlasRenderer {
    public static final net.minecraft.class_2960 ATLAS_TEX;
    public static final int ATLAS_SIZE = 512;

    private AtlasRenderer() {
        super();
        return;
    }

    public static void drawRoundedRect(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5) {
        com.viper.client.ui.glass.GlassRenderer.drawRoundedRect(arg0, arg1, arg2, arg3, arg4, arg5);
        return;
    }

    public static void drawRoundedBorder(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5) {
        com.viper.client.ui.glass.GlassRenderer.drawRoundedBorder(arg0, arg1, arg2, arg3, arg4, arg5);
        return;
    }

    public static void drawLargePanel(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6) {
        com.viper.client.ui.glass.GlassRenderer.drawGlassPanel(arg0, arg1, arg2, arg3, arg4, arg5, arg6, 1.0f);
        return;
    }

    public static void drawRoundedGradient(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6) {
        // if (arg3 <= 0) -> offset 9
        // if (arg4 > 0) -> offset 10
        return;
        // if (com.viper.client.utils.AtlasRenderer.argbAlpha(arg5) != 0) -> offset 27
        // if (com.viper.client.utils.AtlasRenderer.argbAlpha(arg6) != 0) -> offset 27
        return;
        // if (arg5 != arg6) -> offset 46
        com.viper.client.ui.glass.GlassRenderer.drawRoundedRect(arg0, arg1, arg2, arg3, arg4, arg5);
        return;
        v7 = Math.min(8, Math.min((arg3 / 2), (arg4 / 2)));
        com.viper.client.ui.glass.GlassRenderer.drawRoundedRect(arg0, arg1, arg2, arg3, arg4, arg5);
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 4, 768, 248, 248, 48, v7, arg6);
        return;
    }

    public static void drawShadowPill(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6) {
        com.viper.client.ui.glass.GlassRenderer.drawGlassPill(arg0, arg1, arg2, arg3, arg4, arg5, arg6);
        return;
    }

    public static void drawCircle(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4) {
        com.viper.client.ui.glass.GlassRenderer.drawSmoothCircle(arg0, arg1, arg2, arg3, arg4);
        return;
    }

    public static void drawRadialGlow(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4) {
        com.viper.client.ui.glass.GlassRenderer.drawSmoothGlow(arg0, arg1, arg2, arg3, arg4);
        return;
    }

    public static void drawIcon(net.minecraft.class_332 arg0, net.minecraft.class_2960 arg1, int arg2, int arg3, int arg4, int arg5) {
        // if (arg1 == null) -> offset 17
        // if (arg4 <= 0) -> offset 17
        // if (com.viper.client.utils.AtlasRenderer.argbAlpha(arg5) != 0) -> offset 18
        return;
        arg0.method_25293(net.minecraft.class_10799.field_56883, arg1, arg2, arg3, 0.0f, 0.0f, arg4, arg4, 64, 64, 64, 64, arg5);
        return;
    }

    public static int getTextWidth(net.minecraft.class_327 arg0, String arg1) {
        return com.viper.client.ui.font.SmoothFontRenderer.getWidth(arg0, arg1, 0, 1.0f);
    }

    public static int getBoldTextWidth(net.minecraft.class_327 arg0, String arg1) {
        return com.viper.client.ui.font.SmoothFontRenderer.getWidth(arg0, arg1, 1, 1.0f);
    }

    public static void drawText(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, String arg2, int arg3, int arg4, int arg5, boolean arg6) {
        // if (com.viper.client.utils.AtlasRenderer.argbAlpha(arg5) <= 4) -> offset 20
        // if (arg2 == null) -> offset 20
        // if (arg2.isEmpty() == 0) -> offset 21
        return;
        com.viper.client.ui.font.SmoothFontRenderer.drawText(arg0, arg1, arg2, arg3, arg4, arg5, 0, 1.0f);
        return;
    }

    public static void drawAutoFitText(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, String arg2, int arg3, int arg4, int arg5, float arg6, int arg7) {
        // if (arg2 == null) -> offset 26
        // if (arg2.isEmpty() != 0) -> offset 26
        // if (arg5 <= 4) -> offset 26
        // if (com.viper.client.utils.AtlasRenderer.argbAlpha(arg7) > 4) -> offset 27
        return;
        v8 = com.viper.client.ui.font.SmoothFontRenderer.getWidth(arg1, arg2, 0, 1.0f);
        // if (v8 > arg5) -> offset 57
        com.viper.client.ui.font.SmoothFontRenderer.drawText(arg0, arg1, arg2, arg3, arg4, arg7, 0, 1.0f);
        return;
        v9 = ((float)arg5 / (float)Math.max(1, v8));
        // if (Double.compare(v9, arg6) < 0) -> offset 93
        com.viper.client.ui.font.SmoothFontRenderer.drawText(arg0, arg1, arg2, arg3, arg4, arg7, 0, v9);
        return;
        v10 = arg2;
        // if (v10.length() <= 2) -> offset 142
        // if (com.viper.client.ui.font.SmoothFontRenderer.getWidth(arg1, makeConcatWithConstants(v10), 0, arg6) <= arg5) -> offset 142
        v10 = v10.substring(0, (v10.length() - 1));
        com.viper.client.ui.font.SmoothFontRenderer.drawText(arg0, arg1, makeConcatWithConstants(v10), arg3, arg4, arg7, 0, arg6);
        return;
    }

    public static void drawGradientText(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, String arg2, int arg3, int arg4, int arg5, int arg6, boolean arg7) {
        // if (arg2 == null) -> offset 20
        // if (arg2.isEmpty() != 0) -> offset 20
        // if (com.viper.client.utils.AtlasRenderer.argbAlpha(arg5) > 4) -> offset 21
        return;
        com.viper.client.ui.font.SmoothFontRenderer.drawGradientText(arg0, arg1, arg2, arg3, arg4, arg5, arg6, 1, 1.0f);
        return;
    }

    public static void drawThinLine(net.minecraft.class_332 arg0, float arg1, float arg2, float arg3, float arg4, float arg5, int arg6) {
        // if (com.viper.client.utils.AtlasRenderer.argbAlpha(arg6) <= 3) -> offset 17
        // if (Double.compare(arg5, 0.05000000074505806f) > 0) -> offset 18
        return;
        v7 = (arg3 - arg1);
        v8 = (arg4 - arg2);
        v9 = (float)Math.hypot((double)v7, (double)v8);
        // if (Double.compare(v9, 0.25f) >= 0) -> offset 50
        return;
        v10 = (float)Math.atan2((double)v8, (double)v7);
        v11 = Math.max(0.25f, (arg5 * 0.5f));
        arg0.method_51448().pushMatrix();
        arg0.method_51448().translate(arg1, arg2);
        arg0.method_51448().rotate(v10);
        arg0.method_51448().scale(v9, v11);
        arg0.method_25294(0, -1, 1, 1, arg6);
        arg0.method_51448().popMatrix();
        return;
    }

    private static int argbAlpha(int arg0) {
        return 255;
    }

}
