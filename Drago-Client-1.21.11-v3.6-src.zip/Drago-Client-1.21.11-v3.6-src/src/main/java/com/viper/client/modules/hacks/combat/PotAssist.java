package com.viper.client.modules.hacks.combat;

public final class PotAssist extends com.viper.client.modules.Module {
    private static final int ROTATION_PRIORITY = 3;
    private static boolean bypassingUse;
    public final com.viper.client.modules.Setting.ModeSetting rotationMode;
    public final com.viper.client.modules.Setting.NumberSetting throwPitch;
    public final com.viper.client.modules.Setting.NumberSetting smoothness;
    public final com.viper.client.modules.Setting.BooleanSetting autoRelease;
    private boolean pendingThrow;
    private boolean returningCamera;
    private net.minecraft.class_1268 pendingHand;
    private float lockedYaw;
    private float lockedPitch;
    private float returnYaw;
    private float returnPitch;
    private long requestStartedMs;
    private long holdUntilMs;
    public final com.viper.client.modules.Setting.BooleanSetting simulateClick;

    public PotAssist() {
        super("pot_assist", "PotAssist", "Aims downward cleanly when throwing splash or lingering potions.", com.viper.client.modules.Category.COMBAT, "pot_assist", -1);
        new java.lang.String[2][0] = "Silent";
        new java.lang.String[2][1] = "Legit";
        this.rotationMode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("rotation_mode", "Rotation Mode", "Throw downward silently (Silent) or visibly move camera (Camera)", "Silent", new java.lang.String[2])));
        this.throwPitch = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("throw_pitch", "Throw Pitch", "Downward pitch angle to splash potion directly under your feet", 88.0, 72.0, 90.0, 1.0, "°")));
        this.smoothness = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("smoothness", "Smoothness", "Rotation speed looking down to throw", 90.0, 25.0, 100.0, 1.0, "%")));
        this.autoRelease = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("auto_release", "Smooth Return", "Smoothly return view/server pitch after throwing potion", 1)));
        this.pendingThrow = 0;
        this.returningCamera = 0;
        this.pendingHand = net.minecraft.class_1268.field_5808;
        this.lockedYaw = 0.0f;
        this.lockedPitch = 88.0f;
        this.returnYaw = 0.0f;
        this.returnPitch = 0.0f;
        this.requestStartedMs = 0L;
        this.holdUntilMs = 0L;
        this.simulateClick = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left/Right click presses during module actions", 1)));
        return;
    }

    public static boolean isBypassingUse() {
        return com.viper.client.modules.hacks.combat.PotAssist.bypassingUse;
    }

    protected void onDisable() {
        this.pendingThrow = 0;
        this.returningCamera = 0;
        this.holdUntilMs = 0L;
        this.release();
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(((java.lang.String) this.rotationMode.getValue()), this.throwPitch.intValue());
    }

    private void release() {
        com.viper.client.utils.RotationUtils.releaseSilentRotation(3);
        com.viper.client.utils.RotationUtils.releaseCameraTarget(3);
        return;
    }

    private static boolean isThrowablePotion(net.minecraft.class_1799 arg0) {
        // if (arg0 == null) -> offset 11
        // if (arg0.method_7960() == 0) -> offset 13
        return false;
        v1 = com.viper.client.utils.WeaponUtils.getItemId(arg0);
        // if ("minecraft:splash_potion".equals(v1) != 0) -> offset 36
        // if ("minecraft:lingering_potion".equals(v1) == 0) -> offset 40
        return false;
    }

    private static net.minecraft.class_1268 findPotionHand(net.minecraft.class_746 arg0) {
        // if (com.viper.client.modules.hacks.combat.PotAssist.isThrowablePotion(arg0.method_6047()) == 0) -> offset 14
        return net.minecraft.class_1268.field_5808;
        // if (com.viper.client.modules.hacks.combat.PotAssist.isThrowablePotion(arg0.method_6079()) == 0) -> offset 28
        return net.minecraft.class_1268.field_5810;
        return null;
    }

    public static boolean interceptDoItemUse(net.minecraft.class_310 arg0) {
        // if (com.viper.client.modules.hacks.combat.PotAssist.bypassingUse != 0) -> offset 31
        // if (arg0 == null) -> offset 31
        // if (arg0.field_1724 == null) -> offset 31
        // if (arg0.field_1687 == null) -> offset 31
        // if (arg0.field_1761 != null) -> offset 33
        return false;
        // if (arg0.field_1755 == null) -> offset 42
        return false;
        v1 = com.viper.client.ViperClient.getInstance();
        // if (v1 != null) -> offset 52
        return false;
        v2 = ((com.viper.client.modules.hacks.combat.PotAssist) v1.getModuleManager().getModule(com.viper.client.modules.hacks.combat.PotAssist.class));
        // if (v2 == null) -> offset 76
        // if (v2.isEnabled() != 0) -> offset 78
        return false;
        return v2.handleUseAttempt(arg0);
    }

    public static void pollRenderFrame() {
        v0 = com.viper.client.ViperClient.getInstance();
        // if (v0 != null) -> offset 9
        return;
        v1 = ((com.viper.client.modules.hacks.combat.PotAssist) v0.getModuleManager().getModule(com.viper.client.modules.hacks.combat.PotAssist.class));
        // if (v1 == null) -> offset 37
        // if (v1.isEnabled() == 0) -> offset 37
        v1.advanceFrame();
        v0 = /*?*/;
        return;
    }

    private boolean handleUseAttempt(net.minecraft.class_310 arg0) {
        v2 = arg0.field_1724;
        v3 = com.viper.client.modules.hacks.combat.PotAssist.findPotionHand(v2);
        // if (v3 != null) -> offset 16
        return false;
        // if (this.pendingThrow != 0) -> offset 107
        this.pendingThrow = 1;
        this.returningCamera = 0;
        this.pendingHand = v3;
        this.returnYaw = com.viper.client.utils.RotationUtils.getRealViewYaw(v2);
        this.returnPitch = com.viper.client.utils.RotationUtils.getRealViewPitch(v2);
        this.lockedYaw = this.returnYaw;
        v4 = ((java.util.concurrent.ThreadLocalRandom.current().nextFloat() - 0.5f) * 0.8999999761581421f);
        this.lockedPitch = com.viper.client.utils.RotationUtils.clampPitch((this.throwPitch.floatValue() + v4));
        this.requestStartedMs = System.currentTimeMillis();
        this.holdUntilMs = 0L;
        this.stepRotation(v2);
        this.tryCompleteThrow(arg0, v2);
        return true;
    }

    private float computeEffectiveDampSmoothness() {
        v1 = this.smoothness.floatValue();
        return com.viper.client.utils.AnimUtils.clamp((92.0f - ((v1 - 25.0f) * 1.0499999523162842f)), 8.0f, 82.0f);
    }

    private void stepRotation(net.minecraft.class_746 arg0) {
        v2 = this.computeEffectiveDampSmoothness();
        // if (this.rotationMode.is("Silent") == 0) -> offset 42
        com.viper.client.utils.RotationUtils.releaseCameraTarget(3);
        com.viper.client.utils.RotationUtils.driveSilentRotationCapped(arg0, this.lockedYaw, this.lockedPitch, v2, 72.0f, 0, 3);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(3);
        v3 = arg0.method_36454();
        v4 = arg0.method_36455();
        v5 = com.viper.client.utils.RotationUtils.smoothStepCapped(v3, v4, this.lockedYaw, this.lockedPitch, v2, 72.0f, 1.0f);
        arg0.method_36456(v5[0]);
        arg0.method_36457(v5[1]);
        return;
    }

    private boolean tryCompleteThrow(net.minecraft.class_310 arg0, net.minecraft.class_746 arg1) {
        // if (this.pendingThrow != 0) -> offset 9
        return false;
        v4 = System.currentTimeMillis();
        // if (this.rotationMode.is("Silent") == 0) -> offset 38
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 38
        v6 = arg1.method_36454();
        // if (this.rotationMode.is("Silent") == 0) -> offset 68
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 68
        v7 = arg1.method_36455();
        // if (Double.compare(v7, (this.lockedPitch - 7.5f)) >= 0) -> offset 97
        // if (Double.compare(v7, 80.0f) < 0) -> offset 101
        v8 = 0;
        // if (Double.compare((v4 - this.requestStartedMs), 130L) < 0) -> offset 122
        v3 = 0;
        v9 = 0;
        // if (v8 != 0) -> offset 138
        // if (v3 != 0) -> offset 138
        return false;
        v10 = com.viper.client.modules.hacks.combat.PotAssist.findPotionHand(arg1);
        // if (v10 != null) -> offset 160
        this.pendingThrow = 0;
        this.release();
        return false;
        v11 = this.lockedYaw;
        // if (v8 == 0) -> offset 176
        v12 = this.lockedPitch;
        v13 = arg1.method_36454();
        v14 = arg1.method_36455();
        com.viper.client.modules.hacks.combat.PotAssist.bypassingUse = 1;
        // if (arg1.field_3944 == null) -> offset 238
        arg1.field_3944.method_52787(new net.minecraft.class_2828.class_2831(v11, v12, arg1.method_24828(), arg1.field_5976));
        com.viper.client.utils.RotationUtils.recordPacketConfirmedAngles(v11, v12);
        arg1.method_36456(v11);
        arg1.method_36457(v12);
        v15 = com.viper.client.utils.ClickSimulator.interactItem(arg0.field_1761, arg1, v10);
        // if (v15 == null) -> offset 283
        // if (v15.method_23665() == 0) -> offset 283
        arg1.method_6104(v10);
        arg0.field_1752 = Math.max(arg0.field_1752, 4);
        com.viper.client.modules.hacks.combat.PotAssist.bypassingUse = 0;
        // if (this.rotationMode.is("Silent") == 0) -> offset 359
        arg1.method_36456(v13);
        arg1.method_36457(v14);
        v16 = v7;
        com.viper.client.modules.hacks.combat.PotAssist.bypassingUse = 0;
        // if (this.rotationMode.is("Silent") == 0) -> offset 356
        arg1.method_36456(v13);
        arg1.method_36457(v14);
        throw v16;
        this.pendingThrow = 0;
        this.holdUntilMs = (v4 + 85L);
        // if (this.rotationMode.is("Silent") != 0) -> offset 407
        // if (Boolean.TRUE.equals(this.autoRelease.getValue()) == 0) -> offset 407
        this.returningCamera = 1;
        return true;
    }

    private void advanceFrame() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 29
        // if (v1.field_1724 == null) -> offset 29
        // if (v1.field_1687 == null) -> offset 29
        // if (v1.field_1761 != null) -> offset 30
        return;
        // if (v1.field_1755 == null) -> offset 57
        this.pendingThrow = 0;
        this.returningCamera = 0;
        this.holdUntilMs = 0L;
        this.release();
        return;
        v2 = v1.field_1724;
        v3 = System.currentTimeMillis();
        // if (this.pendingThrow == 0) -> offset 111
        // if (Double.compare((v3 - this.requestStartedMs), 500L) > 0) -> offset 93
        // if (com.viper.client.modules.hacks.combat.PotAssist.findPotionHand(v2) != null) -> offset 103
        this.pendingThrow = 0;
        this.release();
        return;
        this.tryCompleteThrow(v1, v2);
        return;
        // if (this.returningCamera == 0) -> offset 211
        // if (Double.compare(v3, this.holdUntilMs) <= 0) -> offset 211
        v5 = v2.method_36454();
        v6 = v2.method_36455();
        // if (Double.compare(Math.abs((v6 - this.returnPitch)), 1.2000000476837158f) >= 0) -> offset 166
        this.returningCamera = 0;
        this.release();
        return;
        v7 = this.computeEffectiveDampSmoothness();
        v8 = com.viper.client.utils.RotationUtils.smoothStepCapped(v5, v6, this.returnYaw, this.returnPitch, v7, 54.0f, 1.0f);
        v2.method_36456(v8[0]);
        v2.method_36457(v8[1]);
        v1 = /*?*/;
        return;
    }

    private void onTick$viperImpl() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 29
        // if (v1.field_1724 == null) -> offset 29
        // if (v1.field_1687 == null) -> offset 29
        // if (v1.field_1761 != null) -> offset 30
        return;
        // if (v1.field_1755 == null) -> offset 57
        this.pendingThrow = 0;
        this.returningCamera = 0;
        this.holdUntilMs = 0L;
        this.release();
        return;
        v2 = v1.field_1724;
        v3 = System.currentTimeMillis();
        // if (this.pendingThrow == 0) -> offset 86
        this.stepRotation(v2);
        this.tryCompleteThrow(v1, v2);
        return;
        // if (Double.compare(v3, this.holdUntilMs) > 0) -> offset 128
        // if (this.rotationMode.is("Silent") == 0) -> offset 127
        com.viper.client.utils.RotationUtils.driveSilentRotationCapped(v2, this.lockedYaw, this.lockedPitch, 20.0f, 48.0f, 0, 3);
        return;
        // if (this.returningCamera != 0) -> offset 139
        this.release();
        v1 = /*?*/;
        return;
    }

    public boolean isSimulateClick() {
        return ((java.lang.Boolean) this.simulateClick.getValue()).booleanValue();
    }

    public void onTick() {
        com.viper.client.utils.ClickSimulator.pushSimulate(this.isSimulateClick());
        this.onTick$viperImpl();
        com.viper.client.utils.ClickSimulator.popSimulate();
        v1 = /*?*/;
        com.viper.client.utils.ClickSimulator.popSimulate();
        throw v1;
        return;
    }

}
