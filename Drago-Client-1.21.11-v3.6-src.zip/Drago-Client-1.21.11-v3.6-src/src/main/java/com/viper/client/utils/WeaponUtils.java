package com.viper.client.utils;

public final class WeaponUtils {
    private static final int PLAYER_CHEST_ARMOR_SLOT_ID = 6;

    private WeaponUtils() {
        super();
        return;
    }

    public static String getItemId(net.minecraft.class_1799 arg0) {
        // if (arg0 == null) -> offset 11
        // if (arg0.method_7960() == 0) -> offset 14
        return "";
        v1 = arg0.method_7909();
        // if (v1 != null) -> offset 26
        return "";
        v2 = net.minecraft.class_7923.field_41178.method_10221(v1);
        // if (v2 == null) -> offset 51
        return v2.toString().toLowerCase(java.util.Locale.ROOT);
        v2 = /*?*/;
        return v1.toString().toLowerCase(java.util.Locale.ROOT);
    }

    public static com.viper.client.utils.WeaponUtils.WeaponKind classify(net.minecraft.class_1799 arg0) {
        v1 = com.viper.client.utils.WeaponUtils.getItemId(arg0);
        // if (v1.isEmpty() == 0) -> offset 16
        return com.viper.client.utils.WeaponUtils.WeaponKind.OTHER;
        // if (v1.endsWith("mace") == 0) -> offset 29
        return com.viper.client.utils.WeaponUtils.WeaponKind.MACE;
        // if (v1.endsWith("_sword") == 0) -> offset 42
        return com.viper.client.utils.WeaponUtils.WeaponKind.SWORD;
        // if (v1.endsWith("_axe") == 0) -> offset 55
        return com.viper.client.utils.WeaponUtils.WeaponKind.AXE;
        // if (v1.endsWith("_spear") != 0) -> offset 73
        // if (v1.endsWith("trident") == 0) -> offset 77
        return com.viper.client.utils.WeaponUtils.WeaponKind.SPEAR;
        return com.viper.client.utils.WeaponUtils.WeaponKind.OTHER;
    }

    public static boolean isElytra(net.minecraft.class_1799 arg0) {
        v1 = com.viper.client.utils.WeaponUtils.getItemId(arg0);
        // if (v1.isEmpty() != 0) -> offset 43
        // if (v1.endsWith(":elytra") != 0) -> offset 39
        // if (v1.equals("elytra") != 0) -> offset 39
        // if (v1.endsWith("_elytra") == 0) -> offset 43
        return false;
    }

    public static boolean isChestplate(net.minecraft.class_1799 arg0) {
        v1 = com.viper.client.utils.WeaponUtils.getItemId(arg0);
        // if (v1.isEmpty() != 0) -> offset 25
        // if (v1.endsWith("_chestplate") == 0) -> offset 25
        return false;
    }

    public static boolean isFireworkRocket(net.minecraft.class_1799 arg0) {
        v1 = com.viper.client.utils.WeaponUtils.getItemId(arg0);
        // if (v1.isEmpty() != 0) -> offset 25
        // if (v1.contains("firework_rocket") == 0) -> offset 25
        return false;
    }

    public static boolean isCobweb(net.minecraft.class_1799 arg0) {
        v1 = com.viper.client.utils.WeaponUtils.getItemId(arg0);
        // if (v1.isEmpty() != 0) -> offset 34
        // if (v1.endsWith(":cobweb") != 0) -> offset 30
        // if (v1.equals("cobweb") == 0) -> offset 34
        return false;
    }

    public static boolean isEmptyBucket(net.minecraft.class_1799 arg0) {
        v1 = com.viper.client.utils.WeaponUtils.getItemId(arg0);
        // if (v1.equals("minecraft:bucket") != 0) -> offset 23
        // if (v1.equals("bucket") == 0) -> offset 27
        return false;
    }

    public static boolean isWearingElytra(net.minecraft.class_746 arg0) {
        // if (arg0 != null) -> offset 6
        return false;
        return com.viper.client.utils.WeaponUtils.isElytra(arg0.method_6118(net.minecraft.class_1304.field_6174));
    }

    public static boolean isWearingChestplate(net.minecraft.class_746 arg0) {
        // if (arg0 != null) -> offset 6
        return false;
        return com.viper.client.utils.WeaponUtils.isChestplate(arg0.method_6118(net.minecraft.class_1304.field_6174));
    }

    public static int findCobwebHotbarSlot(net.minecraft.class_1657 arg0) {
        // if (arg0 != null) -> offset 6
        return -1;
        v1 = arg0.method_31548();
        v2 = 0;
        // if (v2 >= 9) -> offset 38
        // if (com.viper.client.utils.WeaponUtils.isCobweb(v1.method_5438(v2)) == 0) -> offset 32
        return v2;
        v2 += 1;
        return -1;
    }

    public static int findEmptyBucketHotbarSlot(net.minecraft.class_1657 arg0) {
        // if (arg0 != null) -> offset 6
        return -1;
        v1 = arg0.method_31548();
        v2 = 0;
        // if (v2 >= 9) -> offset 38
        // if (com.viper.client.utils.WeaponUtils.isEmptyBucket(v1.method_5438(v2)) == 0) -> offset 32
        return v2;
        v2 += 1;
        return -1;
    }

    public static int findPlaceableSolidBlockHotbarSlot(net.minecraft.class_1657 arg0) {
        // if (arg0 != null) -> offset 6
        return -1;
        v1 = arg0.method_31548();
        v2 = -1;
        v3 = -1;
        v4 = 0;
        // if (v4 >= 9) -> offset 605
        v5 = v1.method_5438(v4);
        // if (v5 == null) -> offset 599
        // if (v5.method_7960() != 0) -> offset 599
        v7 = v5.method_7909();
        // if ((v7 instanceof net.minecraft.class_1747) == 0) -> offset 599
        v6 = ((net.minecraft.class_1747) v7);
        v7 = com.viper.client.utils.WeaponUtils.getItemId(v5);
        // if (v7.isEmpty() == 0) -> offset 86
        // if (v7.contains("cobweb") != 0) -> offset 599
        // if (v7.contains("sand") != 0) -> offset 599
        // if (v7.contains("gravel") != 0) -> offset 599
        // if (v7.contains("concrete_powder") != 0) -> offset 599
        // if (v7.contains("anvil") != 0) -> offset 599
        // if (v7.contains("chest") != 0) -> offset 599
        // if (v7.contains("shulker") != 0) -> offset 599
        // if (v7.contains("barrel") != 0) -> offset 599
        // if (v7.contains("hopper") != 0) -> offset 599
        // if (v7.contains("furnace") != 0) -> offset 599
        // if (v7.contains("crafting_table") != 0) -> offset 599
        // if (v7.contains("respawn_anchor") != 0) -> offset 599
        // if (v7.contains("tnt") != 0) -> offset 599
        // if (v7.contains("bed") != 0) -> offset 599
        // if (v7.contains("door") != 0) -> offset 599
        // if (v7.contains("trapdoor") != 0) -> offset 599
        // if (v7.contains("fence") != 0) -> offset 599
        // if (v7.contains("wall") != 0) -> offset 599
        // if (v7.contains("slab") != 0) -> offset 599
        // if (v7.contains("stairs") != 0) -> offset 599
        // if (v7.contains("torch") != 0) -> offset 599
        // if (v7.contains("lantern") != 0) -> offset 599
        // if (v7.contains("button") != 0) -> offset 599
        // if (v7.contains("lever") != 0) -> offset 599
        // if (v7.contains("pressure_plate") != 0) -> offset 599
        // if (v7.contains("sign") != 0) -> offset 599
        // if (v7.contains("banner") != 0) -> offset 599
        // if (v7.contains("carpet") != 0) -> offset 599
        // if (v7.contains("pane") != 0) -> offset 599
        // if (v7.contains("bars") != 0) -> offset 599
        // if (v7.contains("ladder") != 0) -> offset 599
        // if (v7.contains("vine") != 0) -> offset 599
        // if (v7.contains("flower") != 0) -> offset 599
        // if (v7.contains("sapling") != 0) -> offset 599
        // if (v7.contains("rail") != 0) -> offset 599
        // if (v7.contains("scaffolding") == 0) -> offset 449
        v8 = v6.method_7711();
        // if (v8 != null) -> offset 464
        v9 = v8.method_9564();
        // if (v9 == null) -> offset 599
        // if (v9.method_26215() == 0) -> offset 487
        v10 = 10;
        // if (v7.contains("cobblestone") != 0) -> offset 583
        // if (v7.contains("stone") != 0) -> offset 583
        // if (v7.contains("deepslate") != 0) -> offset 583
        // if (v7.contains("netherrack") != 0) -> offset 583
        // if (v7.contains("dirt") != 0) -> offset 583
        // if (v7.contains("planks") != 0) -> offset 583
        // if (v7.contains("wool") != 0) -> offset 583
        // if (v7.contains("terracotta") != 0) -> offset 583
        // if (v7.contains("obsidian") == 0) -> offset 587
        v10 = 30;
        // if (v10 <= v3) -> offset 599
        v3 = v10;
        v2 = v4;
        v4 += 1;
        return v2;
    }

    public static double scoreChestItem(net.minecraft.class_1799 arg0, boolean arg1) {
        // if (arg0 == null) -> offset 11
        // if (arg0.method_7960() == 0) -> offset 15
        return -1.0;
        // if (arg1 == 0) -> offset 46
        // if (com.viper.client.utils.WeaponUtils.isElytra(arg0) != 0) -> offset 30
        return -1.0;
        v2 = com.viper.client.utils.WeaponUtils.getTotalEnchantmentLevels(arg0);
        return (100.0 + ((double)v2 * 5.0));
        // if (com.viper.client.utils.WeaponUtils.isChestplate(arg0) != 0) -> offset 57
        return -1.0;
        v2 = com.viper.client.utils.WeaponUtils.getItemId(arg0);
        v3 = 10.0;
        // if (v2.contains("netherite") == 0) -> offset 83
        v3 = 60.0;
        // if (v2.contains("diamond") == 0) -> offset 100
        v3 = 50.0;
        // if (v2.contains("iron") == 0) -> offset 117
        v3 = 40.0;
        // if (v2.contains("copper") != 0) -> offset 137
        // if (v2.contains("chainmail") == 0) -> offset 144
        v3 = 30.0;
        // if (v2.contains("golden") == 0) -> offset 158
        v3 = 25.0;
        return (v3 + ((double)com.viper.client.utils.WeaponUtils.getTotalEnchantmentLevels(arg0) * 3.0));
    }

    public static int findBestChestplateHotbarSlot(net.minecraft.class_1657 arg0) {
        // if (arg0 != null) -> offset 6
        return -1;
        v1 = arg0.method_31548();
        v2 = -1;
        v3 = -1.0;
        v5 = 0;
        // if (v5 >= 9) -> offset 58
        v6 = com.viper.client.utils.WeaponUtils.scoreChestItem(v1.method_5438(v5), 0);
        // if (Double.compare(v6, v3) <= 0) -> offset 52
        v3 = v6;
        v2 = v5;
        v5 += 1;
        return v2;
    }

    public static int findElytraHotbarSlot(net.minecraft.class_1657 arg0) {
        // if (arg0 != null) -> offset 6
        return -1;
        v1 = arg0.method_31548();
        v2 = -1;
        v3 = -1.0;
        v5 = 0;
        // if (v5 >= 9) -> offset 58
        v6 = com.viper.client.utils.WeaponUtils.scoreChestItem(v1.method_5438(v5), 1);
        // if (Double.compare(v6, v3) <= 0) -> offset 52
        v3 = v6;
        v2 = v5;
        v5 += 1;
        return v2;
    }

    public static boolean equipHeldArmorRightClick(net.minecraft.class_310 arg0, net.minecraft.class_746 arg1) {
        // if (arg0 == null) -> offset 15
        // if (arg1 == null) -> offset 15
        // if (arg0.field_1761 != null) -> offset 17
        return false;
        v3 = arg0.field_1761;
        // if ((v3 instanceof com.viper.client.utils.HotbarCoordinator.InteractionSync) == 0) -> offset 40
        v2 = ((com.viper.client.utils.HotbarCoordinator.InteractionSync) v3);
        v2.viper$syncSelectedSlot();
        v2 = arg0.field_1761.method_2919(arg1, net.minecraft.class_1268.field_5808);
        // if (v2 == null) -> offset 74
        // if (v2.method_23665() == 0) -> offset 74
        arg1.method_6104(net.minecraft.class_1268.field_5808);
        return true;
        return true;
    }

    public static boolean equipChestArmor(net.minecraft.class_310 arg0, net.minecraft.class_746 arg1, boolean arg2) {
        // if (arg0 == null) -> offset 22
        // if (arg1 == null) -> offset 22
        // if (arg0.field_1761 == null) -> offset 22
        // if (arg1.field_7498 != null) -> offset 24
        return false;
        v3 = arg1.method_6118(net.minecraft.class_1304.field_6174);
        // if (arg2 == 0) -> offset 45
        // if (com.viper.client.utils.WeaponUtils.isElytra(v3) == 0) -> offset 45
        return true;
        // if (arg2 != 0) -> offset 58
        // if (com.viper.client.utils.WeaponUtils.isChestplate(v3) == 0) -> offset 58
        return true;
        v4 = arg1.method_31548();
        v5 = -1;
        v6 = -1.0;
        v8 = 0;
        // if (v8 >= 9) -> offset 117
        v9 = com.viper.client.utils.WeaponUtils.scoreChestItem(v4.method_5438(v8), arg2);
        // if (Double.compare(v9, v6) <= 0) -> offset 111
        v6 = v9;
        v5 = v8;
        v8 += 1;
        v8 = -1;
        v9 = -1.0;
        v11 = 9;
        // if (v11 >= 36) -> offset 171
        v12 = com.viper.client.utils.WeaponUtils.scoreChestItem(v4.method_5438(v11), arg2);
        // if (Double.compare(v12, v9) <= 0) -> offset 165
        v9 = v12;
        v8 = v11;
        v11 += 1;
        // if (v5 >= 0) -> offset 183
        // if (v8 >= 0) -> offset 183
        return false;
        v11 = arg1.field_7498.field_7763;
        // if (v5 < 0) -> offset 209
        // if (Double.compare(v6, v9) < 0) -> offset 209
        v12 = 0;
        // if (v12 == 0) -> offset 237
        arg0.field_1761.method_2906(v11, 6, v5, net.minecraft.class_1713.field_7791, arg1);
        // if (v3 == null) -> offset 252
        // if (v3.method_7960() != 0) -> offset 252
        v13 = 0;
        arg0.field_1761.method_2906(v11, v8, 0, net.minecraft.class_1713.field_7790, arg1);
        arg0.field_1761.method_2906(v11, 6, 0, net.minecraft.class_1713.field_7790, arg1);
        // if (v13 == 0) -> offset 308
        arg0.field_1761.method_2906(v11, v8, 0, net.minecraft.class_1713.field_7790, arg1);
        v13 = arg1.method_6118(net.minecraft.class_1304.field_6174);
        // if (arg2 == 0) -> offset 332
        // if (com.viper.client.utils.WeaponUtils.isElytra(v13) == 0) -> offset 340
        // if (com.viper.client.utils.WeaponUtils.isChestplate(v13) != 0) -> offset 350
        // if (v12 != 0) -> offset 350
        // if (v8 < 0) -> offset 354
        return false;
    }

    public static boolean isBlockItem(net.minecraft.class_1799 arg0) {
        // if (arg0 == null) -> offset 25
        // if (arg0.method_7960() != 0) -> offset 25
        // if ((arg0.method_7909() instanceof net.minecraft.class_1747) == 0) -> offset 25
        return false;
    }

    public static boolean isWeaponStack(net.minecraft.class_1799 arg0) {
        // if (com.viper.client.utils.WeaponUtils.classify(arg0) == com.viper.client.utils.WeaponUtils.WeaponKind.OTHER) -> offset 14
        return false;
    }

    public static boolean isHoldingWeapon(net.minecraft.class_1657 arg0) {
        // if (arg0 != null) -> offset 6
        return false;
        return com.viper.client.utils.WeaponUtils.isWeaponStack(arg0.method_6047());
    }

    public static boolean isTargetBlockingWithShield(net.minecraft.class_1309 arg0) {
        // if (arg0 != null) -> offset 6
        return false;
        // if (arg0.method_6039() == 0) -> offset 15
        return true;
        // if (arg0.method_6115() == 0) -> offset 49
        v1 = arg0.method_6030();
        // if (v1 == null) -> offset 49
        // if (v1.method_7960() != 0) -> offset 49
        return com.viper.client.utils.WeaponUtils.getItemId(v1).contains("shield");
        return false;
    }

    public static double estimateBaseDamage(net.minecraft.class_1799 arg0) {
        v1 = com.viper.client.utils.WeaponUtils.getItemId(arg0);
        // if (v1.isEmpty() == 0) -> offset 14
        return 1.0;
        v2 = 0.0;
        // if (v1.contains("netherite") == 0) -> offset 33
        v2 = 4.0;
        // if (v1.contains("diamond") == 0) -> offset 50
        v2 = 3.0;
        // if (v1.contains("iron") == 0) -> offset 67
        v2 = 2.0;
        // if (v1.contains("copper") == 0) -> offset 84
        v2 = 1.5;
        // if (v1.contains("stone") == 0) -> offset 95
        v2 = 1.0;
        throw new MatchException(null, null);
        return 1.0;
    }

    public static double estimateAttackSpeed(net.minecraft.class_1799 arg0) {
        throw new MatchException(null, null);
        return 4.0;
    }

    public static int getTotalEnchantmentLevels(net.minecraft.class_1799 arg0) {
        // if (arg0 == null) -> offset 11
        // if (arg0.method_7960() == 0) -> offset 13
        return 0;
        v1 = arg0.method_58657();
        // if (v1 == null) -> offset 29
        // if (v1.method_57543() == 0) -> offset 31
        return 0;
        v2 = 0;
        v3 = v1.method_57539().iterator();
        // if (v3.hasNext() == 0) -> offset 76
        v4 = ((it.unimi.dsi.fastutil.objects.Object2IntMap.Entry) v3.next());
        v2 = (v2 + v4.getIntValue());
        return v2;
    }

    public static int findBestFollowUpWeaponSlot(net.minecraft.class_1657 arg0, String arg1, int arg2, double arg3) {
        // if (arg0 != null) -> offset 6
        return -1;
        // if ("Axe Only".equalsIgnoreCase(arg1) != 0) -> offset 26
        // if ("Stay on Axe".equalsIgnoreCase(arg1) == 0) -> offset 28
        return -1;
        // if ("Previous Weapon".equalsIgnoreCase(arg1) == 0) -> offset 54
        // if (arg2 < 0) -> offset 52
        // if (arg2 >= 9) -> offset 52
        return -1;
        // if ("Sword".equalsIgnoreCase(arg1) == 0) -> offset 76
        return com.viper.client.utils.WeaponUtils.findBestHotbarSlot(arg0, "Sword", "Damage", arg3);
        // if ("Mace".equalsIgnoreCase(arg1) == 0) -> offset 104
        return com.viper.client.utils.WeaponUtils.findBestHotbarSlot(arg0, "Mace", "Damage", Math.max(2.0, arg3));
        v5 = arg0.method_31548();
        v6 = -1;
        v7 = -1.0;
        v9 = 0;
        // if (v9 >= 9) -> offset 265
        v10 = v5.method_5438(v9);
        // if (v10 == null) -> offset 259
        // if (v10.method_7960() == 0) -> offset 153
        v11 = com.viper.client.utils.WeaponUtils.classify(v10);
        // if (v11 == com.viper.client.utils.WeaponUtils.WeaponKind.OTHER) -> offset 259
        // if (v11 != com.viper.client.utils.WeaponUtils.WeaponKind.AXE) -> offset 179
        v12 = com.viper.client.utils.WeaponUtils.estimateBaseDamage(v10);
        // if (v11 != com.viper.client.utils.WeaponUtils.WeaponKind.MACE) -> offset 218
        // if (Double.compare(arg3, 1.5) < 0) -> offset 218
        v12 = (v12 + Math.min(28.0, (arg3 * 3.5)));
        v14 = (((v12 * com.viper.client.utils.WeaponUtils.estimateAttackSpeed(v10)) * 2.2) + ((double)com.viper.client.utils.WeaponUtils.getTotalEnchantmentLevels(v10) * 1.5));
        // if (Double.compare(v14, v7) <= 0) -> offset 259
        v7 = v14;
        v6 = v9;
        v9 += 1;
        // if (v6 < 0) -> offset 273
        return v6;
        return com.viper.client.utils.WeaponUtils.findBestHotbarSlot(arg0, "Best Weapon", "Damage", arg3);
    }

    public static int findBestHotbarSlot(net.minecraft.class_1657 arg0, String arg1, String arg2, double arg3) {
        // if (arg0 != null) -> offset 6
        return -1;
        v5 = arg0.method_31548();
        v6 = -1;
        v7 = -1.0;
        v9 = 0;
        // if (v9 >= 9) -> offset 390
        v10 = v5.method_5438(v9);
        // if (v10 == null) -> offset 384
        // if (v10.method_7960() == 0) -> offset 55
        v11 = com.viper.client.utils.WeaponUtils.classify(v10);
        // if (v11 != com.viper.client.utils.WeaponUtils.WeaponKind.OTHER) -> offset 73
        // if ("Sword".equalsIgnoreCase(arg1) == 0) -> offset 94
        // if (v11 == com.viper.client.utils.WeaponUtils.WeaponKind.SWORD) -> offset 94
        // if ("Axe".equalsIgnoreCase(arg1) == 0) -> offset 115
        // if (v11 == com.viper.client.utils.WeaponUtils.WeaponKind.AXE) -> offset 115
        // if ("Mace".equalsIgnoreCase(arg1) == 0) -> offset 136
        // if (v11 == com.viper.client.utils.WeaponUtils.WeaponKind.MACE) -> offset 136
        // if ("Spear".equalsIgnoreCase(arg1) == 0) -> offset 157
        // if (v11 == com.viper.client.utils.WeaponUtils.WeaponKind.SPEAR) -> offset 157
        v12 = com.viper.client.utils.WeaponUtils.estimateBaseDamage(v10);
        // if (v11 != com.viper.client.utils.WeaponUtils.WeaponKind.MACE) -> offset 196
        // if (Double.compare(arg3, 1.5) < 0) -> offset 196
        v12 = (v12 + Math.min(28.0, (arg3 * 3.5)));
        v14 = com.viper.client.utils.WeaponUtils.getTotalEnchantmentLevels(v10);
        v15 = com.viper.client.utils.WeaponUtils.estimateAttackSpeed(v10);
        // if (arg2 != null) -> offset 220
        v19 = arg2;
        v20 = -1;
        // if (v19.equals("Enchantments") == 0) -> offset 287
        v20 = 0;
        // if (v19.equals("Attack Speed") == 0) -> offset 287
        v20 = 1;
        v17 = (((v12 * 3.0) + ((double)v14 * 1.25)) + v15);
        // if (Double.compare(v17, v7) <= 0) -> offset 384
        v7 = v17;
        v6 = v9;
        v9 += 1;
        return v6;
    }

    public enum WeaponKind {
        SWORD, AXE, MACE, SPEAR, OTHER;


    }

}
