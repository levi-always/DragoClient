package com.viper.client.modules.hacks.inventory;

import com.viper.client.modules.Category;
import com.viper.client.modules.Module;
import com.viper.client.modules.Setting;
import com.viper.client.utils.WeaponUtils;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_746;

public final class AutoTotem extends Module {
    public final Setting.ModeSetting mode;
    public final Setting.NumberSetting health;
    public final Setting.NumberSetting delay;
    public final Setting.BooleanSetting openInv;
    public final Setting.BooleanSetting fallCheck;
    public final Setting.ModeSetting priority;
    private int swapStep;
    private int pendingSlot = -1;
    private long nextStepAtMs;
    private boolean invOpenedByUs;

    public AutoTotem() {
        super("auto_totem", "AutoTotem", "Undetected multi-tick Totem of Undying equipper (max 1 container action per tick).", Category.INVENTORY, "auto_totem", -1);
        this.mode = registerSetting(new Setting.ModeSetting("mode", "Mode", "When AutoTotem equips a totem", "Smart Health", new String[]{"Smart Health", "Always"}));
        this.health = registerSetting(new Setting.NumberSetting("health", "Health", "Equip totem when health + absorption drops to this HP", 12.0, 2.0, 20.0, 0.5, "HP"));
        this.delay = registerSetting(new Setting.NumberSetting("delay", "Delay", "Humanized delay between inventory swap steps", 95.0, 0.0, 250.0, 5.0, "ms"));
        this.openInv = registerSetting(new Setting.BooleanSetting("open_inv", "Open Inv", "Briefly open InventoryScreen, swap Totem cleanly, and close", true));
        this.fallCheck = registerSetting(new Setting.BooleanSetting("fall_check", "Fall Check", "Equip Totem when falling >= 3 blocks in Smart Health mode", true));
        this.priority = registerSetting(new Setting.ModeSetting("priority", "Priority", "Search Inventory or Hotbar first for Totem", "Inventory First", new String[]{"Inventory First", "Hotbar First"}));
    }

    private static int findTotemContainerSlot(class_746 player, boolean invFirst) {
        if (invFirst) {
            for (int i = 9; i < 36; i++) if ("minecraft:totem_of_undying".equals(WeaponUtils.getItemId(player.method_31548().method_5438(i)))) return i;
            for (int i = 0; i < 9; i++) if ("minecraft:totem_of_undying".equals(WeaponUtils.getItemId(player.method_31548().method_5438(i)))) return i + 36;
        } else {
            for (int i = 0; i < 9; i++) if ("minecraft:totem_of_undying".equals(WeaponUtils.getItemId(player.method_31548().method_5438(i)))) return i + 36;
            for (int i = 9; i < 36; i++) if ("minecraft:totem_of_undying".equals(WeaponUtils.getItemId(player.method_31548().method_5438(i)))) return i;
        }
        return -1;
    }

    @Override
    public void onTick() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1761 == null) return;
        class_746 player = mc.field_1724;
        long now = System.currentTimeMillis();
        if ("minecraft:totem_of_undying".equals(WeaponUtils.getItemId(player.method_6079()))) {
            if (invOpenedByUs && mc.field_1755 instanceof class_490) { mc.method_1507(null); invOpenedByUs = false; }
            swapStep = 0;
            pendingSlot = -1;
            return;
        }
        boolean needed = mode.is("Always") || (player.method_6032() + player.method_6067() <= health.floatValue()) || (Boolean.TRUE.equals(fallCheck.getValue()) && player.field_6017 >= 3.0f);
        if (!needed) return;
        if (now < nextStepAtMs) return;
        long stepDelay = Math.max(40L, delay.longValue());

        if (swapStep == 0) {
            pendingSlot = findTotemContainerSlot(player, priority.is("Inventory First"));
            if (pendingSlot < 0) return;
            if (Boolean.TRUE.equals(openInv.getValue()) && !(mc.field_1755 instanceof class_490)) {
                mc.method_1507(new class_490(player));
                invOpenedByUs = true;
            }
            swapStep = 1;
            nextStepAtMs = now + stepDelay;
        } else if (swapStep == 1) {
            mc.field_1761.method_2906(player.field_7498.field_7763, pendingSlot, 0, class_1713.field_7790, player);
            swapStep = 2;
            nextStepAtMs = now + stepDelay;
        } else if (swapStep == 2) {
            mc.field_1761.method_2906(player.field_7498.field_7763, 45, 0, class_1713.field_7790, player);
            swapStep = 3;
            nextStepAtMs = now + stepDelay;
        } else if (swapStep == 3) {
            if (!player.field_7498.method_34255().method_7960()) {
                mc.field_1761.method_2906(player.field_7498.field_7763, pendingSlot, 0, class_1713.field_7790, player);
            }
            swapStep = 4;
            nextStepAtMs = now + 35L;
        } else {
            if (invOpenedByUs && mc.field_1755 instanceof class_490) { mc.method_1507(null); invOpenedByUs = false; }
            swapStep = 0;
            pendingSlot = -1;
        }
    }
}
