package com.viper.client.modules.hacks.world;

public final class FastPlace extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.NumberSetting cps;
    private final com.viper.client.modules.Setting.ModeSetting filter;
    private double clickBudget;
    public final com.viper.client.modules.Setting.BooleanSetting simulateClick;

    public FastPlace() {
        super("fast_place", "FastPlace", "Accelerates block placement and item use speed.", com.viper.client.modules.Category.WORLD, "fast_place", -1);
        this.cps = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("cps", "CPS", "Placement / right-click rate per second", 24.0, 1.0, 60.0, 1.0, " CPS")));
        new java.lang.String[3][0] = "Blocks & Items";
        new java.lang.String[3][1] = "Blocks Only";
        new java.lang.String[3][2] = "Items Only";
        this.filter = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("filter", "Apply To", "Valid held item category for FastPlace", "Blocks & Items", new java.lang.String[3])));
        this.clickBudget = 0.0;
        this.simulateClick = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left/Right click presses during module actions", 1)));
        return;
    }

    protected void onDisable() {
        this.clickBudget = 0.0;
        return;
    }

    public int getTargetCps() {
        return this.cps.intValue();
    }

    public boolean matchesHeldItem(net.minecraft.class_746 arg0) {
        // if (arg0 != null) -> offset 6
        return false;
        v2 = arg0.method_6047();
        v3 = arg0.method_6079();
        // if (v2 == null) -> offset 27
        // if (v2.method_7960() == 0) -> offset 31
        v4 = 0;
        // if (v3 == null) -> offset 45
        // if (v3.method_7960() == 0) -> offset 49
        v5 = 0;
        // if (v4 == 0) -> offset 64
        // if (v5 == 0) -> offset 64
        return false;
        // if (v4 != 0) -> offset 76
        // if (com.viper.client.utils.WeaponUtils.isBlockItem(v2) != 0) -> offset 88
        // if (v4 == 0) -> offset 92
        // if (com.viper.client.utils.WeaponUtils.isBlockItem(v3) == 0) -> offset 92
        v6 = 0;
        v7 = ((java.lang.String) this.filter.getValue());
        v8 = -1;
        // if (v7.equals("Blocks Only") == 0) -> offset 169
        v8 = 0;
        // if (v7.equals("Items Only") == 0) -> offset 169
        v8 = 1;
        // if (v6 != 0) -> offset 210
        return true;
    }

    public int computeCooldownCapTicks() {
        v1 = this.cps.intValue();
        // if (v1 < 20) -> offset 16
        return 0;
        return Math.max(0, ((int)Math.round((20.0 / (double)v1)) - 1));
    }

    public int pollExtraPlacementsThisTick() {
        v1 = this.cps.intValue();
        // if (v1 > 20) -> offset 21
        this.clickBudget = 0.0;
        return 0;
        this.clickBudget = (this.clickBudget + (((double)v1 - 20.0) / 20.0));
        v2 = (int)Math.floor(this.clickBudget);
        this.clickBudget = (this.clickBudget - (double)v2);
        return Math.min(2, Math.max(0, v2));
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.cps.intValue());
    }

    public boolean isSimulateClick() {
        return ((java.lang.Boolean) this.simulateClick.getValue()).booleanValue();
    }

}
