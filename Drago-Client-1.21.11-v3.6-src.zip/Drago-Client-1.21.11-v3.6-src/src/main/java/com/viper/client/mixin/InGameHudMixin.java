package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_329.class})
public abstract class InGameHudMixin {
    public InGameHudMixin() {
        super();
        return;
    }

    @Inject(method = {"method_1753"}, at = {@At("TAIL")})
    private void viper$onRenderHud(net.minecraft.class_332 arg0, net.minecraft.class_9779 arg1, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg2) {
        v4 = com.viper.client.ViperClient.getInstance();
        // if (v4 == null) -> offset 35
        // if (arg1 == null) -> offset 24
        v5 = 1.0f;
        v4.onRenderHud(arg0, v5);
        return;
    }

}
