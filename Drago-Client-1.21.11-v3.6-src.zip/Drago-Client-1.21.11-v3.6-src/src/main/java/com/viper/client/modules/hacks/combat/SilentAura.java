package com.viper.client.modules.hacks.combat;

import com.viper.client.modules.Category;
import com.viper.client.modules.Module;
import com.viper.client.modules.Setting;
import com.viper.client.utils.ClickSimulator;
import com.viper.client.utils.RotationUtils;
import com.viper.client.utils.TargetUtils;
import com.viper.client.utils.WeaponUtils;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class SilentAura extends Module {
    public final Setting.ModeSetting aimType;
    public final Setting.ModeSetting targetMode;
    public final Setting.ModeSetting aimPoint;
    public final Setting.NumberSetting range;
    public final Setting.NumberSetting fov;
    public final Setting.NumberSetting smoothness;
    public final Setting.BooleanSetting moveFix;
    public final Setting.BooleanSetting playersOnly;
    public final Setting.BooleanSetting weaponsOnly;
    public final Setting.BooleanSetting raytraceCheck;
    public final Setting.BooleanSetting simulateClick;
    private float nextCooldownThreshold = 0.88f;
    private long nextAttackAllowedMs = 0L;

    public SilentAura() {
        super("silent_aura", "SilentAura", "Undetected Ghost silent aura: 5.5m smooth pre-aim, fast 3.0m strike, MoveFix & strict hitbox raycast.", Category.COMBAT, "silent_aura", -1);
        this.aimType = registerSetting(new Setting.ModeSetting("aim_type", "Mode", "Ghost undetected silent aim, Silent server aim, or visible Legit aim", "Ghost", new String[]{"Ghost", "Silent", "Legit"}));
        this.targetMode = registerSetting(new Setting.ModeSetting("target_mode", "Target", "Priority mode", "Nearest", new String[]{"Nearest", "Crosshair", "Health"}));
        this.aimPoint = registerSetting(new Setting.ModeSetting("aim_point", "Aim Point", "Target hitbox point", "Auto", new String[]{"Auto", "Head", "Center", "Torso"}));
        this.range = registerSetting(new Setting.NumberSetting("range", "Range", "Strike range in blocks (3.0m strike, 5.5m Ghost pre-aim)", 3.0, 2.5, 5.5, 0.05, "m"));
        this.fov = registerSetting(new Setting.NumberSetting("fov", "FOV", "Maximum angular acquisition cone (85 deg Ghost undetected)", 85.0, 15.0, 180.0, 5.0, "deg"));
        this.smoothness = registerSetting(new Setting.NumberSetting("smoothness", "Smoothness", "Rotation speed", 80.0, 10.0, 100.0, 1.0, "%"));
        this.moveFix = registerSetting(new Setting.BooleanSetting("move_fix", "Move Fix", "Remap WASD relative to silent rotation yaw (recommended for anti-cheats)", true));
        this.playersOnly = registerSetting(new Setting.BooleanSetting("players_only", "Players Only", "Target Players only", true));
        this.weaponsOnly = registerSetting(new Setting.BooleanSetting("weapons_only", "Weapons Only", "Only engage while holding a weapon", true));
        this.raytraceCheck = registerSetting(new Setting.BooleanSetting("raytrace_check", "Raytrace Check", "Confirm strict server-confirmed hitbox raycast before swinging", true));
        this.simulateClick = registerSetting(new Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left clicks", true));
    }

    @Override
    public void onTick() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        class_746 player = mc.field_1724;
        if (mc.field_1755 != null || (Boolean.TRUE.equals(weaponsOnly.getValue()) && !WeaponUtils.isHoldingWeapon(player)) || player.method_6115()) {
            RotationUtils.releaseSilentRotation(2);
            RotationUtils.releaseCameraTarget(2);
            return;
        }
        double strikeRange = range.doubleValue();
        double prepRange = strikeRange + 2.5; // 5.5m Ghost preparation distance
        class_1309 target = TargetUtils.findBestTarget(prepRange, fov.floatValue(), Boolean.TRUE.equals(playersOnly.getValue()), targetMode.getValue());
        if (target == null) {
            RotationUtils.releaseSilentRotation(2);
            RotationUtils.releaseCameraTarget(2);
            return;
        }
        double dist = TargetUtils.getClosestBoxDistance(player, target);
        if (dist > prepRange) {
            RotationUtils.releaseSilentRotation(2);
            RotationUtils.releaseCameraTarget(2);
            return;
        }
        float curYaw = !aimType.is("Legit") && RotationUtils.isSilentControlling() ? RotationUtils.getServerYaw() : player.method_36454();
        float curPitch = !aimType.is("Legit") && RotationUtils.isSilentControlling() ? RotationUtils.getServerPitch() : player.method_36455();
        float[] rot = RotationUtils.getAimPointRotationsForCurrent(player, target, aimPoint.getValue(), curYaw, curPitch);
        ThreadLocalRandom rng = ThreadLocalRandom.current();
        float aimYaw = rot[0] + (rng.nextFloat() - 0.5f) * 0.22f;
        float aimPitch = RotationUtils.clampPitch(rot[1] + (rng.nextFloat() - 0.5f) * 0.16f);
        float effSmooth = Math.max(10.0f, Math.min(88.0f, smoothness.floatValue() * 0.58f));
        float serverYaw;
        float serverPitch;
        if (!aimType.is("Legit")) {
            RotationUtils.releaseCameraTarget(2);
            RotationUtils.driveSilentRotationCapped(player, aimYaw, aimPitch, effSmooth, 32.0f, Boolean.TRUE.equals(moveFix.getValue()), 2);
            serverYaw = RotationUtils.getConfirmedServerYaw(player);
            serverPitch = RotationUtils.getConfirmedServerPitch(player);
        } else {
            RotationUtils.releaseSilentRotation(2);
            RotationUtils.driveCameraTarget(player, target, aimPoint.getValue(), effSmooth, true, 0.85f, 2);
            serverYaw = player.method_36454();
            serverPitch = player.method_36455();
        }
        long now = System.currentTimeMillis();
        if ((!Boolean.TRUE.equals(raytraceCheck.getValue()) || RotationUtils.raycastStrictServerHitbox(player, target, serverYaw, serverPitch, strikeRange))
                && now >= nextAttackAllowedMs
                && player.method_7261(0.5f) >= nextCooldownThreshold
                && dist <= strikeRange) {
            ClickSimulator.pushSimulate(Boolean.TRUE.equals(simulateClick.getValue()));
            try {
                ClickSimulator.attackEntity(mc.field_1761, player, target);
                player.method_6104(class_1268.field_5808);
            } finally {
                ClickSimulator.popSimulate();
            }
            nextCooldownThreshold = 0.86f + rng.nextFloat() * 0.04f;
            nextAttackAllowedMs = now + 8L + rng.nextInt(12);
        }
    }
}
