package com.viper.client.modules.hacks.combat;

public final class Velocity extends com.viper.client.modules.Module {
    public final com.viper.client.modules.Setting.ModeSetting mode;
    public final com.viper.client.modules.Setting.NumberSetting horizontal;
    public final com.viper.client.modules.Setting.NumberSetting vertical;
    public final com.viper.client.modules.Setting.NumberSetting chance;
    public final com.viper.client.modules.Setting.BooleanSetting movingOnly;
    private float lastHealth;
    private int hurtGraceTicks;

    public Velocity() {
        super("velocity", "Velocity", "Reduces or resets incoming knockback smoothly.", com.viper.client.modules.Category.COMBAT, "sprint_reset", -1);
        new java.lang.String[3][0] = "Standard";
        new java.lang.String[3][1] = "Jump Reset";
        new java.lang.String[3][2] = "Legit";
        this.mode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("mode", "Mode", "Knockback reduction strategy", "Standard", new java.lang.String[3])));
        this.horizontal = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("horizontal", "Horizontal", "Horizontal knockback percentage (0% = none, 100% = vanilla)", 65.0, 0.0, 100.0, 1.0, "%")));
        this.vertical = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("vertical", "Vertical", "Vertical knockback percentage (0% = none, 100% = vanilla)", 85.0, 0.0, 100.0, 1.0, "%")));
        this.chance = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("chance", "Chance", "Probability of applying velocity reduction when hit", 90.0, 0.0, 100.0, 1.0, "%")));
        this.movingOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("moving_only", "Only While Moving", "Reduce knockback only while player is actively moving", 0)));
        this.lastHealth = -1.0f;
        this.hurtGraceTicks = 0;
        return;
    }

    protected void onDisable() {
        this.lastHealth = -1.0f;
        this.hurtGraceTicks = 0;
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.horizontal.intValue(), this.vertical.intValue());
    }

    public void onTick() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 22
        // if (v1.field_1724 == null) -> offset 22
        // if (v1.field_1687 != null) -> offset 23
        return;
        v2 = v1.field_1724;
        v3 = v2.method_6032();
        // if (Double.compare(this.lastHealth, 0.0f) <= 0) -> offset 58
        // if (Double.compare(v3, (this.lastHealth - 0.009999999776482582f)) >= 0) -> offset 58
        v4 = 0;
        this.lastHealth = v3;
        // if (v4 == 0) -> offset 79
        this.hurtGraceTicks = 2;
        // if (this.hurtGraceTicks <= 0) -> offset 99
        this.hurtGraceTicks = (this.hurtGraceTicks - 1);
        return;
        v5 = v2.method_18798();
        // if (((java.lang.Boolean) this.movingOnly.getValue()).booleanValue() == 0) -> offset 143
        // if (Double.compare(Math.hypot(v5.field_1352, v5.field_1350), 0.04) >= 0) -> offset 143
        return;
        // if (Double.compare((java.util.concurrent.ThreadLocalRandom.current().nextDouble() * 100.0), this.chance.doubleValue()) <= 0) -> offset 165
        return;
        // if (this.mode.is("Jump Reset") == 0) -> offset 189
        // if (v2.method_24828() == 0) -> offset 188
        v2.method_6043();
        return;
        v6 = (this.horizontal.doubleValue() / 100.0);
        v8 = (this.vertical.doubleValue() / 100.0);
        // if (this.mode.is("Legit") == 0) -> offset 247
        v6 = Math.max(0.55, v6);
        v8 = Math.max(0.7, v8);
        v2.method_18800((v5.field_1352 * v6), (v5.field_1351 * v8), (v5.field_1350 * v6));
        this.hurtGraceTicks = 0;
        v1 = 1;
        return;
    }

}
