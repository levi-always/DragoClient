package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({net.minecraft.class_765.class})
public abstract class LightmapTextureManagerMixin {
    @Shadow
    private boolean field_4135;
    @Unique
    private float viper$lastAmbientBoost;

    public LightmapTextureManagerMixin() {
        super();
        this.viper$lastAmbientBoost = 0.0f;
        return;
    }

    @Unique
    private static float viper$resolveDesiredAmbientBoost() {
        v0 = com.viper.client.ViperClient.getInstance();
        // if (v0 != null) -> offset 10
        return 0.0f;
        v1 = ((com.viper.client.modules.hacks.render.Fullbright) v0.getModuleManager().getModule(com.viper.client.modules.hacks.render.Fullbright.class));
        // if (v1 == null) -> offset 39
        // if (v1.isEnabled() == 0) -> offset 39
        return v1.getAmbientBoost();
        v2 = ((com.viper.client.modules.hacks.render.XRay) v0.getModuleManager().getModule(com.viper.client.modules.hacks.render.XRay.class));
        // if (v2 == null) -> offset 65
        // if (v2.isEnabled() == 0) -> offset 65
        return 1.0f;
        return 0.0f;
    }

    @Inject(method = {"method_3313"}, at = {@At("HEAD")})
    private void viper$markDirtyOnBoostChange(float arg0, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg1) {
        v3 = com.viper.client.mixin.LightmapTextureManagerMixin.viper$resolveDesiredAmbientBoost();
        // if (Double.compare(Math.abs((v3 - this.viper$lastAmbientBoost)), 0.0010000000474974513f) <= 0) -> offset 29
        this.viper$lastAmbientBoost = v3;
        this.field_4135 = 1;
        return;
    }

    @Redirect(method = {"method_3313"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/class_2874;comp_656()F"))
    private float viper$redirectAmbientLight(net.minecraft.class_2874 arg0) {
        v2 = arg0.comp_656();
        v3 = com.viper.client.mixin.LightmapTextureManagerMixin.viper$resolveDesiredAmbientBoost();
        // if (Double.compare(v3, 0.0010000000474974513f) <= 0) -> offset 24
        return v2;
    }

    @Inject(method = {"method_23284"}, at = {@At("RETURN")}, cancellable = true)
    private static void viper$boostCpuBrightness(net.minecraft.class_2874 arg0, int arg1, org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable arg2) {
        v3 = com.viper.client.ViperClient.getInstance();
        // if (v3 != null) -> offset 9
        return;
        v4 = ((com.viper.client.modules.hacks.render.Fullbright) v3.getModuleManager().getModule(com.viper.client.modules.hacks.render.Fullbright.class));
        // if (v4 == null) -> offset 59
        // if (v4.isEnabled() == 0) -> offset 59
        arg2.setReturnValue(Float.valueOf(v4.computeBoostedBrightness(((java.lang.Float) arg2.getReturnValue()).floatValue())));
        return;
        v5 = ((com.viper.client.modules.hacks.render.XRay) v3.getModuleManager().getModule(com.viper.client.modules.hacks.render.XRay.class));
        // if (v5 == null) -> offset 94
        // if (v5.isEnabled() == 0) -> offset 94
        arg2.setReturnValue(Float.valueOf(1.0f));
        return;
    }

}
