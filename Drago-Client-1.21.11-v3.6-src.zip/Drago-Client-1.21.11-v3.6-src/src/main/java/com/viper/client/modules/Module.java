package com.viper.client.modules;

public abstract class Module {
    private final String id;
    private final String name;
    private final String description;
    private final com.viper.client.modules.Category category;
    private final String iconName;
    private boolean enabled;
    private boolean hidden;
    private int keyCode;
    private boolean settingsOpen;
    private float enableAnim;
    private float hoverAnim;
    private float pressAnim;
    private float settingsAnim;
    private float hudAnim;
    private final java.util.List settings;

    protected Module(String arg0, String arg1, String arg2, com.viper.client.modules.Category arg3, String arg4, int arg5) {
        super();
        this.hidden = 0;
        this.enableAnim = 0.0f;
        this.hoverAnim = 0.0f;
        this.pressAnim = 0.0f;
        this.settingsAnim = 0.0f;
        this.hudAnim = 0.0f;
        this.settings = new java.util.ArrayList();
        this.id = arg0;
        this.name = arg1;
        this.description = arg2;
        this.category = arg3;
        this.iconName = arg4;
        this.keyCode = arg5;
        return;
    }

    protected com.viper.client.modules.Setting registerSetting(com.viper.client.modules.Setting arg0) {
        this.settings.add(arg0);
        return arg0;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public com.viper.client.modules.Category getCategory() {
        return this.category;
    }

    public String getIconName() {
        return this.iconName;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public void setHidden(boolean arg0) {
        this.hidden = arg0;
        return;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean arg0) {
        // if (this.enabled != arg0) -> offset 9
        return;
        this.enabled = arg0;
        // if (arg0 == 0) -> offset 25
        this.onEnable();
        this.onDisable();
        return;
    }

    public void toggle() {
        // if (this.enabled != 0) -> offset 12
        1.setEnabled(0);
        this.triggerPressPulse();
        return;
    }

    public int getKeyCode() {
        return this.keyCode;
    }

    public void setKeyCode(int arg0) {
        this.keyCode = arg0;
        return;
    }

    public boolean isSettingsOpen() {
        return this.settingsOpen;
    }

    public void setSettingsOpen(boolean arg0) {
        this.settingsOpen = arg0;
        return;
    }

    public void toggleSettingsOpen() {
        // if (this.settingsOpen != 0) -> offset 12
        1.settingsOpen = 0;
        return;
    }

    public java.util.List getSettings() {
        return java.util.Collections.unmodifiableList(this.settings);
    }

    public com.viper.client.modules.Setting findSetting(String arg0) {
        v2 = this.settings.iterator();
        // if (v2.hasNext() == 0) -> offset 56
        v3 = ((com.viper.client.modules.Setting) v2.next());
        // if (v3.getId().equalsIgnoreCase(arg0) != 0) -> offset 51
        // if (v3.getName().equalsIgnoreCase(arg0) == 0) -> offset 53
        return v3;
        return null;
    }

    public void triggerPressPulse() {
        this.pressAnim = 1.0f;
        return;
    }

    public float getEnableAnim() {
        return this.enableAnim;
    }

    public void setEnableAnim(float arg0) {
        this.enableAnim = arg0;
        return;
    }

    public float getHoverAnim() {
        return this.hoverAnim;
    }

    public void setHoverAnim(float arg0) {
        this.hoverAnim = arg0;
        return;
    }

    public float getPressAnim() {
        return this.pressAnim;
    }

    public void setPressAnim(float arg0) {
        this.pressAnim = arg0;
        return;
    }

    public float getSettingsAnim() {
        return this.settingsAnim;
    }

    public void setSettingsAnim(float arg0) {
        this.settingsAnim = arg0;
        return;
    }

    public float getHudAnim() {
        return this.hudAnim;
    }

    public void setHudAnim(float arg0) {
        this.hudAnim = arg0;
        return;
    }

    public String getHudMetadata() {
        return "";
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    public void onTick() {
    }

    public void onAttackEntity(Object arg0) {
    }

    public void onRenderOverlay(net.minecraft.class_332 arg0, float arg1) {
    }

}
