package com.viper.client;

public final class ViperClient implements net.fabricmc.api.ClientModInitializer {
    public static final String NAME = "DRAGO";
    public static final String VERSION = "3.6";
    public static final String MC_VERSION = "1.21.11";
    private static com.viper.client.ViperClient instance;
    private final com.viper.client.core.EventManager eventManager;
    private final com.viper.client.ui.ThemeManager themeManager;
    private final com.viper.client.core.ModuleManager moduleManager;
    private com.viper.client.utils.ConfigManager configManager;
    private final java.util.Set heldKeys;
    private long lastHudFrameNs;

    public ViperClient() {
        super();
        this.heldKeys = new java.util.HashSet();
        this.lastHudFrameNs = System.nanoTime();
        this.eventManager = new com.viper.client.core.EventManager();
        this.themeManager = new com.viper.client.ui.ThemeManager();
        this.moduleManager = new com.viper.client.core.ModuleManager(this.eventManager);
        return;
    }

    public void initializeWithGameDir(java.nio.file.Path arg0) {
        com.viper.client.ViperClient.instance = this;
        this.configManager = new com.viper.client.utils.ConfigManager(arg0);
        this.configManager.load(this.moduleManager, this.themeManager);
        Runtime.getRuntime().addShutdownHook(new Thread(run(this), "Drago-Config-Save"));
        return;
    }

    public void onInitializeClient() {
        v1 = net.fabricmc.loader.api.FabricLoader.getInstance().getGameDir();
        this.initializeWithGameDir(v1);
        return;
    }

    public static com.viper.client.ViperClient getInstance() {
        return com.viper.client.ViperClient.instance;
    }

    public com.viper.client.core.EventManager getEventManager() {
        return this.eventManager;
    }

    public com.viper.client.ui.ThemeManager getThemeManager() {
        return this.themeManager;
    }

    public com.viper.client.core.ModuleManager getModuleManager() {
        return this.moduleManager;
    }

    public com.viper.client.utils.ConfigManager getConfigManager() {
        return this.configManager;
    }

    public void saveConfig() {
        // if (this.configManager == null) -> offset 22
        this.configManager.save(this.moduleManager, this.themeManager);
        return;
    }

    public void onClientTick() {
        com.viper.client.utils.RotationUtils.beginClientTick();
        com.viper.client.utils.HotbarCoordinator.onClientTick();
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 29
        // if (v1.field_1755 != null) -> offset 29
        this.pollKeybinds(v1);
        this.heldKeys.clear();
        this.eventManager.post(com.viper.client.core.EventManager.TickEvent.INSTANCE);
        com.viper.client.utils.RotationUtils.finishClientTick();
        return;
    }

    public void onRenderFrame(float arg0) {
        com.viper.client.utils.RotationUtils.onRenderFrame(arg0);
        com.viper.client.utils.HotbarCoordinator.onRenderFrame();
        com.viper.client.modules.hacks.combat.PotAssist.pollRenderFrame();
        com.viper.client.modules.hacks.combat.KeyPearl.pollRenderFrame();
        com.viper.client.modules.hacks.combat.AutoHitCrystal.pollRenderFrame();
        com.viper.client.modules.hacks.combat.AnchorMacro.pollRenderFrame();
        com.viper.client.modules.hacks.combat.AutoClicker.pollRenderFrame();
        com.viper.client.modules.hacks.combat.KnockbackDelay.pollRenderFrame();
        com.viper.client.modules.hacks.combat.WindCharge.pollRenderFrame();
        com.viper.client.modules.hacks.combat.WindChargeClutch.pollRenderFrame();
        return;
    }

    private void pollKeybinds(net.minecraft.class_310 arg0) {
        // if (arg0.method_22683() == null) -> offset 17
        v2 = org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        v4 = v2;
        // if (Double.compare(v2, 0L) != 0) -> offset 31
        return;
        v6 = this.themeManager.getOpenGuiKeyCode();
        // if (v6 <= 0) -> offset 68
        // if (this.isKeyJustPressed(v2, v6) == 0) -> offset 68
        arg0.method_1507(new com.viper.client.ui.ViperClickGuiScreen(this));
        return;
        v7 = this.moduleManager.getVisibleModules().iterator();
        // if (v7.hasNext() == 0) -> offset 153
        v8 = ((com.viper.client.modules.Module) v7.next());
        v9 = v8.getKeyCode();
        // if (v9 <= 0) -> offset 82
        // if (this.isKeyJustPressed(v2, v9) != 0) -> offset 129
        this.eventManager.post(new com.viper.client.core.EventManager.KeyPressEvent(v9));
        this.saveConfig();
        return;
    }

    private boolean isKeyJustPressed(long arg0, int arg1) {
        // if (org.lwjgl.glfw.GLFW.glfwGetKey(arg0, arg1) != 1) -> offset 13
        v4 = 0;
        v5 = v4;
        // if (v4 == 0) -> offset 39
        return this.heldKeys.add(Integer.valueOf(arg1));
        this.heldKeys.remove(Integer.valueOf(arg1));
        return false;
    }

    public void onRenderHud(net.minecraft.class_332 arg0) {
        this.onRenderHud(arg0, 1.0f);
        return;
    }

    public void onRenderHud(net.minecraft.class_332 arg0, float arg1) {
        v3 = System.nanoTime();
        v5 = Math.max(0.0010000000474974513f, Math.min(0.07999999821186066f, ((float)(v3 - this.lastHudFrameNs) / 1000000000.0f)));
        this.lastHudFrameNs = v3;
        this.themeManager.updateAnimation(v5);
        v6 = net.minecraft.class_310.method_1551();
        // if (v6 == null) -> offset 83
        // if (v6.field_1724 == null) -> offset 83
        // if ((v6.field_1755 instanceof com.viper.client.ui.ViperClickGuiScreen) != 0) -> offset 83
        // if ((v6.field_1755 instanceof com.viper.client.ui.HudEditorScreen) == 0) -> offset 84
        return;
        v7 = this.moduleManager.getModules().iterator();
        // if (v7.hasNext() == 0) -> offset 141
        v8 = ((com.viper.client.modules.Module) v7.next());
        // if (v8.isEnabled() != 0) -> offset 131
        v8.onRenderOverlay(arg0, arg1);
        v7 = v6.field_1772;
        // if (v7 != null) -> offset 154
        return;
        v8 = new java.util.ArrayList();
        v9 = this.moduleManager.getVisibleModules().iterator();
        // if (v9.hasNext() == 0) -> offset 256
        v10 = ((com.viper.client.modules.Module) v9.next());
        // if (v10.isEnabled() == 0) -> offset 218
        v10.getHudAnim().setHudAnim(com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 16.0f, v5));
        // if (Double.compare(v10.getHudAnim(), 0.009999999776482582f) > 0) -> offset 245
        v8.add(v10);
        // if (this.themeManager.isWatermarkEnabled() == 0) -> offset 287
        this.renderWatermarkPreview(arg0, v7, this.themeManager.getWatermarkX(), this.themeManager.getWatermarkY());
        // if (this.themeManager.isArrayListEnabled() == 0) -> offset 305
        // if (v8.isEmpty() == 0) -> offset 306
        return;
        v8.sort(java.util.Comparator.comparingInt(applyAsInt(v7)).reversed());
        v9 = this.themeManager.getArrayListX();
        v10 = this.themeManager.getArrayListY();
        v11 = v8.iterator();
        // if (v11.hasNext() == 0) -> offset 700
        v12 = ((com.viper.client.modules.Module) v11.next());
        v13 = com.viper.client.utils.AnimUtils.easeOutCubic(v12.getHudAnim());
        v14 = v12.getHudMetadata();
        v15 = com.viper.client.utils.AtlasRenderer.getTextWidth(v7, v12.getName());
        // if (v14.isEmpty() == 0) -> offset 414
        v16 = com.viper.client.utils.AtlasRenderer.getTextWidth(v7, makeConcatWithConstants(v14));
        v17 = (((24 + v15) + v16) + 9);
        v18 = 18;
        v19 = (v9 - Math.round(((1.0f - v13) * 12.0f)));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v19, v10, v17, v18, com.viper.client.utils.AnimUtils.withAlpha(this.themeManager.windowBg(), v13));
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, v19, v10, v17, v18, com.viper.client.utils.AnimUtils.withAlpha(this.themeManager.borderSubtle(), v13));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, (v19 + 2), (v10 + 3), 2, (v18 - 6), com.viper.client.utils.AnimUtils.withAlpha(this.themeManager.accentSecondary(), v13));
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.of(v12.getIconName()), (v19 + 7), (v10 + 3), 12, com.viper.client.utils.AnimUtils.withAlpha(this.themeManager.accentSecondary(), v13));
        com.viper.client.utils.AtlasRenderer.drawGradientText(arg0, v7, v12.getName(), (v19 + 22), (v10 + 5), com.viper.client.utils.AnimUtils.withAlpha(this.themeManager.textGradStart(), v13), com.viper.client.utils.AnimUtils.withAlpha(this.themeManager.textGradEnd(), v13), 0);
        // if (v14.isEmpty() != 0) -> offset 677
        v20 = com.viper.client.utils.AtlasRenderer.getTextWidth(v7, makeConcatWithConstants(v12.getName()));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, v7, v14, ((v19 + 22) + v20), (v10 + 5), com.viper.client.utils.AnimUtils.withAlpha(this.themeManager.textSecondary(), v13), 0);
        v10 = (v10 + Math.max(1, Math.round(((float)(v18 + 2) * v13))));
        return;
    }

    public void renderWatermarkPreview(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, int arg2, int arg3) {
        v5 = com.viper.client.utils.AtlasRenderer.getTextWidth(arg1, "DRAGO");
        v6 = Math.round(((float)com.viper.client.utils.AtlasRenderer.getTextWidth(arg1, "3.6") * 0.7799999713897705f));
        v7 = ((((28 + v5) + 4) + v6) + 10);
        v8 = 25;
        com.viper.client.utils.AtlasRenderer.drawShadowPill(arg0, arg2, arg3, v7, v8, 4, 1912602624);
        com.viper.client.utils.AtlasRenderer.drawLargePanel(arg0, arg2, arg3, v7, v8, this.themeManager.windowBg(), this.themeManager.borderSubtle());
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, (arg2 + 6), (arg3 + 1), (v7 - 12), 2, this.themeManager.accentSecondary(), this.themeManager.accentPrimary());
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.VIPER_LOGO, (arg2 + 7), (arg3 + 5), 15, this.themeManager.accentSecondary());
        com.viper.client.utils.AtlasRenderer.drawGradientText(arg0, arg1, "DRAGO", (arg2 + 26), (arg3 + 6), this.themeManager.textGradStart(), this.themeManager.textGradEnd(), 0);
        arg0.method_51448().pushMatrix();
        arg0.method_51448().translate((float)(((arg2 + 26) + v5) + 3), (float)(arg3 + 11));
        arg0.method_51448().scale(0.7799999713897705f, 0.7799999713897705f);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, "3.6", 0, 0, this.themeManager.textGradEnd(), 0);
        arg0.method_51448().popMatrix();
        return;
    }

}
