package com.viper.client.modules.hacks.combat;

import com.viper.client.modules.Category;
import com.viper.client.modules.Module;
import com.viper.client.modules.Setting;
import com.viper.client.utils.ClickSimulator;
import com.viper.client.utils.HotbarCoordinator;
import com.viper.client.utils.RotationUtils;
import com.viper.client.utils.TargetUtils;
import com.viper.client.utils.WeaponUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class AutoMace extends Module {
    public final Setting.ModeSetting mode;
    public final Setting.NumberSetting minFall;
    public final Setting.NumberSetting approachRange;
    public final Setting.NumberSetting attackRange;
    public final Setting.NumberSetting smoothness;
    public final Setting.BooleanSetting elytraSwap;
    public final Setting.BooleanSetting switchBack;
    public final Setting.BooleanSetting simulateClick;
    public final Setting.BooleanSetting playersOnly;
    private long lastSmashMs = 0L;

    public AutoMace() {
        super("auto_mace", "AutoMace", "Undetected Mace smash when falling near target (85 deg FOV, 34 deg/tick cap, strict raycast, MoveFix).", Category.COMBAT, "auto_mace", -1);
        this.mode = registerSetting(new Setting.ModeSetting("mode", "Mode", "Aiming mode: Silent server aim or visible Legit aim", "Silent", new String[]{"Silent", "Legit"}));
        this.minFall = registerSetting(new Setting.NumberSetting("min_fall", "Min Fall", "Minimum fall distance in blocks", 1.5, 1.0, 10.0, 0.5, "b"));
        this.approachRange = registerSetting(new Setting.NumberSetting("approach_range", "Approach Range", "Pre-aim detection distance before Mace smash", 4.5, 3.0, 7.0, 0.1, "m"));
        this.attackRange = registerSetting(new Setting.NumberSetting("attack_range", "Attack Range", "Strict vanilla-safe strike distance for Mace smash", 3.0, 2.5, 4.5, 0.1, "m"));
        this.smoothness = registerSetting(new Setting.NumberSetting("smoothness", "Smoothness", "Rotation smoothness toward target", 78.0, 5.0, 100.0, 1.0, "%"));
        this.elytraSwap = registerSetting(new Setting.BooleanSetting("elytra_swap", "Elytra Swap", "Swap chestplate/elytra cleanly", false));
        this.switchBack = registerSetting(new Setting.BooleanSetting("switch_back", "Switch Back", "Restore previous slot after Mace smash", true));
        this.simulateClick = registerSetting(new Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate click presses", true));
        this.playersOnly = registerSetting(new Setting.BooleanSetting("players_only", "Players Only", "Target Players only", true));
    }

    @Override
    public void onTick() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        class_746 player = mc.field_1724;
        if (player.field_6017 < minFall.floatValue() || player.method_24828()) {
            RotationUtils.releaseSilentRotation(5);
            return;
        }
        class_1309 target = TargetUtils.findBestTarget(approachRange.doubleValue(), 85.0f, Boolean.TRUE.equals(playersOnly.getValue()), "Nearest");
        if (target == null) return;
        float[] rot = RotationUtils.getRotationsToEntity(player, target);
        float effSmooth = Math.max(24.0f, smoothness.floatValue() * 0.62f);
        if (mode.is("Silent")) {
            RotationUtils.driveSilentRotationCapped(player, rot[0], rot[1], effSmooth, 34.0f, true, 5);
        } else {
            RotationUtils.driveCameraPoint(player, target.method_23317(), target.method_23320(), target.method_23321(), effSmooth, false, 5);
        }
        int maceSlot = WeaponUtils.findMaceHotbarSlot(player);
        long now = System.currentTimeMillis();
        if (maceSlot >= 0
                && TargetUtils.getClosestBoxDistance(player, target) <= attackRange.doubleValue()
                && now - lastSmashMs >= 185L
                && RotationUtils.raycastStrictServerHitbox(player, target, RotationUtils.getConfirmedServerYaw(player), RotationUtils.getConfirmedServerPitch(player), attackRange.doubleValue())) {
            if (HotbarCoordinator.beginSequence("auto_mace", 46, maceSlot, Boolean.TRUE.equals(switchBack.getValue()))) {
                ClickSimulator.pushSimulate(Boolean.TRUE.equals(simulateClick.getValue()));
                try {
                    ClickSimulator.attackEntity(mc.field_1761, player, target);
                    player.method_6104(class_1268.field_5808);
                    lastSmashMs = now;
                } finally {
                    ClickSimulator.popSimulate();
                    HotbarCoordinator.releaseOwner("auto_mace", Boolean.TRUE.equals(switchBack.getValue()));
                }
            }
        }
    }
}
