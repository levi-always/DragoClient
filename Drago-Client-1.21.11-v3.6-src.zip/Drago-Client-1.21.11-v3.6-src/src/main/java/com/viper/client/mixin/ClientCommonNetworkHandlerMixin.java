package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({net.minecraft.class_8673.class})
public abstract class ClientCommonNetworkHandlerMixin {
    public ClientCommonNetworkHandlerMixin() {
        super();
        return;
    }

    @ModifyVariable(method = {"method_52787"}, at = @At("HEAD"), argsOnly = true)
    private net.minecraft.class_2596 viper$modifyOutgoingPacket(net.minecraft.class_2596 arg0) {
        v4 = com.viper.client.ViperClient.getInstance();
        // if (v4 == null) -> offset 55
        v3 = ((com.viper.client.core.EventManager.PacketSendEvent) v4.getEventManager().post(new com.viper.client.core.EventManager.PacketSendEvent(arg0)));
        // if (((com.viper.client.core.EventManager.PacketSendEvent) v4.getEventManager().post(new com.viper.client.core.EventManager.PacketSendEvent(arg0))) == null) -> offset 55
        v2 = v3.getPacket();
        // if ((v3.getPacket() instanceof net.minecraft.class_2596) == 0) -> offset 55
        v5 = ((net.minecraft.class_2596) v2);
        return v5;
        return arg0;
    }

    @Inject(method = {"method_52781"}, at = {@At("HEAD")})
    private void viper$onDisconnectVelocityReset(net.minecraft.class_2661 arg0, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg1) {
        com.viper.client.modules.hacks.combat.KnockbackDelay.onNetworkReset();
        return;
    }

}
