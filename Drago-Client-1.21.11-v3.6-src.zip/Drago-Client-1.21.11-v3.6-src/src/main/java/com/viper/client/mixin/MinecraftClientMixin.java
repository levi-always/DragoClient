package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_310.class})
public abstract class MinecraftClientMixin implements com.viper.client.utils.ClickSimulator.ClientAccess {
    @Shadow
    private int field_1752;

    public MinecraftClientMixin() {
        super();
        return;
    }

    @Shadow
    private void method_1583() {
    }

    @Inject(method = {"method_1583"}, at = {@At("HEAD")}, cancellable = true)
    private void viper$onDoItemUseHead(org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg0) {
        v2 = ((net.minecraft.class_310) this);
        // if (com.viper.client.modules.hacks.combat.PotAssist.interceptDoItemUse(v2) != 0) -> offset 33
        // if (com.viper.client.modules.hacks.combat.WindCharge.interceptDoItemUse(v2) != 0) -> offset 33
        // if (com.viper.client.modules.hacks.combat.AutoHitCrystal.interceptDoItemUse(v2) != 0) -> offset 33
        // if (com.viper.client.modules.hacks.combat.AnchorMacro.interceptDoItemUse(v2) == 0) -> offset 37
        arg0.cancel();
        v2 = /*?*/;
        return;
    }

    @Inject(method = {"method_1574"}, at = {@At("HEAD")})
    private void viper$onTickHead(org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg0) {
        v3 = com.viper.client.ViperClient.getInstance();
        // if (v3 != null) -> offset 9
        return;
        v3.onClientTick();
        v4 = ((net.minecraft.class_310) this);
        // if (v4.field_1724 != null) -> offset 28
        return;
        v5 = ((com.viper.client.modules.hacks.world.FastPlace) v3.getModuleManager().getModule(com.viper.client.modules.hacks.world.FastPlace.class));
        // if (v5 == null) -> offset 95
        // if (v5.isEnabled() == 0) -> offset 95
        // if (v4.field_1755 != null) -> offset 95
        // if (v5.matchesHeldItem(v4.field_1724) == 0) -> offset 95
        v2 = v5.computeCooldownCapTicks();
        // if (this.field_1752 <= v5.computeCooldownCapTicks()) -> offset 95
        this.field_1752 = v2;
        return;
    }

    @Inject(method = {"method_1574"}, at = {@At("TAIL")})
    private void viper$onTickTail(org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg0) {
        v2 = com.viper.client.ViperClient.getInstance();
        // if (v2 == null) -> offset 131
        v4 = ((net.minecraft.class_310) this);
        // if (v4.field_1724 == null) -> offset 131
        // if (v4.field_1755 != null) -> offset 131
        // if (v4.field_1690 == null) -> offset 131
        v3 = ((com.viper.client.modules.hacks.world.FastPlace) v2.getModuleManager().getModule(com.viper.client.modules.hacks.world.FastPlace.class));
        // if (((com.viper.client.modules.hacks.world.FastPlace) v2.getModuleManager().getModule(com.viper.client.modules.hacks.world.FastPlace.class)) == null) -> offset 131
        // if (v3.isEnabled() == 0) -> offset 131
        // if (v4.field_1690.field_1904.method_1434() == 0) -> offset 131
        // if (v4.field_1724.method_6115() != 0) -> offset 131
        // if (v3.matchesHeldItem(v4.field_1724) == 0) -> offset 131
        v5 = v3.pollExtraPlacementsThisTick();
        v6 = 0;
        // if (v6 >= v5) -> offset 131
        this.field_1752 = 0;
        this.viper$fastPlaceUse(v3);
        v6 += 1;
        return;
    }

    @Shadow
    private boolean method_1536() {
        return false;
    }

    public boolean viper$doAttack() {
        return this.method_1536();
    }

    public void viper$doItemUse() {
        this.method_1583();
        return;
    }

    public void viper$setItemUseCooldown(int arg0) {
        this.field_1752 = arg0;
        return;
    }

    private void viper$fastPlaceUse(com.viper.client.modules.hacks.world.FastPlace arg0) {
        // if (arg0 == null) -> offset 32
        // if (arg0.isSimulateClick() == 0) -> offset 32
        com.viper.client.utils.ClickSimulator.pulseUseKey(((net.minecraft.class_310) this), 1);
        this.method_1583();
        com.viper.client.utils.ClickSimulator.pulseUseKey(((net.minecraft.class_310) this), 0);
        return;
        this.method_1583();
        return;
    }

}
