package com.viper.client.ui.components;

public final class ColorPicker extends com.viper.client.ui.components.UIComponent {
    private static final int PANEL_EXTRA_HEIGHT = 94;
    private static final int[] QUICK_SWATCHES;
    private final com.viper.client.modules.Setting.ColorSetting setting;
    private Runnable onOpenCallback;
    private boolean expanded;
    private float expandAnim;
    private boolean draggingSb;
    private boolean draggingHue;

    public ColorPicker(com.viper.client.modules.Setting.ColorSetting arg0) {
        super();
        this.expanded = 0;
        this.expandAnim = 0.0f;
        this.draggingSb = 0;
        this.draggingHue = 0;
        this.setting = arg0;
        this.setDescription(arg0.getDescription());
        this.setVisibleSupplier(arg0.getVisibleCondition());
        return;
    }

    public com.viper.client.modules.Setting.ColorSetting getSetting() {
        return this.setting;
    }

    public void setOnOpenCallback(Runnable arg0) {
        this.onOpenCallback = arg0;
        return;
    }

    public boolean isExpanded() {
        return this.expanded;
    }

    public void setExpanded(boolean arg0) {
        this.expanded = arg0;
        // if (arg0 != 0) -> offset 19
        this.draggingSb = 0;
        this.draggingHue = 0;
        return;
    }

    protected void onHidden() {
        this.setExpanded(0);
        return;
    }

    public int getRenderedHeight() {
        v1 = Math.round((94.0f * com.viper.client.utils.AnimUtils.easeOutCubic(this.expandAnim)));
        return (this.height + v1);
    }

    public void render(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, com.viper.client.ui.ThemeManager arg2, int arg3, int arg4, float arg5) {
        this.updateBaseAnimations((double)arg3, (double)arg4, arg5);
        // if (this.expanded == 0) -> offset 28
        this.expandAnim.expandAnim = com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 15.0f, arg5);
        this.pushInteractiveScale(arg0, 0.014999999664723873f);
        v7 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.dropdownBg(), arg2.cardHoverBg(), (this.hoverAnim * 0.75f)));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, this.x, this.y, this.width, this.height, v7);
        // if (this.expanded == 0) -> offset 124
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(this.x, this.y, this.width, this.height, this, arg2.accentSecondary().applyAlpha(arg2.borderSubtle()));
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.PALETTE, (this.x + 6), (this.y + ((this.height - 11) / 2)), 11, this.applyAlpha(this.setting.getArgb()));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, this.setting.getName(), (this.x + 20), (this.y + ((this.height - 8) / 2)), this.applyAlpha(arg2.textSecondary()), 0);
        v8 = 22;
        v9 = 12;
        v10 = (((this.x + this.width) - v8) - 18);
        v11 = (this.y + ((this.height - v9) / 2));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v10, v11, v8, v9, this.applyAlpha(this.setting.getArgb()));
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, v10, v11, v8, v9, this.applyAlpha(-1996488705));
        // if (this.expanded == 0) -> offset 313
        com.viper.client.utils.AtlasRenderer.drawIcon(com.viper.client.ui.Icons.CHEVRON_DOWN, com.viper.client.ui.Icons.CHEVRON_RIGHT, ((this.x + this.width) - 15), (this.y + ((this.height - 10) / 2)), 10, this.applyAlpha(arg2.accentSecondary()));
        this.popInteractiveScale(arg0);
        v12 = Math.round((92.0f * com.viper.client.utils.AnimUtils.easeOutCubic(this.expandAnim)));
        // if (v12 <= 6) -> offset 1204
        v13 = ((this.y + this.height) + 2);
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, (this.x + 1), v13, (this.width - 2), v12, this.applyAlpha(arg2.dropdownBg()));
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, (this.x + 1), v13, (this.width - 2), v12, this.applyAlpha(arg2.borderSubtle()));
        v14 = (this.x + 6);
        v15 = Math.max(24, (this.width - 12));
        v16 = (v13 + 5);
        v17 = 48;
        // if ((v16 + v17) > (v13 + v12)) -> offset 788
        v18 = 16;
        v19 = 10;
        v20 = this.setting.getHue();
        v21 = 0;
        // if (v21 >= v19) -> offset 657
        v22 = (v16 + ((v21 * v17) / v19));
        v23 = (v16 + (((v21 + 1) * v17) / v19));
        v24 = (1.0f - (((float)v21 + 0.5f) / (float)v19));
        v25 = 0;
        // if (v25 >= v18) -> offset 651
        v26 = (v14 + ((v25 * v15) / v18));
        v27 = (v14 + (((v25 + 1) * v15) / v18));
        v28 = (((float)v25 + 0.5f) / (float)v18);
        v29 = this.applyAlpha(com.viper.client.modules.Setting.ColorSetting.hsbToArgb(v20, v28, v24));
        arg0.method_25294(v26, v22, v27, v23, v29);
        v25 += 1;
        v21 += 1;
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, (v14 - 1), (v16 - 1), (v15 + 2), (v17 + 2), this.applyAlpha(arg2.borderSubtle()));
        v21 = (v14 + Math.round((this.setting.getSaturation() * (float)(v15 - 1))));
        v22 = (v16 + Math.round(((1.0f - this.setting.getBrightness()) * (float)(v17 - 1))));
        com.viper.client.utils.AtlasRenderer.drawRadialGlow(arg0, v21, v22, 7, this.applyAlpha(-2013265920));
        com.viper.client.utils.AtlasRenderer.drawCircle(arg0, (v21 - 4), (v22 - 4), 8, this.applyAlpha(-1));
        com.viper.client.utils.AtlasRenderer.drawCircle(arg0, (v21 - 2), (v22 - 2), 4, this.applyAlpha(this.setting.getArgb()));
        v18 = ((v16 + v17) + 6);
        v19 = 8;
        // if ((v18 + v19) > (v13 + v12)) -> offset 999
        v20 = 24;
        v21 = 0;
        // if (v21 >= v20) -> offset 901
        v22 = (v14 + ((v21 * v15) / v20));
        v23 = (v14 + (((v21 + 1) * v15) / v20));
        v24 = this.applyAlpha(com.viper.client.modules.Setting.ColorSetting.hsbToArgb((((float)v21 + 0.5f) / (float)v20), 1.0f, 1.0f));
        arg0.method_25294(v22, v18, v23, (v18 + v19), v24);
        v21 += 1;
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, (v14 - 1), (v18 - 1), (v15 + 2), (v19 + 2), this.applyAlpha(arg2.borderSubtle()));
        v21 = (v14 + Math.round((this.setting.getHue() * (float)(v15 - 1))));
        com.viper.client.utils.AtlasRenderer.drawCircle(arg0, (v21 - 5), (v18 - 1), 10, this.applyAlpha(-1));
        com.viper.client.utils.AtlasRenderer.drawCircle(arg0, (v21 - 3), (v18 + 1), 6, this.applyAlpha(com.viper.client.modules.Setting.ColorSetting.hsbToArgb(this.setting.getHue(), 1.0f, 1.0f)));
        v20 = ((v18 + v19) + 6);
        // if ((v20 + 13) > (v13 + v12)) -> offset 1204
        v21 = 12;
        v22 = 3;
        v23 = 0;
        // if (v23 >= com.viper.client.ui.components.ColorPicker.QUICK_SWATCHES.length) -> offset 1159
        v24 = (v14 + (v23 * (v21 + v22)));
        // if ((v24 + v21) <= ((v14 + v15) - 44)) -> offset 1073
        v25 = com.viper.client.ui.components.ColorPicker.QUICK_SWATCHES[v23];
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v24, v20, v21, v21, this.applyAlpha(v25));
        // if (v25 != 16777215) -> offset 1121
        v26 = 0;
        // if (v26 == 0) -> offset 1143
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(v24, v20, v21, v21, this, -1.applyAlpha(arg2.borderSubtle()));
        v23 += 1;
        v23 = this.setting.toHex();
        v24 = arg1.method_1727(v23);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, v23, ((v14 + v15) - v24), (v20 + 2), this.applyAlpha(arg2.textPrimary()), 0);
        return;
    }

    private void updateSbFromMouse(double arg0, double arg1) {
        v5 = (this.x + 6);
        v6 = Math.max(24, (this.width - 12));
        v7 = ((this.y + this.height) + 7);
        v8 = 48;
        v9 = (float)((arg0 - (double)v5) / (double)v6);
        v10 = (1.0f - (float)((arg1 - (double)v7) / (double)v8));
        this.setting.setHSB(this.setting.getHue(), v9, v10);
        return;
    }

    private void updateHueFromMouse(double arg0) {
        v3 = (this.x + 6);
        v4 = Math.max(24, (this.width - 12));
        v5 = (float)((arg0 - (double)v3) / (double)v4);
        this.setting.setHSB(Math.max(0.0f, Math.min(0.9990000128746033f, v5)), this.setting.getSaturation(), this.setting.getBrightness());
        return;
    }

    public boolean mouseClicked(double arg0, double arg1, int arg2) {
        // if (this.isMouseOver(arg0, arg1) == 0) -> offset 61
        // if (arg2 != 0) -> offset 61
        // if (this.expanded != 0) -> offset 25
        v6 = 0;
        // if (v6 == 0) -> offset 49
        // if (this.onOpenCallback == null) -> offset 49
        this.onOpenCallback.run();
        this.setExpanded(v6);
        this.triggerPress();
        return true;
        // if (this.expanded == 0) -> offset 370
        // if (Double.compare(this.expandAnim, 0.550000011920929f) <= 0) -> offset 370
        // if (arg2 != 0) -> offset 370
        v6 = (this.x + 6);
        v7 = Math.max(24, (this.width - 12));
        v8 = ((this.y + this.height) + 7);
        v9 = 48;
        // if (Double.compare(arg0, (double)v6) < 0) -> offset 175
        // if (Double.compare(arg0, (double)(v6 + v7)) > 0) -> offset 175
        // if (Double.compare(arg1, (double)v8) < 0) -> offset 175
        // if (Double.compare(arg1, (double)(v8 + v9)) > 0) -> offset 175
        this.draggingSb = 1;
        this.updateSbFromMouse(arg0, arg1);
        return true;
        v10 = ((v8 + v9) + 6);
        v11 = 8;
        // if (Double.compare(arg0, (double)v6) < 0) -> offset 243
        // if (Double.compare(arg0, (double)(v6 + v7)) > 0) -> offset 243
        // if (Double.compare(arg1, (double)(v10 - 2)) < 0) -> offset 243
        // if (Double.compare(arg1, (double)((v10 + v11) + 2)) > 0) -> offset 243
        this.draggingHue = 1;
        this.updateHueFromMouse(arg0);
        return true;
        v12 = ((v10 + v11) + 6);
        v13 = 12;
        v14 = 3;
        v15 = 0;
        // if (v15 >= com.viper.client.ui.components.ColorPicker.QUICK_SWATCHES.length) -> offset 370
        v16 = (v6 + (v15 * (v13 + v14)));
        // if ((v16 + v13) <= ((v6 + v7) - 44)) -> offset 304
        // if (Double.compare(arg0, (double)v16) < 0) -> offset 364
        // if (Double.compare(arg0, (double)(v16 + v13)) > 0) -> offset 364
        // if (Double.compare(arg1, (double)v12) < 0) -> offset 364
        // if (Double.compare(arg1, (double)(v12 + v13)) > 0) -> offset 364
        this.setting.setValue(Integer.valueOf(com.viper.client.ui.components.ColorPicker.QUICK_SWATCHES[v15]));
        this.triggerPress();
        return true;
        v15 += 1;
        return false;
    }

    public boolean mouseDragged(double arg0, double arg1, int arg2, double arg3, double arg4) {
        // if (arg2 == 0) -> offset 7
        return false;
        // if (this.draggingSb == 0) -> offset 22
        this.updateSbFromMouse(arg0, arg1);
        return true;
        // if (this.draggingHue == 0) -> offset 36
        this.updateHueFromMouse(arg0);
        return true;
        return false;
    }

    public boolean mouseReleased(double arg0, double arg1, int arg2) {
        // if (this.draggingSb != 0) -> offset 14
        // if (this.draggingHue == 0) -> offset 26
        this.draggingSb = 0;
        this.draggingHue = 0;
        return true;
        return false;
    }

}
