package com.viper.client.modules.hacks.combat;

public final class WindCharge extends com.viper.client.modules.Module {
    private static final String OWNER_ID = "wind_charge";
    private static final int HOTBAR_PRIORITY = 45;
    private static final int ROTATION_PRIORITY = 4;
    private static volatile boolean bypassingUse;
    public final com.viper.client.modules.Setting.ModeSetting mode;
    public final com.viper.client.modules.Setting.BooleanSetting onKey;
    public final com.viper.client.modules.Setting.KeybindSetting triggerKey;
    public final com.viper.client.modules.Setting.BooleanSetting switchBack;
    public final com.viper.client.modules.Setting.NumberSetting throwPitch;
    public final com.viper.client.modules.Setting.NumberSetting smoothness;
    public final com.viper.client.modules.Setting.BooleanSetting simulateClick;
    private boolean pendingThrow;
    private boolean triggeredByKey;
    private boolean returningCamera;
    private int targetSlot;
    private net.minecraft.class_1268 pendingHand;
    private float lockedYaw;
    private float lockedPitch;
    private float returnYaw;
    private float returnPitch;
    private long startedAtMs;
    private long holdUntilMs;
    private long restoreAtMs;
    private boolean awaitingRestore;
    private long lastThrowAtMs;
    private boolean wasKeyDown;

    public WindCharge() {
        super("wind_charge", "WindCharge", "Aims downward and throws Wind Charge on right-click or held key.", com.viper.client.modules.Category.COMBAT, "wind_charge", -1);
        new java.lang.String[2][0] = "Silent";
        new java.lang.String[2][1] = "Legit";
        this.mode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("mode", "Mode", "Aiming mode when throwing Wind Charge downward", "Silent", new java.lang.String[2])));
        this.onKey = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("on_key", "On Key", "Hold a configured key to select and throw Wind Charge", 0)));
        java.util.Objects.requireNonNull(this.onKey);
        this.triggerKey = ((com.viper.client.modules.Setting.KeybindSetting) this.registerSetting(((com.viper.client.modules.Setting.KeybindSetting) new com.viper.client.modules.Setting.KeybindSetting("trigger_key", "Key", "Key to hold to select and throw Wind Charge", -1).visibleWhen(getAsBoolean(this.onKey)))));
        java.util.Objects.requireNonNull(this.onKey);
        this.switchBack = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(((com.viper.client.modules.Setting.BooleanSetting) new com.viper.client.modules.Setting.BooleanSetting("switch_back", "Switch Back", "Return to your previous hotbar slot after throwing Wind Charge", 1).visibleWhen(getAsBoolean(this.onKey)))));
        this.throwPitch = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("pitch", "Throw Pitch", "Downward pitch target for Wind Charge self-boost", 86.0, 65.0, 90.0, 0.5, "°")));
        this.smoothness = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("smoothness", "Smoothness", "Rotation speed looking downward before throw", 88.0, 25.0, 100.0, 1.0, "%")));
        this.simulateClick = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Right click press when throwing Wind Charge", 1)));
        this.pendingThrow = 0;
        this.triggeredByKey = 0;
        this.returningCamera = 0;
        this.targetSlot = -1;
        this.pendingHand = net.minecraft.class_1268.field_5808;
        this.lockedYaw = 0.0f;
        this.lockedPitch = 86.0f;
        this.returnYaw = 0.0f;
        this.returnPitch = 0.0f;
        this.startedAtMs = 0L;
        this.holdUntilMs = 0L;
        this.restoreAtMs = 0L;
        this.awaitingRestore = 0;
        this.lastThrowAtMs = 0L;
        this.wasKeyDown = 0;
        return;
    }

    public static boolean isBypassingUse() {
        return com.viper.client.modules.hacks.combat.WindCharge.bypassingUse;
    }

    protected void onDisable() {
        this.resetSequence(0);
        return;
    }

    public String getHudMetadata() {
        return ((java.lang.String) this.mode.getValue());
    }

    public static boolean isWindCharge(net.minecraft.class_1799 arg0) {
        // if (arg0 == null) -> offset 27
        // if (arg0.method_7960() != 0) -> offset 27
        // if ("minecraft:wind_charge".equals(com.viper.client.utils.WeaponUtils.getItemId(arg0)) == 0) -> offset 27
        return false;
    }

    private static int findWindChargeSlot(net.minecraft.class_746 arg0) {
        v1 = 0;
        // if (v1 >= 9) -> offset 30
        // if (com.viper.client.modules.hacks.combat.WindCharge.isWindCharge(arg0.method_31548().method_5438(v1)) == 0) -> offset 24
        return v1;
        v1 += 1;
        return -1;
    }

    private static boolean isCoolingDown(net.minecraft.class_746 arg0, net.minecraft.class_1799 arg1) {
        // if (arg0 == null) -> offset 15
        // if (arg1 == null) -> offset 15
        // if (arg1.method_7960() == 0) -> offset 17
        return true;
        // if (arg0.method_7357() == null) -> offset 39
        // if (arg0.method_7357().method_7904(arg1) == 0) -> offset 39
        return false;
        v2 = 1;
        return false;
    }

    private void resetSequence(boolean arg0) {
        this.pendingThrow = 0;
        this.triggeredByKey = 0;
        this.returningCamera = 0;
        this.awaitingRestore = 0;
        this.targetSlot = -1;
        this.holdUntilMs = 0L;
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        com.viper.client.utils.HotbarCoordinator.releaseOwner("wind_charge", arg0);
        return;
    }

    public static boolean interceptDoItemUse(net.minecraft.class_310 arg0) {
        // if (com.viper.client.modules.hacks.combat.WindCharge.bypassingUse != 0) -> offset 38
        // if (arg0 == null) -> offset 38
        // if (arg0.field_1724 == null) -> offset 38
        // if (arg0.field_1687 == null) -> offset 38
        // if (arg0.field_1761 == null) -> offset 38
        // if (arg0.field_1755 == null) -> offset 40
        return false;
        v1 = com.viper.client.ViperClient.getInstance();
        // if (v1 != null) -> offset 50
        return false;
        v2 = ((com.viper.client.modules.hacks.combat.WindCharge) v1.getModuleManager().getModule(com.viper.client.modules.hacks.combat.WindCharge.class));
        // if (v2 == null) -> offset 74
        // if (v2.isEnabled() != 0) -> offset 76
        return false;
        return v2.handleRightClickUse(arg0);
    }

    private boolean handleRightClickUse(net.minecraft.class_310 arg0) {
        v2 = arg0.field_1724;
        v3 = v2.method_6047();
        v4 = v2.method_6079();
        v5 = null;
        // if (com.viper.client.modules.hacks.combat.WindCharge.isWindCharge(v3) == 0) -> offset 42
        // if (com.viper.client.modules.hacks.combat.WindCharge.isCoolingDown(v2, v3) != 0) -> offset 42
        v5 = net.minecraft.class_1268.field_5808;
        // if (com.viper.client.modules.hacks.combat.WindCharge.isWindCharge(v4) == 0) -> offset 64
        // if (com.viper.client.modules.hacks.combat.WindCharge.isCoolingDown(v2, v4) != 0) -> offset 64
        v5 = net.minecraft.class_1268.field_5810;
        // if (v5 != null) -> offset 71
        return false;
        // if (this.pendingThrow != 0) -> offset 87
        this.beginDownwardThrow(v2, v5, -1, 0);
        this.stepRotation(v2);
        this.tryCompleteThrow(arg0, v2);
        return true;
    }

    private void beginDownwardThrow(net.minecraft.class_746 arg0, net.minecraft.class_1268 arg1, int arg2, boolean arg3) {
        this.pendingThrow = 1;
        this.triggeredByKey = arg3;
        this.returningCamera = 0;
        this.awaitingRestore = 0;
        this.pendingHand = arg1;
        this.targetSlot = arg2;
        this.returnYaw = com.viper.client.utils.RotationUtils.getRealViewYaw(arg0);
        this.returnPitch = com.viper.client.utils.RotationUtils.getRealViewPitch(arg0);
        this.lockedYaw = this.returnYaw;
        v5 = ((java.util.concurrent.ThreadLocalRandom.current().nextFloat() - 0.5f) * 0.6000000238418579f);
        this.lockedPitch = com.viper.client.utils.RotationUtils.clampPitch((this.throwPitch.floatValue() + v5));
        this.startedAtMs = System.currentTimeMillis();
        this.holdUntilMs = 0L;
        return;
    }

    private float computeDampSmoothness() {
        v1 = this.smoothness.floatValue();
        return com.viper.client.utils.AnimUtils.clamp((90.0f - ((v1 - 25.0f) * 1.0199999809265137f)), 8.0f, 82.0f);
    }

    private void stepRotation(net.minecraft.class_746 arg0) {
        v2 = this.computeDampSmoothness();
        // if (this.mode.is("Silent") == 0) -> offset 42
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        com.viper.client.utils.RotationUtils.driveSilentRotationCapped(arg0, this.lockedYaw, this.lockedPitch, v2, 76.0f, 0, 4);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        v3 = arg0.method_36454();
        v4 = arg0.method_36455();
        v5 = com.viper.client.utils.RotationUtils.smoothStepCapped(v3, v4, this.lockedYaw, this.lockedPitch, v2, 76.0f, 1.0f);
        arg0.method_36456(v5[0]);
        arg0.method_36457(v5[1]);
        return;
    }

    private boolean tryCompleteThrow(net.minecraft.class_310 arg0, net.minecraft.class_746 arg1) {
        // if (this.pendingThrow != 0) -> offset 9
        return false;
        v3 = System.currentTimeMillis();
        // if (this.triggeredByKey == 0) -> offset 78
        // if (this.pendingHand != net.minecraft.class_1268.field_5808) -> offset 78
        // if (this.targetSlot < 0) -> offset 78
        // if (com.viper.client.utils.HotbarCoordinator.selectSlotInSequence("wind_charge", 45, this.targetSlot, Boolean.TRUE.equals(this.switchBack.getValue())) != 0) -> offset 71
        this.resetSequence(0);
        return false;
        arg0.field_1761.method_2911();
        // if (this.mode.is("Silent") == 0) -> offset 102
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 102
        v5 = arg1.method_36455();
        // if (Double.compare(v5, (this.lockedPitch - 6.0f)) >= 0) -> offset 131
        // if (Double.compare(v5, 80.0f) < 0) -> offset 135
        v6 = 0;
        // if (Double.compare((v3 - this.startedAtMs), 130L) < 0) -> offset 155
        v7 = 0;
        // if (v6 != 0) -> offset 170
        // if (v7 != 0) -> offset 170
        return false;
        // if (this.pendingHand != net.minecraft.class_1268.field_5810) -> offset 187
        v8 = arg1.method_6047();
        // if (com.viper.client.modules.hacks.combat.WindCharge.isWindCharge(v8) == 0) -> offset 210
        // if (com.viper.client.modules.hacks.combat.WindCharge.isCoolingDown(arg1, v8) == 0) -> offset 244
        // if (this.triggeredByKey == 0) -> offset 238
        // if (Boolean.TRUE.equals(this.switchBack.getValue()) == 0) -> offset 238
        1.resetSequence(0);
        return false;
        v9 = this.lockedYaw;
        // if (v6 == 0) -> offset 260
        v10 = this.lockedPitch;
        v11 = arg1.method_36454();
        v12 = arg1.method_36455();
        com.viper.client.utils.ClickSimulator.pushSimulate(Boolean.TRUE.equals(this.simulateClick.getValue()));
        com.viper.client.modules.hacks.combat.WindCharge.bypassingUse = 1;
        // if (arg1.field_3944 == null) -> offset 338
        arg1.field_3944.method_52787(new net.minecraft.class_2828.class_2831(v9, v10, arg1.method_24828(), arg1.field_5976));
        com.viper.client.utils.RotationUtils.recordPacketConfirmedAngles(v9, v10);
        arg1.method_36456(v9);
        arg1.method_36457(v10);
        v13 = com.viper.client.utils.ClickSimulator.interactItem(arg0.field_1761, arg1, this.pendingHand);
        // if (v13 == null) -> offset 387
        // if (v13.method_23665() == 0) -> offset 387
        arg1.method_6104(this.pendingHand);
        arg0.field_1752 = Math.max(arg0.field_1752, 4);
        com.viper.client.modules.hacks.combat.WindCharge.bypassingUse = 0;
        com.viper.client.utils.ClickSimulator.popSimulate();
        // if (this.mode.is("Silent") == 0) -> offset 469
        arg1.method_36456(v11);
        arg1.method_36457(v12);
        v14 = v5;
        com.viper.client.modules.hacks.combat.WindCharge.bypassingUse = 0;
        com.viper.client.utils.ClickSimulator.popSimulate();
        // if (this.mode.is("Silent") == 0) -> offset 466
        arg1.method_36456(v11);
        arg1.method_36457(v12);
        throw v14;
        this.lastThrowAtMs = v3;
        this.pendingThrow = 0;
        this.holdUntilMs = (v3 + 80L);
        // if (this.mode.is("Silent") != 0) -> offset 505
        this.returningCamera = 1;
        // if (this.triggeredByKey == 0) -> offset 545
        // if (Boolean.TRUE.equals(this.switchBack.getValue()) == 0) -> offset 545
        this.awaitingRestore = 1;
        this.restoreAtMs = (v3 + 75L);
        // if (this.triggeredByKey == 0) -> offset 558
        com.viper.client.utils.HotbarCoordinator.releaseOwner("wind_charge", 0);
        return true;
    }

    private void pollHoldKey(net.minecraft.class_310 arg0) {
        // if (Boolean.TRUE.equals(this.onKey.getValue()) != 0) -> offset 22
        this.wasKeyDown = 0;
        return;
        v2 = this.triggerKey.getKeyCode();
        // if (v2 <= 0) -> offset 41
        // if (arg0.field_1755 == null) -> offset 47
        this.wasKeyDown = 0;
        return;
        // if (arg0.method_22683() == null) -> offset 64
        v3 = org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        // if (Double.compare(v3, 0L) == 0) -> offset 87
        // if (org.lwjgl.glfw.GLFW.glfwGetKey(v3, v2) != 1) -> offset 87
        v5 = 0;
        v6 = System.currentTimeMillis();
        // if (v5 != 0) -> offset 143
        this.wasKeyDown = 0;
        // if (this.triggeredByKey == 0) -> offset 142
        // if (this.awaitingRestore == 0) -> offset 142
        this.awaitingRestore = 0;
        com.viper.client.utils.HotbarCoordinator.releaseOwner("wind_charge", Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        // if (this.pendingThrow != 0) -> offset 171
        // if (this.awaitingRestore != 0) -> offset 171
        // if (Double.compare((v6 - this.lastThrowAtMs), 510L) >= 0) -> offset 177
        this.wasKeyDown = 1;
        return;
        v8 = arg0.field_1724;
        v9 = com.viper.client.modules.hacks.combat.WindCharge.findWindChargeSlot(v8);
        v10 = net.minecraft.class_1268.field_5808;
        // if (v9 >= 0) -> offset 238
        // if (com.viper.client.modules.hacks.combat.WindCharge.isWindCharge(v8.method_6079()) == 0) -> offset 232
        // if (com.viper.client.modules.hacks.combat.WindCharge.isCoolingDown(v8, v8.method_6079()) != 0) -> offset 232
        v10 = net.minecraft.class_1268.field_5810;
        this.wasKeyDown = 1;
        return;
        v11 = v8.method_31548().method_5438(v9);
        // if (com.viper.client.modules.hacks.combat.WindCharge.isCoolingDown(v8, v11) == 0) -> offset 266
        this.wasKeyDown = 1;
        return;
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("wind_charge", 45, v9, Boolean.TRUE.equals(this.switchBack.getValue())) != 0) -> offset 297
        this.wasKeyDown = 1;
        return;
        this.wasKeyDown = 1;
        this.beginDownwardThrow(v8, v10, v9, 1);
        this.stepRotation(v8);
        this.tryCompleteThrow(arg0, v8);
        return;
    }

    private void advanceFrame() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 29
        // if (v1.field_1724 == null) -> offset 29
        // if (v1.field_1687 == null) -> offset 29
        // if (v1.field_1761 != null) -> offset 30
        return;
        // if (v1.field_1755 == null) -> offset 76
        // if (this.pendingThrow != 0) -> offset 58
        // if (this.returningCamera != 0) -> offset 58
        // if (this.awaitingRestore == 0) -> offset 75
        this.resetSequence(Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        v2 = v1.field_1724;
        v3 = System.currentTimeMillis();
        // if (this.awaitingRestore == 0) -> offset 124
        // if (Double.compare(v3, this.restoreAtMs) < 0) -> offset 124
        this.awaitingRestore = 0;
        com.viper.client.utils.HotbarCoordinator.releaseOwner("wind_charge", Boolean.TRUE.equals(this.switchBack.getValue()));
        // if (this.pendingThrow == 0) -> offset 190
        // if (Double.compare((v3 - this.startedAtMs), 450L) <= 0) -> offset 177
        // if (this.triggeredByKey == 0) -> offset 172
        // if (Boolean.TRUE.equals(this.switchBack.getValue()) == 0) -> offset 172
        1.resetSequence(0);
        return;
        this.stepRotation(v2);
        this.tryCompleteThrow(v1, v2);
        return;
        // if (this.returningCamera == 0) -> offset 286
        // if (Double.compare(v3, this.holdUntilMs) <= 0) -> offset 286
        v5 = v2.method_36454();
        v6 = v2.method_36455();
        // if (Double.compare(Math.abs((v6 - this.returnPitch)), 1.2000000476837158f) >= 0) -> offset 245
        this.returningCamera = 0;
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        return;
        v7 = com.viper.client.utils.RotationUtils.smoothStepCapped(v5, v6, this.returnYaw, this.returnPitch, this.computeDampSmoothness(), 56.0f, 1.0f);
        v2.method_36456(v7[0]);
        v2.method_36457(v7[1]);
        return;
    }

    public void onTick() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 29
        // if (v1.field_1724 == null) -> offset 29
        // if (v1.field_1687 == null) -> offset 29
        // if (v1.field_1761 != null) -> offset 30
        return;
        // if (v1.field_1755 == null) -> offset 76
        // if (this.pendingThrow != 0) -> offset 58
        // if (this.returningCamera != 0) -> offset 58
        // if (this.awaitingRestore == 0) -> offset 75
        this.resetSequence(Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        this.pollHoldKey(v1);
        this.advanceFrame();
        // if (this.pendingThrow != 0) -> offset 114
        // if (this.returningCamera != 0) -> offset 114
        // if (Double.compare(System.currentTimeMillis(), this.holdUntilMs) <= 0) -> offset 114
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        return;
    }

    public static void pollRenderFrame() {
        v0 = com.viper.client.ViperClient.getInstance();
        // if (v0 != null) -> offset 9
        return;
        v1 = ((com.viper.client.modules.hacks.combat.WindCharge) v0.getModuleManager().getModule(com.viper.client.modules.hacks.combat.WindCharge.class));
        // if (v1 == null) -> offset 37
        // if (v1.isEnabled() == 0) -> offset 37
        v1.advanceFrame();
        v0 = /*?*/;
        return;
    }

}
