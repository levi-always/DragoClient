package com.viper.client.modules;

public abstract class Setting {
    private final String id;
    private final String name;
    private final String description;
    protected Object value;
    protected final Object defaultValue;
    private java.util.function.BooleanSupplier visibleCondition;

    protected Setting(String arg0, String arg1, String arg2, Object arg3) {
        super();
        this.visibleCondition = getAsBoolean();
        this.id = arg0;
        this.name = arg1;
        this.description = arg2;
        this.defaultValue = arg3;
        this.value = arg3;
        return;
    }

    public com.viper.client.modules.Setting visibleWhen(java.util.function.BooleanSupplier arg0) {
        // if (arg0 == null) -> offset 9
        this.visibleCondition = arg0;
        return this;
    }

    public boolean isVisible() {
        return this.visibleCondition.getAsBoolean();
    }

    public java.util.function.BooleanSupplier getVisibleCondition() {
        return this.visibleCondition;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Object getValue() {
        return this.value;
    }

    public Object getDefaultValue() {
        return this.defaultValue;
    }

    public void setValue(Object arg0) {
        // if (arg0 == null) -> offset 9
        this.value = arg0;
        return;
    }

    public void reset() {
        this.value = this.defaultValue;
        return;
    }

    public abstract String serialize();

    public abstract void deserialize(String arg0);

    public final class BooleanSetting extends com.viper.client.modules.Setting {
        public BooleanSetting(String arg0, String arg1, String arg2, boolean arg3) {
            super(arg0, arg1, arg2, Boolean.valueOf(arg3));
            return;
        }

        public void toggle() {
            // if (((java.lang.Boolean) this.getValue()).booleanValue() != 0) -> offset 18
            1.setValue(Boolean.valueOf(0));
            return;
        }

        public String serialize() {
            return Boolean.toString(((java.lang.Boolean) this.getValue()).booleanValue());
        }

        public void deserialize(String arg0) {
            // if (arg0 == null) -> offset 18
            this.setValue(Boolean.valueOf(Boolean.parseBoolean(arg0.trim())));
            return;
        }

    }

    public final class ColorSetting extends com.viper.client.modules.Setting {
        private float hue;
        private float saturation;
        private float brightness;

        public ColorSetting(String arg0, String arg1, String arg2, int arg3) {
            new com.viper.client.modules.Setting(arg2, -16777216, arg3, Integer.valueOf(16777215));
            this.syncHsbFromRgb(((java.lang.Integer) this.value).intValue());
            return;
        }

        private void syncHsbFromRgb(int arg0) {
            v2 = com.viper.client.modules.Setting.ColorSetting.rgbToHsb(255, arg0, 255);
            this.hue = v2[0];
            this.saturation = v2[1];
            this.brightness = v2[2];
            return;
        }

        public void setValue(Integer arg0) {
            // if (arg0 == null) -> offset 35
            arg0.intValue().value = Integer.valueOf(16777215);
            this.syncHsbFromRgb(((java.lang.Integer) this.value).intValue());
            return;
        }

        public void reset() {
            this.reset();
            this.syncHsbFromRgb(((java.lang.Integer) this.value).intValue());
            return;
        }

        public void setHSB(float arg0, float arg1, float arg2) {
            this.hue = (arg0 - (float)Math.floor((double)arg0));
            this.saturation = Math.max(0.0f, Math.min(1.0f, arg1));
            this.brightness = Math.max(0.0f, Math.min(1.0f, arg2));
            this.value = Integer.valueOf(com.viper.client.modules.Setting.ColorSetting.hsbToArgb(this.hue, this.saturation, this.brightness));
            return;
        }

        public float getHue() {
            return this.hue;
        }

        public float getSaturation() {
            return this.saturation;
        }

        public float getBrightness() {
            return this.brightness;
        }

        public int getArgb() {
            return ((java.lang.Integer) this.value).intValue();
        }

        public int getArgb(float arg0) {
            v2 = Math.max(0, Math.min(255, Math.round((arg0 * 255.0f))));
            return 16777215;
        }

        public String toHex() {
            0[((java.lang.Integer) this.value).intValue()] = Integer.valueOf(16777215);
            return String.format("#%06X", new java.lang.Object[1], new java.lang.Object[1]);
        }

        public String serialize() {
            return this.toHex();
        }

        public void deserialize(String arg0) {
            // if (arg0 != null) -> offset 5
            return;
            v2 = arg0.trim();
            // if (v2.startsWith("#") == 0) -> offset 28
            v2 = v2.substring(1);
            // if (v2.startsWith("0x") != 0) -> offset 46
            // if (v2.startsWith("0X") == 0) -> offset 52
            v2 = v2.substring(2);
            // if (v2.length() != 8) -> offset 67
            v2 = v2.substring(2);
            // if (v2.length() != 6) -> offset 98
            v3 = Integer.parseInt(v2, 16);
            -16777216.setValue(Integer.valueOf(v3));
            v3 = this;
            return;
        }

        public static int hsbToArgb(float arg0, float arg1, float arg2) {
            v3 = 0;
            v4 = 0;
            v5 = 0;
            // if (Double.compare(arg1, 9.999999747378752e-05f) > 0) -> offset 33
            v5 = Math.round((arg2 * 255.0f));
            v4 = Math.round((arg2 * 255.0f));
            v3 = v5;
            v6 = ((arg0 - (float)Math.floor((double)arg0)) * 6.0f);
            v7 = (int)Math.floor((double)v6);
            v8 = (v6 - (float)v7);
            v9 = (arg2 * (1.0f - arg1));
            v10 = (arg2 * (1.0f - (arg1 * v8)));
            v11 = (arg2 * (1.0f - (arg1 * (1.0f - v8))));
            v3 = Math.round((arg2 * 255.0f));
            v4 = Math.round((v11 * 255.0f));
            v5 = Math.round((v9 * 255.0f));
            v3 = Math.round((v10 * 255.0f));
            v4 = Math.round((arg2 * 255.0f));
            v5 = Math.round((v9 * 255.0f));
            v3 = Math.round((v9 * 255.0f));
            v4 = Math.round((arg2 * 255.0f));
            v5 = Math.round((v11 * 255.0f));
            v3 = Math.round((v9 * 255.0f));
            v4 = Math.round((v10 * 255.0f));
            v5 = Math.round((arg2 * 255.0f));
            v3 = Math.round((v11 * 255.0f));
            v4 = Math.round((v9 * 255.0f));
            v5 = Math.round((arg2 * 255.0f));
            v3 = Math.round((arg2 * 255.0f));
            v4 = Math.round((v9 * 255.0f));
            v5 = Math.round((v10 * 255.0f));
            v3 = Math.max(0, Math.min(255, v3));
            v4 = Math.max(0, Math.min(255, v4));
            v5 = Math.max(0, Math.min(255, v5));
            return v5;
        }

        public static float[] rgbToHsb(int arg0, int arg1, int arg2) {
            v4 = Math.max(arg0, Math.max(arg1, arg2));
            v5 = Math.min(arg0, Math.min(arg1, arg2));
            v6 = ((float)v4 / 255.0f);
            // if (v4 == 0) -> offset 48
            v7 = 0.0f;
            v8 = v7;
            // if (Double.compare(v7, 0.0f) != 0) -> offset 67
            v3 = 0.0f;
            v9 = ((float)(v4 - arg0) / (float)(v4 - v5));
            v10 = ((float)(v4 - arg1) / (float)(v4 - v5));
            v11 = ((float)(v4 - arg2) / (float)(v4 - v5));
            // if (arg0 != v4) -> offset 123
            // if (arg1 != v4) -> offset 139
            v3 = ((4.0f + v10) - v9);
            v3 = (v3 / 6.0f);
            // if (Double.compare(v3, 0.0f) >= 0) -> offset 163
            v3 = (v3 + 1.0f);
            new Object[3][0] = v3;
            new Object[3][1] = v7;
            new Object[3][2] = v6;
            return new Object[3];
        }

    }

    public final class KeybindSetting extends com.viper.client.modules.Setting {
        public KeybindSetting(String arg0, String arg1, String arg2, int arg3) {
            super(arg0, arg1, arg2, Integer.valueOf(arg3));
            return;
        }

        public int getKeyCode() {
            v1 = ((java.lang.Integer) this.getValue());
            // if (v1 == null) -> offset 19
            return -1;
        }

        public void setKeyCode(int arg0) {
            // if (arg0 > 0) -> offset 9
            -1.setValue(Integer.valueOf(arg0));
            return;
        }

        public String serialize() {
            return Integer.toString(this.getKeyCode());
        }

        public void deserialize(String arg0) {
            // if (arg0 == null) -> offset 11
            // if (arg0.isBlank() == 0) -> offset 12
            return;
            this.setKeyCode(Integer.parseInt(arg0.trim()));
            v2 = /*?*/;
            return;
        }

    }

    public final class ModeSetting extends com.viper.client.modules.Setting {
        private final java.util.List modes;

        public ModeSetting(String arg0, String arg1, String arg2, String arg3, String[] arg4) {
            super(arg0, arg1, arg2, arg3);
            this.modes = java.util.List.of(arg4);
            return;
        }

        public java.util.List getModes() {
            return this.modes;
        }

        public void setValue(String arg0) {
            // if (arg0 != null) -> offset 5
            return;
            v2 = arg0.trim();
            // if ("Camera".equalsIgnoreCase(v2) == 0) -> offset 36
            // if (this.modes.contains("Legit") == 0) -> offset 36
            v2 = "Legit";
            v3 = this.modes.iterator();
            // if (v3.hasNext() == 0) -> offset 85
            v4 = ((java.lang.String) v3.next());
            // if (v4.equalsIgnoreCase(v2) != 0) -> offset 78
            this.value = v4;
            return;
            return;
        }

        public void cycleNext() {
            v1 = this.modes.indexOf(this.value);
            v2 = ((v1 + 1) % this.modes.size());
            this.value = this.modes.get(v2);
            return;
        }

        public boolean is(String arg0) {
            return ((java.lang.String) this.value).equalsIgnoreCase(arg0);
        }

        public String serialize() {
            return ((java.lang.String) this.getValue());
        }

        public void deserialize(String arg0) {
            this.setValue(arg0);
            return;
        }

    }

    public final class NumberSetting extends com.viper.client.modules.Setting {
        private final double min;
        private final double max;
        private final double step;
        private final String suffix;

        public NumberSetting(String arg0, String arg1, String arg2, double arg3, double arg4, double arg5, double arg6, String arg7) {
            super(arg0, arg1, arg2, Double.valueOf(com.viper.client.modules.Setting.NumberSetting.clampSnap(arg3, arg4, arg5, arg6)));
            this.min = arg4;
            this.max = arg5;
            this.step = arg6;
            // if (arg7 != null) -> offset 50
            "".suffix = arg7;
            return;
        }

        private static double clampSnap(double arg0, double arg1, double arg2, double arg3) {
            v8 = Math.max(arg1, Math.min(arg2, arg0));
            // if (Double.compare(arg3, 0.0) <= 0) -> offset 50
            v8 = (((double)Math.round(((v8 - arg1) / arg3)) * arg3) + arg1);
            v8 = Math.max(arg1, Math.min(arg2, v8));
            return ((double)Math.round((v8 * 100.0)) / 100.0);
        }

        public void setValue(Double arg0) {
            // if (arg0 == null) -> offset 40
            // if (Double.isFinite(arg0.doubleValue()) == 0) -> offset 40
            this.value = Double.valueOf(com.viper.client.modules.Setting.NumberSetting.clampSnap(arg0.doubleValue(), this.min, this.max, this.step));
            return;
        }

        public double getMin() {
            return this.min;
        }

        public double getMax() {
            return this.max;
        }

        public double getStep() {
            return this.step;
        }

        public String getSuffix() {
            return this.suffix;
        }

        public float floatValue() {
            return ((java.lang.Double) this.value).floatValue();
        }

        public double doubleValue() {
            return ((java.lang.Double) this.value).doubleValue();
        }

        public long longValue() {
            return Math.round(((java.lang.Double) this.value).doubleValue());
        }

        public int intValue() {
            return (int)Math.round(((java.lang.Double) this.value).doubleValue());
        }

        public double getNormalizedProgress() {
            // if (Double.compare(this.max, this.min) > 0) -> offset 14
            return 0.0;
            return Math.max(0.0, Math.min(1.0, ((((java.lang.Double) this.value).doubleValue() - this.min) / (this.max - this.min))));
        }

        public String formatDisplay() {
            // if (Double.compare(this.step, 1.0) < 0) -> offset 23
            return makeConcatWithConstants(this.intValue(), this.suffix);
            new java.lang.Object[2][0] = this.value;
            new java.lang.Object[2][1] = this.suffix;
            return String.format(java.util.Locale.US, "%.1f%s", new java.lang.Object[2]);
        }

        public String serialize() {
            return Double.toString(((java.lang.Double) this.getValue()).doubleValue());
        }

        public void deserialize(String arg0) {
            // if (arg0 != null) -> offset 5
            return;
            this.setValue(Double.valueOf(Double.parseDouble(arg0.trim())));
            v2 = /*?*/;
            return;
        }

    }

}
