package com.viper.client.utils;

public final class ConfigManager {
    private static final java.util.List COMMUNITY_PRESETS;
    private final java.nio.file.Path configFile;
    private final java.nio.file.Path profilesDir;

    public ConfigManager(java.nio.file.Path arg0) {
        super();
        v2 = arg0.resolve("config").resolve("drago");
        this.configFile = v2.resolve("drago-config.properties");
        this.profilesDir = v2.resolve("profiles");
        return;
    }

    public java.nio.file.Path getConfigFile() {
        return this.configFile;
    }

    public java.util.List getCommunityPresets() {
        return com.viper.client.utils.ConfigManager.COMMUNITY_PRESETS;
    }

    public java.util.List listUserProfiles() {
        v1 = new java.util.ArrayList();
        // if (java.nio.file.Files.isDirectory(this.profilesDir, new java.nio.file.LinkOption[0]) != 0) -> offset 24
        return v1;
        v2 = java.nio.file.Files.newDirectoryStream(this.profilesDir, "*.properties");
        v3 = v2.iterator();
        // if (v3.hasNext() == 0) -> offset 228
        v4 = ((java.nio.file.Path) v3.next());
        v5 = new java.util.Properties();
        v6 = java.nio.file.Files.newInputStream(v4, new java.nio.file.OpenOption[0]);
        v5.load(v6);
        // if (v6 == null) -> offset 128
        v6.close();
        v7 = /*?*/;
        // if (v6 == null) -> offset 125
        v6.close();
        v8 = /*?*/;
        v7.addSuppressed(v8);
        throw v7;
        v6 = v4.getFileName().toString().replace(".properties", "");
        v7 = v5.getProperty("profile.name", v6);
        v8 = v5.getProperty("profile.description", "Saved DRAGO profile");
        v9 = v5.getProperty("profile.category", "Combat");
        v10 = com.viper.client.ui.ThemeManager.ThemePreset.byId(v5.getProperty("ui.theme", "white"));
        v1.add(new com.viper.client.utils.ConfigManager.PresetProfile(v6, v7, v8, v9, "You", 1, 1, v10, java.util.Set.of()));
        // if (v2 == null) -> offset 265
        v2.close();
        v3 = /*?*/;
        // if (v2 == null) -> offset 263
        v2.close();
        v4 = /*?*/;
        v3.addSuppressed(v4);
        throw v3;
        v2 = /*?*/;
        return v1;
    }

    public void saveUserProfile(String arg0, String arg1, com.viper.client.core.ModuleManager arg2, com.viper.client.ui.ThemeManager arg3) {
        v5 = arg0.replaceAll("[^a-zA-Z0-9_-]", "");
        // if (v5.isEmpty() == 0) -> offset 32
        v5 = makeConcatWithConstants((System.currentTimeMillis() % 10000L));
        java.nio.file.Files.createDirectories(this.profilesDir, new java.nio.file.attribute.FileAttribute[0]);
        v6 = this.toProperties(arg2, arg3);
        // if (arg0.isBlank() == 0) -> offset 69
        "profile.name".setProperty(v5, arg0.trim());
        v6.setProperty("profile.description", "Custom saved DRAGO configuration");
        // if (arg1 != null) -> offset 100
        "profile.category".setProperty("Combat", arg1);
        v7 = this.profilesDir.resolve(makeConcatWithConstants(v5));
        v8 = java.nio.file.Files.newOutputStream(v7, new java.nio.file.OpenOption[0]);
        v6.store(v8, "DRAGO Client User Profile");
        // if (v8 == null) -> offset 183
        v8.close();
        v9 = v6;
        // if (v8 == null) -> offset 180
        v8.close();
        v10 = v6;
        v9.addSuppressed(v10);
        throw v9;
        v6 = /*?*/;
        return;
    }

    public void deleteUserProfile(String arg0) {
        // if (arg0 == null) -> offset 11
        // if (arg0.isBlank() == 0) -> offset 12
        return;
        v2 = arg0.replaceAll("[^a-zA-Z0-9_-]", "");
        java.nio.file.Files.deleteIfExists(this.profilesDir.resolve(makeConcatWithConstants(v2)));
        v3 = /*?*/;
        return;
    }

    public void installPreset(com.viper.client.utils.ConfigManager.PresetProfile arg0, com.viper.client.core.ModuleManager arg1, com.viper.client.ui.ThemeManager arg2) {
        // if (arg0 != null) -> offset 5
        return;
        // if (arg0.userOwned() == 0) -> offset 136
        v4 = arg0.id().replaceAll("[^a-zA-Z0-9_-]", "");
        v5 = this.profilesDir.resolve(makeConcatWithConstants(v4));
        // if (java.nio.file.Files.exists(v5, new java.nio.file.LinkOption[0]) == 0) -> offset 136
        v6 = new java.util.Properties();
        v7 = java.nio.file.Files.newInputStream(v5, new java.nio.file.OpenOption[0]);
        v6.load(v7);
        this.applyProperties(v6, arg1, arg2);
        this.save(arg1, arg2);
        // if (v7 == null) -> offset 106
        v7.close();
        return;
        v8 = /*?*/;
        // if (v7 == null) -> offset 131
        v7.close();
        v9 = /*?*/;
        v8.addSuppressed(v9);
        throw v8;
        v7 = /*?*/;
        // if (arg0.theme() == null) -> offset 151
        arg2.setActiveTheme(arg0.theme());
        v4 = arg1.getModules().iterator();
        // if (v4.hasNext() == 0) -> offset 206
        v5 = ((com.viper.client.modules.Module) v4.next());
        v5.setEnabled(arg0.enabledModules().contains(v5.getId()));
        this.save(arg1, arg2);
        return;
    }

    public void load(com.viper.client.core.ModuleManager arg0, com.viper.client.ui.ThemeManager arg1) {
        v3 = new java.util.Properties();
        v4 = com.viper.client.utils.ConfigManager.class.getResourceAsStream("/drago-default.properties");
        // if (v4 == null) -> offset 29
        v3.load(v4);
        // if (v4 == null) -> offset 69
        v4.close();
        v5 = /*?*/;
        // if (v4 == null) -> offset 66
        v4.close();
        v6 = /*?*/;
        v5.addSuppressed(v6);
        throw v5;
        v4 = /*?*/;
        // if (java.nio.file.Files.exists(this.configFile, new java.nio.file.LinkOption[0]) == 0) -> offset 152
        v4 = java.nio.file.Files.newInputStream(this.configFile, new java.nio.file.OpenOption[0]);
        v3.load(v4);
        // if (v4 == null) -> offset 147
        v4.close();
        v5 = /*?*/;
        // if (v4 == null) -> offset 144
        v4.close();
        v6 = /*?*/;
        v5.addSuppressed(v6);
        throw v5;
        v4 = /*?*/;
        // if (v3.isEmpty() != 0) -> offset 166
        this.applyProperties(v3, arg0, arg1);
        return;
    }

    public void applyProperties(java.util.Properties arg0, com.viper.client.core.ModuleManager arg1, com.viper.client.ui.ThemeManager arg2) {
        v4 = arg0.getProperty("ui.uiScale");
        // if (v4 == null) -> offset 31
        arg2.setUiScale(Double.parseDouble(v4.trim()));
        v5 = /*?*/;
        v5 = arg0.getProperty("ui.customFontEnabled");
        // if (v5 == null) -> offset 57
        arg2.setCustomFontEnabled(Boolean.parseBoolean(v5.trim()));
        v6 = arg0.getProperty("ui.darkMode");
        // if (v6 == null) -> offset 83
        arg2.setDarkMode(Boolean.parseBoolean(v6.trim()));
        v7 = arg0.getProperty("ui.theme");
        // if (v7 == null) -> offset 102
        arg2.setActiveThemeById(v7);
        v8 = arg0.getProperty("ui.hudEnabled");
        // if (v8 == null) -> offset 128
        arg2.setHudEnabled(Boolean.parseBoolean(v8.trim()));
        v9 = arg0.getProperty("ui.watermarkEnabled");
        // if (v9 == null) -> offset 154
        arg2.setWatermarkEnabled(Boolean.parseBoolean(v9.trim()));
        v10 = arg0.getProperty("ui.arrayListEnabled");
        // if (v10 == null) -> offset 180
        arg2.setArrayListEnabled(Boolean.parseBoolean(v10.trim()));
        v11 = arg0.getProperty("ui.menuBlurEnabled");
        // if (v11 == null) -> offset 206
        arg2.setMenuBlurEnabled(Boolean.parseBoolean(v11.trim()));
        java.util.Objects.requireNonNull(arg2);
        this.parseOptionalInt(arg0.getProperty("ui.openGuiKey"), accept(arg2));
        java.util.Objects.requireNonNull(arg2);
        this.parseOptionalInt(arg0.getProperty("ui.watermarkX"), accept(arg2));
        java.util.Objects.requireNonNull(arg2);
        this.parseOptionalInt(arg0.getProperty("ui.watermarkY"), accept(arg2));
        java.util.Objects.requireNonNull(arg2);
        this.parseOptionalInt(arg0.getProperty("ui.arrayListX"), accept(arg2));
        java.util.Objects.requireNonNull(arg2);
        this.parseOptionalInt(arg0.getProperty("ui.arrayListY"), accept(arg2));
        v12 = arg1.getModules().iterator();
        // if (v12.hasNext() == 0) -> offset 489
        v13 = ((com.viper.client.modules.Module) v12.next());
        v14 = makeConcatWithConstants(v13.getId());
        v15 = arg0.getProperty(makeConcatWithConstants(v14));
        // if (v15 == null) -> offset 392
        v13.setEnabled(Boolean.parseBoolean(v15.trim()));
        java.util.Objects.requireNonNull(v13);
        this.parseOptionalInt(arg0.getProperty(makeConcatWithConstants(v14)), accept(v13));
        v16 = v13.getSettings().iterator();
        // if (v16.hasNext() == 0) -> offset 486
        v17 = ((com.viper.client.modules.Setting) v16.next());
        v18 = arg0.getProperty(makeConcatWithConstants(v14, v17.getId()));
        // if (v18 == null) -> offset 483
        v17.deserialize(v18);
        return;
    }

    private void parseOptionalInt(String arg0, java.util.function.IntConsumer arg1) {
        // if (arg0 != null) -> offset 5
        return;
        arg1.accept(Integer.parseInt(arg0.trim()));
        v3 = /*?*/;
        return;
    }

    public java.util.Properties toProperties(com.viper.client.core.ModuleManager arg0, com.viper.client.ui.ThemeManager arg1) {
        v3 = new java.util.Properties();
        v3.setProperty("ui.uiScale", Double.toString(arg1.getUiScale()));
        v3.setProperty("ui.customFontEnabled", Boolean.toString(arg1.isCustomFontEnabled()));
        v3.setProperty("ui.darkMode", Boolean.toString(arg1.isDarkMode()));
        v3.setProperty("ui.theme", arg1.getActiveTheme().getId());
        v3.setProperty("ui.watermarkEnabled", Boolean.toString(arg1.isWatermarkEnabled()));
        v3.setProperty("ui.arrayListEnabled", Boolean.toString(arg1.isArrayListEnabled()));
        v3.setProperty("ui.menuBlurEnabled", Boolean.toString(arg1.isMenuBlurEnabled()));
        v3.setProperty("ui.openGuiKey", Integer.toString(arg1.getOpenGuiKeyCode()));
        v3.setProperty("ui.watermarkX", Integer.toString(arg1.getWatermarkX()));
        v3.setProperty("ui.watermarkY", Integer.toString(arg1.getWatermarkY()));
        v3.setProperty("ui.arrayListX", Integer.toString(arg1.getArrayListX()));
        v3.setProperty("ui.arrayListY", Integer.toString(arg1.getArrayListY()));
        v4 = arg0.getModules().iterator();
        // if (v4.hasNext() == 0) -> offset 334
        v5 = ((com.viper.client.modules.Module) v4.next());
        v6 = makeConcatWithConstants(v5.getId());
        v3.setProperty(makeConcatWithConstants(v6), Boolean.toString(v5.isEnabled()));
        v3.setProperty(makeConcatWithConstants(v6), Integer.toString(v5.getKeyCode()));
        v7 = v5.getSettings().iterator();
        // if (v7.hasNext() == 0) -> offset 331
        v8 = ((com.viper.client.modules.Setting) v7.next());
        v3.setProperty(makeConcatWithConstants(v6, v8.getId()), v8.serialize());
        return v3;
    }

    public void save(com.viper.client.core.ModuleManager arg0, com.viper.client.ui.ThemeManager arg1) {
        java.nio.file.Files.createDirectories(this.configFile.getParent(), new java.nio.file.attribute.FileAttribute[0]);
        v3 = this.toProperties(arg0, arg1);
        v4 = java.nio.file.Files.newOutputStream(this.configFile, new java.nio.file.OpenOption[0]);
        v3.store(v4, "DRAGO Client 1.21.11 Configuration");
        // if (v4 == null) -> offset 86
        v4.close();
        v5 = /*?*/;
        // if (v4 == null) -> offset 83
        v4.close();
        v6 = /*?*/;
        v5.addSuppressed(v6);
        throw v5;
        v3 = /*?*/;
        return;
    }

    public final class PresetProfile extends java.lang.Record {
        private final String id;
        private final String name;
        private final String description;
        private final String category;
        private final String author;
        private final int votes;
        private final boolean userOwned;
        private final com.viper.client.ui.ThemeManager.ThemePreset theme;
        private final java.util.Set enabledModules;

        public PresetProfile(String arg0, String arg1, String arg2, String arg3, String arg4, int arg5, boolean arg6, com.viper.client.ui.ThemeManager.ThemePreset arg7, java.util.Set arg8) {
            super();
            this.id = arg0;
            this.name = arg1;
            this.description = arg2;
            this.category = arg3;
            this.author = arg4;
            this.votes = arg5;
            this.userOwned = arg6;
            this.theme = arg7;
            this.enabledModules = arg8;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public String id() {
            return this.id;
        }

        public String name() {
            return this.name;
        }

        public String description() {
            return this.description;
        }

        public String category() {
            return this.category;
        }

        public String author() {
            return this.author;
        }

        public int votes() {
            return this.votes;
        }

        public boolean userOwned() {
            return this.userOwned;
        }

        public com.viper.client.ui.ThemeManager.ThemePreset theme() {
            return this.theme;
        }

        public java.util.Set enabledModules() {
            return this.enabledModules;
        }

    }

}
