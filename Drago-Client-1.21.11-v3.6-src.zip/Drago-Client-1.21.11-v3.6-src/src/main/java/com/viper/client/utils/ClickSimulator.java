package com.viper.client.utils;

public final class ClickSimulator {
    private static int internalAttackDepth;
    private static int simulateDepth;
    private static final boolean[] simulateStack;

    private ClickSimulator() {
        super();
        return;
    }

    public static void beginInternalAttack() {
        com.viper.client.utils.ClickSimulator.internalAttackDepth = (com.viper.client.utils.ClickSimulator.internalAttackDepth + 1);
        return;
    }

    public static void endInternalAttack() {
        com.viper.client.utils.ClickSimulator.internalAttackDepth = Math.max(0, (com.viper.client.utils.ClickSimulator.internalAttackDepth - 1));
        return;
    }

    public static boolean isInternalAttack() {
        // if (com.viper.client.utils.ClickSimulator.internalAttackDepth <= 0) -> offset 8
        return true;
        return false;
    }

    public static void pushSimulate(boolean arg0) {
        v1 = com.viper.client.utils.ClickSimulator.simulateDepth;
        // if (v1 >= 16) -> offset 16
        com.viper.client.utils.ClickSimulator.simulateStack[v1] = arg0;
        com.viper.client.utils.ClickSimulator.simulateDepth = (v1 + 1);
        return;
    }

    public static void popSimulate() {
        com.viper.client.utils.ClickSimulator.simulateDepth = Math.max(0, (com.viper.client.utils.ClickSimulator.simulateDepth - 1));
        return;
    }

    public static boolean isSimulateActive() {
        v0 = com.viper.client.utils.ClickSimulator.simulateDepth;
        // if (v0 <= 0) -> offset 24
        v1 = (v0 - 1);
        // if (v1 >= 16) -> offset 24
        return com.viper.client.utils.ClickSimulator.simulateStack[v1];
        return false;
    }

    public static void pulseAttackKey(net.minecraft.class_310 arg0, boolean arg1) {
        // if (arg0 == null) -> offset 32
        // if (arg0.field_1690 == null) -> offset 32
        // if (arg0.field_1690.field_1886 == null) -> offset 32
        arg0.field_1690.field_1886.method_23481(arg1);
        return;
    }

    public static void pulseUseKey(net.minecraft.class_310 arg0, boolean arg1) {
        // if (arg0 == null) -> offset 32
        // if (arg0.field_1690 == null) -> offset 32
        // if (arg0.field_1690.field_1904 == null) -> offset 32
        arg0.field_1690.field_1904.method_23481(arg1);
        return;
    }

    public static void attackEntity(net.minecraft.class_636 arg0, net.minecraft.class_1657 arg1, net.minecraft.class_1297 arg2) {
        v3 = net.minecraft.class_310.method_1551();
        v4 = com.viper.client.utils.ClickSimulator.isSimulateActive();
        com.viper.client.utils.ClickSimulator.beginInternalAttack();
        // if (v4 == 0) -> offset 22
        com.viper.client.utils.ClickSimulator.pulseAttackKey(v3, 1);
        arg0.method_2918(arg1, arg2);
        // if (v4 == 0) -> offset 38
        com.viper.client.utils.ClickSimulator.pulseAttackKey(v3, 0);
        com.viper.client.utils.ClickSimulator.endInternalAttack();
        return;
        v5 = /*?*/;
        // if (v4 == 0) -> offset 54
        com.viper.client.utils.ClickSimulator.pulseAttackKey(v3, 0);
        com.viper.client.utils.ClickSimulator.endInternalAttack();
        throw v5;
    }

    public static net.minecraft.class_1269 interactBlock(net.minecraft.class_636 arg0, net.minecraft.class_746 arg1, net.minecraft.class_1268 arg2, net.minecraft.class_3965 arg3) {
        v4 = net.minecraft.class_310.method_1551();
        v5 = com.viper.client.utils.ClickSimulator.isSimulateActive();
        // if (v5 == 0) -> offset 26
        // if (v4 == null) -> offset 26
        com.viper.client.utils.ClickSimulator.pulseUseKey(v4, 1);
        v6 = arg0.method_2896(arg1, arg2, arg3);
        // if (v5 == 0) -> offset 46
        com.viper.client.utils.ClickSimulator.pulseUseKey(v4, 0);
        return v6;
        v7 = /*?*/;
        // if (v5 == 0) -> offset 62
        com.viper.client.utils.ClickSimulator.pulseUseKey(v4, 0);
        throw v7;
    }

    public static net.minecraft.class_1269 interactItem(net.minecraft.class_636 arg0, net.minecraft.class_1657 arg1, net.minecraft.class_1268 arg2) {
        v3 = net.minecraft.class_310.method_1551();
        v4 = com.viper.client.utils.ClickSimulator.isSimulateActive();
        // if (v4 == 0) -> offset 23
        // if (v3 == null) -> offset 23
        com.viper.client.utils.ClickSimulator.pulseUseKey(v3, 1);
        v5 = arg0.method_2919(arg1, arg2);
        // if (v4 == 0) -> offset 41
        com.viper.client.utils.ClickSimulator.pulseUseKey(v3, 0);
        return v5;
        v6 = /*?*/;
        // if (v4 == 0) -> offset 56
        com.viper.client.utils.ClickSimulator.pulseUseKey(v3, 0);
        throw v6;
    }

    public static void performRawClick(net.minecraft.class_310 arg0, boolean arg1, boolean arg2) {
        // if (arg0 == null) -> offset 84
        // if (arg0.field_1724 == null) -> offset 84
        // if ((arg0 instanceof com.viper.client.utils.ClickSimulator.ClientAccess) == 0) -> offset 84
        v3 = ((com.viper.client.utils.ClickSimulator.ClientAccess) arg0);
        // if (arg1 == 0) -> offset 59
        v3.viper$setItemUseCooldown(0);
        // if (arg2 == 0) -> offset 43
        com.viper.client.utils.ClickSimulator.pulseUseKey(arg0, 1);
        v3.viper$doItemUse();
        // if (arg2 == 0) -> offset 84
        com.viper.client.utils.ClickSimulator.pulseUseKey(arg0, 0);
        return;
        // if (arg2 == 0) -> offset 68
        com.viper.client.utils.ClickSimulator.pulseAttackKey(arg0, 1);
        v3.viper$doAttack();
        // if (arg2 == 0) -> offset 84
        com.viper.client.utils.ClickSimulator.pulseAttackKey(arg0, 0);
        return;
    }

    public static void performLeftClick(net.minecraft.class_310 arg0, net.minecraft.class_1297 arg1, boolean arg2) {
        // if (arg0 == null) -> offset 58
        // if (arg0.field_1724 == null) -> offset 58
        // if (arg0.field_1761 == null) -> offset 58
        // if (arg1 == null) -> offset 58
        com.viper.client.utils.ClickSimulator.pushSimulate(arg2);
        com.viper.client.utils.ClickSimulator.attackEntity(arg0.field_1761, arg0.field_1724, arg1);
        arg0.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        com.viper.client.utils.ClickSimulator.popSimulate();
        return;
        v3 = /*?*/;
        com.viper.client.utils.ClickSimulator.popSimulate();
        throw v3;
        return;
    }

    public interface ClientAccess {
        public boolean viper$doAttack();

        public void viper$doItemUse();

        public void viper$setItemUseCooldown(int arg0);

    }

}
