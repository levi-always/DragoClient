package com.viper.client.modules.hacks.combat;

public final class KeyPearl extends com.viper.client.modules.Module {
    private static final String OWNER_ID = "key_pearl";
    private static final int HOTBAR_PRIORITY = 45;
    public final com.viper.client.modules.Setting.KeybindSetting throwBind;
    public final com.viper.client.modules.Setting.NumberSetting delay;
    public final com.viper.client.modules.Setting.BooleanSetting switchBack;
    private boolean wasThrowKeyDown;
    private com.viper.client.modules.hacks.combat.KeyPearl.Phase phase;
    private int pearlSlot;
    private net.minecraft.class_1268 throwHand;
    private long nextActionAtMs;
    public final com.viper.client.modules.Setting.BooleanSetting simulateClick;

    public KeyPearl() {
        super("key_pearl", "KeyPearl", "Press Throw Bind to equip Ender Pearl, throw, and switch back.", com.viper.client.modules.Category.COMBAT, "key_pearl", -1);
        this.throwBind = ((com.viper.client.modules.Setting.KeybindSetting) this.registerSetting(new com.viper.client.modules.Setting.KeybindSetting("throw_bind", "Throw Bind", "Key to press while KeyPearl is ON to throw an Ender Pearl", -1)));
        this.delay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("delay", "Delay", "Delay between selecting pearl, throwing, and switching back (0-50ms)", 15.0, 0.0, 50.0, 1.0, "ms")));
        this.switchBack = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("switch_back", "Switch Back", "Automatically switch back to your previous hotbar item", 1)));
        this.wasThrowKeyDown = 0;
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE;
        this.pearlSlot = -1;
        this.throwHand = net.minecraft.class_1268.field_5808;
        this.nextActionAtMs = 0L;
        this.simulateClick = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left/Right click presses during module actions", 1)));
        return;
    }

    protected void onDisable() {
        this.wasThrowKeyDown = 0;
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE;
        this.pearlSlot = -1;
        com.viper.client.utils.HotbarCoordinator.releaseOwner("key_pearl", Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.delay.intValue());
    }

    private static boolean isEnderPearl(net.minecraft.class_1799 arg0) {
        // if (arg0 == null) -> offset 27
        // if (arg0.method_7960() != 0) -> offset 27
        // if ("minecraft:ender_pearl".equals(com.viper.client.utils.WeaponUtils.getItemId(arg0)) == 0) -> offset 27
        return false;
    }

    private static int findPearlHotbarSlot(net.minecraft.class_746 arg0) {
        v1 = 0;
        // if (v1 >= 9) -> offset 33
        // if (com.viper.client.modules.hacks.combat.KeyPearl.isEnderPearl(arg0.method_31548().method_5438(v1)) != 0) -> offset 25
        return v1;
        v1 += 1;
        return -1;
    }

    public static void pollRenderFrame() {
        v0 = com.viper.client.ViperClient.getInstance();
        // if (v0 != null) -> offset 9
        return;
        v1 = ((com.viper.client.modules.hacks.combat.KeyPearl) v0.getModuleManager().getModule(com.viper.client.modules.hacks.combat.KeyPearl.class));
        // if (v1 == null) -> offset 37
        // if (v1.isEnabled() == 0) -> offset 37
        v1.advanceSequence();
        v0 = /*?*/;
        return;
    }

    private void pollThrowBind(net.minecraft.class_310 arg0) {
        v2 = this.throwBind.getKeyCode();
        // if (v2 <= 0) -> offset 19
        // if (arg0.field_1755 == null) -> offset 25
        this.wasThrowKeyDown = 0;
        return;
        // if (arg0.method_22683() == null) -> offset 42
        v3 = org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        // if (Double.compare(v3, 0L) == 0) -> offset 65
        // if (org.lwjgl.glfw.GLFW.glfwGetKey(v3, v2) != 1) -> offset 65
        v5 = 0;
        // if (v5 == 0) -> offset 84
        // if (this.wasThrowKeyDown != 0) -> offset 84
        v6 = 0;
        this.wasThrowKeyDown = v5;
        // if (v6 == 0) -> offset 237
        // if (this.phase != com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE) -> offset 237
        v7 = arg0.field_1724;
        // if (com.viper.client.modules.hacks.combat.KeyPearl.isEnderPearl(v7.method_6079()) == 0) -> offset 151
        // if (com.viper.client.modules.hacks.combat.KeyPearl.isEnderPearl(v7.method_6047()) != 0) -> offset 151
        this.pearlSlot = -1;
        this.throwHand = net.minecraft.class_1268.field_5810;
        v8 = com.viper.client.modules.hacks.combat.KeyPearl.findPearlHotbarSlot(v7);
        // if (v8 >= 0) -> offset 164
        return;
        this.pearlSlot = v8;
        this.throwHand = net.minecraft.class_1268.field_5808;
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("key_pearl", 45, v8, Boolean.TRUE.equals(this.switchBack.getValue())) != 0) -> offset 203
        return;
        v8 = Math.max(0L, this.delay.longValue());
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.WAIT_THROW;
        this.nextActionAtMs = (System.currentTimeMillis() + v8);
        this.advanceSequence();
        return;
    }

    private void advanceSequence$viperImpl() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 22
        // if (v1.field_1724 == null) -> offset 22
        // if (v1.field_1761 != null) -> offset 23
        return;
        // if (this.phase != com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE) -> offset 34
        return;
        // if (v1.field_1755 == null) -> offset 67
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE;
        com.viper.client.utils.HotbarCoordinator.releaseOwner("key_pearl", Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        v2 = System.currentTimeMillis();
        // if (Double.compare(v2, this.nextActionAtMs) >= 0) -> offset 81
        return;
        v4 = v1.field_1724;
        // if (this.phase != com.viper.client.modules.hacks.combat.KeyPearl.Phase.WAIT_THROW) -> offset 339
        // if (this.throwHand != net.minecraft.class_1268.field_5808) -> offset 211
        // if (this.pearlSlot < 0) -> offset 141
        // if (com.viper.client.utils.HotbarCoordinator.selectSlotInSequence("key_pearl", 45, this.pearlSlot, Boolean.TRUE.equals(this.switchBack.getValue())) != 0) -> offset 167
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE;
        com.viper.client.utils.HotbarCoordinator.releaseOwner("key_pearl", Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        v1.field_1761.method_2911();
        // if (com.viper.client.modules.hacks.combat.KeyPearl.isEnderPearl(v4.method_6047()) != 0) -> offset 211
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE;
        com.viper.client.utils.HotbarCoordinator.releaseOwner("key_pearl", Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        v5 = com.viper.client.utils.ClickSimulator.interactItem(v1.field_1761, v4, this.throwHand);
        // if (com.viper.client.utils.ClickSimulator.interactItem(v1.field_1761, v4, this.throwHand) == null) -> offset 249
        // if (v5.method_23665() == 0) -> offset 249
        v4.method_6104(this.throwHand);
        // if (this.throwHand == net.minecraft.class_1268.field_5810) -> offset 275
        // if (Boolean.TRUE.equals(this.switchBack.getValue()) != 0) -> offset 289
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE;
        com.viper.client.utils.HotbarCoordinator.releaseOwner("key_pearl", 0);
        return;
        v6 = Math.max(0L, this.delay.longValue());
        // if (Double.compare(v6, 0L) != 0) -> offset 323
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE;
        com.viper.client.utils.HotbarCoordinator.releaseOwner("key_pearl", 1);
        return;
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.WAIT_RESTORE;
        this.nextActionAtMs = (v2 + v6);
        return;
        // if (this.phase != com.viper.client.modules.hacks.combat.KeyPearl.Phase.WAIT_RESTORE) -> offset 374
        this.phase = com.viper.client.modules.hacks.combat.KeyPearl.Phase.IDLE;
        com.viper.client.utils.HotbarCoordinator.releaseOwner("key_pearl", Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
    }

    public void onTick() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 29
        // if (v1.field_1724 == null) -> offset 29
        // if (v1.field_1687 == null) -> offset 29
        // if (v1.field_1761 != null) -> offset 30
        return;
        this.pollThrowBind(v1);
        this.advanceSequence();
        return;
    }

    public boolean isSimulateClick() {
        return ((java.lang.Boolean) this.simulateClick.getValue()).booleanValue();
    }

    public void advanceSequence() {
        com.viper.client.utils.ClickSimulator.pushSimulate(this.isSimulateClick());
        this.advanceSequence$viperImpl();
        com.viper.client.utils.ClickSimulator.popSimulate();
        v1 = /*?*/;
        com.viper.client.utils.ClickSimulator.popSimulate();
        throw v1;
        return;
    }

     enum Phase {
        IDLE, WAIT_THROW, WAIT_RESTORE;


    }

}
