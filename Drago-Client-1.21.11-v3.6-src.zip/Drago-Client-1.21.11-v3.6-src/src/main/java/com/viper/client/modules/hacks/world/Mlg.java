package com.viper.client.modules.hacks.world;

public final class Mlg extends com.viper.client.modules.Module {
    private static final String OWNER_ID = "Mlg";
    private static final int HOTBAR_PRIORITY = 38;
    private static final int ROTATION_PRIORITY = 4;
    public final com.viper.client.modules.Setting.ModeSetting itemMode;
    public final com.viper.client.modules.Setting.ModeSetting rotationMode;
    public final com.viper.client.modules.Setting.NumberSetting minFallDist;
    public final com.viper.client.modules.Setting.NumberSetting triggerHeight;
    public final com.viper.client.modules.Setting.NumberSetting smoothness;
    public final com.viper.client.modules.Setting.BooleanSetting pickUpWater;
    public final com.viper.client.modules.Setting.BooleanSetting switchBack;
    public final com.viper.client.modules.Setting.BooleanSetting simulateClick;
    private boolean placedThisFall;
    private boolean waitingPickup;
    private long pickupReadyAtMs;
    private net.minecraft.class_2338 placedTargetPos;
    private long cooldownUntilMs;

    public Mlg() {
        super("mlg", "MLG", "Automatically prepares Water or Cobweb and clutches falls.", com.viper.client.modules.Category.WORLD, "mlg", -1);
        new java.lang.String[3][0] = "Water";
        new java.lang.String[3][1] = "Cobweb";
        new java.lang.String[3][2] = "Auto";
        this.itemMode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("item_mode", "Item Mode", "Clutch item to equip and place before hitting ground", "Water", new java.lang.String[3])));
        new java.lang.String[2][0] = "Silent";
        new java.lang.String[2][1] = "Legit";
        this.rotationMode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("rotation_mode", "Rotation Mode", "Silent aim or visible Legit rotation downward", "Silent", new java.lang.String[2])));
        this.minFallDist = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("min_fall", "Min Fall Dist", "Minimum fall distance before preparing MLG clutch", 4.0, 2.0, 16.0, 0.5, "m")));
        this.triggerHeight = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("trigger_height", "Place Height", "Height above ground to execute water/cobweb placement", 3.1, 1.5, 5.5, 0.1, "m")));
        this.smoothness = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("smoothness", "Smoothness", "Rotation speed looking down at landing block", 84.0, 20.0, 100.0, 1.0, "%")));
        this.pickUpWater = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(((com.viper.client.modules.Setting.BooleanSetting) new com.viper.client.modules.Setting.BooleanSetting("pickup_water", "Pick Up Water", "Automatically scoop placed water cleanly after landing", 1).visibleWhen(getAsBoolean(this)))));
        this.switchBack = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("switch_back", "Switch Back", "Restore previous hotbar slot after clutch finishes", 1)));
        this.simulateClick = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left/Right click presses during module actions", 1)));
        this.placedThisFall = 0;
        this.waitingPickup = 0;
        this.pickupReadyAtMs = 0L;
        this.placedTargetPos = null;
        this.cooldownUntilMs = 0L;
        return;
    }

    protected void onDisable() {
        this.resetState(1);
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(((java.lang.String) this.itemMode.getValue()), ((java.lang.String) this.rotationMode.getValue()));
    }

    private void resetState(boolean arg0) {
        this.placedThisFall = 0;
        this.waitingPickup = 0;
        this.pickupReadyAtMs = 0L;
        this.placedTargetPos = null;
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        // if (arg0 == 0) -> offset 50
        com.viper.client.utils.HotbarCoordinator.releaseOwner("Mlg", Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
    }

    private int findMlgSlot(net.minecraft.class_746 arg0) {
        // if (this.itemMode.is("Water") != 0) -> offset 24
        // if (this.itemMode.is("Auto") == 0) -> offset 28
        v2 = 0;
        // if (this.itemMode.is("Cobweb") != 0) -> offset 54
        // if (this.itemMode.is("Auto") == 0) -> offset 58
        v3 = 0;
        // if (v2 == 0) -> offset 115
        v4 = 0;
        // if (v4 >= 9) -> offset 115
        v5 = arg0.method_31548().method_5438(v4);
        // if (v5.method_7960() != 0) -> offset 109
        // if ("minecraft:water_bucket".equals(com.viper.client.utils.WeaponUtils.getItemId(v5)) == 0) -> offset 109
        return v4;
        v4 += 1;
        // if (v3 == 0) -> offset 124
        return com.viper.client.utils.WeaponUtils.findCobwebHotbarSlot(arg0);
        return -1;
    }

    private static boolean isWaterBucket(net.minecraft.class_1799 arg0) {
        // if (arg0 == null) -> offset 27
        // if (arg0.method_7960() != 0) -> offset 27
        // if ("minecraft:water_bucket".equals(com.viper.client.utils.WeaponUtils.getItemId(arg0)) == 0) -> offset 27
        return false;
    }

    private static net.minecraft.class_2338 findSolidGroundBelow(net.minecraft.class_638 arg0, double arg1, double arg2, double arg3, int arg4) {
        v8 = (int)Math.floor(arg1);
        v9 = (int)Math.floor((arg2 - 0.05));
        v10 = (int)Math.floor(arg3);
        v11 = 0;
        // if (v11 > arg4) -> offset 90
        v12 = new net.minecraft.class_2338(v8, (v9 - v11), v10);
        v13 = arg0.method_8320(v12);
        // if (v13 == null) -> offset 84
        // if (v13.method_26220(arg0, v12).method_1110() != 0) -> offset 84
        return v12;
        v11 += 1;
        return null;
    }

    private float[] aimAtPoint(net.minecraft.class_746 arg0, double arg1, double arg2, double arg3) {
        v8 = arg0.method_33571();
        v9 = com.viper.client.utils.RotationUtils.computeRotations(v8.field_1352, v8.field_1351, v8.field_1350, arg1, arg2, arg3);
        // if (this.rotationMode.is("Silent") == 0) -> offset 74
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        com.viper.client.utils.RotationUtils.driveSilentRotationCapped(arg0, v9[0], v9[1], this.smoothness.floatValue(), 64.0f, 0, 4);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        com.viper.client.utils.RotationUtils.driveCameraPoint(arg0, arg1, arg2, arg3, this.smoothness.floatValue(), 1, 4);
        return v9;
    }

    private void onTick$viperImpl() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 29
        // if (v1.field_1724 == null) -> offset 29
        // if (v1.field_1687 == null) -> offset 29
        // if (v1.field_1761 != null) -> offset 30
        return;
        // if (v1.field_1755 == null) -> offset 43
        this.resetState(0);
        return;
        v2 = v1.field_1724;
        v3 = v1.field_1687;
        v4 = System.currentTimeMillis();
        // if (this.waitingPickup == 0) -> offset 492
        // if (Double.compare(v4, this.pickupReadyAtMs) < 0) -> offset 491
        // if (this.placedTargetPos == null) -> offset 491
        v6 = com.viper.client.utils.WeaponUtils.findEmptyBucketHotbarSlot(v2);
        // if (v6 < 0) -> offset 437
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("Mlg", 38, v6, Boolean.TRUE.equals(this.switchBack.getValue())) == 0) -> offset 437
        v1.field_1761.method_2911();
        v7 = ((double)this.placedTargetPos.method_10263() + 0.5);
        v9 = ((double)this.placedTargetPos.method_10264() + 1.0);
        v11 = ((double)this.placedTargetPos.method_10260() + 0.5);
        v13 = this.aimAtPoint(v2, v7, v9, v11);
        // if (this.rotationMode.is("Silent") == 0) -> offset 202
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 202
        v14 = v2.method_36455();
        // if (com.viper.client.utils.WeaponUtils.isEmptyBucket(v2.method_6047()) == 0) -> offset 434
        // if (Double.compare(v14, 56.0f) >= 0) -> offset 241
        // if (Double.compare((v4 - this.pickupReadyAtMs), 120L) <= 0) -> offset 434
        // if (this.rotationMode.is("Silent") == 0) -> offset 311
        // if (v2.field_3944 == null) -> offset 311
        v2.field_3944.method_52787(new net.minecraft.class_2828.class_2831(v13[0], Math.max(v13[1], v14), v2.method_24828(), v2.field_5976));
        com.viper.client.utils.RotationUtils.recordPacketConfirmedAngles(v13[0], Math.max(v13[1], v14));
        v15 = com.viper.client.utils.ClickSimulator.interactItem(v1.field_1761, v2, net.minecraft.class_1268.field_5808);
        // if (v15 == null) -> offset 339
        // if (v15.method_23665() != 0) -> offset 384
        v16 = new net.minecraft.class_3965(new net.minecraft.class_243(v7, v9, v11), net.minecraft.class_2350.field_11036, this.placedTargetPos, 0);
        v15 = com.viper.client.utils.ClickSimulator.interactBlock(v1.field_1761, v2, net.minecraft.class_1268.field_5808, v16);
        // if (v15 == null) -> offset 406
        // if (v15.method_23665() == 0) -> offset 406
        v2.method_6104(net.minecraft.class_1268.field_5808);
        this.cooldownUntilMs = (v4 + 260L);
        this.resetState(Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        // if (v6 >= 0) -> offset 460
        this.resetState(Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        // if (Double.compare((v4 - this.pickupReadyAtMs), 700L) <= 0) -> offset 491
        this.resetState(Boolean.TRUE.equals(this.switchBack.getValue()));
        return;
        // if (v2.method_24828() != 0) -> offset 520
        // if (v2.method_5799() != 0) -> offset 520
        // if (v2.method_5771() != 0) -> offset 520
        // if (v2.method_6128() == 0) -> offset 608
        // if (this.placedThisFall == 0) -> offset 573
        // if (Boolean.TRUE.equals(this.pickUpWater.getValue()) == 0) -> offset 573
        // if (this.placedTargetPos == null) -> offset 573
        // if (v2.method_5799() == 0) -> offset 573
        this.waitingPickup = 1;
        this.pickupReadyAtMs = (v4 + 180L);
        return;
        // if (this.placedThisFall != 0) -> offset 591
        // if ("Mlg".equals(com.viper.client.utils.HotbarCoordinator.getActiveOwner()) == 0) -> offset 599
        this.resetState(1);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        return;
        // if (Double.compare(v4, this.cooldownUntilMs) < 0) -> offset 625
        // if (this.placedThisFall == 0) -> offset 626
        return;
        v6 = v2.method_18798().field_1351;
        // if (Double.compare(v6, -0.14) >= 0) -> offset 659
        // if (Double.compare(v2.field_6017, this.minFallDist.doubleValue()) >= 0) -> offset 660
        return;
        v8 = Math.max(10, ((int)Math.ceil(((-v6) * 5.0)) + 6));
        v9 = com.viper.client.modules.hacks.world.Mlg.findSolidGroundBelow(v3, v2.method_23317(), v2.method_23318(), v2.method_23321(), v8);
        // if (v9 != null) -> offset 707
        return;
        v10 = (v2.method_23318() - ((double)v9.method_10264() + 1.0));
        v12 = this.triggerHeight.doubleValue();
        v14 = Math.max((v12 + 2.8), (((-v6) * 4.0) + 1.5));
        // if (Double.compare(v10, 0.05) < 0) -> offset 770
        // if (Double.compare(v10, v14) <= 0) -> offset 771
        return;
        v16 = this.findMlgSlot(v2);
        // if (v16 >= 0) -> offset 784
        return;
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("Mlg", 38, v16, Boolean.TRUE.equals(this.switchBack.getValue())) != 0) -> offset 810
        return;
        v1.field_1761.method_2911();
        v17 = java.util.concurrent.ThreadLocalRandom.current();
        v18 = (((double)v9.method_10263() + 0.5) + ((v17.nextDouble() - 0.5) * 0.12));
        v20 = ((double)v9.method_10264() + 1.0);
        v22 = (((double)v9.method_10260() + 0.5) + ((v17.nextDouble() - 0.5) * 0.12));
        v24 = this.aimAtPoint(v2, v18, v20, v22);
        v25 = (v10 + v6);
        // if (Double.compare(v10, v12) <= 0) -> offset 921
        // if (Double.compare(v25, 0.45) > 0) -> offset 925
        v27 = 0;
        // if (v27 == 0) -> offset 1304
        // if (v2.method_31548().method_67532() != v16) -> offset 1304
        // if (this.rotationMode.is("Silent") == 0) -> offset 969
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 969
        v28 = v2.method_36455();
        // if (Double.compare(v25, 0.65) > 0) -> offset 988
        v29 = 0;
        // if (Double.compare(v28, 60.0f) >= 0) -> offset 1014
        // if (v29 == 0) -> offset 1304
        // if (Double.compare(v28, 48.0f) < 0) -> offset 1304
        v30 = v2.method_6047();
        v31 = com.viper.client.modules.hacks.world.Mlg.isWaterBucket(v30);
        v32 = com.viper.client.utils.WeaponUtils.isCobweb(v30);
        // if (v31 != 0) -> offset 1044
        // if (v32 == 0) -> offset 1304
        // if (this.rotationMode.is("Silent") == 0) -> offset 1114
        // if (v2.field_3944 == null) -> offset 1114
        v2.field_3944.method_52787(new net.minecraft.class_2828.class_2831(v24[0], Math.max(v28, v24[1]), v2.method_24828(), v2.field_5976));
        com.viper.client.utils.RotationUtils.recordPacketConfirmedAngles(v24[0], Math.max(v28, v24[1]));
        v33 = new net.minecraft.class_3965(new net.minecraft.class_243(v18, v20, v22), net.minecraft.class_2350.field_11036, v9, 0);
        v34 = com.viper.client.utils.ClickSimulator.interactBlock(v1.field_1761, v2, net.minecraft.class_1268.field_5808, v33);
        // if (v34 == null) -> offset 1172
        // if (v34.method_23665() != 0) -> offset 1190
        // if (v31 == 0) -> offset 1190
        v34 = com.viper.client.utils.ClickSimulator.interactItem(v1.field_1761, v2, net.minecraft.class_1268.field_5808);
        // if (v34 == null) -> offset 1304
        // if (v34.method_23665() == 0) -> offset 1304
        v2.method_6104(net.minecraft.class_1268.field_5808);
        this.placedThisFall = 1;
        this.placedTargetPos = v9;
        // if (v31 == 0) -> offset 1262
        // if (Boolean.TRUE.equals(this.pickUpWater.getValue()) == 0) -> offset 1262
        this.waitingPickup = 1;
        this.pickupReadyAtMs = (v4 + 240L);
        this.cooldownUntilMs = (v4 + 260L);
        // if (Boolean.TRUE.equals(this.switchBack.getValue()) == 0) -> offset 1296
        com.viper.client.utils.HotbarCoordinator.queueRestoreOrReleaseMs("Mlg", 150L);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        v1 = 1;
        return;
    }

    public boolean isSimulateClick() {
        return Boolean.TRUE.equals(this.simulateClick.getValue());
    }

    public void onTick() {
        com.viper.client.utils.ClickSimulator.pushSimulate(this.isSimulateClick());
        this.onTick$viperImpl();
        com.viper.client.utils.ClickSimulator.popSimulate();
        v1 = /*?*/;
        com.viper.client.utils.ClickSimulator.popSimulate();
        throw v1;
        return;
    }

}
