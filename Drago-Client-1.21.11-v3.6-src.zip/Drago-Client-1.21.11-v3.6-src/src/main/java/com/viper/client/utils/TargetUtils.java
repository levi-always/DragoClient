package com.viper.client.utils;

public final class TargetUtils {
    private TargetUtils() {
        super();
        return;
    }

    public static boolean matchesPlayersOnly(Object arg0, net.minecraft.class_746 arg1, boolean arg2) {
        // if ((arg0 instanceof net.minecraft.class_1297) == 0) -> offset 15
        v3 = ((net.minecraft.class_1297) arg0);
        return false;
        // if (arg2 == 0) -> offset 28
        return com.viper.client.utils.TargetUtils.matchesTargetFilter(arg1, "Players", "All");
    }

    public static boolean matchesTargetFilter(net.minecraft.class_1297 arg0, net.minecraft.class_746 arg1, String arg2) {
        // if (arg0 == null) -> offset 23
        // if (arg0 == arg1) -> offset 23
        // if (arg0.method_5805() == 0) -> offset 23
        // if (arg0.method_7325() == 0) -> offset 25
        return false;
        // if ((arg0 instanceof net.minecraft.class_1531) == 0) -> offset 34
        return false;
        // if ((arg0 instanceof net.minecraft.class_1309) == 0) -> offset 62
        v3 = ((net.minecraft.class_1309) arg0);
        // if (v3.method_29504() != 0) -> offset 62
        // if (Double.compare(v3.method_6032(), 0.0f) > 0) -> offset 64
        return false;
        // if ((arg0 instanceof net.minecraft.class_1657) == 0) -> offset 111
        v4 = ((net.minecraft.class_1657) arg0);
        // if (v4.method_7325() == 0) -> offset 87
        return false;
        // if ("Players".equalsIgnoreCase(arg2) != 0) -> offset 105
        // if ("All".equalsIgnoreCase(arg2) == 0) -> offset 109
        return false;
        // if ("Mobs".equalsIgnoreCase(arg2) != 0) -> offset 129
        // if ("All".equalsIgnoreCase(arg2) == 0) -> offset 133
        return false;
    }

    public static double getClosestBoxDistance(net.minecraft.class_746 arg0, net.minecraft.class_1297 arg1) {
        v2 = arg0.method_33571();
        v3 = arg1.method_5829();
        v4 = Math.max(v3.field_1323, Math.min(v2.field_1352, v3.field_1320));
        v6 = Math.max(v3.field_1322, Math.min(v2.field_1351, v3.field_1325));
        v8 = Math.max(v3.field_1321, Math.min(v2.field_1350, v3.field_1324));
        v10 = (v2.field_1352 - v4);
        v12 = (v2.field_1351 - v6);
        v14 = (v2.field_1350 - v8);
        return Math.sqrt((((v10 * v10) + (v12 * v12)) + (v14 * v14)));
    }

    public static net.minecraft.class_1309 findBestTarget(double arg0, float arg1, boolean arg2, String arg3) {
        // if (arg2 == 0) -> offset 11
        return com.viper.client.utils.TargetUtils.findBestTarget(arg1, "Players", "All", arg3);
    }

    public static net.minecraft.class_1309 findBestTarget(double arg0, float arg1, String arg2, String arg3) {
        v5 = net.minecraft.class_310.method_1551();
        // if (v5 == null) -> offset 26
        // if (v5.field_1724 == null) -> offset 26
        // if (v5.field_1687 != null) -> offset 28
        return null;
        v6 = v5.field_1724;
        v7 = new java.util.ArrayList();
        v8 = v5.field_1687.method_18112().iterator();
        // if (v8.hasNext() == 0) -> offset 149
        v9 = ((net.minecraft.class_1297) v8.next());
        // if (com.viper.client.utils.TargetUtils.matchesTargetFilter(v9, v6, arg2) != 0) -> offset 95
        v10 = com.viper.client.utils.TargetUtils.getClosestBoxDistance(v6, v9);
        // if (Double.compare(v10, arg0) <= 0) -> offset 114
        v12 = com.viper.client.utils.RotationUtils.getAngleToEntity(v6, v9);
        // if (Double.compare(v12, arg1) <= 0) -> offset 133
        v7.add(((net.minecraft.class_1309) v9));
        // if (v7.isEmpty() == 0) -> offset 161
        return null;
        // if (arg3 != null) -> offset 171
        v9 = arg3;
        v10 = -1;
        // if (v9.equals("Health") == 0) -> offset 237
        v10 = 0;
        // if (v9.equals("Crosshair") == 0) -> offset 237
        v10 = 1;
        v8 = java.util.Comparator.comparingDouble(applyAsDouble(v6));
        v7.sort(v8);
        return ((net.minecraft.class_1309) v7.get(0));
    }

}
