package com.viper.client.modules.hacks.combat;

public final class Silent {
    public static final int PRIORITY = 3;

    public Silent() {
        super();
        return;
    }

    public void engage(net.minecraft.class_746 arg0, net.minecraft.class_1309 arg1, float arg2) {
        // if (arg0 == null) -> offset 8
        // if (arg1 != null) -> offset 13
        this.release();
        return;
        com.viper.client.utils.RotationUtils.releaseCameraTarget(3);
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 29
        v4 = arg0.method_36454();
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 47
        v5 = arg0.method_36455();
        v6 = com.viper.client.utils.RotationUtils.getAimPointRotationsForCurrent(arg0, arg1, "Center", v4, v5);
        v7 = arg0.method_18798().method_1033();
        // if (Double.compare(v7, 0.55) <= 0) -> offset 98
        v9 = com.viper.client.utils.AnimUtils.clamp(arg2, 12.0f, 92.0f);
        // if (Double.compare(v7, 0.55) <= 0) -> offset 122
        v10 = 44.0f;
        com.viper.client.utils.RotationUtils.driveSilentRotationCapped(arg0, v6[0], v6[1], v9, v10, 1, 3);
        return;
    }

    public float getActiveYaw() {
        return com.viper.client.utils.RotationUtils.getServerYaw();
    }

    public float getActivePitch() {
        return com.viper.client.utils.RotationUtils.getServerPitch();
    }

    public void release() {
        com.viper.client.utils.RotationUtils.releaseSilentRotation(3);
        return;
    }

}
