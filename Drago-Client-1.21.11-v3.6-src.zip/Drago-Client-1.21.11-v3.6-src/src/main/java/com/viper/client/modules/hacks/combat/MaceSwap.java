package com.viper.client.modules.hacks.combat;

public final class MaceSwap extends com.viper.client.modules.Module {
    private static final String OWNER_ID = "mace_swap";
    public final com.viper.client.modules.Setting.NumberSetting delay;
    public final com.viper.client.modules.Setting.BooleanSetting switchBack;
    public final com.viper.client.modules.Setting.BooleanSetting playersOnly;
    public final com.viper.client.modules.Setting.BooleanSetting weaponsOnly;
    public final com.viper.client.modules.Setting.BooleanSetting simulateClick;

    public MaceSwap() {
        super("mace_swap", "MaceSwap", "Swaps to Mace on strike then restores.", com.viper.client.modules.Category.COMBAT, "mace_swap", -1);
        this.delay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("delay", "Delay", "Millisecond swap duration before restoring original slot (0ms = instant fast-swap)", 35.0, 0.0, 300.0, 5.0, "ms")));
        this.switchBack = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("switch_back", "Switch Back", "Return to your original hotbar slot after swapping to Mace", 1)));
        this.playersOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("players_only", "Players Only", "Only swap to Mace when attacking Players (OFF = Players & Animals/Mobs)", 1)));
        this.weaponsOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("weapons_only", "Weapons Only", "Only trigger MaceSwap while holding a weapon", 0)));
        this.simulateClick = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left/Right click presses during module actions", 1)));
        return;
    }

    protected void onDisable() {
        com.viper.client.utils.HotbarCoordinator.releaseOwner("mace_swap", 1);
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.delay.intValue());
    }

    public boolean executeSwap(int arg0, int arg1, net.minecraft.class_1799 arg2) {
        // if (this.isEnabled() == 0) -> offset 17
        // if (arg1 < 0) -> offset 17
        // if (arg1 < 9) -> offset 19
        return false;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 44
        // if (com.viper.client.utils.WeaponUtils.isWeaponStack(arg2) != 0) -> offset 44
        return false;
        // if (com.viper.client.utils.HotbarCoordinator.canAcquire("mace_swap", 30) != 0) -> offset 56
        return false;
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("mace_swap", 30, arg1, ((java.lang.Boolean) this.switchBack.getValue()).booleanValue()) != 0) -> offset 82
        return false;
        com.viper.client.utils.HotbarCoordinator.queueRestoreOrReleaseMs("mace_swap", this.delay.longValue());
        return true;
    }

    private void onAttackEntity$viperImpl(Object arg0) {
        // if (this.isEnabled() != 0) -> offset 8
        return;
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 23
        // if (v2.field_1724 != null) -> offset 24
        return;
        v3 = v2.field_1724;
        // if (com.viper.client.utils.TargetUtils.matchesPlayersOnly(arg0, v3, ((java.lang.Boolean) this.playersOnly.getValue()).booleanValue()) != 0) -> offset 51
        return;
        v4 = v3.method_31548().method_67532();
        v5 = com.viper.client.utils.WeaponUtils.findBestHotbarSlot(v3, "Mace", "Damage", Math.max(2.0, v3.field_6017));
        // if (v5 >= 0) -> offset 86
        return;
        this.executeSwap(v4, v5, v3.method_6047());
        return;
    }

    public boolean isSimulateClick() {
        return ((java.lang.Boolean) this.simulateClick.getValue()).booleanValue();
    }

    public void onAttackEntity(Object arg0) {
        // if (com.viper.client.utils.ClickSimulator.isInternalAttack() != 0) -> offset 41
        // if ("auto_mace".equals(com.viper.client.utils.HotbarCoordinator.getActiveOwner()) != 0) -> offset 41
        com.viper.client.utils.ClickSimulator.pushSimulate(this.isSimulateClick());
        this.onAttackEntity$viperImpl(arg0);
        com.viper.client.utils.ClickSimulator.popSimulate();
        v2 = /*?*/;
        com.viper.client.utils.ClickSimulator.popSimulate();
        throw v2;
        return;
    }

}
