package com.viper.client.modules;

public enum Category {
    COMBAT, RENDER, WORLD, INVENTORY;

    private final String displayName;
    private final String iconName;
    private final String description;

    public String getDisplayName() {
        return this.displayName;
    }

    public String getIconName() {
        return this.iconName;
    }

    public String getDescription() {
        return this.description;
    }

}
