package com.viper.client.ui.font;

public final class SmoothFontRenderer {
    public static final net.minecraft.class_2960 REGULAR_TEX;
    public static final net.minecraft.class_2960 BOLD_TEX;
    private static final int TEX_W = 1024;
    private static final int TEX_H = 512;
    private static final int CELL_W = 64;
    private static final int CELL_H = 80;
    private static final int COLS = 16;
    private static final float PAD_X = 8.0f;
    private static final float BASE_SCALE = 0.1720000058412552f;
    private static final int[] REGULAR_WIDTHS;
    private static final int[] BOLD_WIDTHS;
    private static boolean enabled;

    private SmoothFontRenderer() {
        super();
        return;
    }

    public static boolean isEnabled() {
        return com.viper.client.ui.font.SmoothFontRenderer.enabled;
    }

    public static void setEnabled(boolean arg0) {
        com.viper.client.ui.font.SmoothFontRenderer.enabled = arg0;
        return;
    }

    public static int getWidth(net.minecraft.class_327 arg0, String arg1) {
        return com.viper.client.ui.font.SmoothFontRenderer.getWidth(arg0, arg1, 0, 1.0f);
    }

    public static int getWidth(net.minecraft.class_327 arg0, String arg1, boolean arg2, float arg3) {
        // if (arg1 == null) -> offset 11
        // if (arg1.isEmpty() == 0) -> offset 13
        return 0;
        // if (com.viper.client.ui.font.SmoothFontRenderer.enabled != 0) -> offset 45
        // if (arg0 == null) -> offset 37
        return (arg1.length() * 6);
        // if (arg2 == 0) -> offset 55
        v4 = com.viper.client.ui.font.SmoothFontRenderer.REGULAR_WIDTHS;
        v5 = 0.0f;
        v6 = (0.1720000058412552f * arg3);
        v7 = 0;
        // if (v7 >= arg1.length()) -> offset 163
        v8 = arg1.charAt(v7);
        // if (v8 < 32) -> offset 123
        // if (v8 > 126) -> offset 123
        v5 = (v5 + ((float)v4[(v8 - 32)] * v6));
        // if (arg0 == null) -> offset 147
        v5 = (v5 + ((float)arg0.method_1727(String.valueOf(v8)) * arg3));
        v5 = (v5 + (22.0f * v6));
        v7 += 1;
        return Math.round(v5);
    }

    public static void drawText(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, String arg2, int arg3, int arg4, int arg5, boolean arg6, float arg7) {
        // if (arg0 == null) -> offset 28
        // if (arg2 == null) -> offset 28
        // if (arg2.isEmpty() != 0) -> offset 28
        // if (255 > 4) -> offset 29
        return;
        // if (com.viper.client.ui.font.SmoothFontRenderer.enabled != 0) -> offset 120
        // if (arg1 == null) -> offset 119
        // if (Double.compare(Math.abs((arg7 - 1.0f)), 0.009999999776482582f) >= 0) -> offset 67
        arg0.method_51433(arg1, arg2, arg3, arg4, arg5, 0);
        arg0.method_51448().pushMatrix();
        arg0.method_51448().translate((float)arg3, (float)arg4);
        arg0.method_51448().scale(arg7, arg7);
        arg0.method_51433(arg1, arg2, 0, 0, arg5, 0);
        arg0.method_51448().popMatrix();
        return;
        // if (arg6 == 0) -> offset 131
        v8 = com.viper.client.ui.font.SmoothFontRenderer.REGULAR_TEX;
        // if (arg6 == 0) -> offset 147
        v9 = com.viper.client.ui.font.SmoothFontRenderer.REGULAR_WIDTHS;
        v10 = (0.1720000058412552f * arg7);
        v11 = (float)arg3;
        v12 = (arg4 - Math.round((2.5f * arg7)));
        v13 = Math.max(1, Math.round((64.0f * v10)));
        v14 = Math.max(1, Math.round((80.0f * v10)));
        v15 = (8.0f * v10);
        v16 = 0;
        // if (v16 >= arg2.length()) -> offset 386
        v17 = arg2.charAt(v16);
        // if (v17 < 32) -> offset 337
        // if (v17 > 126) -> offset 337
        v18 = (v17 - 32);
        v19 = (v18 % 16);
        v20 = (v18 / 16);
        // if (v17 == 32) -> offset 320
        arg0.method_25293(net.minecraft.class_10799.field_56883, v8, Math.round((v11 - v15)), v12, (float)(v19 * 64), (float)(v20 * 80), v13, v14, 64, 80, 1024, 512, arg5);
        v11 = (v11 + ((float)v9[v18] * v10));
        // if (arg1 == null) -> offset 380
        v18 = String.valueOf(v17);
        arg0.method_51433(arg1, v18, Math.round(v11), arg4, arg5, 0);
        v11 = (v11 + ((float)arg1.method_1727(v18) * arg7));
        v16 += 1;
        return;
    }

    public static void drawGradientText(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, String arg2, int arg3, int arg4, int arg5, int arg6, boolean arg7, float arg8) {
        // if (arg0 == null) -> offset 28
        // if (arg2 == null) -> offset 28
        // if (arg2.isEmpty() != 0) -> offset 28
        // if (255 > 4) -> offset 29
        return;
        v9 = arg2.length();
        // if (v9 == 1) -> offset 48
        // if (arg5 != arg6) -> offset 64
        com.viper.client.ui.font.SmoothFontRenderer.drawText(arg0, arg1, arg2, arg3, arg4, arg5, arg7, arg8);
        return;
        // if (com.viper.client.ui.font.SmoothFontRenderer.enabled != 0) -> offset 148
        // if (arg1 == null) -> offset 148
        v10 = arg3;
        v11 = 0;
        // if (v11 >= v9) -> offset 147
        v12 = String.valueOf(arg2.charAt(v11));
        v13 = com.viper.client.utils.AnimUtils.lerpColor(arg5, arg6, ((float)v11 / (float)(v9 - 1)));
        arg0.method_51433(arg1, v12, v10, arg4, v13, 0);
        v10 = (v10 + arg1.method_1727(v12));
        v11 += 1;
        return;
        // if (arg7 == 0) -> offset 159
        v10 = com.viper.client.ui.font.SmoothFontRenderer.REGULAR_TEX;
        // if (arg7 == 0) -> offset 175
        v11 = com.viper.client.ui.font.SmoothFontRenderer.REGULAR_WIDTHS;
        v12 = (0.1720000058412552f * arg8);
        v13 = (float)arg3;
        v14 = (arg4 - Math.round((2.5f * arg8)));
        v15 = Math.max(1, Math.round((64.0f * v12)));
        v16 = Math.max(1, Math.round((80.0f * v12)));
        v17 = (8.0f * v12);
        v18 = 0;
        // if (v18 >= v9) -> offset 438
        v19 = arg2.charAt(v18);
        v20 = ((float)v18 / (float)Math.max(1, (v9 - 1)));
        v21 = com.viper.client.utils.AnimUtils.lerpColor(arg5, arg6, v20);
        // if (v19 < 32) -> offset 389
        // if (v19 > 126) -> offset 389
        v22 = (v19 - 32);
        v23 = (v22 % 16);
        v24 = (v22 / 16);
        // if (v19 == 32) -> offset 372
        arg0.method_25293(net.minecraft.class_10799.field_56883, v10, Math.round((v13 - v17)), v14, (float)(v23 * 64), (float)(v24 * 80), v15, v16, 64, 80, 1024, 512, v21);
        v13 = (v13 + ((float)v11[v22] * v12));
        // if (arg1 == null) -> offset 432
        v22 = String.valueOf(v19);
        arg0.method_51433(arg1, v22, Math.round(v13), arg4, v21, 0);
        v13 = (v13 + ((float)arg1.method_1727(v22) * arg8));
        v18 += 1;
        return;
    }

}
