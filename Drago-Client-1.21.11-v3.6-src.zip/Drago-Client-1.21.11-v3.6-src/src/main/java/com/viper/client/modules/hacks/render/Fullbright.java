package com.viper.client.modules.hacks.render;

public final class Fullbright extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.ModeSetting mode;
    private final com.viper.client.modules.Setting.NumberSetting strength;

    public Fullbright() {
        super("fullbright", "Fullbright", "Illuminates dark caves and night terrain cleanly.", com.viper.client.modules.Category.RENDER, "fullbright", -1);
        new java.lang.String[2][0] = "Lightmap";
        new java.lang.String[2][1] = "Soft Ambient";
        this.mode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("mode", "Mode", "Brightness boost curve applied to the GPU lightmap", "Lightmap", new java.lang.String[2])));
        this.strength = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("strength", "Brightness", "Minimum ambient light floor across caves and night terrain", 100.0, 40.0, 100.0, 5.0, "%")));
        return;
    }

    public float getAmbientBoost() {
        v1 = Math.max(0.0f, Math.min(1.0f, (this.strength.floatValue() / 100.0f)));
        // if (this.mode.is("Soft Ambient") == 0) -> offset 36
        return (v1 * 0.7799999713897705f);
        return v1;
    }

    public float computeBoostedBrightness(float arg0) {
        v2 = this.getAmbientBoost();
        // if (this.mode.is("Soft Ambient") == 0) -> offset 29
        return Math.min(1.0f, (arg0 + ((1.0f - arg0) * v2)));
        return Math.max(arg0, v2);
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.strength.intValue());
    }

}
