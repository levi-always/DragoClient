package com.viper.client.modules.hacks.combat;

public final class Camera {
    public static final int PRIORITY = 3;

    public Camera() {
        super();
        return;
    }

    public void engage(net.minecraft.class_746 arg0, net.minecraft.class_1309 arg1, float arg2) {
        // if (arg0 == null) -> offset 8
        // if (arg1 != null) -> offset 13
        this.release();
        return;
        com.viper.client.utils.RotationUtils.releaseSilentRotation(3);
        v4 = arg0.method_18798().method_1033();
        // if (Double.compare(v4, 0.65) <= 0) -> offset 49
        v6 = arg2;
        com.viper.client.utils.RotationUtils.driveCameraTarget(arg0, arg1, "Center", v6, 1, 0.3499999940395355f, 3);
        return;
    }

    public float getActiveYaw(net.minecraft.class_746 arg0) {
        return arg0.method_36454();
    }

    public float getActivePitch(net.minecraft.class_746 arg0) {
        return arg0.method_36455();
    }

    public void release() {
        com.viper.client.utils.RotationUtils.releaseCameraTarget(3);
        return;
    }

}
