package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_759.class})
public abstract class HeldItemRendererMixin {
    @Unique
    private static final ThreadLocal VIPER_PUSH_STACK;

    public HeldItemRendererMixin() {
        super();
        return;
    }

    @Inject(method = {"method_3228"}, at = {@At("HEAD")})
    private void viper$onRenderFirstPersonItemHead(net.minecraft.class_742 arg0, float arg1, float arg2, net.minecraft.class_1268 arg3, float arg4, net.minecraft.class_1799 arg5, float arg6, net.minecraft.class_4587 arg7, net.minecraft.class_11659 arg8, int arg9, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg10) {
        v12 = 0;
        v13 = com.viper.client.ViperClient.getInstance();
        // if (v13 == null) -> offset 308
        // if (arg7 == null) -> offset 308
        // if (arg5 == null) -> offset 308
        // if (arg5.method_7960() != 0) -> offset 308
        v14 = ((com.viper.client.modules.hacks.render.ModelViewer) v13.getModuleManager().getModule(com.viper.client.modules.hacks.render.ModelViewer.class));
        // if (v14 == null) -> offset 308
        // if (v14.isEnabled() == 0) -> offset 308
        // if (arg3 == net.minecraft.class_1268.field_5808) -> offset 84
        // if (Boolean.TRUE.equals(v14.affectOffhand.getValue()) == 0) -> offset 308
        arg7.method_22903();
        // if (arg3 != net.minecraft.class_1268.field_5810) -> offset 102
        v15 = 1.0f;
        v16 = ((float)v14.posX.doubleValue() * v15);
        v17 = (float)v14.posY.doubleValue();
        v18 = (float)v14.posZ.doubleValue();
        // if (Double.compare(v16, 0.0f) != 0) -> offset 162
        // if (Double.compare(v17, 0.0f) != 0) -> offset 162
        // if (Double.compare(v18, 0.0f) == 0) -> offset 173
        arg7.method_46416(v16, v17, v18);
        v19 = (float)Math.toRadians(v14.rotX.doubleValue());
        v20 = (float)Math.toRadians((v14.rotY.doubleValue() * (double)v15));
        v21 = (float)Math.toRadians((v14.rotZ.doubleValue() * (double)v15));
        // if (Double.compare(v19, 0.0f) != 0) -> offset 244
        // if (Double.compare(v20, 0.0f) != 0) -> offset 244
        // if (Double.compare(v21, 0.0f) == 0) -> offset 265
        arg7.method_22907(new org.joml.Quaternionf().rotateXYZ(v19, v20, v21));
        v22 = Math.max(0.10000000149011612f, (float)v14.scale.doubleValue());
        // if (Double.compare(Math.abs((v22 - 1.0f)), 0.0010000000474974513f) <= 0) -> offset 305
        arg7.method_22905(v22, v22, v22);
        v12 = 1;
        v13 = -1.0f;
        ((java.util.Deque) com.viper.client.mixin.HeldItemRendererMixin.VIPER_PUSH_STACK.get()).push(Boolean.valueOf(v12));
        return;
    }

    @Inject(method = {"method_3228"}, at = {@At("RETURN")})
    private void viper$onRenderFirstPersonItemReturn(net.minecraft.class_742 arg0, float arg1, float arg2, net.minecraft.class_1268 arg3, float arg4, net.minecraft.class_1799 arg5, float arg6, net.minecraft.class_4587 arg7, net.minecraft.class_11659 arg8, int arg9, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg10) {
        v12 = ((java.util.Deque) com.viper.client.mixin.HeldItemRendererMixin.VIPER_PUSH_STACK.get());
        // if (v12.isEmpty() != 0) -> offset 47
        // if (Boolean.TRUE.equals(v12.pop()) == 0) -> offset 47
        // if (arg7 == null) -> offset 47
        arg7.method_22909();
        return;
    }

}
