package com.viper.client.modules.hacks.render;

public final class XRay extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.ModeSetting orePreset;
    private final com.viper.client.modules.Setting.NumberSetting range;
    private final com.viper.client.modules.Setting.NumberSetting thickness;
    private final com.viper.client.modules.Setting.NumberSetting opacity;
    private final com.viper.client.modules.Setting.BooleanSetting showLabels;
    private final java.util.List discoveredOres;
    private int scanTimer;

    public XRay() {
        super("xray", "X-Ray", "Reveals valuable underground ore veins in 3D.", com.viper.client.modules.Category.RENDER, "xray", -1);
        new java.lang.String[3][0] = "Diamonds & Debris";
        new java.lang.String[3][1] = "All Valuables";
        new java.lang.String[3][2] = "All Ores";
        this.orePreset = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("preset", "Ore Filter", "Valuable ore blocks revealed through terrain", "All Valuables", new java.lang.String[3])));
        this.range = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("range", "Range", "Underground ore scan radius", 24.0, 12.0, 40.0, 2.0, "m")));
        this.thickness = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("thickness", "Thickness", "Ore box wireframe thickness", 1.25, 0.6, 3.0, 0.05, "px")));
        this.opacity = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("opacity", "Opacity", "Ore highlight opacity", 85.0, 20.0, 100.0, 5.0, "%")));
        this.showLabels = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("show_labels", "Ore Labels", "Display compact ore tags on closest veins", 1)));
        this.discoveredOres = new java.util.ArrayList();
        this.scanTimer = 0;
        return;
    }

    protected void onDisable() {
        this.discoveredOres.clear();
        this.scanTimer = 0;
        return;
    }

    public void onTick() {
        // if (this.scanTimer <= 0) -> offset 18
        this.scanTimer = (this.scanTimer - 1);
        return;
        this.scanTimer = 14;
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 46
        // if (v1.field_1724 == null) -> offset 46
        // if (v1.field_1687 != null) -> offset 47
        return;
        this.discoveredOres.clear();
        v2 = this.range.intValue();
        v3 = v1.field_1724.method_24515().method_10263();
        v4 = v1.field_1724.method_24515().method_10264();
        v5 = v1.field_1724.method_24515().method_10260();
        v6 = ((java.lang.String) this.orePreset.getValue());
        v7 = new net.minecraft.class_2338.class_2339();
        v8 = (v4 - Math.min(v2, 24));
        // if (v8 > (v4 + Math.min(v2, 18))) -> offset 278
        v9 = (v3 - v2);
        // if (v9 > (v3 + v2)) -> offset 272
        v10 = (v5 - v2);
        // if (v10 > (v5 + v2)) -> offset 266
        v7.method_10103(v9, v8, v10);
        v11 = v1.field_1687.method_8320(v7);
        // if (v11 == null) -> offset 260
        // if (v11.method_26215() == 0) -> offset 212
        v12 = this.classifyOre(v7, v11.method_26204(), v6);
        // if (v12 == null) -> offset 260
        this.discoveredOres.add(v12);
        // if (this.discoveredOres.size() < 140) -> offset 260
        return;
        v10 += 1;
        v9 += 1;
        v8 += 1;
        return;
    }

    private com.viper.client.modules.hacks.render.XRay.OreNode classifyOre(net.minecraft.class_2338 arg0, net.minecraft.class_2248 arg1, String arg2) {
        v4 = net.minecraft.class_7923.field_41175.method_10221(arg1);
        // if (v4 == null) -> offset 30
        v5 = "";
        // if (v5.isEmpty() == 0) -> offset 44
        return null;
        // if (v5.contains("diamond_ore") != 0) -> offset 65
        // if (v5.contains("diamond_block") == 0) -> offset 83
        return new com.viper.client.modules.hacks.render.XRay.OreNode(arg0.method_10062(), -13058568, "DIA");
        // if (v5.contains("ancient_debris") == 0) -> offset 112
        return new com.viper.client.modules.hacks.render.XRay.OreNode(arg0.method_10062(), -1096636, "DEB");
        // if ("Diamonds & Debris".equals(arg2) == 0) -> offset 123
        return null;
        // if (v5.contains("emerald_ore") == 0) -> offset 152
        return new com.viper.client.modules.hacks.render.XRay.OreNode(arg0.method_10062(), -14498466, "EME");
        // if (v5.contains("gold_ore") == 0) -> offset 181
        return new com.viper.client.modules.hacks.render.XRay.OreNode(arg0.method_10062(), -340971, "GLD");
        // if ("All Valuables".equals(arg2) == 0) -> offset 192
        return null;
        // if (v5.contains("iron_ore") == 0) -> offset 221
        return new com.viper.client.modules.hacks.render.XRay.OreNode(arg0.method_10062(), -1776409, "IRN");
        // if (v5.contains("lapis_ore") == 0) -> offset 250
        return new com.viper.client.modules.hacks.render.XRay.OreNode(arg0.method_10062(), -12877066, "LAP");
        // if (v5.contains("redstone_ore") == 0) -> offset 279
        return new com.viper.client.modules.hacks.render.XRay.OreNode(arg0.method_10062(), -2349530, "RED");
        return null;
    }

    public void onRenderOverlay(net.minecraft.class_332 arg0, float arg1) {
        // if (this.discoveredOres.isEmpty() == 0) -> offset 13
        return;
        v3 = net.minecraft.class_310.method_1551();
        v4 = com.viper.client.utils.WorldProjectionUtils.captureCameraFrame(arg0, com.viper.client.modules.hacks.render.Zoom.getActiveDivisorSnapshot());
        // if (v3 == null) -> offset 35
        // if (v4 != null) -> offset 36
        return;
        v5 = (this.opacity.floatValue() / 100.0f);
        v6 = this.thickness.floatValue();
        v7 = 0;
        v8 = this.discoveredOres.iterator();
        // if (v8.hasNext() == 0) -> offset 327
        v9 = ((com.viper.client.modules.hacks.render.XRay.OreNode) v8.next());
        v10 = v9.pos();
        v11 = com.viper.client.utils.AnimUtils.withAlpha(v9.rgb(), v5);
        v12 = new net.minecraft.class_238((double)v10.method_10263(), (double)v10.method_10264(), (double)v10.method_10260(), ((double)v10.method_10263() + 1.0), ((double)v10.method_10264() + 1.0), ((double)v10.method_10260() + 1.0));
        com.viper.client.utils.WorldProjectionUtils.drawWorldBoxWireframe(arg0, v4, v12, v6, v11);
        // if (((java.lang.Boolean) this.showLabels.getValue()).booleanValue() == 0) -> offset 324
        // if (v7 >= 18) -> offset 324
        // if (v3.field_1772 == null) -> offset 324
        v13 = com.viper.client.utils.WorldProjectionUtils.projectWorldPoint(v4, ((double)v10.method_10263() + 0.5), ((double)v10.method_10264() + 0.5), ((double)v10.method_10260() + 0.5));
        // if (v13.visible() == 0) -> offset 324
        // if (Double.compare(v13.depth(), 18.0f) >= 0) -> offset 324
        v14 = v3.field_1772.method_1727(v9.shortTag());
        com.viper.client.utils.AtlasRenderer.drawText(arg0, v3.field_1772, v9.shortTag(), Math.round((v13.x() - ((float)v14 * 0.5f))), Math.round((v13.y() - 4.0f)), v11, 1);
        v7 += 1;
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.discoveredOres.size());
    }

    public final class OreNode extends java.lang.Record {
        private final net.minecraft.class_2338 pos;
        private final int rgb;
        private final String shortTag;

        public OreNode(net.minecraft.class_2338 arg0, int arg1, String arg2) {
            super();
            this.pos = arg0;
            this.rgb = arg1;
            this.shortTag = arg2;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public net.minecraft.class_2338 pos() {
            return this.pos;
        }

        public int rgb() {
            return this.rgb;
        }

        public String shortTag() {
            return this.shortTag;
        }

    }

}
