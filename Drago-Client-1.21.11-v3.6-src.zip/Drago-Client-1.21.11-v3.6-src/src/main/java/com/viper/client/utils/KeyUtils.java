package com.viper.client.utils;

import org.lwjgl.glfw.GLFW;

public final class KeyUtils {
    public static final int KEY_NONE = -1;
    public static final int KEY_ESCAPE = 256;
    public static final int KEY_ENTER = 257;
    public static final int KEY_TAB = 258;
    public static final int KEY_BACKSPACE = 259;
    public static final int KEY_DELETE = 261;
    public static final int KEY_LEFT_SHIFT = 340;
    public static final int KEY_LEFT_CONTROL = 341;
    public static final int KEY_LEFT_ALT = 342;
    public static final int KEY_RIGHT_SHIFT = 344;
    public static final int KEY_RIGHT_CONTROL = 345;
    public static final int KEY_RIGHT_ALT = 346;

    private KeyUtils() {}

    public static boolean isBindDown(long windowHandle, int keyCode) {
        if (windowHandle == 0L || keyCode < 0) return false;
        if (keyCode >= 1000 && keyCode <= 1007) {
            return GLFW.glfwGetMouseButton(windowHandle, keyCode - 1000) == 1;
        }
        if (keyCode <= 7) {
            return GLFW.glfwGetMouseButton(windowHandle, keyCode) == 1;
        }
        return GLFW.glfwGetKey(windowHandle, keyCode) == 1;
    }

    public static String getKeyName(int keyCode) {
        if (keyCode >= 1000 && keyCode <= 1007) {
            return "M" + (keyCode - 999);
        }
        return getKeyboardName(keyCode);
    }

    public static String getKeyboardName(int keyCode) {
        if (keyCode <= 0) return "NONE";
        if (keyCode >= 65 && keyCode <= 90) return String.valueOf((char) keyCode);
        if (keyCode >= 48 && keyCode <= 57) return String.valueOf((char) keyCode);
        if (keyCode >= 290 && keyCode <= 301) return "F" + (keyCode - 289);
        return "KEY_" + keyCode;
    }
}
