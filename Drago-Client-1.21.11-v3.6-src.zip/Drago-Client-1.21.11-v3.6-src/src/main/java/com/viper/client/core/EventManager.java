package com.viper.client.core;

public final class EventManager {
    private final java.util.Map listeners;

    public EventManager() {
        super();
        this.listeners = new java.util.concurrent.ConcurrentHashMap();
        return;
    }

    public void subscribe(Class arg0, Object arg1, java.util.function.Consumer arg2) {
        this.subscribe(arg0, arg1, 0, arg2);
        return;
    }

    public void subscribe(Class arg0, Object arg1, int arg2, java.util.function.Consumer arg3) {
        v5 = ((java.util.concurrent.CopyOnWriteArrayList) this.listeners.computeIfAbsent(arg0, apply()));
        v5.add(new com.viper.client.core.EventManager.ListenerEntry(arg1, arg2, arg3));
        v5.sort(java.util.Comparator.comparingInt(applyAsInt()).reversed());
        return;
    }

    public void unsubscribeAll(Object arg0) {
        v2 = this.listeners.values().iterator();
        // if (v2.hasNext() == 0) -> offset 48
        v3 = ((java.util.concurrent.CopyOnWriteArrayList) v2.next());
        v3.removeIf(test(arg0));
        return;
    }

    public Object post(Object arg0) {
        // if (arg0 != null) -> offset 6
        return null;
        v2 = ((java.util.List) this.listeners.get(arg0.getClass()));
        // if (v2 == null) -> offset 96
        // if (v2.isEmpty() != 0) -> offset 96
        v3 = v2.iterator();
        // if (v3.hasNext() == 0) -> offset 96
        v4 = ((com.viper.client.core.EventManager.ListenerEntry) v3.next());
        v4.handler().accept(arg0);
        v5 = /*?*/;
        // if ((arg0 instanceof com.viper.client.core.EventManager.CancellableEvent) == 0) -> offset 43
        // if (((com.viper.client.core.EventManager.CancellableEvent) arg0).isCancelled() == 0) -> offset 43
        return arg0;
    }

    public int getSubscriberCount(Class arg0) {
        v2 = ((java.util.List) this.listeners.get(arg0));
        // if (v2 != null) -> offset 22
        return v2.size();
    }

    public final class AttackEntityEvent extends com.viper.client.core.EventManager.CancellableEvent {
        private final Object targetEntity;

        public AttackEntityEvent(Object arg0) {
            super();
            this.targetEntity = arg0;
            return;
        }

        public Object getTargetEntity() {
            return this.targetEntity;
        }

    }

    public abstract class CancellableEvent {
        private boolean cancelled;

        public CancellableEvent() {
            super();
            return;
        }

        public boolean isCancelled() {
            return this.cancelled;
        }

        public void cancel() {
            this.cancelled = 1;
            return;
        }

    }

    public final class KeyPressEvent {
        private final int keyCode;

        public KeyPressEvent(int arg0) {
            super();
            this.keyCode = arg0;
            return;
        }

        public int getKeyCode() {
            return this.keyCode;
        }

    }

    final class ListenerEntry extends java.lang.Record {
        private final Object owner;
        private final int priority;
        private final java.util.function.Consumer handler;

        private ListenerEntry(Object arg0, int arg1, java.util.function.Consumer arg2) {
            super();
            this.owner = arg0;
            this.priority = arg1;
            this.handler = arg2;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public Object owner() {
            return this.owner;
        }

        public int priority() {
            return this.priority;
        }

        public java.util.function.Consumer handler() {
            return this.handler;
        }

    }

    public final class PacketSendEvent extends com.viper.client.core.EventManager.CancellableEvent {
        private Object packet;

        public PacketSendEvent(Object arg0) {
            super();
            this.packet = arg0;
            return;
        }

        public Object getPacket() {
            return this.packet;
        }

        public void setPacket(Object arg0) {
            this.packet = arg0;
            return;
        }

    }

    public final class Render2DEvent {
        private final Object drawContext;
        private final int scaledWidth;
        private final int scaledHeight;
        private final float tickDelta;

        public Render2DEvent(Object arg0, int arg1, int arg2, float arg3) {
            super();
            this.drawContext = arg0;
            this.scaledWidth = arg1;
            this.scaledHeight = arg2;
            this.tickDelta = arg3;
            return;
        }

        public Object getDrawContext() {
            return this.drawContext;
        }

        public int getScaledWidth() {
            return this.scaledWidth;
        }

        public int getScaledHeight() {
            return this.scaledHeight;
        }

        public float getTickDelta() {
            return this.tickDelta;
        }

    }

    public final class TickEvent {
        public static final com.viper.client.core.EventManager.TickEvent INSTANCE;

        private TickEvent() {
            super();
            return;
        }

    }

}
