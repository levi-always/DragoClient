package com.viper.client.ui;

public final class Icons {
    private static final java.util.Map CACHE;
    public static final net.minecraft.class_2960 VIPER_LOGO;
    public static final net.minecraft.class_2960 COMBAT;
    public static final net.minecraft.class_2960 RENDER;
    public static final net.minecraft.class_2960 WORLD;
    public static final net.minecraft.class_2960 INVENTORY;
    public static final net.minecraft.class_2960 CONFIGS;
    public static final net.minecraft.class_2960 THEMES;
    public static final net.minecraft.class_2960 SPRINT_RESET;
    public static final net.minecraft.class_2960 W_TAP;
    public static final net.minecraft.class_2960 HIT_WEB;
    public static final net.minecraft.class_2960 AUTO_DRAIN;
    public static final net.minecraft.class_2960 SAFE_WALK;
    public static final net.minecraft.class_2960 KEY_PEARL;
    public static final net.minecraft.class_2960 AUTO_HIT_CRYSTAL;
    public static final net.minecraft.class_2960 ANCHOR_MACRO;
    public static final net.minecraft.class_2960 MODEL_VIEWER;
    public static final net.minecraft.class_2960 BACK;
    public static final net.minecraft.class_2960 SETTINGS;
    public static final net.minecraft.class_2960 CLOSE;
    public static final net.minecraft.class_2960 KEYBIND;
    public static final net.minecraft.class_2960 CHECK;
    public static final net.minecraft.class_2960 CHEVRON_DOWN;
    public static final net.minecraft.class_2960 CHEVRON_RIGHT;
    public static final net.minecraft.class_2960 MOON;
    public static final net.minecraft.class_2960 SUN;
    public static final net.minecraft.class_2960 RESET;
    public static final net.minecraft.class_2960 SEARCH;
    public static final net.minecraft.class_2960 PALETTE;
    public static final net.minecraft.class_2960 HUD_EDITOR;
    public static final net.minecraft.class_2960 KNOCKBACK_DELAY;
    public static final net.minecraft.class_2960 WIND_CHARGE;
    public static final net.minecraft.class_2960 PEARL_CATCH;
    public static final net.minecraft.class_2960 WIND_CHARGE_CLUTCH;

    private Icons() {
        super();
        return;
    }

    public static net.minecraft.class_2960 of(String arg0) {
        return ((net.minecraft.class_2960) com.viper.client.ui.Icons.CACHE.computeIfAbsent(arg0, apply()));
    }

}
