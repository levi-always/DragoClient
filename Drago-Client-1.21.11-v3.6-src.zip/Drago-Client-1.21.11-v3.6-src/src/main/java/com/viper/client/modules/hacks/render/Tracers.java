package com.viper.client.modules.hacks.render;

public final class Tracers extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.ModeSetting targetFilter;
    private final com.viper.client.modules.Setting.ColorSetting color;
    private final com.viper.client.modules.Setting.NumberSetting thickness;
    private final com.viper.client.modules.Setting.NumberSetting opacity;

    public Tracers() {
        super("tracers", "Tracers", "Draws crisp vector lines to nearby targets.", com.viper.client.modules.Category.RENDER, "tracers", -1);
        new java.lang.String[3][0] = "Players";
        new java.lang.String[3][1] = "Mobs";
        new java.lang.String[3][2] = "All";
        this.targetFilter = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("target", "Target", "Entities connected by center-screen tracers", "Players", new java.lang.String[3])));
        this.color = ((com.viper.client.modules.Setting.ColorSetting) this.registerSetting(new com.viper.client.modules.Setting.ColorSetting("color", "Color", "Tracer line color", 15680580)));
        this.thickness = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("thickness", "Thickness", "Tracer line stroke thickness", 1.2, 0.5, 4.0, 0.1, "px")));
        this.opacity = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("opacity", "Opacity", "Tracer line opacity", 75.0, 10.0, 100.0, 5.0, "%")));
        return;
    }

    public void onRenderOverlay(net.minecraft.class_332 arg0, float arg1) {
        v3 = net.minecraft.class_310.method_1551();
        // if (v3 == null) -> offset 22
        // if (v3.field_1724 == null) -> offset 22
        // if (v3.field_1687 != null) -> offset 23
        return;
        v4 = com.viper.client.utils.WorldProjectionUtils.captureCameraFrame(arg0, com.viper.client.modules.hacks.render.Zoom.getActiveDivisorSnapshot());
        // if (v4 != null) -> offset 38
        return;
        v5 = v4.centerX();
        v6 = v4.centerY();
        v7 = this.thickness.floatValue();
        v8 = this.color.getArgb((this.opacity.floatValue() / 100.0f));
        v9 = new org.joml.Vector3f();
        v10 = v3.field_1687.method_18112().iterator();
        // if (v10.hasNext() == 0) -> offset 383
        v11 = ((net.minecraft.class_1297) v10.next());
        // if (com.viper.client.utils.TargetUtils.matchesTargetFilter(v11, v3.field_1724, ((java.lang.String) this.targetFilter.getValue())) != 0) -> offset 150
        v12 = (v11.field_6014 + ((v11.method_23317() - v11.field_6014) * (double)arg1));
        v14 = ((v11.field_6036 + ((v11.method_23318() - v11.field_6036) * (double)arg1)) + ((double)v11.method_17682() * 0.5));
        v16 = (v11.field_5969 + ((v11.method_23321() - v11.field_5969) * (double)arg1));
        com.viper.client.utils.WorldProjectionUtils.worldToView(v4, v12, v14, v16, v9);
        v18 = (-v9.z);
        // if (Double.compare(v18, 0.10000000149011612f) < 0) -> offset 298
        v19 = (v5 + ((v9.x / v18) * v4.focalY()));
        v20 = (v6 - ((v9.y / v18) * v4.focalY()));
        v19 = (v5 - (v9.x * v4.focalY()));
        v20 = (v6 + (v9.y * v4.focalY()));
        v19 = Math.max(0.0f, Math.min((float)v4.screenW(), v19));
        v20 = Math.max(0.0f, Math.min((float)v4.screenH(), v20));
        com.viper.client.utils.AtlasRenderer.drawThinLine(arg0, v5, v6, v19, v20, v7, v8);
        return;
    }

    public String getHudMetadata() {
        return this.thickness.formatDisplay();
    }

}
