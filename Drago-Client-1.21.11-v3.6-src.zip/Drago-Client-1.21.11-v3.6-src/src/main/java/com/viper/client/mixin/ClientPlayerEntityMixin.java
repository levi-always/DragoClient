package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_746.class})
public abstract class ClientPlayerEntityMixin {
    public ClientPlayerEntityMixin() {
        super();
        return;
    }

    @Inject(method = {"method_5773"}, at = {@At("HEAD")})
    private void viper$beforePlayerTick(org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg0) {
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() != 0) -> offset 7
        return;
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 23
        // if (this == v2.field_1724) -> offset 24
        return;
        v3 = ((net.minecraft.class_746) this);
        v3.field_5982 = com.viper.client.utils.RotationUtils.getPrevServerYaw();
        v3.field_6004 = com.viper.client.utils.RotationUtils.getPrevServerPitch();
        v3.method_36456(com.viper.client.utils.RotationUtils.getServerYaw());
        v3.method_36457(com.viper.client.utils.RotationUtils.getServerPitch());
        v3.field_6259 = com.viper.client.utils.RotationUtils.getPrevServerYaw();
        v3.field_6241 = com.viper.client.utils.RotationUtils.getServerYaw();
        return;
    }

    @Inject(method = {"method_5773"}, at = {@At("TAIL")})
    private void viper$afterPlayerTick(org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg0) {
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 16
        // if (this == v2.field_1724) -> offset 17
        return;
        v3 = ((net.minecraft.class_746) this);
        com.viper.client.utils.RotationUtils.recordPacketConfirmedAngles(v3.method_36454(), v3.method_36455());
        // if (com.viper.client.utils.RotationUtils.isSilentControlling() == 0) -> offset 53
        v3.field_6259 = com.viper.client.utils.RotationUtils.getPrevServerYaw();
        v3.field_6241 = com.viper.client.utils.RotationUtils.getServerYaw();
        return;
    }

}
