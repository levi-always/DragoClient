package com.viper.client.ui.components;

public final class Toggle extends com.viper.client.ui.components.UIComponent {
    private final String label;
    private final java.util.function.BooleanSupplier getter;
    private final java.util.function.Consumer setter;
    private float toggleAnim;

    public Toggle(String arg0, String arg1, java.util.function.BooleanSupplier arg2, java.util.function.Consumer arg3) {
        super();
        this.label = arg0;
        this.getter = arg2;
        this.setter = arg3;
        // if (arg2.getAsBoolean() == 0) -> offset 34
        1.0f.toggleAnim = 0.0f;
        this.setDescription(arg1);
        return;
    }

    public Toggle(String arg0, java.util.function.BooleanSupplier arg1, java.util.function.Consumer arg2) {
        this(arg0, "", arg1, arg2);
        return;
    }

    public Toggle(com.viper.client.modules.Setting.BooleanSetting arg0) {
        java.util.Objects.requireNonNull(arg0);
        java.util.Objects.requireNonNull(arg0);
        this(arg0.getName(), arg0.getDescription(), getAsBoolean(arg0), accept(arg0));
        this.setVisibleSupplier(arg0.getVisibleCondition());
        return;
    }

    public String getLabel() {
        return this.label;
    }

    public boolean getState() {
        return this.getter.getAsBoolean();
    }

    public void setState(boolean arg0) {
        this.setter.accept(Boolean.valueOf(arg0));
        this.triggerPress();
        return;
    }

    public void render(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, com.viper.client.ui.ThemeManager arg2, int arg3, int arg4, float arg5) {
        this.updateBaseAnimations((double)arg3, (double)arg4, arg5);
        v7 = this.getter.getAsBoolean();
        // if (v7 == 0) -> offset 37
        this.toggleAnim.toggleAnim = com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 15.0f, arg5);
        this.pushInteractiveScale(arg0, 0.014999999664723873f);
        v8 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.settingsDrawerBg(), arg2.cardHoverBg(), (this.hoverAnim * 0.699999988079071f)));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, this.x, this.y, this.width, this.height, v8);
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, this.x, this.y, this.width, this.height, this.applyAlpha(arg2.borderSubtle()));
        v9 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.textSecondary(), arg2.textPrimary(), Math.max((this.hoverAnim * 0.5f), this.toggleAnim)));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, this.label, (this.x + 7), (this.y + ((this.height - 8) / 2)), v9, 0);
        v10 = 28;
        v11 = 14;
        v12 = (((this.x + this.width) - v10) - 6);
        v13 = (this.y + ((this.height - v11) / 2));
        // if (Double.compare(this.toggleAnim, 0.05000000074505806f) <= 0) -> offset 297
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, v12, v13, v10, v11, this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.controlTrackBg(), arg2.accentSecondary(), this.toggleAnim)), this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.controlTrackBg(), arg2.accentPrimary(), this.toggleAnim)));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v12, v13, v10, v11, this.applyAlpha(arg2.controlTrackBg()));
        v14 = 10;
        v15 = ((v12 + 2) + Math.round(((float)((v10 - v14) - 4) * this.toggleAnim)));
        v16 = (v13 + 2);
        // if (Double.compare(this.toggleAnim, 0.10000000149011612f) > 0) -> offset 370
        // if (Double.compare(this.hoverAnim, 0.10000000149011612f) <= 0) -> offset 422
        v17 = this.applyAlpha(com.viper.client.utils.AnimUtils.withAlpha(arg2.accentSecondary(), (0.30000001192092896f * Math.max(this.toggleAnim, (this.hoverAnim * 0.6000000238418579f)))));
        com.viper.client.utils.AtlasRenderer.drawRadialGlow(arg0, (v15 + (v14 / 2)), (v16 + (v14 / 2)), 8, v17);
        com.viper.client.utils.AtlasRenderer.drawCircle(arg0, v15, v16, v14, this.applyAlpha(-1));
        // if (Double.compare(this.toggleAnim, 0.550000011920929f) <= 0) -> offset 488
        v17 = this.applyAlpha(com.viper.client.utils.AnimUtils.withAlpha(arg2.accentPrimary(), ((this.toggleAnim - 0.5f) * 2.0f)));
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.CHECK, (v15 + 1), (v16 + 1), 8, v17);
        this.popInteractiveScale(arg0);
        return;
    }

    public boolean mouseClicked(double arg0, double arg1, int arg2) {
        // if (arg2 != 0) -> offset 37
        // if (this.isMouseOver(arg0, arg1) == 0) -> offset 37
        // if (this.getter.getAsBoolean() != 0) -> offset 31
        1.setState(0);
        return true;
        return false;
    }

}
