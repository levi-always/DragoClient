package com.viper.client.modules.hacks.combat;

public final class WTap extends com.viper.client.modules.Module {
    public final com.viper.client.modules.Setting.NumberSetting tapCount;
    public final com.viper.client.modules.Setting.NumberSetting tapDelay;
    public final com.viper.client.modules.Setting.NumberSetting tapInterval;
    public final com.viper.client.modules.Setting.BooleanSetting onlyForward;
    public final com.viper.client.modules.Setting.BooleanSetting playersOnly;
    public final com.viper.client.modules.Setting.BooleanSetting weaponsOnly;
    private int tapsRemaining;
    private boolean releasingW;
    private long phaseEndsAtMs;
    private long lastTriggeredAtMs;

    public WTap() {
        super("w_tap", "W-Tap", "Taps forward movement on hit for spacing.", com.viper.client.modules.Category.COMBAT, "w_tap", -1);
        this.tapCount = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("tap_count", "Tap Count", "Number of W-key release & re-press taps after hitting a target (1x to 4x)", 1.0, 1.0, 4.0, 1.0, "x")));
        this.tapDelay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("tap_delay", "Release Delay", "Duration in milliseconds that forward movement (W) stays released per tap", 55.0, 20.0, 180.0, 5.0, "ms")));
        this.tapInterval = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("tap_interval", "Tap Interval", "Forward-press interval in milliseconds between multi-taps", 65.0, 30.0, 220.0, 5.0, "ms")));
        this.onlyForward = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("only_forward", "Only Forward", "Only trigger W-Tap while actively pressing forward (W)", 1)));
        this.playersOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("players_only", "Players Only", "Only trigger W-Tap when hitting Players (OFF = Players & Animals/Mobs)", 1)));
        this.weaponsOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("weapons_only", "Weapons Only", "Only trigger W-Tap while holding a weapon", 1)));
        this.tapsRemaining = 0;
        this.releasingW = 0;
        this.phaseEndsAtMs = 0L;
        this.lastTriggeredAtMs = 0L;
        return;
    }

    protected void onDisable() {
        this.tapsRemaining = 0;
        this.releasingW = 0;
        this.phaseEndsAtMs = 0L;
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.tapCount.intValue(), this.tapDelay.intValue());
    }

    public boolean isReleasingForward(long arg0) {
        // if (this.isEnabled() != 0) -> offset 9
        return false;
        this.advanceTimeline(arg0);
        return this.releasingW;
    }

    public boolean isReleasingForward() {
        return this.isReleasingForward(System.currentTimeMillis());
    }

    public boolean triggerForTest(long arg0, boolean arg1, boolean arg2) {
        // if (this.isEnabled() != 0) -> offset 9
        return false;
        // if (((java.lang.Boolean) this.onlyForward.getValue()).booleanValue() == 0) -> offset 31
        // if (arg1 != 0) -> offset 31
        return false;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 54
        // if (arg2 != 0) -> offset 54
        return false;
        this.startTapSequence(arg0);
        return true;
    }

    private void startTapSequence(long arg0) {
        this.lastTriggeredAtMs = arg0;
        this.tapsRemaining = Math.max(1, this.tapCount.intValue());
        this.releasingW = 1;
        this.phaseEndsAtMs = (arg0 + Math.max(15L, this.tapDelay.longValue()));
        return;
    }

    public void advanceTimeline(long arg0) {
        // if (this.tapsRemaining > 0) -> offset 15
        // if (this.releasingW != 0) -> offset 15
        return;
        // if (Double.compare(arg0, this.phaseEndsAtMs) < 0) -> offset 130
        // if (this.releasingW != 0) -> offset 38
        // if (this.tapsRemaining <= 0) -> offset 130
        // if (this.releasingW == 0) -> offset 100
        this.releasingW = 0;
        this.tapsRemaining = (this.tapsRemaining - 1);
        // if (this.tapsRemaining <= 0) -> offset 92
        this.phaseEndsAtMs = (this.phaseEndsAtMs + Math.max(20L, this.tapInterval.longValue()));
        this.phaseEndsAtMs = 0L;
        this.releasingW = 1;
        this.phaseEndsAtMs = (this.phaseEndsAtMs + Math.max(15L, this.tapDelay.longValue()));
        return;
    }

    public void onAttackEntity(Object arg0) {
        // if (this.isEnabled() != 0) -> offset 8
        return;
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 23
        // if (v2.field_1724 != null) -> offset 24
        return;
        v3 = v2.field_1724;
        // if (com.viper.client.utils.TargetUtils.matchesPlayersOnly(arg0, v3, ((java.lang.Boolean) this.playersOnly.getValue()).booleanValue()) != 0) -> offset 51
        return;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 75
        // if (com.viper.client.utils.WeaponUtils.isHoldingWeapon(v3) != 0) -> offset 75
        return;
        // if (((java.lang.Boolean) this.onlyForward.getValue()).booleanValue() == 0) -> offset 112
        // if (v2.field_1690 == null) -> offset 112
        // if (v2.field_1690.field_1894.method_1434() != 0) -> offset 112
        return;
        v4 = System.currentTimeMillis();
        // if (Double.compare((v4 - this.lastTriggeredAtMs), 60L) >= 0) -> offset 132
        return;
        this.startTapSequence(v4);
        return;
    }

    public void onTick() {
        this.advanceTimeline(System.currentTimeMillis());
        return;
    }

}
