package com.viper.client.modules.hacks.combat;

public final class Reach extends com.viper.client.modules.Module {
    public final com.viper.client.modules.Setting.NumberSetting attackRange;
    public final com.viper.client.modules.Setting.NumberSetting hitboxMargin;
    public final com.viper.client.modules.Setting.BooleanSetting sprintOnly;
    public final com.viper.client.modules.Setting.BooleanSetting weaponsOnly;
    private boolean prevLeftDown;
    private long lastReachSwingMs;

    public Reach() {
        super("reach", "Reach", "Smooth extended melee attack range and targeting margin.", com.viper.client.modules.Category.COMBAT, "hitboxes", -1);
        this.attackRange = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("attack_range", "Attack Range", "Extended melee strike reach in blocks", 3.6, 3.0, 6.0, 0.05, "m")));
        this.hitboxMargin = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("hitbox_margin", "Hitbox Margin", "Subtle targeting margin expansion for smoother hits", 0.15, 0.0, 1.2, 0.05, "m")));
        this.sprintOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("sprint_only", "Only While Sprinting", "Apply extended reach only when sprinting", 0)));
        this.weaponsOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("weapons_only", "Weapons Only", "Only extend reach while holding a weapon", 0)));
        this.prevLeftDown = 0;
        this.lastReachSwingMs = 0L;
        return;
    }

    protected void onDisable() {
        this.prevLeftDown = 0;
        return;
    }

    public String getHudMetadata() {
        new java.lang.Object[1][0] = Double.valueOf(this.attackRange.doubleValue());
        return String.format(java.util.Locale.US, "%.2fm", new java.lang.Object[1]);
    }

    public float getExtraMarginFor(net.minecraft.class_1297 arg0) {
        // if (this.isEnabled() != 0) -> offset 9
        return 0.0f;
        v2 = this.hitboxMargin.doubleValue();
        // if (Double.compare(v2, 0.0) > 0) -> offset 25
        return 0.0f;
        v4 = net.minecraft.class_310.method_1551();
        // if (v4 == null) -> offset 43
        // if (v4.field_1724 != null) -> offset 45
        return 0.0f;
        // if (((java.lang.Boolean) this.sprintOnly.getValue()).booleanValue() == 0) -> offset 74
        // if (v4.field_1724.method_5624() != 0) -> offset 74
        return 0.0f;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 103
        // if (com.viper.client.utils.WeaponUtils.isHoldingWeapon(v4.field_1724) != 0) -> offset 103
        return 0.0f;
        // if (com.viper.client.utils.TargetUtils.matchesPlayersOnly(arg0, v4.field_1724, 1) != 0) -> offset 118
        return 0.0f;
        return (float)v2;
        v2 = /*?*/;
        return 0.0f;
    }

    public void onTick() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 29
        // if (v1.field_1724 == null) -> offset 29
        // if (v1.field_1687 == null) -> offset 29
        // if (v1.field_1761 != null) -> offset 30
        return;
        // if (v1.field_1755 == null) -> offset 43
        this.prevLeftDown = 0;
        return;
        // if (v1.method_22683() == null) -> offset 60
        v2 = org.lwjgl.glfw.GLFW.glfwGetCurrentContext();
        // if (Double.compare(v2, 0L) != 0) -> offset 71
        return;
        // if (org.lwjgl.glfw.GLFW.glfwGetMouseButton(v2, 0) != 1) -> offset 84
        v4 = 0;
        // if (v4 == 0) -> offset 103
        // if (this.prevLeftDown != 0) -> offset 103
        v5 = 0;
        this.prevLeftDown = v4;
        // if (v5 != 0) -> offset 118
        return;
        v6 = v1.field_1724;
        // if (((java.lang.Boolean) this.sprintOnly.getValue()).booleanValue() == 0) -> offset 149
        // if (v6.method_5624() != 0) -> offset 149
        return;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 174
        // if (com.viper.client.utils.WeaponUtils.isHoldingWeapon(v6) != 0) -> offset 174
        return;
        v7 = this.attackRange.doubleValue();
        // if (Double.compare(v7, 3.05) > 0) -> offset 193
        return;
        v9 = System.currentTimeMillis();
        // if (Double.compare((v9 - this.lastReachSwingMs), 95L) >= 0) -> offset 213
        return;
        v11 = com.viper.client.utils.TargetUtils.findBestTarget(v7, 45.0f, 1, "Crosshair");
        // if (v11 != null) -> offset 231
        return;
        v12 = Math.sqrt(v6.method_5858(v11));
        // if (Double.compare(v12, 3.0) <= 0) -> offset 260
        // if (Double.compare(v12, v7) <= 0) -> offset 261
        return;
        v14 = com.viper.client.utils.RotationUtils.getRealViewYaw(v6);
        v15 = com.viper.client.utils.RotationUtils.getRealViewPitch(v6);
        // if (com.viper.client.utils.RotationUtils.raycastEntityHitbox(v6, v11, v14, v15, v7) != 0) -> offset 292
        return;
        v1.field_1761.method_2918(v6, v11);
        v6.method_6104(net.minecraft.class_1268.field_5808);
        this.lastReachSwingMs = v9;
        v1 = 1;
        return;
    }

}
