package com.viper.client.ui.components;

public final class Button extends com.viper.client.ui.components.UIComponent {
    private String label;
    private net.minecraft.class_2960 iconTexture;
    private boolean accentVariant;
    private final Runnable onLeftClick;
    private final Runnable onRightClick;

    public Button(String arg0, String arg1, net.minecraft.class_2960 arg2, boolean arg3, Runnable arg4, Runnable arg5) {
        super();
        this.label = arg0;
        this.iconTexture = arg2;
        this.accentVariant = arg3;
        this.onLeftClick = arg4;
        this.onRightClick = arg5;
        this.setDescription(arg1);
        return;
    }

    public Button(String arg0, net.minecraft.class_2960 arg1, boolean arg2, Runnable arg3, Runnable arg4) {
        this(arg0, "", arg1, arg2, arg3, arg4);
        return;
    }

    public Button(String arg0, net.minecraft.class_2960 arg1, Runnable arg2) {
        this(arg0, "", arg1, 0, arg2, null);
        return;
    }

    public Button(String arg0, String arg1, net.minecraft.class_2960 arg2, Runnable arg3) {
        this(arg0, arg1, arg2, 0, arg3, null);
        return;
    }

    public String getLabel() {
        return this.label;
    }

    public void setLabel(String arg0) {
        this.label = arg0;
        return;
    }

    public void setIconTexture(net.minecraft.class_2960 arg0) {
        this.iconTexture = arg0;
        return;
    }

    public void setAccentVariant(boolean arg0) {
        this.accentVariant = arg0;
        return;
    }

    public void render(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, com.viper.client.ui.ThemeManager arg2, int arg3, int arg4, float arg5) {
        this.updateBaseAnimations((double)arg3, (double)arg4, arg5);
        this.pushInteractiveScale(arg0, 0.012000000104308128f);
        // if (this.accentVariant == 0) -> offset 93
        com.viper.client.utils.AtlasRenderer.drawRoundedGradient(arg0, this.x, this.y, this.width, this.height, this.applyAlpha(arg2.accentSecondary()), this.applyAlpha(arg2.accentPrimary()));
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, this.x, this.y, this.width, this.height, this.applyAlpha(arg2.accentSecondary()));
        v7 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.cardBg(), arg2.cardHoverBg(), this.hoverAnim));
        v8 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.borderSubtle(), arg2.borderStrong(), this.hoverAnim));
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, this.x, this.y, this.width, this.height, v7);
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, this.x, this.y, this.width, this.height, v8);
        // if (this.accentVariant == 0) -> offset 191
        v7 = -1.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg2.textSecondary(), arg2.textPrimary(), this.hoverAnim));
        // if (this.label == null) -> offset 232
        // if (this.label.isEmpty() != 0) -> offset 232
        v8 = 0;
        // if (this.iconTexture == null) -> offset 246
        v9 = 0;
        v10 = 12;
        // if (v9 == 0) -> offset 360
        // if (v8 == 0) -> offset 360
        v11 = ((v10 + 6) + com.viper.client.utils.AtlasRenderer.getTextWidth(arg1, this.label));
        v12 = (this.x + ((this.width - v11) / 2));
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, this.iconTexture, v12, (this.y + ((this.height - v10) / 2)), v10, v7);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, this.label, ((v12 + v10) + 6), (this.y + ((this.height - 8) / 2)), v7, 0);
        // if (v9 == 0) -> offset 408
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, this.iconTexture, (this.x + ((this.width - v10) / 2)), (this.y + ((this.height - v10) / 2)), v10, v7);
        // if (v8 == 0) -> offset 463
        v11 = com.viper.client.utils.AtlasRenderer.getTextWidth(arg1, this.label);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, this.label, (this.x + ((this.width - v11) / 2)), (this.y + ((this.height - 8) / 2)), v7, 0);
        this.popInteractiveScale(arg0);
        return;
    }

    public boolean mouseClicked(double arg0, double arg1, int arg2) {
        // if (this.isMouseOver(arg0, arg1) != 0) -> offset 11
        return false;
        // if (arg2 != 0) -> offset 38
        // if (this.onLeftClick == null) -> offset 38
        this.triggerPress();
        this.onLeftClick.run();
        return true;
        // if (arg2 != 1) -> offset 66
        // if (this.onRightClick == null) -> offset 66
        this.triggerPress();
        this.onRightClick.run();
        return true;
        return false;
    }

}
