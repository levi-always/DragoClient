package com.viper.client.modules.hacks.world;

public final class SafeWalk extends com.viper.client.modules.Module {
    public final com.viper.client.modules.Setting.ModeSetting mode;
    private long shiftHoldUntilMs;

    public SafeWalk() {
        super("safe_walk", "Safe Walk", "Prevents falling off block ledges safely.", com.viper.client.modules.Category.WORLD, "safe_walk", -1);
        new java.lang.String[2][0] = "Strict";
        new java.lang.String[2][1] = "Shift";
        this.mode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("mode", "Mode", "Strict clips movement natively at ledges; Shift holds real sneak at block edges", "Strict", new java.lang.String[2])));
        this.shiftHoldUntilMs = 0L;
        return;
    }

    protected void onDisable() {
        this.shiftHoldUntilMs = 0L;
        return;
    }

    public String getHudMetadata() {
        return ((java.lang.String) this.mode.getValue());
    }

    public boolean shouldClipAtLedge(net.minecraft.class_1657 arg0) {
        // if (this.isEnabled() == 0) -> offset 23
        // if (this.mode.is("Strict") == 0) -> offset 23
        // if (arg0 != null) -> offset 25
        return false;
        // if (arg0.method_24828() == 0) -> offset 50
        // if (arg0.method_5799() != 0) -> offset 50
        // if (arg0.method_5771() != 0) -> offset 50
        return false;
    }

    public boolean shouldSneakAtEdge(net.minecraft.class_310 arg0, net.minecraft.class_746 arg1) {
        // if (this.isEnabled() == 0) -> offset 34
        // if (this.mode.is("Shift") == 0) -> offset 34
        // if (arg0 == null) -> offset 34
        // if (arg1 == null) -> offset 34
        // if (arg0.field_1687 != null) -> offset 41
        this.shiftHoldUntilMs = 0L;
        return false;
        // if (arg0.field_1755 != null) -> offset 69
        // if (arg1.method_24828() == 0) -> offset 69
        // if (arg1.method_5799() != 0) -> offset 69
        // if (arg1.method_5771() == 0) -> offset 76
        this.shiftHoldUntilMs = 0L;
        return false;
        v3 = arg0.field_1687;
        v4 = arg1.method_5829();
        v5 = arg1.method_18798();
        v6 = arg1.method_23317();
        v8 = arg1.method_23321();
        v10 = (v4.field_1322 - 0.25);
        // if (com.viper.client.modules.hacks.world.SafeWalk.hasSupportAtPoint(v3, v6, v10, v8) != 0) -> offset 133
        v12 = 0;
        // if (com.viper.client.modules.hacks.world.SafeWalk.hasSupportAtPoint(v3, (v6 + (v5.field_1352 * 0.85)), v10, (v8 + (v5.field_1350 * 0.85))) != 0) -> offset 173
        v13 = 0;
        v14 = System.currentTimeMillis();
        // if (v12 != 0) -> offset 191
        // if (v13 == 0) -> offset 213
        this.shiftHoldUntilMs = ((v14 + 75L) + (long)java.util.concurrent.ThreadLocalRandom.current().nextInt(32));
        return true;
        // if (Double.compare(v14, this.shiftHoldUntilMs) >= 0) -> offset 227
        return false;
    }

    private static boolean hasSupportAtPoint(net.minecraft.class_638 arg0, double arg1, double arg2, double arg3) {
        v7 = new net.minecraft.class_2338((int)Math.floor(arg1), (int)Math.floor(arg2), (int)Math.floor(arg3));
        v8 = arg0.method_8320(v7);
        // if (v8 == null) -> offset 46
        // if (v8.method_26215() == 0) -> offset 48
        return false;
        // if (v8.method_26220(arg0, v7).method_1110() != 0) -> offset 66
        return false;
    }

}
