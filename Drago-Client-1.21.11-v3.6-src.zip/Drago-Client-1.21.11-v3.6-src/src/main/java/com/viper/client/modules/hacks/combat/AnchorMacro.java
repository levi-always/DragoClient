package com.viper.client.modules.hacks.combat;

import com.viper.client.ViperClient;
import com.viper.client.modules.Category;
import com.viper.client.modules.Module;
import com.viper.client.modules.Setting;
import com.viper.client.utils.ClickSimulator;
import com.viper.client.utils.HotbarCoordinator;
import com.viper.client.utils.KeyUtils;
import com.viper.client.utils.RotationUtils;
import com.viper.client.utils.WeaponUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_746;

public final class AnchorMacro extends Module {
    private static final String OWNER_ID = "anchor_macro";
    private static final int HOTBAR_PRIORITY = 43;
    private static final int ROTATION_PRIORITY = 6;
    private static boolean bypassingUse;

    public final Setting.ModeSetting mode;
    public final Setting.BooleanSetting onKey;
    public final Setting.KeybindSetting triggerKey;
    public final Setting.BooleanSetting safeAnchor;
    public final Setting.NumberSetting placeAnchorDelay;
    public final Setting.NumberSetting placeGlowstoneDelay;
    public final Setting.NumberSetting explodeDelay;
    public final Setting.BooleanSetting switchBack;
    public final Setting.BooleanSetting simulateClick;

    private Phase phase = Phase.IDLE;
    private int lastSafeSlot = -1;
    private int anchorSlot = -1;
    private int glowstoneSlot = -1;
    private int detonateSlot = -1;
    private class_2338 placeTargetPos;
    private class_2350 placeTargetSide = class_2350.field_11036;
    private class_243 placeHitVec;
    private class_2338 anchorPos;
    private long nextStepAtMs;
    private long explodeTimeoutMs;
    private boolean wasKeyDown;

    public AnchorMacro() {
        super("anchor_macro", "AnchorMacro", "Places Respawn Anchor, charges Glowstone, places Safe Anchor shield block, and detonates cleanly.", Category.COMBAT, "anchor_macro", -1);
        this.mode = registerSetting(new Setting.ModeSetting("mode", "Mode", "Aim controller mode: Silent server aim or Legit aim", "Silent", new String[]{"Silent", "Legit"}));
        this.onKey = registerSetting(new Setting.BooleanSetting("on_key", "On Key", "Trigger AnchorMacro from any held item with Key (OFF = on right-click)", false));
        this.triggerKey = (Setting.KeybindSetting) registerSetting(new Setting.KeybindSetting("trigger_key", "Key", "Key or mouse button to run AnchorMacro", -1)).visibleWhen(() -> Boolean.TRUE.equals(onKey.getValue()));
        this.safeAnchor = registerSetting(new Setting.BooleanSetting("safe_anchor", "Safe Anchor", "Place a protective solid block between you and Anchor to cut self-damage", true));
        this.placeAnchorDelay = registerSetting(new Setting.NumberSetting("place_anchor_delay", "Place Anchor Delay", "Delay before placing Respawn Anchor (0-100ms)", 15.0, 0.0, 100.0, 5.0, "ms"));
        this.placeGlowstoneDelay = registerSetting(new Setting.NumberSetting("place_glowstone_delay", "Place Glowstone Delay", "Delay before charging Anchor with Glowstone (0-100ms)", 25.0, 0.0, 100.0, 5.0, "ms"));
        this.explodeDelay = registerSetting(new Setting.NumberSetting("explode_delay", "Explode Delay", "Delay after switching back before detonating Anchor (0-100ms)", 30.0, 0.0, 100.0, 5.0, "ms"));
        this.switchBack = registerSetting(new Setting.BooleanSetting("switch_back", "Switch Back", "Switch back to your last used non-anchor item before detonating", true));
        this.simulateClick = registerSetting(new Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left/Right click presses during module actions", true));
    }

    public static boolean isBypassingUse() { return bypassingUse; }

    @Override
    protected void onDisable() {
        abortSequence();
        wasKeyDown = false;
    }

    @Override
    public String getHudMetadata() {
        return mode.getValue() + " " + explodeDelay.intValue() + "ms";
    }

    private void abortSequence() {
        phase = Phase.IDLE;
        anchorPos = null;
        placeTargetPos = null;
        RotationUtils.releaseSilentRotation(ROTATION_PRIORITY);
        RotationUtils.releaseCameraTarget(ROTATION_PRIORITY);
        HotbarCoordinator.releaseOwner(OWNER_ID, Boolean.TRUE.equals(switchBack.getValue()));
    }

    private static boolean isRespawnAnchorItem(class_1799 stack) {
        return stack != null && !stack.method_7960() && "minecraft:respawn_anchor".equals(WeaponUtils.getItemId(stack));
    }

    private static boolean isGlowstoneItem(class_1799 stack) {
        return stack != null && !stack.method_7960() && "minecraft:glowstone".equals(WeaponUtils.getItemId(stack));
    }

    private static int findAnchorSlot(class_746 player) {
        for (int i = 0; i < 9; i++) if (isRespawnAnchorItem(player.method_31548().method_5438(i))) return i;
        return -1;
    }

    private static int findGlowstoneSlot(class_746 player) {
        for (int i = 0; i < 9; i++) if (isGlowstoneItem(player.method_31548().method_5438(i))) return i;
        return -1;
    }

    private int chooseSafeDetonateSlot(class_746 player) {
        int cur = player.method_31548().method_67532();
        if (lastSafeSlot >= 0 && lastSafeSlot < 9 && !isGlowstoneItem(player.method_31548().method_5438(lastSafeSlot)) && !isRespawnAnchorItem(player.method_31548().method_5438(lastSafeSlot))) {
            return lastSafeSlot;
        }
        return cur;
    }

    private void pollTriggerKey(class_310 mc) {
        if (!Boolean.TRUE.equals(onKey.getValue()) || mc.field_1755 != null) {
            wasKeyDown = false;
            return;
        }
        int code = triggerKey.getKeyCode();
        if (code < 0) {
            wasKeyDown = false;
            return;
        }
        boolean down = KeyUtils.isBindDown(mc.method_22683().method_4490(), code);
        boolean pressed = down && !wasKeyDown;
        wasKeyDown = down;
        if (pressed && phase == Phase.IDLE) interceptDoItemUse(mc);
    }

    public boolean interceptDoItemUse(class_310 mc) {
        if (bypassingUse || mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return false;
        if (mc.field_1755 != null || phase != Phase.IDLE) return false;
        class_746 player = mc.field_1724;
        if (!(mc.field_1765 instanceof class_3965 bhr)) return false;
        class_2338 hitPos = bhr.method_17777();
        class_2350 side = bhr.method_17780();
        class_2680 hitState = mc.field_1687.method_8320(hitPos);
        int gSlot = findGlowstoneSlot(player);
        if (gSlot < 0) return false;

        if (hitState != null && hitState.method_27852(class_2246.field_23152)) {
            if (!HotbarCoordinator.beginSequence(OWNER_ID, HOTBAR_PRIORITY, gSlot, Boolean.TRUE.equals(switchBack.getValue()))) return false;
            lastSafeSlot = player.method_31548().method_67532();
            anchorPos = hitPos;
            placeTargetPos = hitPos;
            placeTargetSide = side;
            placeHitVec = hitPos.method_46558();
            glowstoneSlot = gSlot;
            detonateSlot = chooseSafeDetonateSlot(player);
            phase = Phase.WAIT_CHARGE_GLOWSTONE;
            nextStepAtMs = System.currentTimeMillis() + Math.max(0L, placeGlowstoneDelay.longValue());
            advanceSequence();
            return true;
        }

        int aSlot = findAnchorSlot(player);
        if (aSlot < 0) return false;
        if (!Boolean.TRUE.equals(onKey.getValue()) && !isRespawnAnchorItem(player.method_6047())) return false;
        lastSafeSlot = player.method_31548().method_67532();
        if (!HotbarCoordinator.beginSequence(OWNER_ID, HOTBAR_PRIORITY, aSlot, Boolean.TRUE.equals(switchBack.getValue()))) return false;
        anchorPos = hitState != null && hitState.method_45474() ? hitPos : hitPos.method_10093(side);
        placeTargetPos = hitPos;
        placeTargetSide = side;
        placeHitVec = bhr.method_17784() != null ? bhr.method_17784() : hitPos.method_46558();
        anchorSlot = aSlot;
        glowstoneSlot = gSlot;
        detonateSlot = chooseSafeDetonateSlot(player);
        phase = Phase.WAIT_PLACE_ANCHOR;
        nextStepAtMs = System.currentTimeMillis() + Math.max(0L, placeAnchorDelay.longValue());
        advanceSequence();
        return true;
    }

    private float[] aimAtPoint(class_746 player, class_243 point) {
        if (point == null) return new float[]{player.method_36454(), player.method_36455()};
        class_243 eye = player.method_33571();
        float[] rot = RotationUtils.computeRotations(eye.field_1352, eye.field_1351, eye.field_1350, point.field_1352, point.field_1351, point.field_1350);
        if (mode.is("Silent")) {
            RotationUtils.releaseCameraTarget(ROTATION_PRIORITY);
            RotationUtils.driveSilentRotationCapped(player, rot[0], rot[1], 14.0f, 90.0f, false, ROTATION_PRIORITY);
            return new float[]{RotationUtils.getServerYaw(), RotationUtils.getServerPitch()};
        }
        RotationUtils.releaseSilentRotation(ROTATION_PRIORITY);
        RotationUtils.driveCameraPoint(player, point.field_1352, point.field_1351, point.field_1350, 18.0f, true, ROTATION_PRIORITY);
        return new float[]{player.method_36454(), player.method_36455()};
    }

    private boolean placeSafeShieldBlock(class_310 mc, class_746 player) {
        int blockSlot = WeaponUtils.findPlaceableSolidBlockHotbarSlot(player);
        if (blockSlot < 0 || anchorPos == null) return false;
        class_243 pPos = player.method_33571();
        double dx = pPos.field_1352 - (anchorPos.method_10263() + 0.5);
        double dz = pPos.field_1350 - (anchorPos.method_10260() + 0.5);
        class_2350 dirToPlayer = Math.abs(dx) >= Math.abs(dz)
            ? (dx >= 0 ? class_2350.field_11034 : class_2350.field_11039)
            : (dz >= 0 ? class_2350.field_11035 : class_2350.field_11043);
        class_2338 shieldPos = anchorPos.method_10093(dirToPlayer);
        class_2680 existing = mc.field_1687.method_8320(shieldPos);
        if (existing != null && !existing.method_45474()) return true;
        if (!HotbarCoordinator.selectSlotInSequence(OWNER_ID, HOTBAR_PRIORITY, blockSlot, Boolean.TRUE.equals(switchBack.getValue()))) return false;
        class_243 hit = anchorPos.method_46558();
        float[] rot = aimAtPoint(player, hit);
        if (mode.is("Silent")) RotationUtils.setSilentRotation(rot[0], rot[1], ROTATION_PRIORITY, false);
        bypassingUse = true;
        try {
            class_3965 bhr = new class_3965(hit, dirToPlayer, anchorPos, false);
            class_1269 res = ClickSimulator.interactBlock(mc.field_1761, player, class_1268.field_5808, bhr);
            if (res != null && res.method_23665()) player.method_6104(class_1268.field_5808);
        } finally {
            bypassingUse = false;
        }
        return true;
    }

    private void advanceSequence$viperImpl() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        pollTriggerKey(mc);
        if (phase == Phase.IDLE) return;
        if (mc.field_1755 != null) {
            abortSequence();
            return;
        }
        long now = System.currentTimeMillis();
        class_746 player = mc.field_1724;

        if (phase == Phase.WAIT_PLACE_ANCHOR) {
            aimAtPoint(player, placeHitVec);
            if (now < nextStepAtMs) return;
            if (!HotbarCoordinator.selectSlotInSequence(OWNER_ID, HOTBAR_PRIORITY, anchorSlot, Boolean.TRUE.equals(switchBack.getValue()))) {
                if (HotbarCoordinator.canSwitchSlotThisTick()) abortSequence();
                return;
            }
            mc.field_1761.method_2911();
            bypassingUse = true;
            try {
                class_1269 res = ClickSimulator.interactBlock(mc.field_1761, player, class_1268.field_5808, new class_3965(placeHitVec, placeTargetSide, placeTargetPos, false));
                if (res != null && res.method_23665()) player.method_6104(class_1268.field_5808);
            } finally {
                bypassingUse = false;
            }
            phase = Phase.WAIT_CHARGE_GLOWSTONE;
            nextStepAtMs = now + Math.max(0L, placeGlowstoneDelay.longValue());
            if (placeGlowstoneDelay.longValue() > 0L) return;
        }

        if (phase == Phase.WAIT_CHARGE_GLOWSTONE) {
            class_243 center = anchorPos.method_46558();
            aimAtPoint(player, center);
            if (now < nextStepAtMs) return;
            int gSlot = findGlowstoneSlot(player);
            if (gSlot < 0 || !HotbarCoordinator.selectSlotInSequence(OWNER_ID, HOTBAR_PRIORITY, gSlot, Boolean.TRUE.equals(switchBack.getValue()))) {
                if (gSlot < 0 || HotbarCoordinator.canSwitchSlotThisTick()) abortSequence();
                return;
            }
            bypassingUse = true;
            try {
                class_1269 res = ClickSimulator.interactBlock(mc.field_1761, player, class_1268.field_5808, new class_3965(center, class_2350.field_11036, anchorPos, false));
                if (res != null && res.method_23665()) player.method_6104(class_1268.field_5808);
            } finally {
                bypassingUse = false;
            }
            if (Boolean.TRUE.equals(safeAnchor.getValue())) {
                phase = Phase.WAIT_SAFE_BLOCK;
                nextStepAtMs = now + 20L;
                return;
            }
            phase = Phase.WAIT_EXPLODE;
            nextStepAtMs = now + Math.max(0L, explodeDelay.longValue());
            explodeTimeoutMs = now + Math.max(250L, explodeDelay.longValue() + 200L);
            return;
        }

        if (phase == Phase.WAIT_SAFE_BLOCK) {
            if (now < nextStepAtMs) return;
            placeSafeShieldBlock(mc, player);
            HotbarCoordinator.selectSlotInSequence(OWNER_ID, HOTBAR_PRIORITY, chooseSafeDetonateSlot(player), Boolean.TRUE.equals(switchBack.getValue()));
            phase = Phase.WAIT_EXPLODE;
            nextStepAtMs = now + Math.max(0L, explodeDelay.longValue());
            explodeTimeoutMs = now + Math.max(250L, explodeDelay.longValue() + 200L);
            return;
        }

        if (phase == Phase.WAIT_EXPLODE) {
            if (anchorPos == null || now >= explodeTimeoutMs) {
                abortSequence();
                return;
            }
            class_243 center = anchorPos.method_46558();
            aimAtPoint(player, center);
            if (now < nextStepAtMs) return;
            int det = chooseSafeDetonateSlot(player);
            if (!HotbarCoordinator.selectSlotInSequence(OWNER_ID, HOTBAR_PRIORITY, det, Boolean.TRUE.equals(switchBack.getValue()))) {
                if (HotbarCoordinator.canSwitchSlotThisTick()) abortSequence();
                return;
            }
            bypassingUse = true;
            try {
                class_1269 res = ClickSimulator.interactBlock(mc.field_1761, player, class_1268.field_5808, new class_3965(center, class_2350.field_11036, anchorPos, false));
                if (res != null && res.method_23665()) player.method_6104(class_1268.field_5808);
            } finally {
                bypassingUse = false;
            }
            abortSequence();
        }
    }

    public boolean isSimulateClick() { return Boolean.TRUE.equals(simulateClick.getValue()); }

    public void advanceSequence() {
        ClickSimulator.pushSimulate(isSimulateClick());
        try {
            advanceSequence$viperImpl();
        } finally {
            ClickSimulator.popSimulate();
        }
    }

    @Override
    public void onTick() { advanceSequence(); }

    public static void pollRenderFrame() {
        ViperClient client = ViperClient.getInstance();
        if (client == null) return;
        AnchorMacro mod = (AnchorMacro) client.getModuleManager().getModule(AnchorMacro.class);
        if (mod != null && mod.isEnabled()) mod.advanceSequence();
    }

    public enum Phase {
        IDLE, WAIT_PLACE_ANCHOR, WAIT_CHARGE_GLOWSTONE, WAIT_SAFE_BLOCK, WAIT_EXPLODE
    }
}
