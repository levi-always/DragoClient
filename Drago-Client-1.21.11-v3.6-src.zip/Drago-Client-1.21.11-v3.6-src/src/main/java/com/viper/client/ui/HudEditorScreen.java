package com.viper.client.ui;

public final class HudEditorScreen extends net.minecraft.class_437 {
    private final com.viper.client.ViperClient viper;
    private final net.minecraft.class_437 parentScreen;
    private final com.viper.client.ui.components.Button backButton;
    private final com.viper.client.ui.components.Button resetButton;
    private final com.viper.client.ui.components.Button closeButton;
    private com.viper.client.ui.HudEditorScreen.DragTarget activeDrag;
    private int dragGrabDx;
    private int dragGrabDy;
    private float openAnim;
    private boolean closing;
    private boolean returnToParent;
    private long lastFrameNs;

    public HudEditorScreen(com.viper.client.ViperClient arg0, net.minecraft.class_437 arg1) {
        super(net.minecraft.class_2561.method_43470("DRAGO HUD Editor"));
        this.activeDrag = com.viper.client.ui.HudEditorScreen.DragTarget.NONE;
        this.dragGrabDx = 0;
        this.dragGrabDy = 0;
        this.openAnim = 0.0f;
        this.closing = 0;
        this.returnToParent = 0;
        this.lastFrameNs = System.nanoTime();
        this.viper = arg0;
        this.parentScreen = arg1;
        this.backButton = new com.viper.client.ui.components.Button("Back", "Return to the DRAGO v3.6 ClickGUI menu", com.viper.client.ui.Icons.BACK, run(this));
        this.resetButton = new com.viper.client.ui.components.Button("Reset HUD", "Snap Watermark and ArrayList back to their default top-left alignment", com.viper.client.ui.Icons.RESET, run(arg0));
        this.closeButton = new com.viper.client.ui.components.Button("Close", "Save HUD positions and return to gameplay", com.viper.client.ui.Icons.CLOSE, run(this));
        return;
    }

    public float getOpenProgress() {
        return com.viper.client.utils.AnimUtils.easeOutCubic(this.openAnim);
    }

    private void beginTransition(boolean arg0) {
        this.viper.saveConfig();
        this.returnToParent = arg0;
        this.closing = 1;
        return;
    }

    protected void method_25426() {
        this.openAnim = 0.0f;
        this.closing = 0;
        this.lastFrameNs = System.nanoTime();
        return;
    }

    public boolean method_25421() {
        return false;
    }

    public void method_25419() {
        this.viper.saveConfig();
        // if (Double.compare(this.openAnim, 0.029999999329447746f) > 0) -> offset 68
        // if (this.field_22787 == null) -> offset 68
        // if (this.returnToParent == 0) -> offset 63
        // if (this.parentScreen == null) -> offset 49
        new com.viper.client.ui.ViperClickGuiScreen(this.viper).method_1507(null);
        return;
        this.closing = 1;
        return;
    }

    public void method_25420(net.minecraft.class_332 arg0, int arg1, int arg2, float arg3) {
        v5 = this.getOpenProgress();
        // if (Double.compare(v5, 0.019999999552965164f) <= 0) -> offset 18
        arg0.method_71278();
        arg0.method_25294(0, 0, this.field_22789, this.field_22790, com.viper.client.utils.AnimUtils.withAlpha(this.viper.getThemeManager().backdropTint(), Math.max(0.05000000074505806f, v5)));
        return;
    }

    public void method_25394(net.minecraft.class_332 arg0, int arg1, int arg2, float arg3) {
        v5 = System.nanoTime();
        v7 = Math.max(0.0010000000474974513f, Math.min(0.07999999821186066f, ((float)(v5 - this.lastFrameNs) / 1000000000.0f)));
        this.lastFrameNs = v5;
        v8 = this.viper.getThemeManager();
        v8.updateAnimation(v7);
        // if (this.closing == 0) -> offset 66
        this.openAnim.openAnim = com.viper.client.utils.AnimUtils.damp(0.0f, 1.0f, 16.0f, v7);
        // if (this.closing == 0) -> offset 149
        // if (Double.compare(this.openAnim, 0.02500000037252903f) > 0) -> offset 149
        // if (this.field_22787 == null) -> offset 148
        // if (this.returnToParent == 0) -> offset 136
        // if (this.parentScreen == null) -> offset 122
        v9 = null;
        this.field_22787.method_1507(v9);
        return;
        v9 = this.getOpenProgress();
        v10 = com.viper.client.utils.AnimUtils.withAlpha(419430399, v9);
        v11 = 32;
        // if (v11 >= this.field_22789) -> offset 200
        arg0.method_25294(v11, 0, (v11 + 1), this.field_22790, v10);
        v11 += 32;
        v11 = 32;
        // if (v11 >= this.field_22790) -> offset 236
        arg0.method_25294(0, v11, this.field_22789, (v11 + 1), v10);
        v11 += 32;
        arg0.method_25294((this.field_22789 / 2), 0, ((this.field_22789 / 2) + 1), this.field_22790, com.viper.client.utils.AnimUtils.withAlpha(871645022, v9));
        arg0.method_25294(0, (this.field_22790 / 2), this.field_22789, ((this.field_22790 / 2) + 1), com.viper.client.utils.AnimUtils.withAlpha(871645022, v9));
        v11 = 320;
        v12 = 36;
        v13 = ((this.field_22789 - v11) / 2);
        v14 = (12 - Math.round(((1.0f - v9) * 10.0f)));
        com.viper.client.utils.AtlasRenderer.drawShadowPill(arg0, v13, v14, v11, v12, 6, com.viper.client.utils.AnimUtils.withAlpha(-2013265920, v9));
        com.viper.client.utils.AtlasRenderer.drawLargePanel(arg0, v13, v14, v11, v12, com.viper.client.utils.AnimUtils.withAlpha(v8.windowBg(), v9), com.viper.client.utils.AnimUtils.withAlpha(v8.borderStrong(), v9));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "HUD EDITOR", (v13 + 14), (v14 + 14), com.viper.client.utils.AnimUtils.withAlpha(v8.textPrimary(), v9), 0);
        this.backButton.setAlphaFactor(v9);
        this.resetButton.setAlphaFactor(v9);
        this.closeButton.setAlphaFactor(v9);
        this.backButton.setBounds((v13 + 98), (v14 + 7), 62, 22);
        this.resetButton.setBounds((v13 + 165), (v14 + 7), 82, 22);
        this.closeButton.setBounds((v13 + 252), (v14 + 7), 58, 22);
        this.backButton.render(arg0, this.field_22793, v8, arg1, arg2, v7);
        this.resetButton.render(arg0, this.field_22793, v8, arg1, arg2, v7);
        this.closeButton.render(arg0, this.field_22793, v8, arg1, arg2, v7);
        v15 = v8.getWatermarkX();
        v16 = v8.getWatermarkY();
        v17 = 104;
        v18 = 25;
        this.viper.renderWatermarkPreview(arg0, this.field_22793, v15, v16);
        // if (this.activeDrag != com.viper.client.ui.HudEditorScreen.DragTarget.WATERMARK) -> offset 625
        arg0.drawSelectionFrame(v15, v16, v17, v18, "Watermark", 1, 0);
        v19 = v8.getArrayListX();
        v20 = v8.getArrayListY();
        v21 = 128;
        v22 = 62;
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, v19, v20, v21, v22, com.viper.client.utils.AnimUtils.withAlpha(v8.windowBg(), (0.8500000238418579f * v9)));
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, v19, v20, v21, v22, com.viper.client.utils.AnimUtils.withAlpha(v8.borderSubtle(), v9));
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "Active ArrayList", (v19 + 8), (v20 + 8), com.viper.client.utils.AnimUtils.withAlpha(v8.textPrimary(), v9), 0);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "SilentAura Silent 3.3m", (v19 + 8), (v20 + 23), com.viper.client.utils.AnimUtils.withAlpha(v8.accentSecondary(), v9), 0);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, "AutoMace Silent", (v19 + 8), (v20 + 37), com.viper.client.utils.AnimUtils.withAlpha(v8.textSecondary(), v9), 0);
        // if (this.activeDrag != com.viper.client.ui.HudEditorScreen.DragTarget.ARRAYLIST) -> offset 823
        arg0.drawSelectionFrame(v19, v20, v21, v22, "ArrayList", 1, 0);
        return;
    }

    private void drawSelectionFrame(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, String arg5, boolean arg6) {
        // if (arg6 == 0) -> offset 11
        v8 = -1433099336;
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(arg0, (arg1 - 2), (arg2 - 2), (arg3 + 4), (arg4 + 4), v8);
        // if (arg6 == 0) -> offset 71
        com.viper.client.utils.AtlasRenderer.drawText(arg0, this.field_22793, makeConcatWithConstants(arg5, arg1, arg2), arg1, Math.max(2, (arg2 - 11)), -770210, 1);
        return;
    }

    private int snapCoord(int arg0) {
        v2 = ((com.viper.client.modules.hacks.render.HudEditorModule) this.viper.getModuleManager().getModule(com.viper.client.modules.hacks.render.HudEditorModule.class));
        // if (v2 == null) -> offset 40
        // if (v2.isSnapGrid() == 0) -> offset 40
        return (Math.round(((float)arg0 / 4.0f)) * 4);
        return arg0;
    }

    public boolean method_25402(net.minecraft.class_11909 arg0, boolean arg1) {
        // if (this.closing == 0) -> offset 9
        return true;
        v3 = arg0.comp_4798();
        v5 = arg0.comp_4799();
        v7 = arg0.method_74245();
        // if (this.backButton.mouseClicked(v3, v5, v7) != 0) -> offset 71
        // if (this.resetButton.mouseClicked(v3, v5, v7) != 0) -> offset 71
        // if (this.closeButton.mouseClicked(v3, v5, v7) == 0) -> offset 73
        return true;
        // if (v7 != 0) -> offset 202
        v8 = this.viper.getThemeManager();
        // if (com.viper.client.ui.HudEditorScreen.inside(v3, v5, v8.getWatermarkX(), v8.getWatermarkY(), 104, 25) == 0) -> offset 144
        this.activeDrag = com.viper.client.ui.HudEditorScreen.DragTarget.WATERMARK;
        this.dragGrabDx = ((int)v3 - v8.getWatermarkX());
        this.dragGrabDy = ((int)v5 - v8.getWatermarkY());
        return true;
        // if (com.viper.client.ui.HudEditorScreen.inside(v3, v5, v8.getArrayListX(), v8.getArrayListY(), 128, 62) == 0) -> offset 202
        this.activeDrag = com.viper.client.ui.HudEditorScreen.DragTarget.ARRAYLIST;
        this.dragGrabDx = ((int)v3 - v8.getArrayListX());
        this.dragGrabDy = ((int)v5 - v8.getArrayListY());
        return true;
        return this.method_25402(arg0, arg1);
    }

    public boolean method_25403(net.minecraft.class_11909 arg0, double arg1, double arg2) {
        // if (this.activeDrag == com.viper.client.ui.HudEditorScreen.DragTarget.NONE) -> offset 17
        // if (this.closing == 0) -> offset 26
        return this.method_25403(arg0, arg1, arg2);
        v6 = (int)arg0.comp_4798();
        v7 = (int)arg0.comp_4799();
        v8 = this.viper.getThemeManager();
        v8.setWatermarkX(this.snapCoord(Math.max(2, Math.min((this.field_22789 - 108), (v6 - this.dragGrabDx)))));
        v8.setWatermarkY(this.snapCoord(Math.max(2, Math.min((this.field_22790 - 28), (v7 - this.dragGrabDy)))));
        v8.setArrayListX(this.snapCoord(Math.max(2, Math.min((this.field_22789 - 132), (v6 - this.dragGrabDx)))));
        v8.setArrayListY(this.snapCoord(Math.max(2, Math.min((this.field_22790 - 66), (v7 - this.dragGrabDy)))));
        return true;
    }

    public boolean method_25406(net.minecraft.class_11909 arg0) {
        // if (this.activeDrag == com.viper.client.ui.HudEditorScreen.DragTarget.NONE) -> offset 26
        this.activeDrag = com.viper.client.ui.HudEditorScreen.DragTarget.NONE;
        this.viper.saveConfig();
        return true;
        return this.method_25406(arg0);
    }

    public boolean method_25404(net.minecraft.class_11908 arg0) {
        // if (arg0.comp_4795() != 256) -> offset 28
        // if (this.parentScreen == null) -> offset 22
        1.beginTransition(0);
        return true;
        return this.method_25404(arg0);
    }

    private static boolean inside(double arg0, double arg1, int arg2, int arg3, int arg4, int arg5) {
        // if (Double.compare(arg0, (double)arg2) < 0) -> offset 42
        // if (Double.compare(arg0, (double)(arg2 + arg4)) > 0) -> offset 42
        // if (Double.compare(arg1, (double)arg3) < 0) -> offset 42
        // if (Double.compare(arg1, (double)(arg3 + arg5)) > 0) -> offset 42
        return false;
    }

     enum DragTarget {
        NONE, WATERMARK, ARRAYLIST;


    }

}
