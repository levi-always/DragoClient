package com.viper.client.modules.hacks.render;

public final class RenderCategoryInfo {
    public static final com.viper.client.modules.Category CATEGORY;

    private RenderCategoryInfo() {
        super();
        return;
    }

}
