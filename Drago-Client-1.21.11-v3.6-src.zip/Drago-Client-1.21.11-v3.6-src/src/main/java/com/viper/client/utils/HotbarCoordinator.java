package com.viper.client.utils;

public final class HotbarCoordinator {
    public static final int PRIORITY_SHIELD_BREAK = 50;
    public static final int PRIORITY_AUTO_MACE = 40;
    public static final int PRIORITY_HIT_WEB = 35;
    public static final int PRIORITY_AUTO_DRAIN = 32;
    public static final int PRIORITY_MACE_SWAP = 30;
    public static final int PRIORITY_AUTO_WEAPON = 10;
    private static com.viper.client.utils.HotbarCoordinator.SlotAccess customAccessForTests;
    private static java.util.function.LongSupplier clock;
    private static String activeOwner;
    private static int activePriority;
    private static int savedUserSlot;
    private static int lastAppliedSlot;
    private static boolean switchBackRequested;
    private static long currentStepArmedAtMs;
    private static long clientTickCounter;
    private static long lastSlotSwitchTick;
    private static final java.util.Deque pendingSteps;

    private HotbarCoordinator() {
        super();
        return;
    }

    public static void setTestEnvironment(com.viper.client.utils.HotbarCoordinator.SlotAccess arg0, java.util.function.LongSupplier arg1) {
        com.viper.client.utils.HotbarCoordinator.customAccessForTests = arg0;
        // if (arg1 == null) -> offset 12
        com.viper.client.utils.HotbarCoordinator.clock = getAsLong();
        com.viper.client.utils.HotbarCoordinator.clientTickCounter = 0L;
        com.viper.client.utils.HotbarCoordinator.lastSlotSwitchTick = -10L;
        com.viper.client.utils.HotbarCoordinator.resetAll();
        return;
    }

    public static void setTestSlotAccess(com.viper.client.utils.HotbarCoordinator.SlotAccess arg0) {
        com.viper.client.utils.HotbarCoordinator.setTestEnvironment(arg0, getAsLong());
        return;
    }

    public static void resetAll() {
        com.viper.client.utils.HotbarCoordinator.activeOwner = null;
        com.viper.client.utils.HotbarCoordinator.activePriority = 0;
        com.viper.client.utils.HotbarCoordinator.savedUserSlot = -1;
        com.viper.client.utils.HotbarCoordinator.lastAppliedSlot = -1;
        com.viper.client.utils.HotbarCoordinator.switchBackRequested = 0;
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = -1L;
        com.viper.client.utils.HotbarCoordinator.pendingSteps.clear();
        return;
    }

    private static com.viper.client.utils.HotbarCoordinator.SlotAccess resolveSlotAccess() {
        // if (com.viper.client.utils.HotbarCoordinator.customAccessForTests == null) -> offset 10
        return com.viper.client.utils.HotbarCoordinator.customAccessForTests;
        v0 = net.minecraft.class_310.method_1551();
        v1 = /*?*/;
        return null;
        // if (v0 == null) -> offset 31
        // if (v0.field_1724 != null) -> offset 33
        return null;
        v1 = v0.field_1724;
        return new com.viper.client.utils.HotbarCoordinator.1(v1, v0);
    }

    private static boolean canSwitchSlotThisTick() {
        // if (com.viper.client.utils.HotbarCoordinator.customAccessForTests != null) -> offset 16
        // if (Double.compare(com.viper.client.utils.HotbarCoordinator.lastSlotSwitchTick, com.viper.client.utils.HotbarCoordinator.clientTickCounter) == 0) -> offset 20
        return false;
    }

    private static void applySlotChange(com.viper.client.utils.HotbarCoordinator.SlotAccess arg0, int arg1) {
        // if (arg1 < 0) -> offset 39
        // if (arg1 >= 9) -> offset 39
        v2 = arg0.getSelectedSlot();
        // if (v2 == arg1) -> offset 35
        arg0.setSelectedSlot(arg1);
        com.viper.client.utils.HotbarCoordinator.lastSlotSwitchTick = com.viper.client.utils.HotbarCoordinator.clientTickCounter;
        com.viper.client.utils.HotbarCoordinator.lastAppliedSlot = arg1;
        return;
    }

    public static boolean canAcquire(String arg0, int arg1) {
        // if (arg0 != null) -> offset 6
        return false;
        // if (com.viper.client.utils.HotbarCoordinator.activeOwner == null) -> offset 22
        // if (com.viper.client.utils.HotbarCoordinator.activeOwner.equals(arg0) == 0) -> offset 24
        return true;
        // if (arg1 <= com.viper.client.utils.HotbarCoordinator.activePriority) -> offset 35
        return false;
    }

    public static String getActiveOwner() {
        return com.viper.client.utils.HotbarCoordinator.activeOwner;
    }

    public static int getSavedUserSlot() {
        return com.viper.client.utils.HotbarCoordinator.savedUserSlot;
    }

    public static boolean beginSequence(String arg0, int arg1, int arg2, boolean arg3) {
        // if (com.viper.client.utils.HotbarCoordinator.canAcquire(arg0, arg1) != 0) -> offset 10
        return false;
        v4 = com.viper.client.utils.HotbarCoordinator.resolveSlotAccess();
        // if (v4 != null) -> offset 22
        return false;
        v5 = v4.getSelectedSlot();
        // if (com.viper.client.utils.HotbarCoordinator.activeOwner == null) -> offset 43
        // if (com.viper.client.utils.HotbarCoordinator.savedUserSlot >= 0) -> offset 48
        com.viper.client.utils.HotbarCoordinator.savedUserSlot = v5;
        com.viper.client.utils.HotbarCoordinator.activeOwner = arg0;
        com.viper.client.utils.HotbarCoordinator.activePriority = arg1;
        com.viper.client.utils.HotbarCoordinator.switchBackRequested = arg3;
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = -1L;
        com.viper.client.utils.HotbarCoordinator.pendingSteps.clear();
        // if (arg2 < 0) -> offset 118
        // if (arg2 >= 9) -> offset 118
        // if (arg2 == v5) -> offset 118
        // if (com.viper.client.utils.HotbarCoordinator.canSwitchSlotThisTick() != 0) -> offset 109
        com.viper.client.utils.HotbarCoordinator.lastAppliedSlot = v5;
        com.viper.client.utils.HotbarCoordinator.queueStep(arg0, 1, arg2);
        return true;
        com.viper.client.utils.HotbarCoordinator.applySlotChange(v4, arg2);
        com.viper.client.utils.HotbarCoordinator.lastAppliedSlot = v5;
        return true;
    }

    public static boolean selectSlotInSequence(String arg0, int arg1, int arg2, boolean arg3) {
        // if (com.viper.client.utils.HotbarCoordinator.canAcquire(arg0, arg1) == 0) -> offset 18
        // if (arg2 < 0) -> offset 18
        // if (arg2 < 9) -> offset 20
        return false;
        v4 = com.viper.client.utils.HotbarCoordinator.resolveSlotAccess();
        // if (v4 != null) -> offset 32
        return false;
        v5 = v4.getSelectedSlot();
        // if (com.viper.client.utils.HotbarCoordinator.activeOwner == null) -> offset 53
        // if (com.viper.client.utils.HotbarCoordinator.savedUserSlot >= 0) -> offset 58
        com.viper.client.utils.HotbarCoordinator.savedUserSlot = v5;
        com.viper.client.utils.HotbarCoordinator.activeOwner = arg0;
        com.viper.client.utils.HotbarCoordinator.activePriority = arg1;
        com.viper.client.utils.HotbarCoordinator.switchBackRequested = arg3;
        com.viper.client.utils.HotbarCoordinator.pendingSteps.clear();
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = -1L;
        // if (v5 != arg2) -> offset 96
        com.viper.client.utils.HotbarCoordinator.lastAppliedSlot = arg2;
        return true;
        // if (com.viper.client.utils.HotbarCoordinator.canSwitchSlotThisTick() != 0) -> offset 109
        com.viper.client.utils.HotbarCoordinator.lastAppliedSlot = v5;
        return false;
        com.viper.client.utils.HotbarCoordinator.applySlotChange(v4, arg2);
        // if (v4.getSelectedSlot() != arg2) -> offset 130
        return false;
    }

    public static void queueStep(String arg0, int arg1, int arg2) {
        // if (arg0 == null) -> offset 24
        // if (arg0.equals(com.viper.client.utils.HotbarCoordinator.activeOwner) == 0) -> offset 24
        // if (arg2 < 0) -> offset 24
        // if (arg2 < 9) -> offset 25
        return;
        v3 = com.viper.client.utils.HotbarCoordinator.pendingSteps.isEmpty();
        com.viper.client.utils.HotbarCoordinator.pendingSteps.addLast(new com.viper.client.utils.HotbarCoordinator.QueuedStep(0, Math.max(1, arg1), 0L, arg2, 0));
        // if (v3 == 0) -> offset 73
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = com.viper.client.utils.HotbarCoordinator.clock.getAsLong();
        return;
    }

    public static void queueStepMs(String arg0, long arg1, int arg2) {
        // if (arg0 == null) -> offset 24
        // if (arg0.equals(com.viper.client.utils.HotbarCoordinator.activeOwner) == 0) -> offset 24
        // if (arg2 < 0) -> offset 24
        // if (arg2 < 9) -> offset 25
        return;
        v4 = com.viper.client.utils.HotbarCoordinator.pendingSteps.isEmpty();
        com.viper.client.utils.HotbarCoordinator.pendingSteps.addLast(new com.viper.client.utils.HotbarCoordinator.QueuedStep(1, 0, Math.max(0L, arg1), arg2, 0));
        // if (v4 == 0) -> offset 75
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = com.viper.client.utils.HotbarCoordinator.clock.getAsLong();
        return;
    }

    public static void queueRestoreOrRelease(String arg0, int arg1) {
        // if (arg0 == null) -> offset 14
        // if (arg0.equals(com.viper.client.utils.HotbarCoordinator.activeOwner) != 0) -> offset 15
        return;
        // if (com.viper.client.utils.HotbarCoordinator.switchBackRequested == 0) -> offset 41
        // if (com.viper.client.utils.HotbarCoordinator.savedUserSlot < 0) -> offset 41
        // if (com.viper.client.utils.HotbarCoordinator.savedUserSlot >= 9) -> offset 41
        v2 = -1;
        v3 = com.viper.client.utils.HotbarCoordinator.pendingSteps.isEmpty();
        com.viper.client.utils.HotbarCoordinator.pendingSteps.addLast(new com.viper.client.utils.HotbarCoordinator.QueuedStep(0, Math.max(1, arg1), 0L, v2, 1));
        // if (v3 == 0) -> offset 91
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = com.viper.client.utils.HotbarCoordinator.clock.getAsLong();
        return;
    }

    public static void queueRestoreOrReleaseMs(String arg0, long arg1) {
        // if (arg0 == null) -> offset 14
        // if (arg0.equals(com.viper.client.utils.HotbarCoordinator.activeOwner) != 0) -> offset 15
        return;
        // if (com.viper.client.utils.HotbarCoordinator.switchBackRequested == 0) -> offset 41
        // if (com.viper.client.utils.HotbarCoordinator.savedUserSlot < 0) -> offset 41
        // if (com.viper.client.utils.HotbarCoordinator.savedUserSlot >= 9) -> offset 41
        v3 = -1;
        v4 = com.viper.client.utils.HotbarCoordinator.pendingSteps.isEmpty();
        com.viper.client.utils.HotbarCoordinator.pendingSteps.addLast(new com.viper.client.utils.HotbarCoordinator.QueuedStep(1, 0, Math.max(0L, arg1), v3, 1));
        // if (v4 == 0) -> offset 93
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = com.viper.client.utils.HotbarCoordinator.clock.getAsLong();
        return;
    }

    public static void releaseOwner(String arg0, boolean arg1) {
        // if (arg0 == null) -> offset 14
        // if (arg0.equals(com.viper.client.utils.HotbarCoordinator.activeOwner) != 0) -> offset 15
        return;
        // if (arg1 == 0) -> offset 89
        // if (com.viper.client.utils.HotbarCoordinator.switchBackRequested == 0) -> offset 89
        // if (com.viper.client.utils.HotbarCoordinator.savedUserSlot < 0) -> offset 89
        // if (com.viper.client.utils.HotbarCoordinator.savedUserSlot >= 9) -> offset 89
        v2 = com.viper.client.utils.HotbarCoordinator.resolveSlotAccess();
        // if (v2 == null) -> offset 89
        // if (v2.getSelectedSlot() == com.viper.client.utils.HotbarCoordinator.savedUserSlot) -> offset 89
        // if (com.viper.client.utils.HotbarCoordinator.canSwitchSlotThisTick() == 0) -> offset 75
        com.viper.client.utils.HotbarCoordinator.applySlotChange(v2, com.viper.client.utils.HotbarCoordinator.savedUserSlot);
        com.viper.client.utils.HotbarCoordinator.pendingSteps.clear();
        com.viper.client.utils.HotbarCoordinator.queueRestoreOrRelease(arg0, 1);
        return;
        com.viper.client.utils.HotbarCoordinator.resetAll();
        return;
    }

    public static void onPostAttackEntity() {
        com.viper.client.utils.HotbarCoordinator.processMillisecondQueue();
        return;
    }

    public static void onRenderFrame() {
        com.viper.client.utils.HotbarCoordinator.processMillisecondQueue();
        return;
    }

    private static boolean validateOwnerState(com.viper.client.utils.HotbarCoordinator.SlotAccess arg0) {
        // if (arg0 != null) -> offset 9
        com.viper.client.utils.HotbarCoordinator.resetAll();
        return false;
        v1 = arg0.getSelectedSlot();
        // if (com.viper.client.utils.HotbarCoordinator.lastAppliedSlot < 0) -> offset 41
        // if (v1 == com.viper.client.utils.HotbarCoordinator.lastAppliedSlot) -> offset 41
        // if (v1 == com.viper.client.utils.HotbarCoordinator.savedUserSlot) -> offset 41
        com.viper.client.utils.HotbarCoordinator.resetAll();
        return false;
        return true;
    }

    private static void processMillisecondQueue() {
        // if (com.viper.client.utils.HotbarCoordinator.activeOwner == null) -> offset 17
        // if (com.viper.client.utils.HotbarCoordinator.pendingSteps.isEmpty() == 0) -> offset 18
        return;
        v0 = com.viper.client.utils.HotbarCoordinator.resolveSlotAccess();
        // if (com.viper.client.utils.HotbarCoordinator.validateOwnerState(v0) != 0) -> offset 30
        return;
        v1 = com.viper.client.utils.HotbarCoordinator.clock.getAsLong();
        // if (com.viper.client.utils.HotbarCoordinator.pendingSteps.isEmpty() != 0) -> offset 183
        v3 = ((com.viper.client.utils.HotbarCoordinator.QueuedStep) com.viper.client.utils.HotbarCoordinator.pendingSteps.peekFirst());
        // if (v3.useMillis() != 0) -> offset 70
        return;
        // if (Double.compare(com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs, 0L) >= 0) -> offset 82
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = v1;
        // if (Double.compare((v1 - com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs), v3.delayMs()) >= 0) -> offset 96
        return;
        // if (v3.targetSlot() < 0) -> offset 132
        // if (v3.targetSlot() >= 9) -> offset 132
        // if (v0.getSelectedSlot() == v3.targetSlot()) -> offset 132
        // if (com.viper.client.utils.HotbarCoordinator.canSwitchSlotThisTick() != 0) -> offset 132
        return;
        com.viper.client.utils.HotbarCoordinator.pendingSteps.pollFirst();
        // if (v3.targetSlot() < 0) -> offset 165
        // if (v3.targetSlot() >= 9) -> offset 165
        com.viper.client.utils.HotbarCoordinator.applySlotChange(v0, v3.targetSlot());
        // if (v3.isFinalRestore() == 0) -> offset 176
        com.viper.client.utils.HotbarCoordinator.resetAll();
        return;
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = v1;
        return;
    }

    public static void onClientTick() {
        com.viper.client.utils.HotbarCoordinator.clientTickCounter = (com.viper.client.utils.HotbarCoordinator.clientTickCounter + 1L);
        // if (com.viper.client.utils.HotbarCoordinator.activeOwner != null) -> offset 15
        return;
        v0 = com.viper.client.utils.HotbarCoordinator.resolveSlotAccess();
        // if (com.viper.client.utils.HotbarCoordinator.validateOwnerState(v0) != 0) -> offset 27
        return;
        com.viper.client.utils.HotbarCoordinator.processMillisecondQueue();
        // if (com.viper.client.utils.HotbarCoordinator.activeOwner == null) -> offset 47
        // if (com.viper.client.utils.HotbarCoordinator.pendingSteps.isEmpty() == 0) -> offset 48
        return;
        v1 = ((com.viper.client.utils.HotbarCoordinator.QueuedStep) com.viper.client.utils.HotbarCoordinator.pendingSteps.peekFirst());
        // if (v1.useMillis() == 0) -> offset 68
        return;
        com.viper.client.utils.HotbarCoordinator.pendingSteps.pollFirst();
        v2 = (v1.ticksRemaining() - 1);
        // if (v2 <= 0) -> offset 115
        com.viper.client.utils.HotbarCoordinator.pendingSteps.addFirst(new com.viper.client.utils.HotbarCoordinator.QueuedStep(0, v2, 0L, v1.targetSlot(), v1.isFinalRestore()));
        return;
        // if (v1.targetSlot() < 0) -> offset 185
        // if (v1.targetSlot() >= 9) -> offset 185
        // if (v0.getSelectedSlot() == v1.targetSlot()) -> offset 177
        // if (com.viper.client.utils.HotbarCoordinator.canSwitchSlotThisTick() != 0) -> offset 177
        com.viper.client.utils.HotbarCoordinator.pendingSteps.addFirst(new com.viper.client.utils.HotbarCoordinator.QueuedStep(0, 1, 0L, v1.targetSlot(), v1.isFinalRestore()));
        return;
        com.viper.client.utils.HotbarCoordinator.applySlotChange(v0, v1.targetSlot());
        // if (v1.isFinalRestore() == 0) -> offset 198
        com.viper.client.utils.HotbarCoordinator.resetAll();
        // if (com.viper.client.utils.HotbarCoordinator.pendingSteps.isEmpty() != 0) -> offset 220
        com.viper.client.utils.HotbarCoordinator.currentStepArmedAtMs = com.viper.client.utils.HotbarCoordinator.clock.getAsLong();
        return;
    }

     class 1 implements com.viper.client.utils.HotbarCoordinator.SlotAccess {

        1(net.minecraft.class_746 arg0, net.minecraft.class_310 arg1) {
            this.val$player = arg0;
            this.val$mc = arg1;
            super();
            return;
        }

        public int getSelectedSlot() {
            return this.val$player.method_31548().method_67532();
        }

        public void setSelectedSlot(int arg0) {
            // if (arg0 < 0) -> offset 47
            // if (arg0 >= 9) -> offset 47
            this.val$player.method_31548().method_61496(arg0);
            v3 = this.val$mc.field_1761;
            // if ((v3 instanceof com.viper.client.utils.HotbarCoordinator.InteractionSync) == 0) -> offset 47
            v2 = ((com.viper.client.utils.HotbarCoordinator.InteractionSync) v3);
            v2.viper$syncSelectedSlot();
            return;
        }

    }

    public interface InteractionSync {
        public void viper$syncSelectedSlot();

    }

    final class QueuedStep extends java.lang.Record {
        private final boolean useMillis;
        private final int ticksRemaining;
        private final long delayMs;
        private final int targetSlot;
        private final boolean isFinalRestore;

        private QueuedStep(boolean arg0, int arg1, long arg2, int arg3, boolean arg4) {
            super();
            this.useMillis = arg0;
            this.ticksRemaining = arg1;
            this.delayMs = arg2;
            this.targetSlot = arg3;
            this.isFinalRestore = arg4;
            return;
        }

        public final String toString() {
            return toString(this);
        }

        public final int hashCode() {
            return hashCode(this);
        }

        public final boolean equals(Object arg0) {
            return equals(this, arg0);
        }

        public boolean useMillis() {
            return this.useMillis;
        }

        public int ticksRemaining() {
            return this.ticksRemaining;
        }

        public long delayMs() {
            return this.delayMs;
        }

        public int targetSlot() {
            return this.targetSlot;
        }

        public boolean isFinalRestore() {
            return this.isFinalRestore;
        }

    }

    public interface SlotAccess {
        public int getSelectedSlot();

        public void setSelectedSlot(int arg0);

    }

}
