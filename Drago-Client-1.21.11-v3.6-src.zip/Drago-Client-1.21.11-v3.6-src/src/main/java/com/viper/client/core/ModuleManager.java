package com.viper.client.core;

public final class ModuleManager {
    private final java.util.List modules;
    private final java.util.Map byClass;
    private final java.util.Map byId;

    public ModuleManager(com.viper.client.core.EventManager arg0) {
        super();
        this.modules = new java.util.ArrayList();
        this.byClass = new java.util.LinkedHashMap();
        this.byId = new java.util.LinkedHashMap();
        this.register(new com.viper.client.modules.hacks.combat.SilentAura());
        this.register(new com.viper.client.modules.hacks.combat.TriggerBot());
        this.register(new com.viper.client.modules.hacks.combat.AimAssist());
        this.register(new com.viper.client.modules.hacks.combat.Reach());
        this.register(new com.viper.client.modules.hacks.combat.Velocity());
        this.register(new com.viper.client.modules.hacks.combat.PotAssist());
        this.register(new com.viper.client.modules.hacks.combat.AutoMace());
        this.register(new com.viper.client.modules.hacks.combat.MaceSwap());
        this.register(new com.viper.client.modules.hacks.combat.SprintReset());
        this.register(new com.viper.client.modules.hacks.combat.KeyPearl());
        this.register(new com.viper.client.modules.hacks.combat.AutoHitCrystal());
        this.register(new com.viper.client.modules.hacks.combat.AnchorMacro());
        this.register(new com.viper.client.modules.hacks.combat.Hitboxes());
        this.register(new com.viper.client.modules.hacks.combat.ShieldBreak());
        this.registerHidden(new com.viper.client.modules.hacks.combat.WTap());
        this.register(new com.viper.client.modules.hacks.combat.HitWeb());
        this.register(new com.viper.client.modules.hacks.render.Esp());
        this.register(new com.viper.client.modules.hacks.render.Tracers());
        this.register(new com.viper.client.modules.hacks.render.StorageEsp());
        this.register(new com.viper.client.modules.hacks.render.BlockSearch());
        this.register(new com.viper.client.modules.hacks.render.ModelViewer());
        this.register(new com.viper.client.modules.hacks.render.HudEditorModule());
        this.register(new com.viper.client.modules.hacks.render.Fullbright());
        this.register(new com.viper.client.modules.hacks.render.Zoom());
        this.register(new com.viper.client.modules.hacks.render.Nametags());
        this.register(new com.viper.client.modules.hacks.render.XRay());
        this.register(new com.viper.client.modules.hacks.world.FastPlace());
        this.register(new com.viper.client.modules.hacks.world.Freelook());
        this.register(new com.viper.client.modules.hacks.world.AutoDrain());
        this.register(new com.viper.client.modules.hacks.world.SafeWalk());
        this.register(new com.viper.client.modules.hacks.world.Mlg());
        this.register(new com.viper.client.modules.hacks.inventory.AutoWeapon());
        this.register(new com.viper.client.modules.hacks.inventory.InvMove());
        arg0.subscribe(com.viper.client.core.EventManager.TickEvent.class, this, accept(this));
        arg0.subscribe(com.viper.client.core.EventManager.AttackEntityEvent.class, this, accept(this));
        arg0.subscribe(com.viper.client.core.EventManager.KeyPressEvent.class, this, accept(this));
        this.registerExtendedModules();
        return;
    }

    private void register(com.viper.client.modules.Module arg0) {
        this.modules.add(arg0);
        this.byClass.put(arg0.getClass(), arg0);
        this.byId.put(arg0.getId().toLowerCase(java.util.Locale.ROOT), arg0);
        this.byId.put(arg0.getName().toLowerCase(java.util.Locale.ROOT), arg0);
        return;
    }

    private void registerHidden(com.viper.client.modules.Module arg0) {
        arg0.setHidden(1);
        this.register(arg0);
        return;
    }

    public java.util.List getModules() {
        return java.util.Collections.unmodifiableList(this.modules);
    }

    public java.util.List getVisibleModules() {
        v1 = new java.util.ArrayList();
        v2 = this.modules.iterator();
        // if (v2.hasNext() == 0) -> offset 56
        v3 = ((com.viper.client.modules.Module) v2.next());
        // if (v3.isHidden() == 0) -> offset 47
        v1.add(v3);
        return v1;
    }

    public java.util.List getModulesByCategory(com.viper.client.modules.Category arg0) {
        v2 = new java.util.ArrayList();
        v3 = this.modules.iterator();
        // if (v3.hasNext() == 0) -> offset 68
        v4 = ((com.viper.client.modules.Module) v3.next());
        // if (v4.getCategory() != arg0) -> offset 18
        // if (v4.isHidden() == 0) -> offset 58
        v2.add(v4);
        return v2;
    }

    public java.util.List getEnabledModules() {
        v1 = new java.util.ArrayList();
        v2 = this.modules.iterator();
        // if (v2.hasNext() == 0) -> offset 63
        v3 = ((com.viper.client.modules.Module) v2.next());
        // if (v3.isEnabled() == 0) -> offset 18
        // if (v3.isHidden() == 0) -> offset 54
        v1.add(v3);
        return v1;
    }

    public com.viper.client.modules.Module getModule(Class arg0) {
        return ((com.viper.client.modules.Module) this.byClass.get(arg0));
    }

    public com.viper.client.modules.Module getModuleByName(String arg0) {
        // if (arg0 != null) -> offset 6
        return null;
        return ((com.viper.client.modules.Module) this.byId.get(arg0.trim().toLowerCase(java.util.Locale.ROOT)));
    }

    private void registerExtendedModules() {
        this.register(new com.viper.client.modules.hacks.combat.KnockbackDelay());
        this.register(new com.viper.client.modules.hacks.combat.WindCharge());
        this.register(new com.viper.client.modules.hacks.combat.WindChargeClutch());
        this.register(new com.viper.client.modules.hacks.combat.AutoClicker());
        this.register(new com.viper.client.modules.hacks.inventory.AutoTotem());
        return;
    }

}
