package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_636.class})
public abstract class ClientPlayerInteractionManagerMixin implements com.viper.client.utils.HotbarCoordinator.InteractionSync {
    public ClientPlayerInteractionManagerMixin() {
        super();
        return;
    }

    @Shadow
    private void method_2911() {
    }

    public void viper$syncSelectedSlot() {
        this.method_2911();
        return;
    }

    @Inject(method = {"method_2918"}, at = {@At("HEAD")}, cancellable = true)
    private void viper$onAttackEntity(net.minecraft.class_1657 arg0, net.minecraft.class_1297 arg1, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg2) {
        v4 = com.viper.client.ViperClient.getInstance();
        // if (v4 == null) -> offset 53
        v5 = ((com.viper.client.core.EventManager.AttackEntityEvent) v4.getEventManager().post(new com.viper.client.core.EventManager.AttackEntityEvent(arg1)));
        // if (v5 == null) -> offset 49
        // if (v5.isCancelled() == 0) -> offset 49
        arg2.cancel();
        return;
        this.method_2911();
        return;
    }

    @Inject(method = {"method_2918"}, at = {@At("TAIL")})
    private void viper$onPostAttackEntity(net.minecraft.class_1657 arg0, net.minecraft.class_1297 arg1, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg2) {
        com.viper.client.utils.HotbarCoordinator.onPostAttackEntity();
        return;
    }

}
