package com.viper.client.modules.hacks.inventory;

public final class AutoWeapon extends com.viper.client.modules.Module {
    private static final String OWNER_ID = "auto_weapon";
    public final com.viper.client.modules.Setting.ModeSetting mode;
    public final com.viper.client.modules.Setting.BooleanSetting axeOnShield;
    public final com.viper.client.modules.Setting.BooleanSetting switchBack;
    public final com.viper.client.modules.Setting.NumberSetting switchDelay;
    public final com.viper.client.modules.Setting.ModeSetting priority;
    private long lastSwitchAtMs;

    public AutoWeapon() {
        super("auto_weapon", "AutoWeapon", "Equips strongest weapon with Axe on Shield.", com.viper.client.modules.Category.INVENTORY, "auto_weapon", -1);
        new java.lang.String[5][0] = "Best Weapon";
        new java.lang.String[5][1] = "Sword";
        new java.lang.String[5][2] = "Axe";
        new java.lang.String[5][3] = "Mace";
        new java.lang.String[5][4] = "Spear";
        this.mode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("mode", "Mode", "Preferred weapon family when engaging targets", "Best Weapon", new java.lang.String[5])));
        this.axeOnShield = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("axe_on_shield", "Axe on Shield", "Swap to strongest Axe when attacking a shield-blocking target", 1)));
        this.switchBack = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("switch_back", "Switch Back", "Return to your previous hotbar slot after the automatic weapon strike", 1)));
        this.switchDelay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("switch_delay", "Switch Delay", "Minimum delay between standard hotbar switches", 25.0, 0.0, 250.0, 5.0, "ms")));
        new java.lang.String[3][0] = "Damage";
        new java.lang.String[3][1] = "Enchantments";
        new java.lang.String[3][2] = "Attack Speed";
        this.priority = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("priority", "Priority", "Scoring heuristic used to pick the strongest hotbar slot", "Damage", new java.lang.String[3])));
        this.lastSwitchAtMs = 0L;
        return;
    }

    protected void onDisable() {
        com.viper.client.utils.HotbarCoordinator.releaseOwner("auto_weapon", 1);
        return;
    }

    public String getHudMetadata() {
        // if (((java.lang.Boolean) this.axeOnShield.getValue()).booleanValue() == 0) -> offset 34
        return ((java.lang.String) this.mode.getValue());
    }

    public void onAttackEntity(Object arg0) {
        // if (this.isEnabled() != 0) -> offset 8
        return;
        // if (com.viper.client.utils.HotbarCoordinator.canAcquire("auto_weapon", 10) != 0) -> offset 19
        return;
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 34
        // if (v2.field_1724 != null) -> offset 35
        return;
        v3 = v2.field_1724;
        v4 = System.currentTimeMillis();
        // if (((java.lang.Boolean) this.axeOnShield.getValue()).booleanValue() == 0) -> offset 144
        // if ((arg0 instanceof net.minecraft.class_1309) == 0) -> offset 144
        v6 = ((net.minecraft.class_1309) arg0);
        // if (com.viper.client.utils.WeaponUtils.isTargetBlockingWithShield(v6) == 0) -> offset 144
        v7 = com.viper.client.utils.WeaponUtils.findBestHotbarSlot(v3, "Axe", ((java.lang.String) this.priority.getValue()), 0.0);
        // if (v7 < 0) -> offset 144
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("auto_weapon", 10, v7, ((java.lang.Boolean) this.switchBack.getValue()).booleanValue()) == 0) -> offset 143
        com.viper.client.utils.HotbarCoordinator.queueRestoreOrRelease("auto_weapon", 4);
        this.lastSwitchAtMs = v4;
        return;
        // if (Double.compare((v4 - this.lastSwitchAtMs), (long)this.switchDelay.intValue()) >= 0) -> offset 164
        return;
        v6 = Math.max(v3.field_6017, ((-v3.method_18798().field_1351) * 4.0));
        v8 = com.viper.client.utils.WeaponUtils.findBestHotbarSlot(v3, ((java.lang.String) this.mode.getValue()), ((java.lang.String) this.priority.getValue()), v6);
        // if (v8 >= 0) -> offset 219
        return;
        v9 = Math.max(0, Math.round((this.switchDelay.floatValue() / 50.0f)));
        // if (v9 != 0) -> offset 284
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("auto_weapon", 10, v8, ((java.lang.Boolean) this.switchBack.getValue()).booleanValue()) == 0) -> offset 340
        com.viper.client.utils.HotbarCoordinator.queueRestoreOrRelease("auto_weapon", 8);
        this.lastSwitchAtMs = v4;
        v10 = v3.method_31548().method_67532();
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("auto_weapon", 10, v10, ((java.lang.Boolean) this.switchBack.getValue()).booleanValue()) == 0) -> offset 340
        com.viper.client.utils.HotbarCoordinator.queueStep("auto_weapon", v9, v8);
        com.viper.client.utils.HotbarCoordinator.queueRestoreOrRelease("auto_weapon", 8);
        this.lastSwitchAtMs = v4;
        return;
    }

}
