package com.viper.client.modules.hacks.combat;

import com.viper.client.modules.Category;
import com.viper.client.modules.Module;
import com.viper.client.modules.Setting;
import com.viper.client.utils.ClickSimulator;
import com.viper.client.utils.HotbarCoordinator;
import com.viper.client.utils.RotationUtils;
import com.viper.client.utils.TargetUtils;
import com.viper.client.utils.WeaponUtils;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class ShieldBreak extends Module {
    private static final String OWNER_ID = "shield_break";
    public final Setting.ModeSetting mode;
    public final Setting.ModeSetting followUp;
    public final Setting.NumberSetting swapDelay;
    public final Setting.NumberSetting restoreDelay;
    public final Setting.BooleanSetting switchBack;
    public final Setting.BooleanSetting autoStrike;
    public final Setting.NumberSetting range;
    public final Setting.BooleanSetting simulateClick;
    public final Setting.BooleanSetting playersOnly;
    private long lastBreakMs = 0L;

    public ShieldBreak() {
        super("shield_break", "Auto Shield Breaker", "Undetected shield break: capped 34 deg/tick silent aim, strict raycast, and clean Axe swap (3.0m, 85 deg FOV).", Category.COMBAT, "shield_break", -1);
        this.mode = registerSetting(new Setting.ModeSetting("mode", "Mode", "Aiming mode when auto-breaking shields", "Silent", new String[]{"Silent", "Legit"}));
        this.followUp = registerSetting(new Setting.ModeSetting("follow_up", "Follow-Up", "Weapon to follow up with after Axe shield break", "Sword", new String[]{"Sword", "Mace", "Axe Only"}));
        this.swapDelay = registerSetting(new Setting.NumberSetting("swap_delay", "Swap Delay", "Delay before swapping back from Axe (1 to 8 ticks)", 2.0, 1.0, 8.0, 1.0, "t"));
        this.restoreDelay = registerSetting(new Setting.NumberSetting("restore_delay", "Restore Delay", "Delay before releasing hotbar ownership", 40.0, 0.0, 200.0, 5.0, "ms"));
        this.switchBack = registerSetting(new Setting.BooleanSetting("switch_back", "Switch Back", "Return to your previous weapon after breaking enemy shield", true));
        this.autoStrike = registerSetting(new Setting.BooleanSetting("auto_strike", "Auto Strike", "Automatically strike shield-blocking opponents inside range", true));
        this.range = registerSetting(new Setting.NumberSetting("range", "Range", "Strict vanilla-safe shield-break reach in blocks", 3.0, 2.5, 4.5, 0.1, "m"));
        this.simulateClick = registerSetting(new Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left Click when breaking shields", true));
        this.playersOnly = registerSetting(new Setting.BooleanSetting("players_only", "Players Only", "Only break shields on Players (OFF = Players & Mobs)", true));
    }

    @Override
    protected void onDisable() {
        HotbarCoordinator.releaseOwner(OWNER_ID, true);
    }

    @Override
    public String getHudMetadata() {
        return String.valueOf(this.followUp.getValue());
    }

    public boolean executeShieldBreakSequence(int axeSlot, int followSlot) {
        if (!this.isEnabled() || axeSlot < 0 || axeSlot >= 9) return false;
        if (!HotbarCoordinator.beginSequence(OWNER_ID, 50, axeSlot, Boolean.TRUE.equals(switchBack.getValue()))) return false;
        int delayTicks = Math.max(this.swapDelay.intValue(), 1);
        if (!this.followUp.is("Axe Only") && followSlot >= 0 && followSlot < 9 && followSlot != axeSlot) {
            HotbarCoordinator.queueStep(OWNER_ID, delayTicks, followSlot);
        }
        HotbarCoordinator.queueRestoreOrRelease(OWNER_ID, delayTicks);
        return true;
    }

    public void onAttackEntity(Object targetObj) {
        if (!this.isEnabled() || !(targetObj instanceof class_1309 target)) return;
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null) return;
        class_746 player = mc.field_1724;
        if (!TargetUtils.matchesPlayersOnly(target, player, Boolean.TRUE.equals(playersOnly.getValue()))) return;
        if (!WeaponUtils.isTargetBlockingWithShield(target)) return;
        int prevSlot = player.method_31548().method_67532();
        int axeSlot = WeaponUtils.findBestHotbarSlot((class_1657) player, "Axe", "Damage", 0.0);
        int followSlot = WeaponUtils.findBestFollowUpWeaponSlot((class_1657) player, (String) followUp.getValue(), prevSlot, player.field_6017);
        if (axeSlot >= 0) {
            this.executeShieldBreakSequence(axeSlot, followSlot);
            this.lastBreakMs = System.currentTimeMillis();
        }
    }

    @Override
    public void onTick() {
        if (!Boolean.TRUE.equals(autoStrike.getValue())) return;
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null || mc.field_1755 != null) return;
        long now = System.currentTimeMillis();
        if (now - this.lastBreakMs < 280L) return;
        class_746 player = mc.field_1724;
        class_1309 target = TargetUtils.findBestTarget(range.doubleValue(), 85.0f, Boolean.TRUE.equals(playersOnly.getValue()), "Distance");
        if (target == null || !WeaponUtils.isTargetBlockingWithShield(target)) return;
        int prevSlot = player.method_31548().method_67532();
        int axeSlot = WeaponUtils.findBestHotbarSlot((class_1657) player, "Axe", "Damage", 0.0);
        if (axeSlot < 0) return;
        int followSlot = WeaponUtils.findBestFollowUpWeaponSlot((class_1657) player, (String) followUp.getValue(), prevSlot, player.field_6017);
        float[] rot = RotationUtils.getRotationsToEntity(player, target);
        if (mode.is("Silent")) {
            RotationUtils.driveSilentRotationCapped(player, rot[0], rot[1], 52.0f, 34.0f, true, 4);
            if (!RotationUtils.raycastStrictServerHitbox(player, target, RotationUtils.getConfirmedServerYaw(player), RotationUtils.getConfirmedServerPitch(player), range.doubleValue())) {
                return;
            }
        } else {
            RotationUtils.driveCameraTarget(player, target, "Center", 46.0f, false, 0.0f, 4);
        }
        if (this.executeShieldBreakSequence(axeSlot, followSlot)) {
            ClickSimulator.performLeftClick(mc, target, Boolean.TRUE.equals(simulateClick.getValue()));
            this.lastBreakMs = now;
        }
    }
}
