package com.viper.client.modules.hacks.combat;

public final class AimAssist extends com.viper.client.modules.Module {
    private static final int ROTATION_PRIORITY = 1;
    public final com.viper.client.modules.Setting.ModeSetting mode;
    public final com.viper.client.modules.Setting.ModeSetting aimPoint;
    public final com.viper.client.modules.Setting.NumberSetting fov;
    public final com.viper.client.modules.Setting.NumberSetting range;
    public final com.viper.client.modules.Setting.NumberSetting smoothness;
    public final com.viper.client.modules.Setting.BooleanSetting playersOnly;
    public final com.viper.client.modules.Setting.BooleanSetting weaponsOnly;
    public final com.viper.client.modules.Setting.BooleanSetting onHit;
    private long lastHitAtMs = 0L;

    public AimAssist() {
        super("aim_assist", "AimAssist", "Smooth native-pixel camera or silent aim guidance.", com.viper.client.modules.Category.COMBAT, "aim_assist", -1);
        new java.lang.String[2][0] = "Legit";
        new java.lang.String[2][1] = "Silent";
        this.mode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("mode", "Mode", "Ultra-smooth Legit guidance or F5-visible Silent head rotation", "Legit", new java.lang.String[2])));
        new java.lang.String[8][0] = "Auto";
        new java.lang.String[8][1] = "Head";
        new java.lang.String[8][2] = "Center";
        new java.lang.String[8][3] = "Torso";
        new java.lang.String[8][4] = "Right Arm";
        new java.lang.String[8][5] = "Left Arm";
        new java.lang.String[8][6] = "Right Leg";
        new java.lang.String[8][7] = "Left Leg";
        this.aimPoint = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("aim_point", "Aim Point", "Target body part (Auto dynamically tracks closest fluid zone to crosshair)", "Auto", new java.lang.String[8])));
        this.fov = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("fov", "FOV", "Maximum field of view cone for aim assistance", 90.0, 1.0, 180.0, 1.0, "°")));
        this.range = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("range", "Range", "Maximum engagement distance in blocks", 4.2, 1.0, 6.0, 0.1, "m")));
        this.smoothness = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("smoothness", "Smoothness", "Ultra-smooth angular damping factor (1 = fast, 100 = silky smooth)", 92.0, 1.0, 100.0, 1.0, "%")));
        this.playersOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("players_only", "Players Only", "Assist aim on Players only (turn OFF to target Players and Animals/Mobs)", 1)));
        this.weaponsOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("weapons_only", "Weapons Only", "Only assist aim while holding a weapon", 0)));
        this.onHit = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("on_hit", "On Hit", "Lock/snap camera smoothly onto the nearest player right when you strike", false)));
        return;
    }

    protected void onDisable() {
        this.releaseSmoothly();
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(((java.lang.String) this.mode.getValue()), this.smoothness.intValue());
    }

    private void releaseSmoothly() {
        com.viper.client.utils.RotationUtils.releaseCameraTarget(1);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(1);
        return;
    }

    public void onTick() {
        v1 = net.minecraft.class_310.method_1551();
        // if (v1 == null) -> offset 22
        // if (v1.field_1724 == null) -> offset 22
        // if (v1.field_1687 != null) -> offset 23
        return;
        // if (v1.field_1755 == null) -> offset 35
        this.releaseSmoothly();
        return;
        v2 = v1.field_1724;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 68
        // if (com.viper.client.utils.WeaponUtils.isHoldingWeapon(v2) != 0) -> offset 68
        this.releaseSmoothly();
        return;
        // if (v2.method_6115() == 0) -> offset 87
        // if (com.viper.client.utils.WeaponUtils.isHoldingWeapon(v2) != 0) -> offset 87
        this.releaseSmoothly();
        return;
        v3 = com.viper.client.utils.TargetUtils.findBestTarget(((java.lang.Double) this.range.getValue()).doubleValue(), this.fov.floatValue(), ((java.lang.Boolean) this.playersOnly.getValue()).booleanValue(), "Crosshair");
        // if (v3 == null) -> offset 138
        // if (v2.method_6057(v3) != 0) -> offset 143
        this.releaseSmoothly();
        return;
        v4 = com.viper.client.utils.RotationUtils.getAngleToEntity(v2, v3);
        // if (Double.compare(v4, this.fov.floatValue()) <= 0) -> offset 168
        this.releaseSmoothly();
        return;
        // if (this.mode.is("Silent") == 0) -> offset 225
        com.viper.client.utils.RotationUtils.releaseCameraTarget(1);
        v5 = com.viper.client.utils.RotationUtils.getAimPointRotations(v2, v3, ((java.lang.String) this.aimPoint.getValue()));
        com.viper.client.utils.RotationUtils.driveSilentRotation(v2, v5[0], v5[1], this.smoothness.floatValue(), 1, 1);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(1);
        com.viper.client.utils.RotationUtils.driveCameraTarget(v2, v3, ((java.lang.String) this.aimPoint.getValue()), this.smoothness.floatValue(), 1, 1.149999976158142f, 1);
        return;
    }


    public void onAttackEntity(Object target) {
        if (this.isEnabled() && target != null) {
            this.lastHitAtMs = System.currentTimeMillis();
        }
    }
}
