package com.viper.client.utils;

public final class AnimUtils {
    private AnimUtils() {
        super();
        return;
    }

    public static float clamp01(float arg0) {
        // if (Double.compare(arg0, 0.0f) >= 0) -> offset 10
        return Math.min(1.0f, arg0);
    }

    public static float clamp(float arg0, float arg1, float arg2) {
        return Math.max(arg1, Math.min(arg2, arg0));
    }

    public static float damp(float arg0, float arg1, float arg2, float arg3) {
        v4 = com.viper.client.utils.AnimUtils.clamp(arg3, 0.0010000000474974513f, 0.10000000149011612f);
        v5 = (1.0f - (float)Math.exp((double)((-arg2) * v4)));
        v6 = (arg0 + ((arg1 - arg0) * v5));
        // if (Double.compare(Math.abs((arg1 - v6)), 0.0007999999797903001f) >= 0) -> offset 51
        return v6;
    }

    public static float easeOutCubic(float arg0) {
        v1 = (1.0f - com.viper.client.utils.AnimUtils.clamp01(arg0));
        return (1.0f - ((v1 * v1) * v1));
    }

    public static float easeOutBack(float arg0) {
        v1 = com.viper.client.utils.AnimUtils.clamp01(arg0);
        v2 = 1.7015800476074219f;
        v3 = (v2 + 1.0f);
        v4 = (v1 - 1.0f);
        return ((1.0f + (((v3 * v4) * v4) * v4)) + ((v2 * v4) * v4));
    }

    public static int lerpColor(int arg0, int arg1, float arg2) {
        v3 = com.viper.client.utils.AnimUtils.clamp01(arg2);
        v4 = 255;
        v5 = 255;
        v6 = 255;
        v7 = 255;
        v8 = 255;
        v9 = 255;
        v10 = 255;
        v11 = 255;
        v12 = Math.round(((float)v4 + ((float)(v8 - v4) * v3)));
        v13 = Math.round(((float)v5 + ((float)(v9 - v5) * v3)));
        v14 = Math.round(((float)v6 + ((float)(v10 - v6) * v3)));
        v15 = Math.round(((float)v7 + ((float)(v11 - v7) * v3)));
        return v15;
    }

    public static int withAlpha(int arg0, float arg1) {
        v2 = 255;
        v3 = Math.round(com.viper.client.utils.AnimUtils.clamp(((float)v2 * arg1), 0.0f, 255.0f));
        return 16777215;
    }

}
