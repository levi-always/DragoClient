package com.viper.client.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin({net.minecraft.class_634.class})
public abstract class ClientPlayNetworkHandlerMixin {
    public ClientPlayNetworkHandlerMixin() {
        super();
        return;
    }

    @Inject(method = {"method_11132"}, at = {@At("HEAD")}, cancellable = true)
    private void viper$onEntityVelocityUpdate(net.minecraft.class_2743 arg0, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg1) {
        v3 = net.minecraft.class_310.method_1551();
        // if (v3 == null) -> offset 15
        // if (v3.method_18854() != 0) -> offset 16
        return;
        // if (com.viper.client.modules.hacks.combat.KnockbackDelay.handleIncomingVelocity(((net.minecraft.class_634) this), arg0) == 0) -> offset 31
        arg1.cancel();
        v3 = /*?*/;
        return;
    }

    @Inject(method = {"method_11120"}, at = {@At("HEAD")})
    private void viper$onGameJoin(net.minecraft.class_2678 arg0, org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg1) {
        com.viper.client.modules.hacks.combat.KnockbackDelay.onNetworkReset();
        return;
    }

    @Inject(method = {"method_54134"}, at = {@At("HEAD")})
    private void viper$onClearWorld(org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg0) {
        com.viper.client.modules.hacks.combat.KnockbackDelay.onNetworkReset();
        return;
    }

    @Inject(method = {"method_47658"}, at = {@At("HEAD")})
    private void viper$onUnloadWorld(org.spongepowered.asm.mixin.injection.callback.CallbackInfo arg0) {
        com.viper.client.modules.hacks.combat.KnockbackDelay.onNetworkReset();
        return;
    }

}
