package com.viper.client.ui.components;

public final class Tab extends com.viper.client.ui.components.UIComponent {
    private final com.viper.client.modules.Category category;
    private final java.util.function.BooleanSupplier isActiveSupplier;
    private final Runnable onSelect;
    private float activeAnim;

    public Tab(com.viper.client.modules.Category arg0, java.util.function.BooleanSupplier arg1, Runnable arg2) {
        super();
        this.activeAnim = 0.0f;
        this.category = arg0;
        this.isActiveSupplier = arg1;
        this.onSelect = arg2;
        this.setDescription(arg0.getDescription());
        return;
    }

    public com.viper.client.modules.Category getCategory() {
        return this.category;
    }

    public void render(net.minecraft.class_332 arg0, net.minecraft.class_327 arg1, com.viper.client.ui.ThemeManager arg2, int arg3, int arg4, float arg5) {
        this.updateBaseAnimations((double)arg3, (double)arg4, arg5);
        v7 = this.isActiveSupplier.getAsBoolean();
        // if (v7 == 0) -> offset 37
        this.activeAnim.activeAnim = com.viper.client.utils.AnimUtils.damp(1.0f, 0.0f, 16.0f, arg5);
        this.pushInteractiveScale(arg0, 0.017999999225139618f);
        v8 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(com.viper.client.utils.AnimUtils.lerpColor(0, arg2.cardHoverBg(), (this.hoverAnim * 0.7799999713897705f)), arg2.accentSoftBg(), this.activeAnim));
        // if (255 <= 4) -> offset 122
        com.viper.client.utils.AtlasRenderer.drawRoundedRect(arg0, this.x, this.y, this.width, this.height, v8);
        v9 = Math.max(Math.round((this.hoverAnim * 95.0f)), Math.round((this.activeAnim * 150.0f)));
        // if (v9 <= 8) -> offset 206
        v10 = com.viper.client.utils.AnimUtils.lerpColor(arg2.borderSubtle(), arg2.accentSecondary(), this.activeAnim);
        com.viper.client.utils.AtlasRenderer.drawRoundedBorder(this.width, this.height, this, v9, 24, v10.applyAlpha(16777215));
        v10 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(com.viper.client.utils.AnimUtils.lerpColor(arg2.textSecondary(), arg2.textPrimary(), this.hoverAnim), arg2.accentSecondary(), this.activeAnim));
        v11 = this.applyAlpha(com.viper.client.utils.AnimUtils.lerpColor(com.viper.client.utils.AnimUtils.lerpColor(arg2.textSecondary(), arg2.textPrimary(), this.hoverAnim), arg2.textPrimary(), this.activeAnim));
        v12 = 12;
        v13 = this.category.getDisplayName();
        v14 = ((v12 + 5) + arg1.method_1727(v13));
        v15 = (this.x + ((this.width - v14) / 2));
        com.viper.client.utils.AtlasRenderer.drawIcon(arg0, com.viper.client.ui.Icons.of(this.category.getIconName()), v15, (this.y + ((this.height - v12) / 2)), v12, v10);
        com.viper.client.utils.AtlasRenderer.drawText(arg0, arg1, v13, ((v15 + v12) + 5), (this.y + ((this.height - 8) / 2)), v11, 0);
        this.popInteractiveScale(arg0);
        return;
    }

    public boolean mouseClicked(double arg0, double arg1, int arg2) {
        // if (arg2 != 0) -> offset 29
        // if (this.isMouseOver(arg0, arg1) == 0) -> offset 29
        this.triggerPress();
        this.onSelect.run();
        return true;
        return false;
    }

}
