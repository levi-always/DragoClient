package com.viper.client.modules.hacks.render;

public final class StorageEsp extends com.viper.client.modules.Module {
    private final com.viper.client.modules.Setting.NumberSetting range;
    private final com.viper.client.modules.Setting.BooleanSetting tracers;
    private final com.viper.client.modules.Setting.ColorSetting chestColor;
    private final com.viper.client.modules.Setting.ColorSetting shulkerColor;
    private final com.viper.client.modules.Setting.NumberSetting thickness;
    private final com.viper.client.modules.Setting.NumberSetting opacity;

    public StorageEsp() {
        super("storage_esp", "StorageESP", "Highlights nearby chests, shulkers, barrels, and hoppers.", com.viper.client.modules.Category.RENDER, "storage_esp", -1);
        this.range = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("range", "Range", "Maximum container scan radius", 64.0, 16.0, 128.0, 4.0, "m")));
        this.tracers = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("tracers", "Tracers", "Draw center-screen lines to containers", 0)));
        this.chestColor = ((com.viper.client.modules.Setting.ColorSetting) this.registerSetting(new com.viper.client.modules.Setting.ColorSetting("chest_color", "Chest Color", "Color for Chests & Barrels", 16096779)));
        this.shulkerColor = ((com.viper.client.modules.Setting.ColorSetting) this.registerSetting(new com.viper.client.modules.Setting.ColorSetting("shulker_color", "Shulker Color", "Color for Shulker Boxes & Ender Chests", 15680580)));
        this.thickness = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("thickness", "Thickness", "Wireframe stroke thickness", 1.2, 0.5, 3.0, 0.1, "px")));
        this.opacity = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("opacity", "Opacity", "Container highlight opacity", 85.0, 15.0, 100.0, 5.0, "%")));
        return;
    }

    public void onRenderOverlay(net.minecraft.class_332 arg0, float arg1) {
        v3 = net.minecraft.class_310.method_1551();
        // if (v3 == null) -> offset 22
        // if (v3.field_1724 == null) -> offset 22
        // if (v3.field_1687 != null) -> offset 23
        return;
        v4 = com.viper.client.utils.WorldProjectionUtils.captureCameraFrame(arg0, com.viper.client.modules.hacks.render.Zoom.getActiveDivisorSnapshot());
        // if (v4 != null) -> offset 38
        return;
        v5 = v3.field_1687.method_2935();
        v6 = ((java.lang.Double) this.range.getValue()).doubleValue();
        v8 = (v6 * v6);
        v10 = Math.max(1, (int)Math.ceil((v6 / 16.0)));
        v11 = v3.field_1724.method_31476().field_9181;
        v12 = v3.field_1724.method_31476().field_9180;
        v13 = (this.opacity.floatValue() / 100.0f);
        v14 = this.thickness.floatValue();
        v15 = (v11 - v10);
        // if (v15 > (v11 + v10)) -> offset 642
        v16 = (v12 - v10);
        // if (v16 > (v12 + v10)) -> offset 636
        v17 = v5.method_2857(v15, v16, net.minecraft.class_2806.field_12803, 0);
        // if (v17 != null) -> offset 187
        v18 = v17.method_12214().entrySet().iterator();
        // if (v18.hasNext() == 0) -> offset 630
        v19 = ((java.util.Map.Entry) v18.next());
        v20 = ((net.minecraft.class_2338) v19.getKey());
        v21 = (((double)v20.method_10263() + 0.5) - v3.field_1724.method_23317());
        v23 = (((double)v20.method_10264() + 0.5) - v3.field_1724.method_23318());
        v25 = (((double)v20.method_10260() + 0.5) - v3.field_1724.method_23321());
        // if (Double.compare((((v21 * v21) + (v23 * v23)) + (v25 * v25)), v8) <= 0) -> offset 324
        v27 = net.minecraft.class_7923.field_41181.method_10221(((net.minecraft.class_2586) v19.getValue()).method_11017());
        // if (v27 == null) -> offset 366
        v28 = "";
        // if (v28.contains("shulker") != 0) -> offset 393
        // if (v28.contains("ender_chest") == 0) -> offset 405
        v29 = this.shulkerColor.getArgb();
        // if (v28.contains("chest") != 0) -> offset 438
        // if (v28.contains("barrel") != 0) -> offset 438
        // if (v28.contains("hopper") == 0) -> offset 204
        v29 = this.chestColor.getArgb();
        v30 = com.viper.client.utils.AnimUtils.withAlpha(v29, v13);
        v31 = new net.minecraft.class_238(((double)v20.method_10263() + 0.06), ((double)v20.method_10264() + 0.02), ((double)v20.method_10260() + 0.06), ((double)v20.method_10263() + 0.94), ((double)v20.method_10264() + 0.94), ((double)v20.method_10260() + 0.94));
        com.viper.client.utils.WorldProjectionUtils.drawWorldBoxWireframe(arg0, v4, v31, v14, v30);
        // if (((java.lang.Boolean) this.tracers.getValue()).booleanValue() == 0) -> offset 627
        v32 = com.viper.client.utils.WorldProjectionUtils.projectWorldPoint(v4, ((double)v20.method_10263() + 0.5), ((double)v20.method_10264() + 0.5), ((double)v20.method_10260() + 0.5));
        // if (v32.visible() == 0) -> offset 627
        com.viper.client.utils.AtlasRenderer.drawThinLine(arg0, v4.centerX(), v4.centerY(), v32.x(), v32.y(), 0.8999999761581421f, v30);
        v16 += 1;
        v15 += 1;
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(this.range.intValue());
    }

}
