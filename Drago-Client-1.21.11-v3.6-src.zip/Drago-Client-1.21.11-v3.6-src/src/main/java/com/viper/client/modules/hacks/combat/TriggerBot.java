package com.viper.client.modules.hacks.combat;

import com.viper.client.modules.Category;
import com.viper.client.modules.Module;
import com.viper.client.modules.Setting;
import com.viper.client.utils.ClickSimulator;
import com.viper.client.utils.TargetUtils;
import com.viper.client.utils.WeaponUtils;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_746;

public final class TriggerBot extends Module {
    public final Setting.NumberSetting range;
    public final Setting.NumberSetting delay;
    public final Setting.BooleanSetting playersOnly;
    public final Setting.BooleanSetting weaponsOnly;
    public final Setting.BooleanSetting onlyCriticals;
    public final Setting.BooleanSetting simulateClick;
    private long targetAcquiredAtMs;
    private int lastTargetId = -1;
    private long lastAttackMs;
    private long lastSeenTargetMs;
    private long currentReactionJitterMs = 12L;
    private float nextCooldownThreshold = 0.92f;

    public TriggerBot() {
        super("trigger_bot", "TriggerBot", "Cooldown-synced automatic strike with Only Criticals (falling) option.", Category.COMBAT, "trigger_bot", -1);
        this.range = registerSetting(new Setting.NumberSetting("range", "Range", "Maximum crosshair strike distance in blocks (includes hitbox raycast fallback)", 3.0, 1.0, 6.0, 0.1, "m"));
        this.delay = registerSetting(new Setting.NumberSetting("delay", "Delay", "Additional reaction delay in milliseconds before striking target", 35.0, 0.0, 500.0, 5.0, "ms"));
        this.playersOnly = registerSetting(new Setting.BooleanSetting("players_only", "Players Only", "Only trigger attacks on Players", true));
        this.weaponsOnly = registerSetting(new Setting.BooleanSetting("weapons_only", "Weapons Only", "Only trigger automatic strikes while holding a weapon", false));
        this.onlyCriticals = registerSetting(new Setting.BooleanSetting("only_criticals", "Only Criticals", "Only strike while airborne & falling for vanilla Critical Hits", false));
        this.simulateClick = registerSetting(new Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left/Right click presses during module actions", true));
    }

    @Override
    protected void onDisable() {
        targetAcquiredAtMs = 0L;
        lastTargetId = -1;
    }

    @Override
    public String getHudMetadata() {
        return Boolean.TRUE.equals(onlyCriticals.getValue()) ? "Crit " + delay.intValue() + "ms" : delay.intValue() + "ms";
    }

    private void onTick$viperImpl() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        if (mc.field_1755 != null) return;
        class_746 player = mc.field_1724;
        if (player.method_6115()) return;
        if (Boolean.TRUE.equals(weaponsOnly.getValue()) && !WeaponUtils.isHoldingWeapon(player)) {
            lastTargetId = -1;
            return;
        }
        if (Boolean.TRUE.equals(onlyCriticals.getValue())) {
            if (player.method_24828() || player.field_6017 <= 0.0f || player.method_18798().field_1351 >= -0.04 || player.method_5799() || player.method_5771() || player.method_6128()) {
                return;
            }
        }
        if (!(mc.field_1765 instanceof class_3966 ehr)) {
            lastTargetId = -1;
            return;
        }
        class_1297 target = ehr.method_17782();
        if (!TargetUtils.matchesPlayersOnly(target, player, Boolean.TRUE.equals(playersOnly.getValue()))) {
            lastTargetId = -1;
            return;
        }
        if (TargetUtils.getClosestBoxDistance(player, target) > range.doubleValue()) {
            lastTargetId = -1;
            return;
        }
        long now = System.currentTimeMillis();
        int targetId = System.identityHashCode(target);
        if (targetId != lastTargetId) {
            lastTargetId = targetId;
            targetAcquiredAtMs = now;
            currentReactionJitterMs = ThreadLocalRandom.current().nextInt(6, 24);
        }
        if (now - targetAcquiredAtMs < delay.intValue() + currentReactionJitterMs) return;
        if (now - lastAttackMs < Math.max(65L, delay.intValue() + currentReactionJitterMs)) return;
        if (player.method_7261(0.5f) < nextCooldownThreshold) return;
        ClickSimulator.attackEntity(mc.field_1761, player, target);
        player.method_6104(class_1268.field_5808);
        lastAttackMs = now;
        currentReactionJitterMs = ThreadLocalRandom.current().nextInt(6, 24);
        nextCooldownThreshold = 0.91f + ThreadLocalRandom.current().nextFloat() * 0.085f;
    }

    public boolean isSimulateClick() { return Boolean.TRUE.equals(simulateClick.getValue()); }

    @Override
    public void onTick() {
        ClickSimulator.pushSimulate(isSimulateClick());
        try {
            onTick$viperImpl();
        } finally {
            ClickSimulator.popSimulate();
        }
    }
}
