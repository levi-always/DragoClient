package com.viper.client.modules.hacks.combat;

public final class HitWeb extends com.viper.client.modules.Module {
    private static final String OWNER_ID = "hit_web";
    private static final int ROTATION_PRIORITY = 4;
    private static final double MAX_PLACE_REACH = 4.5;
    public final com.viper.client.modules.Setting.ModeSetting mode;
    public final com.viper.client.modules.Setting.NumberSetting swapDelay;
    public final com.viper.client.modules.Setting.NumberSetting placeDelay;
    public final com.viper.client.modules.Setting.BooleanSetting switchBack;
    public final com.viper.client.modules.Setting.BooleanSetting weaponsOnly;
    public final com.viper.client.modules.Setting.BooleanSetting playersOnly;
    private com.viper.client.modules.hacks.combat.HitWeb.Stage stage;
    private int ticksRemaining;
    private int syncWaitRetries;
    private net.minecraft.class_1309 trackedTarget;
    private net.minecraft.class_3965 lockedPlacement;
    private long lastPlaceTimeMs;
    public final com.viper.client.modules.Setting.BooleanSetting simulateClick;

    private static net.minecraft.class_2350[] supportSearchOrder() {
        new net.minecraft.class_2350[6][0] = net.minecraft.class_2350.field_11033;
        new net.minecraft.class_2350[6][1] = net.minecraft.class_2350.field_11043;
        new net.minecraft.class_2350[6][2] = net.minecraft.class_2350.field_11035;
        new net.minecraft.class_2350[6][3] = net.minecraft.class_2350.field_11039;
        new net.minecraft.class_2350[6][4] = net.minecraft.class_2350.field_11034;
        new net.minecraft.class_2350[6][5] = net.minecraft.class_2350.field_11036;
        return new net.minecraft.class_2350[6];
    }

    public HitWeb() {
        super("hit_web", "Hit Web", "Places cobweb beneath enemies right after striking.", com.viper.client.modules.Category.COMBAT, "hit_web", -1);
        new java.lang.String[2][0] = "Silent";
        new java.lang.String[2][1] = "Legit";
        this.mode = ((com.viper.client.modules.Setting.ModeSetting) this.registerSetting(new com.viper.client.modules.Setting.ModeSetting("mode", "Mode", "Rotation mode when placing Cobweb under struck opponent (Silent or Legit)", "Silent", new java.lang.String[2])));
        this.swapDelay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("swap_delay", "Swap Delay", "Delay in ticks after hitting before swapping to Cobweb (1-20)", 2.0, 1.0, 20.0, 1.0, "t")));
        this.placeDelay = ((com.viper.client.modules.Setting.NumberSetting) this.registerSetting(new com.viper.client.modules.Setting.NumberSetting("place_delay", "Place Delay", "Delay in ticks after equipping Cobweb before placing it (1-20)", 2.0, 1.0, 20.0, 1.0, "t")));
        this.switchBack = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("switch_back", "Switch Back", "Restore your previous weapon slot immediately after placing Cobweb", 1)));
        this.weaponsOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("weapons_only", "Weapons Only", "Only trigger Hit Web when attacking with a weapon", 1)));
        this.playersOnly = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("players_only", "Players Only", "Only place Cobwebs under Player targets", 1)));
        this.stage = com.viper.client.modules.hacks.combat.HitWeb.Stage.IDLE;
        this.ticksRemaining = 0;
        this.syncWaitRetries = 0;
        this.trackedTarget = null;
        this.lockedPlacement = null;
        this.lastPlaceTimeMs = 0L;
        this.simulateClick = ((com.viper.client.modules.Setting.BooleanSetting) this.registerSetting(new com.viper.client.modules.Setting.BooleanSetting("simulate_click", "Simulate Click", "Simulate physical Left/Right click presses during module actions", 1)));
        return;
    }

    protected void onEnable() {
        this.resetSequence(0);
        return;
    }

    protected void onDisable() {
        this.resetSequence(1);
        return;
    }

    public String getHudMetadata() {
        return makeConcatWithConstants(((java.lang.String) this.mode.getValue()), this.swapDelay.intValue(), this.placeDelay.intValue());
    }

    private void resetSequence(boolean arg0) {
        this.stage = com.viper.client.modules.hacks.combat.HitWeb.Stage.IDLE;
        this.ticksRemaining = 0;
        this.syncWaitRetries = 0;
        this.trackedTarget = null;
        this.lockedPlacement = null;
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        // if (arg0 == 0) -> offset 61
        // if (((java.lang.Boolean) this.switchBack.getValue()).booleanValue() == 0) -> offset 61
        com.viper.client.utils.HotbarCoordinator.releaseOwner(1, 0);
        return;
    }

    private static boolean isCobwebBlock(net.minecraft.class_2680 arg0) {
        // if (arg0 == null) -> offset 11
        // if (arg0.method_26215() == 0) -> offset 13
        return false;
        v1 = arg0.method_26204();
        v2 = net.minecraft.class_7923.field_41175.method_10221(v1);
        // if (v2 == null) -> offset 45
        v3 = "";
        // if (v3.endsWith(":cobweb") != 0) -> offset 66
        // if (v3.equals("cobweb") == 0) -> offset 70
        return false;
    }

    private static boolean canPlaceCobwebInto(net.minecraft.class_2680 arg0) {
        // if (arg0 != null) -> offset 6
        return false;
        // if (com.viper.client.modules.hacks.combat.HitWeb.isCobwebBlock(arg0) == 0) -> offset 15
        return false;
        // if (arg0.method_26215() != 0) -> offset 29
        // if (arg0.method_45474() == 0) -> offset 33
        return false;
    }

    private static boolean isSolidSupportBlock(net.minecraft.class_638 arg0, net.minecraft.class_2338 arg1, net.minecraft.class_2680 arg2) {
        // if (arg2 == null) -> offset 18
        // if (arg2.method_26215() != 0) -> offset 18
        // if (arg2.method_45474() == 0) -> offset 20
        return false;
        // if (com.viper.client.modules.hacks.combat.HitWeb.isCobwebBlock(arg2) == 0) -> offset 29
        return false;
        // if (arg2.method_26220(arg0, arg1).method_1110() != 0) -> offset 45
        return false;
    }

    private static net.minecraft.class_3965 findSupportHitForCell(net.minecraft.class_638 arg0, net.minecraft.class_243 arg1, net.minecraft.class_2338 arg2) {
        v3 = arg0.method_8320(arg2);
        // if (com.viper.client.modules.hacks.combat.HitWeb.canPlaceCobwebInto(v3) != 0) -> offset 15
        return null;
        v4 = java.util.concurrent.ThreadLocalRandom.current();
        v5 = com.viper.client.modules.hacks.combat.HitWeb.supportSearchOrder();
        v6 = v5.length;
        v7 = 0;
        // if (v7 >= v6) -> offset 308
        v8 = v5[v7];
        v14 = new net.minecraft.class_2338((arg2.method_10263() + v8.method_10148()), (arg2.method_10264() + v8.method_10164()), (arg2.method_10260() + v8.method_10165()));
        v13 = arg0.method_8320(v14);
        // if (com.viper.client.modules.hacks.combat.HitWeb.isSolidSupportBlock(arg0, v14, arg0.method_8320(v14)) != 0) -> offset 107
        v15 = v8.method_10153();
        v16 = ((v4.nextDouble() - 0.5) * 0.06);
        v18 = ((v4.nextDouble() - 0.5) * 0.06);
        // if (v15.method_10148() != 0) -> offset 178
        v20 = (v16 + 0.0);
        // if (v15.method_10164() != 0) -> offset 222
        v11 = (v18 + 0.0);
        // if (v15.method_10165() != 0) -> offset 261
        v9 = (v16 + 0.0);
        v22 = new net.minecraft.class_243(v20, (((double)v14.method_10264() + 0.5) + ((double)v15.method_10164() * 0.5)), (((double)v14.method_10260() + 0.5) + ((double)v15.method_10165() * 0.5)));
        // if (Double.compare(arg1.method_1022(v22), 4.5) <= 0) -> offset 287
        return new net.minecraft.class_3965(v22, v15, v14, 0);
        v7 += 1;
        return null;
    }

    private static net.minecraft.class_3965 computeCobwebPlacement(net.minecraft.class_638 arg0, net.minecraft.class_746 arg1, net.minecraft.class_1309 arg2) {
        v5 = arg1.method_33571();
        v6 = (int)Math.floor(arg2.method_23317());
        v4 = (int)Math.floor((arg2.method_23318() + 0.06));
        v3 = (int)Math.floor(arg2.method_23321());
        v7 = new net.minecraft.class_2338(v6, (int)Math.floor((arg2.method_23318() + 0.06)), (int)Math.floor(arg2.method_23321()));
        // if (com.viper.client.modules.hacks.combat.HitWeb.isCobwebBlock(arg0.method_8320(v7)) == 0) -> offset 66
        return null;
        v8 = new net.minecraft.class_2338(v6, (v4 - 1), v3);
        // if (com.viper.client.modules.hacks.combat.HitWeb.isCobwebBlock(arg0.method_8320(v8)) == 0) -> offset 96
        return null;
        v9 = com.viper.client.modules.hacks.combat.HitWeb.findSupportHitForCell(arg0, v5, v7);
        // if (v9 == null) -> offset 114
        return v9;
        return com.viper.client.modules.hacks.combat.HitWeb.findSupportHitForCell(arg0, v5, v8);
    }

    private void drivePlacementAim(net.minecraft.class_746 arg0, net.minecraft.class_243 arg1) {
        // if (this.mode.is("Silent") == 0) -> offset 70
        com.viper.client.utils.RotationUtils.releaseCameraTarget(4);
        v3 = arg0.method_33571();
        v4 = com.viper.client.utils.RotationUtils.computeRotations(v3.field_1352, v3.field_1351, v3.field_1350, arg1.field_1352, arg1.field_1351, arg1.field_1350);
        com.viper.client.utils.RotationUtils.driveSilentRotation(arg0, v4[0], v4[1], 66.0f, 1, 4);
        com.viper.client.utils.RotationUtils.releaseSilentRotation(4);
        com.viper.client.utils.RotationUtils.driveCameraPoint(arg0, arg1.field_1352, arg1.field_1351, arg1.field_1350, 70.0f, 1, 4);
        return;
    }

    public void onAttackEntity(Object arg0) {
        // if (this.stage == com.viper.client.modules.hacks.combat.HitWeb.Stage.IDLE) -> offset 11
        return;
        v3 = System.currentTimeMillis();
        // if (Double.compare((v3 - this.lastPlaceTimeMs), 220L) >= 0) -> offset 29
        return;
        v5 = net.minecraft.class_310.method_1551();
        // if (v5 == null) -> offset 63
        // if (v5.field_1724 == null) -> offset 63
        // if (v5.field_1687 == null) -> offset 63
        // if (v5.field_1755 == null) -> offset 64
        return;
        // if ((arg0 instanceof net.minecraft.class_1309) == 0) -> offset 92
        v2 = ((net.minecraft.class_1309) arg0);
        // if (((net.minecraft.class_1309) arg0).method_5805() == 0) -> offset 92
        // if (v2 != v5.field_1724) -> offset 93
        return;
        // if (((java.lang.Boolean) this.playersOnly.getValue()).booleanValue() == 0) -> offset 117
        // if ((v2 instanceof net.minecraft.class_1657) != 0) -> offset 117
        return;
        v6 = v5.field_1724;
        // if (((java.lang.Boolean) this.weaponsOnly.getValue()).booleanValue() == 0) -> offset 194
        v7 = com.viper.client.utils.WeaponUtils.isHoldingWeapon(v6);
        v8 = com.viper.client.utils.HotbarCoordinator.getSavedUserSlot();
        // if (v7 != 0) -> offset 188
        // if (v8 < 0) -> offset 188
        // if (v8 >= 9) -> offset 188
        v9 = v6.method_31548().method_5438(v8);
        v7 = com.viper.client.utils.WeaponUtils.isWeaponStack(v9);
        // if (v7 != 0) -> offset 194
        return;
        // if (com.viper.client.utils.WeaponUtils.findCobwebHotbarSlot(v6) >= 0) -> offset 203
        return;
        v7 = com.viper.client.modules.hacks.combat.HitWeb.computeCobwebPlacement(v5.field_1687, v6, v2);
        // if (v7 != null) -> offset 222
        return;
        this.trackedTarget = v2;
        this.lockedPlacement = v7;
        this.stage = com.viper.client.modules.hacks.combat.HitWeb.Stage.WAIT_SWAP;
        this.ticksRemaining = Math.max(1, this.swapDelay.intValue());
        this.syncWaitRetries = 3;
        return;
    }

    private void onTick$viperImpl() {
        // if (this.stage != com.viper.client.modules.hacks.combat.HitWeb.Stage.IDLE) -> offset 11
        return;
        v2 = net.minecraft.class_310.method_1551();
        // if (v2 == null) -> offset 47
        // if (v2.field_1724 == null) -> offset 47
        // if (v2.field_1687 == null) -> offset 47
        // if (v2.field_1761 == null) -> offset 47
        // if (v2.field_1755 == null) -> offset 53
        this.resetSequence(1);
        return;
        v3 = v2.field_1724;
        v4 = com.viper.client.utils.WeaponUtils.findCobwebHotbarSlot(v3);
        // if (v4 >= 0) -> offset 75
        this.resetSequence(1);
        return;
        // if (this.trackedTarget == null) -> offset 114
        // if (this.trackedTarget.method_5805() == 0) -> offset 114
        v1 = com.viper.client.modules.hacks.combat.HitWeb.computeCobwebPlacement(v2.field_1687, v3, this.trackedTarget);
        // if (com.viper.client.modules.hacks.combat.HitWeb.computeCobwebPlacement(v2.field_1687, v3, this.trackedTarget) == null) -> offset 114
        this.lockedPlacement = v1;
        // if (this.lockedPlacement == null) -> offset 142
        // if (Double.compare(v3.method_33571().method_1022(this.lockedPlacement.method_17784()), 4.65) <= 0) -> offset 148
        this.resetSequence(1);
        return;
        this.drivePlacementAim(v3, this.lockedPlacement.method_17784());
        // if (this.stage != com.viper.client.modules.hacks.combat.HitWeb.Stage.WAIT_SWAP) -> offset 247
        this.ticksRemaining = (this.ticksRemaining - 1);
        // if (this.ticksRemaining <= 0) -> offset 188
        return;
        // if (com.viper.client.utils.HotbarCoordinator.beginSequence("hit_web", 35, v4, ((java.lang.Boolean) this.switchBack.getValue()).booleanValue()) != 0) -> offset 219
        this.resetSequence(0);
        return;
        this.stage = com.viper.client.modules.hacks.combat.HitWeb.Stage.WAIT_PLACE;
        this.ticksRemaining = Math.max(1, this.placeDelay.intValue());
        this.syncWaitRetries = 3;
        return;
        // if (this.stage != com.viper.client.modules.hacks.combat.HitWeb.Stage.WAIT_PLACE) -> offset 488
        // if ("hit_web".equals(com.viper.client.utils.HotbarCoordinator.getActiveOwner()) != 0) -> offset 274
        this.resetSequence(0);
        return;
        // if (v3.method_31548().method_67532() == v4) -> offset 309
        com.viper.client.utils.HotbarCoordinator.beginSequence("hit_web", 35, v4, ((java.lang.Boolean) this.switchBack.getValue()).booleanValue());
        this.ticksRemaining = (this.ticksRemaining - 1);
        // if (this.ticksRemaining <= 0) -> offset 327
        return;
        v7 = v3.method_33571();
        v8 = this.lockedPlacement.method_17784();
        v9 = com.viper.client.utils.RotationUtils.computeRotations(v7.field_1352, v7.field_1351, v7.field_1350, v8.field_1352, v8.field_1351, v8.field_1350);
        v10 = com.viper.client.utils.RotationUtils.getConfirmedServerYaw(v3);
        v6 = com.viper.client.utils.RotationUtils.getConfirmedServerPitch(v3);
        // if (Double.compare(com.viper.client.utils.RotationUtils.getAngleDifference(v10, com.viper.client.utils.RotationUtils.getConfirmedServerPitch(v3), v9[0], v9[1]), 18.0f) <= 0) -> offset 428
        // if (this.syncWaitRetries <= 0) -> offset 428
        this.syncWaitRetries = (this.syncWaitRetries - 1);
        return;
        // if (com.viper.client.utils.WeaponUtils.isCobweb(v3.method_6047()) == 0) -> offset 483
        v5 = com.viper.client.utils.ClickSimulator.interactBlock(v2.field_1761, v3, net.minecraft.class_1268.field_5808, this.lockedPlacement);
        // if (com.viper.client.utils.ClickSimulator.interactBlock(v2.field_1761, v3, net.minecraft.class_1268.field_5808, this.lockedPlacement) == null) -> offset 483
        // if (v5.method_23665() == 0) -> offset 483
        v3.method_6104(net.minecraft.class_1268.field_5808);
        this.lastPlaceTimeMs = System.currentTimeMillis();
        this.resetSequence(1);
        return;
    }

    public boolean isSimulateClick() {
        return ((java.lang.Boolean) this.simulateClick.getValue()).booleanValue();
    }

    public void onTick() {
        com.viper.client.utils.ClickSimulator.pushSimulate(this.isSimulateClick());
        this.onTick$viperImpl();
        com.viper.client.utils.ClickSimulator.popSimulate();
        v1 = /*?*/;
        com.viper.client.utils.ClickSimulator.popSimulate();
        throw v1;
        return;
    }

     enum Stage {
        IDLE, WAIT_SWAP, WAIT_PLACE;


    }

}
