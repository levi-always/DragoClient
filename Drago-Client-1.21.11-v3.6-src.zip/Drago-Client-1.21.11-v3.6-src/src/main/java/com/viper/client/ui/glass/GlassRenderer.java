package com.viper.client.ui.glass;

public final class GlassRenderer {
    public static final net.minecraft.class_2960 GLASS_ATLAS;
    private static final int ATLAS_SIZE = 1024;

    private GlassRenderer() {
        super();
        return;
    }

    public static void drawGlassPanel(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, float arg7) {
        // if (arg0 == null) -> offset 13
        // if (arg3 <= 0) -> offset 13
        // if (arg4 > 0) -> offset 14
        return;
        v8 = ((float)255 / 255.0f);
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, (arg1 - 10), (arg2 - 8), (arg3 + 20), (arg4 + 20), 516, 4, 496, 248, 84, 16, com.viper.client.utils.AnimUtils.withAlpha(-1275068416, v8));
        // if (Double.compare(v8, 0.009999999776482582f) <= 0) -> offset 102
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 4, 4, 248, 248, 48, 10, arg5);
        // if (Double.compare(arg7, 0.019999999552965164f) <= 0) -> offset 143
        // if (arg3 <= 28) -> offset 143
        arg0.method_25294((arg1 + 12), (arg2 + 1), ((arg1 + arg3) - 12), (arg2 + 2), com.viper.client.utils.AnimUtils.withAlpha(1023410175, arg7));
        // if (255 <= 2) -> offset 181
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 260, 4, 248, 248, 48, 10, arg6);
        return;
    }

    public static void drawGlassCard(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, float arg8) {
        // if (arg0 == null) -> offset 13
        // if (arg3 <= 0) -> offset 13
        // if (arg4 > 0) -> offset 14
        return;
        // if (Double.compare(arg8, 0.019999999552965164f) <= 0) -> offset 75
        // if (255 <= 2) -> offset 75
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, (arg1 - 5), (arg2 - 5), (arg3 + 10), (arg4 + 10), 516, 4, 496, 248, 84, 12, com.viper.client.utils.AnimUtils.withAlpha(arg7, arg8));
        // if (255 <= 2) -> offset 111
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 4, 4, 248, 248, 48, 8, arg5);
        // if (arg3 <= 24) -> offset 163
        v9 = Math.min(24, ((float)255 / 220.0f));
        arg0.method_25294((arg1 + 10), (arg2 + 1), ((arg1 + arg3) - 10), (arg2 + 2), com.viper.client.utils.AnimUtils.withAlpha(687865855, v9));
        // if (255 <= 2) -> offset 201
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 260, 4, 248, 248, 48, 8, arg6);
        return;
    }

    public static void drawCornerGlows(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, float arg8) {
        // if (arg0 == null) -> offset 18
        // if (arg7 <= 2) -> offset 18
        // if (Double.compare(arg8, 0.009999999776482582f) > 0) -> offset 19
        return;
        v9 = Math.max(6, Math.min(arg7, Math.min(((arg3 / 2) + 4), ((arg4 / 2) + 4))));
        v10 = Math.max(2, (v9 / 4));
        v11 = com.viper.client.utils.AnimUtils.withAlpha(arg5, arg8);
        v12 = com.viper.client.utils.AnimUtils.withAlpha(arg6, arg8);
        v13 = com.viper.client.utils.AnimUtils.withAlpha(com.viper.client.utils.AnimUtils.lerpColor(arg5, arg6, 0.5f), (arg8 * 0.8500000238418579f));
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, (arg1 - v10), (arg2 - v10), v9, v9, 4, 520, 240, 240, v11);
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, (((arg1 + arg3) - v9) + v10), (arg2 - v10), v9, v9, 252, 520, 240, 240, v13);
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, (arg1 - v10), (((arg2 + arg4) - v9) + v10), v9, v9, 500, 520, 240, 240, v13);
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, (((arg1 + arg3) - v9) + v10), (((arg2 + arg4) - v9) + v10), v9, v9, 748, 520, 240, 240, v12);
        return;
    }

    public static void drawRoundedRect(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5) {
        // if (arg0 == null) -> offset 26
        // if (arg3 <= 0) -> offset 26
        // if (arg4 <= 0) -> offset 26
        // if (255 > 2) -> offset 27
        return;
        v6 = Math.min(8, Math.min((arg3 / 2), (arg4 / 2)));
        // if (arg4 <= 14) -> offset 57
        // if (arg3 > 22) -> offset 85
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 4, 260, 248, 248, 64, v6, arg5);
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 4, 4, 248, 248, 48, v6, arg5);
        return;
    }

    public static void drawRoundedBorder(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5) {
        // if (arg0 == null) -> offset 26
        // if (arg3 <= 0) -> offset 26
        // if (arg4 <= 0) -> offset 26
        // if (255 > 2) -> offset 27
        return;
        v6 = Math.min(8, Math.min((arg3 / 2), (arg4 / 2)));
        // if (arg4 <= 14) -> offset 57
        // if (arg3 > 22) -> offset 87
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 260, 260, 248, 248, 64, v6, arg5);
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 260, 4, 248, 248, 48, v6, arg5);
        return;
    }

    public static void drawGlassPill(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6) {
        // if (arg0 == null) -> offset 13
        // if (arg3 <= 0) -> offset 13
        // if (arg4 > 0) -> offset 14
        return;
        v7 = Math.min(10, Math.min((arg3 / 2), (arg4 / 2)));
        // if (255 <= 2) -> offset 69
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 4, 260, 248, 248, 64, v7, arg5);
        // if (255 <= 2) -> offset 109
        com.viper.client.ui.glass.GlassRenderer.drawNineSlice(arg0, arg1, arg2, arg3, arg4, 260, 260, 248, 248, 64, v7, arg6);
        return;
    }

    public static void drawSmoothCircle(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4) {
        // if (arg0 == null) -> offset 21
        // if (arg3 <= 0) -> offset 21
        // if (255 > 2) -> offset 22
        return;
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, arg1, arg2, arg3, arg3, 520, 264, 240, 240, arg4);
        return;
    }

    public static void drawSmoothGlow(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4) {
        // if (arg0 == null) -> offset 21
        // if (arg3 <= 0) -> offset 21
        // if (255 > 2) -> offset 22
        return;
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, (arg1 - arg3), (arg2 - arg3), (arg3 * 2), (arg3 * 2), 768, 264, 240, 240, arg4);
        return;
    }

    public static void drawNineSlice(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, int arg10, int arg11) {
        // if (arg3 <= 0) -> offset 22
        // if (arg4 <= 0) -> offset 22
        // if (255 > 2) -> offset 23
        return;
        v12 = Math.max(0, Math.min(arg10, Math.min((arg3 / 2), (arg4 / 2))));
        // if (v12 != 0) -> offset 85
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, arg1, arg2, arg3, arg4, (arg5 + arg9), (arg6 + arg9), (arg7 - (arg9 * 2)), (arg8 - (arg9 * 2)), arg11);
        return;
        v13 = (arg3 - (v12 * 2));
        v14 = (arg4 - (v12 * 2));
        v15 = (arg7 - (arg9 * 2));
        v16 = (arg8 - (arg9 * 2));
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, arg1, arg2, v12, v12, arg5, arg6, arg9, arg9, arg11);
        // if (v13 <= 0) -> offset 171
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, (arg1 + v12), arg2, v13, v12, (arg5 + arg9), arg6, v15, arg9, arg11);
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, ((arg1 + arg3) - v12), arg2, v12, v12, ((arg5 + arg7) - arg9), arg6, arg9, arg9, arg11);
        // if (v14 <= 0) -> offset 307
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, arg1, (arg2 + v12), v12, v14, arg5, (arg6 + arg9), arg9, v16, arg11);
        // if (v13 <= 0) -> offset 270
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, (arg1 + v12), (arg2 + v12), v13, v14, (arg5 + arg9), (arg6 + arg9), v15, v16, arg11);
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, ((arg1 + arg3) - v12), (arg2 + v12), v12, v14, ((arg5 + arg7) - arg9), (arg6 + arg9), arg9, v16, arg11);
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, arg1, ((arg2 + arg4) - v12), v12, v12, arg5, ((arg6 + arg8) - arg9), arg9, arg9, arg11);
        // if (v13 <= 0) -> offset 382
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, (arg1 + v12), ((arg2 + arg4) - v12), v13, v12, (arg5 + arg9), ((arg6 + arg8) - arg9), v15, arg9, arg11);
        com.viper.client.ui.glass.GlassRenderer.blitAtlas(arg0, ((arg1 + arg3) - v12), ((arg2 + arg4) - v12), v12, v12, ((arg5 + arg7) - arg9), ((arg6 + arg8) - arg9), arg9, arg9, arg11);
        return;
    }

    private static void blitAtlas(net.minecraft.class_332 arg0, int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9) {
        // if (arg3 <= 0) -> offset 22
        // if (arg4 <= 0) -> offset 22
        // if (255 > 2) -> offset 23
        return;
        arg0.method_25293(net.minecraft.class_10799.field_56883, com.viper.client.ui.glass.GlassRenderer.GLASS_ATLAS, arg1, arg2, (float)arg5, (float)arg6, arg3, arg4, arg7, arg8, 1024, 1024, arg9);
        return;
    }

}
